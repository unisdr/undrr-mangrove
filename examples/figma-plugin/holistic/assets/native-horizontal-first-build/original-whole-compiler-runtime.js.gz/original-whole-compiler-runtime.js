async function mgRun(){const mgAssertExperimentTarget = function assertExperimentTarget(figmaApi, expectedKey, protectedKeys) {
  const actualKey = figmaApi.fileKey;
  if (
    typeof actualKey !== 'string' ||
    protectedKeys.includes(actualKey) ||
    actualKey !== expectedKey
  )
    throw new Error('Experiment target refused before mutation.');
};
const mgAssertExperimentOperationTarget = () => mgAssertExperimentTarget(figma, "uEoniqMXfDJ0vcGrnPKWp3", ["Zgjq8pQ0FMT8d6dhw9M5bt","wOTLILmiXUI3uzG2BdPUxB","JF29fJWi9LzUHeOObGL3nB"]);
mgAssertExperimentOperationTarget();
const MG_SHARED_ONLY = true;
/* global MG_SHARED_ONLY */
// Shared token identities work in both the desktop plugin and the connector.
// Store public token IDs only; shared plugin data is readable by other plugins.
const MG_IDENTITY_NAMESPACE = 'orgundrrmangrove';

function mgReadIdentity(asset, key) {
  const shared = asset.getSharedPluginData
    ? asset.getSharedPluginData(MG_IDENTITY_NAMESPACE, key)
    : '';
  const privateValue =
    typeof MG_SHARED_ONLY !== 'undefined' && MG_SHARED_ONLY
      ? ''
      : asset.getPluginData(key);
  if (shared && privateValue && shared !== privateValue) {
    throw new Error(`Conflicting Mangrove identities on ${asset.id} (${key}).`);
  }
  return shared || privateValue;
}

function mgWriteIdentity(asset, key, value) {
  asset.setSharedPluginData(MG_IDENTITY_NAMESPACE, key, value);
}

;
/* global mgReadIdentity, mgWriteIdentity, figma, MG_CONNECTOR_TEXT_CASE, MG_CONNECTOR_NATIVE_COLLECTIONS, mgAssertExperimentOperationTarget, mgNativeCollectionsSourceCapability, mgNativeCollectionsPreflight, MG_CONNECTOR_NATIVE_TEXT_INSTANCES, mgNativeCollectionsCollectionLedger */
/** Shared variable/style importer for maintenance and occasional construction. */
const ID_KEY = 'mgId';
const STYLE_ID_KEY = 'mgStyleId';
const MG_TEXT_CASE_ENABLED =
  typeof MG_CONNECTOR_TEXT_CASE === 'undefined' || MG_CONNECTOR_TEXT_CASE;

const MG_NATIVE_COLLECTION_IMPORT_ENABLED =
  typeof MG_CONNECTOR_NATIVE_COLLECTIONS === 'undefined' ||
  MG_CONNECTOR_NATIVE_COLLECTIONS;

const MG_NATIVE_TEXT_IMPORT_ENABLED =
  typeof MG_CONNECTOR_NATIVE_TEXT_INSTANCES === 'undefined' ||
  MG_CONNECTOR_NATIVE_TEXT_INSTANCES;

async function nativeCollectionImportSnapshot(fence) {
  fence();
  const collections = await figma.variables.getLocalVariableCollectionsAsync();
  fence();
  const variables = await figma.variables.getLocalVariablesAsync();
  fence();
  return { collections, variables };
}

async function importNativeCollections(
  doc,
  selectedModeIds,
  prune,
  textStyles,
  effects
) {
  if (typeof mgAssertExperimentOperationTarget !== 'function')
    throw new Error(
      'Native collections require a trusted experiment target guard'
    );
  const textProfile =
    MG_NATIVE_TEXT_IMPORT_ENABLED && doc.nativeCollections?.version === 2;
  const operationPageId = textProfile ? figma.currentPage.id : null;
  const fence = textProfile
    ? () => {
        mgAssertExperimentOperationTarget();
        if (figma.currentPage.id !== operationPageId)
          throw new Error('Native text collection import page changed');
      }
    : mgAssertExperimentOperationTarget;
  fence();
  if (
    prune ||
    textStyles !== undefined ||
    effects === false ||
    !Array.isArray(selectedModeIds) ||
    selectedModeIds.length !== doc.modes?.length ||
    new Set(selectedModeIds).size !== selectedModeIds.length ||
    doc.modes.some(mode => !selectedModeIds.includes(mode.id))
  )
    throw new Error(
      'Native collections require the whole document, all modes and prune off'
    );
  validateMangroveImport(doc, selectedModeIds);
  mgNativeCollectionsSourceCapability(doc);
  // Private operation copy freezes the validated source across awaited inventory reads.
  const source = JSON.parse(JSON.stringify(doc));
  const plan = mgNativeCollectionsSourceCapability(source);
  const identity = {
    readCollection: asset => {
      const raw = mgReadIdentity(asset, 'mgNativeCollectionPlan');
      if (!raw) return null;
      try {
        return JSON.parse(raw);
      } catch {
        throw new Error('Invalid native collection ownership JSON');
      }
    },
    readVariable: asset => mgReadIdentity(asset, ID_KEY),
  };
  let state = mgNativeCollectionsPreflight(
    plan,
    await nativeCollectionImportSnapshot(fence),
    identity
  );
  // The v2 variable phase checks declared source fonts before any COL/VAR write.
  // Invalid old native font literals remain repairable; builder checks actual native fonts later.
  const sourceFontsLoaded = [];
  if (MG_NATIVE_TEXT_IMPORT_ENABLED && textProfile) {
    for (const font of plan.sourceFonts) {
      fence();
      await figma.loadFontAsync(font);
      fence();
      sourceFontsLoaded.push(font);
    }
  }
  // Refresh the complete inventory immediately before the first permanent write.
  state = mgNativeCollectionsPreflight(
    plan,
    await nativeCollectionImportSnapshot(fence),
    identity
  );
  const counts = { created: 0, updated: 0, removed: 0, values: 0 };
  const createdCollectionIds = [],
    updatedCollectionIds = [],
    createdModeIds = [],
    createdVariableIds = [],
    updatedVariableIds = [],
    errors = [];
  let completed = false;
  try {
    for (const spec of plan.collectionById.values()) {
      fence();
      let collection = state.collectionsBySourceId.get(spec.id);
      const modeMap = state.modeIdsByCollectionId.get(spec.id);
      if (!collection) {
        collection = figma.variables.createVariableCollection(spec.name);
        createdCollectionIds.push(collection.id);
        state.collectionsBySourceId.set(spec.id, collection);
        fence();
        mgWriteIdentity(
          collection,
          'mgNativeCollectionPlan',
          JSON.stringify(
            MG_NATIVE_TEXT_IMPORT_ENABLED && textProfile
              ? mgNativeCollectionsCollectionLedger(plan, spec.id)
              : { version: 1, planId: plan.planId, collectionId: spec.id }
          )
        );
        const first = source.modes[0];
        fence();
        collection.renameMode(collection.defaultModeId, first.name);
        modeMap.set(first.id, collection.defaultModeId);
        createdModeIds.push({
          collectionId: collection.id,
          sourceModeId: first.id,
          modeId: collection.defaultModeId,
        });
      } else updatedCollectionIds.push(collection.id);
      for (const mode of source.modes) {
        if (modeMap.has(mode.id)) continue;
        fence();
        const modeId = collection.addMode(mode.name);
        modeMap.set(mode.id, modeId);
        createdModeIds.push({
          collectionId: collection.id,
          sourceModeId: mode.id,
          modeId,
        });
      }
    }
    // All native UUIDs exist before any cross-collection alias is assigned.
    for (const spec of source.variables) {
      fence();
      let variable = state.variablesBySourceId.get(spec.id);
      if (!variable) {
        variable = figma.variables.createVariable(
          spec.name,
          state.collectionsBySourceId.get(plan.ownerBySourceId.get(spec.id)),
          spec.type
        );
        createdVariableIds.push(variable.id);
        counts.created++;
        state.variablesBySourceId.set(spec.id, variable);
      } else {
        updatedVariableIds.push(variable.id);
        counts.updated++;
      }
      fence();
      mgWriteIdentity(variable, ID_KEY, spec.id);
      variable.description = spec.description || '';
      variable.hiddenFromPublishing = Boolean(spec.hiddenFromPublishing);
      if (spec.scopes !== undefined) variable.scopes = spec.scopes;
      if (spec.codeSyntax?.WEB)
        variable.setVariableCodeSyntax('WEB', spec.codeSyntax.WEB);
      else if (variable.codeSyntax?.WEB)
        variable.removeVariableCodeSyntax('WEB');
    }
    for (const spec of source.variables) {
      const variable = state.variablesBySourceId.get(spec.id);
      const modeMap = state.modeIdsByCollectionId.get(
        plan.ownerBySourceId.get(spec.id)
      );
      for (const mode of source.modes) {
        fence();
        const value = spec.values[mode.id];
        variable.setValueForMode(
          modeMap.get(mode.id),
          value && typeof value === 'object' && 'alias' in value
            ? figma.variables.createVariableAlias(
                state.variablesBySourceId.get(
                  plan.sourceByName.get(value.alias).id
                )
              )
            : value
        );
        counts.values++;
      }
    }
    state = mgNativeCollectionsPreflight(
      plan,
      await nativeCollectionImportSnapshot(fence),
      identity
    );
    completed = true;
  } catch (error) {
    errors.push(errorMessage(error));
  }
  const primary = state.collectionsBySourceId.get(plan.primary);
  return {
    collection: primary?.name || source.collection,
    collectionId: primary?.id || null,
    modeIds: Object.fromEntries(state.modeIdsByCollectionId.get(plan.primary)),
    modes: completed ? source.modes.map(mode => mode.name) : [],
    requestedModes: source.modes.map(mode => mode.name),
    counts,
    createdVariableIds,
    updatedVariableIds,
    removedVariableIds: [],
    styles: null,
    stale: [],
    skipped: source.skipped || [],
    errors,
    nativeCollections: {
      version: MG_NATIVE_TEXT_IMPORT_ENABLED && textProfile ? 2 : 1,
      ...(MG_NATIVE_TEXT_IMPORT_ENABLED && textProfile
        ? { profile: plan.profile, sourceFontsLoaded }
        : {}),
      planId: plan.planId,
      completed,
      createdCollectionIds,
      updatedCollectionIds,
      createdModeIds,
      collectionIds: Object.fromEntries(
        [...state.collectionsBySourceId].map(([id, c]) => [id, c.id])
      ),
      modeIdsByCollectionId: Object.fromEntries(
        [...state.modeIdsByCollectionId].map(([id, modes]) => [
          id,
          Object.fromEntries(modes),
        ])
      ),
      partialAssetIds: completed
        ? []
        : [...createdCollectionIds, ...createdVariableIds],
    },
  };
}

// Figma API rejections can be strings rather than Error instances.
function errorMessage(error) {
  return error && error.message ? error.message : String(error);
}

function validateMangroveParagraphIndent(doc, selectedTextIds) { if (!MG_CONNECTOR_PARAGRAPH_INDENT) return;
  for (const spec of doc.styles?.text || []) {
    if (selectedTextIds && !selectedTextIds.includes(spec.id)) continue;
    for (const [mode, value] of Object.entries(spec.values || {})) {
      if (
        value.paragraphIndent !== undefined &&
        (!Number.isFinite(value.paragraphIndent) || value.paragraphIndent < 0)
      )
        throw new Error(
          `Import preflight: ${spec.name} [${mode}]: invalid paragraph indent`
        );
    }
  }
}

function validateMangroveTextCase(doc, selectedTextIds) {
  if (!MG_TEXT_CASE_ENABLED) return;
  const modes = (doc.modes || []).map(mode => mode.id).sort();
  for (const spec of doc.styles?.text || []) {
    if (selectedTextIds && !selectedTextIds.includes(spec.id)) continue;
    const values = Object.values(spec.values || {});
    if (!values.some(value => value?.textCase !== undefined)) continue;
    if (
      !modes.length ||
      Object.keys(spec.values || {})
        .sort()
        .join(',') !== modes.join(',') ||
      values.some(value => !['ORIGINAL', 'UPPER'].includes(value?.textCase)) ||
      new Set(values.map(value => value.textCase)).size !== 1
    )
      throw new Error(
        `Import preflight: ${spec.name}: text case needs identical ORIGINAL or UPPER values in every source mode`
      );
  }
}

function validateMangroveNativeTextCase(style, spec) {
  if (!MG_TEXT_CASE_ENABLED) return;
  if (
    !style ||
    !Object.values(spec.values || {}).some(
      value => value?.textCase !== undefined
    )
  )
    return;
  if (
    ![
      'ORIGINAL',
      'UPPER',
      'LOWER',
      'TITLE',
      'SMALL_CAPS',
      'SMALL_CAPS_FORCED',
    ].includes(style.textCase)
  )
    throw new Error(
      `Import preflight: ${spec.name}: native text case field is unavailable or malformed`
    );
}

function validateMangroveImport(doc, selectedModeIds, selectedTextIds) {
  const fail = message => {
    throw new Error(`Import preflight: ${message}`);
  };
  const nonempty = value =>
    typeof value === 'string' && value.trim().length > 0;
  function unique(entries, kind) {
    if (!Array.isArray(entries)) fail(`${kind} must be an array`);
    const ids = new Set();
    const names = new Set();
    for (const entry of entries) {
      if (!entry || !nonempty(entry.id) || !nonempty(entry.name))
        fail(`${kind} needs nonempty IDs and names`);
      if (ids.has(entry.id)) fail(`Duplicate ${kind} ID ${entry.id}`);
      if (names.has(entry.name)) fail(`Duplicate ${kind} name ${entry.name}`);
      ids.add(entry.id);
      names.add(entry.name);
    }
    return ids;
  }
  if (!doc || !nonempty(doc.collection)) fail('collection must have a name');
  const modes = unique(doc.modes, 'mode');
  unique(doc.variables, 'variable');
  if (!Array.isArray(selectedModeIds) || !selectedModeIds.length)
    fail('Select at least one brand.');
  if (new Set(selectedModeIds).size !== selectedModeIds.length)
    fail('Duplicate selected brands');
  for (const id of selectedModeIds)
    if (!modes.has(id)) fail(`Unknown selected brand ${id}`);
  const byName = new Map(
    doc.variables.map(variable => [variable.name, variable])
  );
  function checkValues(spec, kind) {
    if (
      !spec.values ||
      typeof spec.values !== 'object' ||
      Array.isArray(spec.values)
    )
      fail(`${kind} ${spec.name} needs mode values`);
    for (const id of Object.keys(spec.values))
      if (!modes.has(id)) fail(`${kind} ${spec.name} has unknown mode ${id}`);
  }
  function checkBinding(name, type, owner) {
    const target = byName.get(name);
    if (!target) fail(`${owner}: missing binding variable ${name}`);
    if (target.type !== type)
      fail(`${owner}: binding ${name} needs ${type}, got ${target.type}`);
  }
  for (const spec of doc.variables) {
    if (!['COLOR', 'FLOAT', 'STRING', 'BOOLEAN'].includes(spec.type))
      fail(`${spec.name}: unsupported variable type ${spec.type}`);
    checkValues(spec, 'Variable');
    for (const [mode, value] of Object.entries(spec.values)) {
      if (value && typeof value === 'object' && 'alias' in value) {
        const target = byName.get(value.alias);
        if (!target)
          fail(`${spec.name} [${mode}]: alias target ${value.alias} missing`);
        if (target.type !== spec.type)
          fail(
            `${spec.name} [${mode}]: alias target ${value.alias} has wrong type`
          );
        if (!target.values || target.values[mode] === undefined)
          fail(
            `${spec.name} [${mode}]: alias target ${value.alias} has no value`
          );
      } else if (
        (spec.type === 'FLOAT' && !Number.isFinite(value)) ||
        (spec.type === 'STRING' && typeof value !== 'string') ||
        (spec.type === 'BOOLEAN' && typeof value !== 'boolean') ||
        (spec.type === 'COLOR' &&
          (!value ||
            !['r', 'g', 'b', 'a'].every(
              field =>
                Number.isFinite(value[field]) &&
                value[field] >= 0 &&
                value[field] <= 1
            )))
      )
        fail(`${spec.name} [${mode}]: invalid ${spec.type} value`);
    }
  }
  for (const mode of modes) {
    const visiting = new Set();
    const visited = new Set();
    function visit(spec) {
      if (visited.has(spec.name)) return;
      if (visiting.has(spec.name))
        fail(`Alias cycle at ${spec.name} [${mode}]`);
      visiting.add(spec.name);
      const value = spec.values[mode];
      if (value && typeof value === 'object' && 'alias' in value)
        visit(byName.get(value.alias));
      visiting.delete(spec.name);
      visited.add(spec.name);
    }
    for (const spec of doc.variables) visit(spec);
  }
  const text = doc.styles ? doc.styles.text || [] : [];
  const effects = doc.styles ? doc.styles.effect || [] : [];
  if (!Array.isArray(text) || !Array.isArray(effects))
    fail('Style definitions must be arrays');
  unique([...text, ...effects], 'style');
  validateMangroveParagraphIndent(doc);
  if (MG_TEXT_CASE_ENABLED) validateMangroveTextCase(doc);
  if (selectedTextIds !== undefined) {
    if (
      !Array.isArray(selectedTextIds) ||
      new Set(selectedTextIds).size !== selectedTextIds.length
    )
      fail('Text style selection must contain unique IDs');
    const textIds = new Set(text.map(spec => spec.id));
    for (const id of selectedTextIds)
      if (!textIds.has(id)) fail(`Unknown selected text style ${id}`);
  }
  for (const spec of text) {
    checkValues(spec, 'Text style');
    checkBinding(
      spec.bindings && spec.bindings.fontFamily,
      'STRING',
      spec.name
    );
    checkBinding(spec.bindings && spec.bindings.fontSize, 'FLOAT', spec.name);
    for (const [mode, value] of Object.entries(spec.values)) {
      if (
        !value ||
        !value.fontName ||
        !nonempty(value.fontName.family) ||
        !nonempty(value.fontName.style) ||
        !Number.isFinite(value.fontSize) ||
        value.fontSize <= 0
      )
        fail(`${spec.name} [${mode}]: invalid text style value`);
      if (
        value.textDecoration !== undefined &&
        !['NONE', 'UNDERLINE'].includes(value.textDecoration)
      )
        fail(`${spec.name} [${mode}]: invalid text style decoration`);
      if (
        value.textWrapStyle !== undefined &&
        !['AUTO', 'BALANCE', 'PRETTY'].includes(value.textWrapStyle)
      )
        fail(`${spec.name} [${mode}]: invalid text style wrapping`);
      if (MG_CONNECTOR_LETTER_SPACING && value.letterSpacing !== undefined) {
        const spacing = value.letterSpacing;
        if (
          !spacing ||
          !['PIXELS', 'PERCENT'].includes(spacing.unit) ||
          !Number.isFinite(spacing.value) ||
          Object.keys(spacing).some(key => !['unit', 'value'].includes(key))
        )
          fail(`${spec.name} [${mode}]: invalid text style letter spacing`);
      }
      // Source metadata only: native TextStyle has no decoration offset API.
      // Component TextNodes apply this value after their shared style.
      if (value.textDecorationOffset !== undefined) {
        const offset = value.textDecorationOffset;
        if (
          !offset ||
          !['AUTO', 'PIXELS', 'PERCENT'].includes(offset.unit) ||
          (offset.unit === 'AUTO'
            ? Object.keys(offset).some(key => key !== 'unit')
            : !Number.isFinite(offset.value) ||
              Object.keys(offset).some(key => !['unit', 'value'].includes(key)))
        )
          fail(`${spec.name} [${mode}]: invalid decoration offset metadata`);
      }
    }
  }
  for (const spec of effects) {
    checkValues(spec, 'Effect style');
    for (const [mode, entries] of Object.entries(spec.values)) {
      if (!Array.isArray(entries))
        fail(`${spec.name} [${mode}]: effects must be an array`);
      for (const entry of entries) {
        if (!entry || !entry.effect)
          fail(`${spec.name} [${mode}]: effect definition missing`);
        for (const [field, name] of Object.entries(entry.bindings || {})) {
          if (
            !['color', 'radius', 'spread', 'offsetX', 'offsetY'].includes(field)
          )
            fail(`${spec.name}: unsupported effect binding ${field}`);
          checkBinding(name, field === 'color' ? 'COLOR' : 'FLOAT', spec.name);
        }
      }
    }
  }
}

function mangroveAssetIndex(assets, key) {
  const index = { byId: new Map(), byName: new Map(), key };
  for (const asset of assets) rememberMangroveAsset(index, asset);
  return index;
}

function rememberMangroveAsset(index, asset) {
  for (const map of [index.byId, index.byName]) {
    for (const [key, entries] of map) {
      const remaining = entries.filter(entry => entry.id !== asset.id);
      if (remaining.length) map.set(key, remaining);
      else map.delete(key);
    }
  }
  for (const [map, key] of [
    [index.byId, mgReadIdentity(asset, index.key)],
    [index.byName, asset.name],
  ]) {
    if (key) map.set(key, [...(map.get(key) || []), asset]);
  }
}

function findMangroveAsset(index, spec, kind, type) {
  const ids = index.byId.get(spec.id) || [];
  const names = index.byName.get(spec.name) || [];
  if (ids.length > 1 || names.length > 1)
    throw new Error(`Import preflight: ambiguous ${kind} ${spec.name}`);
  const asset = ids[0] || names[0];
  if (!asset) return null;
  if (ids[0] && names[0] && ids[0].id !== names[0].id)
    throw new Error(
      `Import preflight: ${kind} name ${spec.name} conflicts with its existing ID`
    );
  const owner = mgReadIdentity(asset, index.key);
  if (owner && owner !== spec.id)
    throw new Error(
      `Import preflight: ${kind} ${spec.name} belongs to ${owner}`
    );
  const actualType = kind === 'variable' ? asset.resolvedType : asset.type;
  if (actualType !== type)
    throw new Error(
      `Import preflight: ${kind} ${spec.name} changed type from ${actualType} to ${type}; migration required. Existing ID ${asset.id} was preserved.`
    );
  return asset;
}

async function preflightMangroveAssets(doc, textStyles, importEffects) {
  const collections = (
    await figma.variables.getLocalVariableCollectionsAsync()
  ).filter(collection => collection.name === doc.collection);
  if (collections.length > 1)
    throw new Error(`Import preflight: ambiguous collection ${doc.collection}`);
  const collection = collections[0];
  if (
    collection &&
    new Set(collection.modes.map(mode => mode.name)).size !==
      collection.modes.length
  )
    throw new Error(
      `Import preflight: duplicate modes in collection ${doc.collection}`
    );
  const local = (await figma.variables.getLocalVariablesAsync()).filter(
    variable => collection && variable.variableCollectionId === collection.id
  );
  const variables = mangroveAssetIndex(local, ID_KEY);
  for (const spec of doc.variables)
    findMangroveAsset(variables, spec, 'variable', spec.type);
  if (!doc.styles) return;
  const selectedText = (doc.styles.text || []).filter(spec =>
    textStyles ? textStyles.includes(spec.id) : spec.recommended
  );
  const selectedEffects = importEffects ? doc.styles.effect || [] : [];
  if (!selectedText.length && !selectedEffects.length) return;
  const styles = mangroveAssetIndex(
    [
      ...(await figma.getLocalTextStylesAsync()),
      ...(await figma.getLocalEffectStylesAsync()),
    ],
    STYLE_ID_KEY
  );
  for (const [kind, specs, type] of [
    ['text style', selectedText, 'TEXT'],
    ['effect style', selectedEffects, 'EFFECT'],
  ]) {
    for (const spec of specs) {
      const style = findMangroveAsset(styles, spec, kind, type);
      if (MG_TEXT_CASE_ENABLED && type === 'TEXT')
        validateMangroveNativeTextCase(style, spec);
    }
  }
}

async function findOrCreateCollection(name, firstModeName) {
  const collections = await figma.variables.getLocalVariableCollectionsAsync();
  if (collections.filter(collection => collection.name === name).length > 1)
    throw new Error(`Import preflight: ambiguous collection ${name}`);
  const existing = collections.find(c => c.name === name);
  if (existing) return { collection: existing, created: false };
  const collection = figma.variables.createVariableCollection(name);
  collection.renameMode(collection.modes[0].modeId, firstModeName);
  return { collection, created: true };
}

function ensureModes(collection, modes, created) {
  const modeIds = Object.create(null);
  const errors = [];

  // Brand switcher: one brand into a one-mode collection overwrites that
  // mode, so a file limited to 1 mode can still be re-themed by re-importing
  // with another brand. Bindings survive because variables are reused.
  if (modes.length === 1 && collection.modes.length === 1) {
    const only = collection.modes[0];
    if (only.name !== modes[0].name) {
      collection.renameMode(only.modeId, modes[0].name);
    }
    modeIds[modes[0].id] = only.modeId;
    return { modeIds, errors };
  }

  modes.forEach((mode, index) => {
    const match = collection.modes.find(m => m.name === mode.name);
    if (match) {
      modeIds[mode.id] = match.modeId;
      return;
    }
    if (created && index === 0) {
      modeIds[mode.id] = collection.modes[0].modeId;
      return;
    }
    try {
      modeIds[mode.id] = collection.addMode(mode.name);
    } catch (error) {
      errors.push(
        `Could not add mode "${mode.name}" (${collection.modes.length} ` +
          `mode(s) exist). The file's plan limits modes: a file in Drafts ` +
          `or a Starter team allows only 1. Move it into a project in the ` +
          `Professional team and import again, or tick a single brand to ` +
          `use this file as a brand switcher. ` +
          errorMessage(error)
      );
    }
  });
  return { modeIds, errors };
}

async function importStyles(
  doc,
  variables,
  modeId,
  selectedTextIds,
  importEffects
) {
  // Direct component builds call importStyles without importVariables.
  // Validate every selected authored mode before any style is created or updated.
  validateMangroveParagraphIndent(doc, selectedTextIds);
  if (MG_TEXT_CASE_ENABLED) validateMangroveTextCase(doc, selectedTextIds);
  const counts = {
    text: { created: 0, updated: 0, failed: 0 },
    effect: { created: 0, updated: 0, failed: 0 },
  };
  const errors = [];
  const missingFonts = new Set();
  const createdStyleIds = [];
  const updatedStyleIds = [];
  const touchedStyleIds = new Set();
  const removedStyleIds = [];
  const retainedPartialStyleIds = [];
  const trackedIds = () => ({
    createdStyleIds,
    updatedStyleIds,
    touchedStyleIds: [...touchedStyleIds],
    removedStyleIds,
    retainedPartialStyleIds,
  });
  if (!doc.styles) return { counts, errors, missingFonts: [], ...trackedIds() };
  const textSpecs = (doc.styles.text || []).filter(spec =>
    selectedTextIds ? selectedTextIds.includes(spec.id) : spec.recommended
  );
  const effectSpecs = importEffects ? doc.styles.effect || [] : [];
  // TextStyle.textCase is a documented writable field. Check every existing
  // opted-in style before any style write, including a later selected style.
  if (MG_TEXT_CASE_ENABLED) {
    const caseSpecs = textSpecs.filter(spec =>
      Object.values(spec.values).some(value => value.textCase !== undefined)
    );
    if (caseSpecs.length) {
      const caseIndex = mangroveAssetIndex(
        await figma.getLocalTextStylesAsync(),
        STYLE_ID_KEY
      );
      for (const spec of caseSpecs) {
        const style = findMangroveAsset(caseIndex, spec, 'text style', 'TEXT');
        validateMangroveNativeTextCase(style, spec);
      }
    }
  }
  const fontLoads = new Map();
  let fonts = [];
  if (textSpecs.length) {
    try {
      fonts = await figma.listAvailableFontsAsync();
    } catch (error) {
      errors.push(`Could not list fonts: ${errorMessage(error)}`);
    }
  }
  async function loadFont(font) {
    const key = `${font.family} ${font.style}`;
    if (!fontLoads.has(key)) {
      fontLoads.set(
        key,
        (async () => {
          if (
            !fonts.some(
              entry =>
                entry.fontName.family === font.family &&
                entry.fontName.style === font.style
            )
          ) {
            missingFonts.add(key);
            throw new Error(
              `Font "${key}" is not available. Install or enable it in Figma, then re-import.`
            );
          }
          try {
            await figma.loadFontAsync(font);
          } catch (error) {
            missingFonts.add(key);
            throw new Error(
              `Could not load font "${key}": ${errorMessage(error)}`
            );
          }
        })()
      );
    }
    await fontLoads.get(key);
  }
  function binding(name, type) {
    const variable = variables.get(name);
    if (!variable || variable.resolvedType !== type) {
      throw new Error(`Missing ${type} style variable ${name}`);
    }
    return variable;
  }
  for (const [kind, specs, getLocal, create] of [
    [
      'text',
      textSpecs,
      () => figma.getLocalTextStylesAsync(),
      () => figma.createTextStyle(),
    ],
    [
      'effect',
      effectSpecs,
      () => figma.getLocalEffectStylesAsync(),
      () => figma.createEffectStyle(),
    ],
  ]) {
    if (!specs.length) continue;
    let local;
    try {
      local = await getLocal();
    } catch (error) {
      counts[kind].failed += specs.length;
      errors.push(`Could not list ${kind} styles: ${errorMessage(error)}`);
      continue;
    }
    const index = mangroveAssetIndex(local, STYLE_ID_KEY);
    for (const spec of specs) {
      let style = findMangroveAsset(
        index,
        spec,
        `${kind} style`,
        kind === 'text' ? 'TEXT' : 'EFFECT'
      );
      const existing = Boolean(style);
      try {
        const value = spec.values[modeId];
        if (!value) throw new Error(`No style value for brand ${modeId}`);
        let family;
        let size;
        let effects;
        if (kind === 'text') {
          family = binding(spec.bindings.fontFamily, 'STRING');
          size = binding(spec.bindings.fontSize, 'FLOAT');
          // Load every family the style can resolve to before binding it.
          for (const entry of Object.values(spec.values))
            await loadFont(entry.fontName);
          if (style) await loadFont(style.fontName);
        } else {
          effects = value.map(entry => {
            let effect = entry.effect;
            for (const [field, name] of Object.entries(entry.bindings || {})) {
              effect = figma.variables.setBoundVariableForEffect(
                effect,
                field,
                binding(name, field === 'color' ? 'COLOR' : 'FLOAT')
              );
            }
            return effect;
          });
        }
        style = style || create();
        // Record retained writes even when a later setter fails. Font and
        // binding preflight above does not touch the existing style.
        touchedStyleIds.add(style.id);
        if (kind === 'text') {
          style.fontName = value.fontName;
          style.fontSize = value.fontSize;
          style.lineHeight = value.lineHeight;
          style.letterSpacing = (MG_CONNECTOR_LETTER_SPACING && value.letterSpacing) || {
            unit: 'PIXELS',
            value: 0,
          };
          style.setBoundVariable('fontFamily', family);
          style.setBoundVariable('fontSize', size);
          style.textDecoration = value.textDecoration || 'NONE';
          style.textWrapStyle = value.textWrapStyle || 'AUTO';
          style.paragraphIndent = value.paragraphIndent ?? 0;
          if (MG_TEXT_CASE_ENABLED && value.textCase !== undefined)
            style.textCase = value.textCase;
        } else {
          style.effects = effects;
        }
        style.name = spec.name;
        style.description = spec.description || '';
        mgWriteIdentity(style, STYLE_ID_KEY, spec.id);
        rememberMangroveAsset(index, style);
        counts[kind][existing ? 'updated' : 'created'] += 1;
        (existing ? updatedStyleIds : createdStyleIds).push(style.id);
      } catch (error) {
        // Do not leave a new, partly configured style after a failed import.
        if (style && !existing) {
          try {
            style.remove();
            removedStyleIds.push(style.id);
            touchedStyleIds.delete(style.id);
          } catch (removeError) {
            retainedPartialStyleIds.push(style.id);
            errors.push(
              `${spec.name}: partial style ${style.id} could not be removed: ${errorMessage(removeError)}`
            );
          }
        }
        counts[kind].failed += 1;
        errors.push(`${spec.name}: ${errorMessage(error)}`);
      }
    }
  }
  return { counts, errors, missingFonts: [...missingFonts], ...trackedIds() };
}

async function importVariables(
  doc,
  selectedModeIds,
  prune,
  textStyles,
  effects
) {mgAssertExperimentOperationTarget();
  if (
    MG_NATIVE_COLLECTION_IMPORT_ENABLED &&
    doc?.nativeCollections !== undefined
  )
    return importNativeCollections(
      doc,
      selectedModeIds,
      prune,
      textStyles,
      effects
    );
  validateMangroveImport(doc, selectedModeIds, textStyles);
  await preflightMangroveAssets(doc, textStyles, effects !== false);
  const modes = doc.modes.filter(m => selectedModeIds.includes(m.id));
  if (modes.length === 0) throw new Error('Select at least one brand.');

  const { collection, created } = await findOrCreateCollection(
    doc.collection,
    modes[0].name
  );
  const { modeIds, errors } = ensureModes(collection, modes, created);

  const local = (await figma.variables.getLocalVariablesAsync()).filter(
    v => v.variableCollectionId === collection.id
  );
  const index = mangroveAssetIndex(local, ID_KEY);

  const counts = { created: 0, updated: 0, removed: 0, values: 0 };
  const createdVariableIds = [];
  const updatedVariableIds = [];
  const removedVariableIds = [];
  const resolvedByName = new Map();
  const wanted = new Set();

  // Pass 1: every variable exists with the right name, type and metadata,
  // so pass 2 can alias to any of them regardless of order.
  for (const spec of doc.variables) {
    wanted.add(spec.id);
    let variable = findMangroveAsset(index, spec, 'variable', spec.type);
    if (variable) {
      counts.updated += 1;
      updatedVariableIds.push(variable.id);
      if (variable.name !== spec.name) variable.name = spec.name;
    } else {
      variable = figma.variables.createVariable(
        spec.name,
        collection,
        spec.type
      );
      counts.created += 1;
      createdVariableIds.push(variable.id);
    }
    try {
      mgWriteIdentity(variable, ID_KEY, spec.id);
      variable.description = spec.description || '';
      variable.hiddenFromPublishing = Boolean(spec.hiddenFromPublishing);
      variable.scopes = spec.scopes;
      if (spec.codeSyntax && spec.codeSyntax.WEB) {
        variable.setVariableCodeSyntax('WEB', spec.codeSyntax.WEB);
      } else if (variable.codeSyntax && variable.codeSyntax.WEB) {
        // Figma throws if asked to remove a code syntax that is not set.
        variable.removeVariableCodeSyntax('WEB');
      }
    } catch (error) {
      errors.push(`${spec.name}: ${errorMessage(error)}`);
    }
    rememberMangroveAsset(index, variable);
    resolvedByName.set(spec.name, variable);
  }

  // Pass 2: values per mode.
  for (const spec of doc.variables) {
    const variable = resolvedByName.get(spec.name);
    for (const mode of modes) {
      const modeId = modeIds[mode.id];
      const value = spec.values[mode.id];
      if (!modeId || value === undefined) continue;
      try {
        if (value && typeof value === 'object' && 'alias' in value) {
          const target = resolvedByName.get(value.alias);
          if (!target) throw new Error(`alias target ${value.alias} missing`);
          variable.setValueForMode(
            modeId,
            figma.variables.createVariableAlias(target)
          );
        } else {
          variable.setValueForMode(modeId, value);
        }
        counts.values += 1;
      } catch (error) {
        errors.push(`${spec.name} [${mode.name}]: ${errorMessage(error)}`);
      }
    }
  }

  const stale = local.filter(v => {
    const id = mgReadIdentity(v, ID_KEY);
    return id && !wanted.has(id) && !v.removed;
  });
  if (prune) {
    stale.forEach(v => {
      v.remove();
      removedVariableIds.push(v.id);
    });
    counts.removed = stale.length;
  }

  const importedMode = modes.find(mode => modeIds[mode.id]);
  const styles = importedMode
    ? await importStyles(
        doc,
        resolvedByName,
        importedMode.id,
        textStyles,
        effects !== false
      )
    : null;
  if (styles) errors.push(...styles.errors);

  return {
    collection: collection.name,
    collectionId: collection.id,
    modeIds,
    modes: modes.filter(mode => modeIds[mode.id]).map(mode => mode.name),
    requestedModes: modes.map(mode => mode.name),
    counts,
    createdVariableIds,
    updatedVariableIds,
    removedVariableIds,
    styles,
    stale: prune ? [] : stale.map(v => v.name),
    skipped: doc.skipped || [],
    errors,
  };
}

;
/** Rich TEXT capability with transaction preflight and native ownership guards. */
/* global module, MG_CONNECTOR_RICH_DTO_VALIDATION, MG_CONNECTOR_RICH_ALPHA, MG_CONNECTOR_RICH_DECORATION_OFFSET */
'use strict';
const mgRichText = (() => {
  const checkDTO =
    typeof MG_CONNECTOR_RICH_DTO_VALIDATION === 'undefined' ||
    MG_CONNECTOR_RICH_DTO_VALIDATION;
  const alphaEnabled =
    typeof MG_CONNECTOR_RICH_ALPHA === 'undefined' || MG_CONNECTOR_RICH_ALPHA;
  const alphaValid = value =>
    Number.isFinite(value) && value >= 0 && value <= 1;
  const alphaMatches = (actual, expected) =>
    actual === expected || actual === Math.fround(expected);
  const plans = new WeakMap();
  const fields = [
    'textStyleId',
    'fontName',
    'fills',
    'hyperlink',
    'textDecoration',
  ];
  const copy = value => JSON.parse(JSON.stringify(value));
  const fail = message => {
    throw new Error(`Rich text: ${message}`);
  };
  const object = value =>
    value && typeof value === 'object' && !Array.isArray(value);
  const boundary = (text, offset) =>
    !(
      offset > 0 &&
      offset < text.length &&
      /[\uD800-\uDBFF]/.test(text[offset - 1]) &&
      /[\uDC00-\uDFFF]/.test(text[offset])
    );
  const fontValid = font =>
    object(font) &&
    typeof font.family === 'string' &&
    font.family.length &&
    typeof font.style === 'string' &&
    font.style.length &&
    Object.keys(font).every(key =>
      ['family', 'style', 'variationSettings'].includes(key)
    ) &&
    (font.variationSettings === undefined ||
      (object(font.variationSettings) &&
        Object.keys(font.variationSettings).length > 0 &&
        Object.entries(font.variationSettings).every(
          ([axis, value]) =>
            /^[\x20-\x7E]{4}$/.test(axis) && Number.isFinite(value)
        )));
  function normalizedFont(font) {
    if (!fontValid(font)) fail('unsupported run font.');
    return {
      family: font.family,
      style: font.style,
      ...(font.variationSettings === undefined
        ? {}
        : {
            variationSettings: Object.fromEntries(
              Object.entries(font.variationSettings).sort(([a], [b]) =>
                a.localeCompare(b)
              )
            ),
          }),
    };
  }
  function resolveFontInput(font, inventory, nativeAxes) {
    const input = normalizedFont(font);
    if (!Array.isArray(inventory))
      fail('native named-font inventory is missing.');
    const matches = inventory
      .filter(
        entry =>
          entry?.fontName?.family === input.family &&
          entry.fontName.style === input.style
      )
      .map(entry => normalizedFont(entry.fontName));
    if (
      !matches.length ||
      new Set(matches.map(value => JSON.stringify(value))).size !== 1
    )
      fail('native named-font inventory is missing or ambiguous.');
    const native = matches[0];
    if (nativeAxes !== undefined) {
      if (
        nativeAxes !== null &&
        (!Array.isArray(nativeAxes) ||
          !nativeAxes.length ||
          new Set(nativeAxes).size !== nativeAxes.length ||
          nativeAxes.some(
            axis => typeof axis !== 'string' || !/^[\x20-\x7E]{4}$/.test(axis)
          ))
      )
        fail('native font axis inventory is invalid.');
      const expected = nativeAxes === null ? [] : [...nativeAxes].sort();
      if (
        JSON.stringify(Object.keys(native.variationSettings ?? {}).sort()) !==
        JSON.stringify(expected)
      )
        fail(
          'native named-instance default axes are unresolved; separate supported probe required.'
        );
    }
    if (
      input.variationSettings &&
      Object.entries(input.variationSettings).some(
        ([axis, value]) => native.variationSettings?.[axis] !== value
      )
    )
      fail('source font axes disagree with native named-instance defaults.');
    return native;
  }
  function dependencyStamp(ctx, items) {
    return JSON.stringify(
      items.map(item => {
        const style = ctx.resolveStyle(item.styleKey),
          color = ctx.resolveColor(item.colorKey);
        // Native API objects need explicit field reads; JSON enumeration is not a contract.
        return [
          style?.key,
          style?.pending ?? false,
          style?.style?.type,
          style?.style?.id,
          style?.style?.fontName ? normalizedFont(style.style.fontName) : null,
          color?.key,
          color?.variable?.id,
          color?.variable?.resolvedType,
          color?.values,
        ];
      })
    );
  }
  function signature(segment) {
    const fills = segment.fills;
    if (
      !Array.isArray(fills) ||
      fills.length !== 1 ||
      fills[0].type !== 'SOLID' ||
      (alphaEnabled ? !alphaValid(fills[0].opacity) : fills[0].opacity !== 1) ||
      fills[0].visible === false ||
      fills[0].boundVariables?.color?.type !== 'VARIABLE_ALIAS' ||
      typeof fills[0].boundVariables.color.id !== 'string'
    )
      fail('unowned or unsupported run paint.');
    if (!fontValid(segment.fontName)) fail('unsupported run font.');
    if (typeof segment.textStyleId !== 'string' || !segment.textStyleId)
      fail('run style identity is missing.');
    const link = segment.hyperlink ?? null;
    if (
      link !== null &&
      (!object(link) || link.type !== 'URL' || typeof link.value !== 'string')
    )
      fail('unsupported native hyperlink.');
    const result = [
      segment.textStyleId,
      segment.fontName.family,
      segment.fontName.style,
      fills[0].boundVariables.color.id,
      segment.textDecoration,
      link?.value ?? null,
      normalizedFont(segment.fontName).variationSettings ?? null,
    ];
    // Preserve legacy opaque ownership stamps exactly.
    if (alphaEnabled && Math.fround(fills[0].opacity) !== 1)
      result.push(Math.fround(fills[0].opacity));
    return JSON.stringify(result);
  }
  function segments(node) {
    if (!node.characters.length) return [];
    const source = node.getStyledTextSegments(
      false && captureOffsets
        ? [...fields, 'textDecorationOffset']
        : fields
    );
    const result = [];
    let end = 0;
    for (const item of source) {
      if (
        item.start !== end ||
        !Number.isInteger(item.end) ||
        item.end <= item.start ||
        item.end > node.characters.length ||
        !boundary(node.characters, item.start) ||
        !boundary(node.characters, item.end)
      )
        fail('native segment boundaries are invalid.');
      if (
        false &&
        captureOffsets &&
        item.textDecoration === 'UNDERLINE' &&
        !nativeOffsetValid(item.textDecorationOffset)
      )
        fail('unsupported native run underline-offset precision.');
      const sig = signature(item);
      const previous = result[result.length - 1];
      if (previous?.signature === sig) previous.end = item.end;
      else
        result.push({
          start: item.start,
          end: item.end,
          signature: sig,
          fontName: normalizedFont(item.fontName),
        });
      end = item.end;
    }
    if (end !== node.characters.length)
      fail('native segments must cover all current characters.');
    return result;
  }
  function snapshot(node, ctx) {
    if (!node) return null;
    if (node.type !== 'TEXT' || node.removed || node.hasMissingFont)
      fail('existing target must be a live TEXT with available fonts.');
    if (node.componentPropertyReferences?.characters)
      fail('whole-string component property resets are unsupported.');
    return {
      id: node.id,
      characters: node.characters,
      ledger: ctx.readState(node),
      segments: segments(node),
    };
  }
  function decodeLedger(value) {
    let ledger;
    try {
      ledger = typeof value === 'string' ? JSON.parse(value) : null;
    } catch {
      fail('invalid ownership ledger.');
    }
    if (
      !object(ledger) ||
      ledger.version !== 1 ||
      typeof ledger.identity !== 'string' ||
      typeof ledger.sourceCharacters !== 'string' ||
      !Array.isArray(ledger.runs) ||
      !ledger.runs.length ||
      ledger.runs.some(
        run =>
          !object(run) ||
          typeof run.id !== 'string' ||
          typeof run.signature !== 'string'
      )
    )
      fail('missing or invalid ownership ledger; explicit migration required.');
    return ledger;
  }
  async function prepare(spec, ctx, node = null) {
    if (
      !object(ctx) ||
      !ctx.figma ||
      typeof ctx.resolveStyle !== 'function' ||
      typeof ctx.resolveColor !== 'function' ||
      typeof ctx.readState !== 'function' ||
      typeof ctx.writeState !== 'function' ||
      typeof ctx.figma.loadFontAsync !== 'function' ||
      typeof ctx.figma.variables?.setBoundVariableForPaint !== 'function' ||
      !Array.isArray(ctx.modeIds) ||
      !ctx.modeIds.length ||
      new Set(ctx.modeIds).size !== ctx.modeIds.length ||
      ctx.modeIds.some(id => typeof id !== 'string' || !id)
    )
      fail('incomplete capability context.');
    if (
      checkDTO &&
      (!object(spec) ||
        Object.keys(spec).some(
          key =>
            ![
              'id',
              'key',
              'name',
              'type',
              'characters',
              'textRuns',
              'layout',
              'textWrap',
              'textAlign',
              'position',
              'absolute',
            ].includes(key)
        ) ||
        spec.type !== 'TEXT' ||
        typeof spec.id !== 'string' ||
        !spec.id ||
        typeof spec.characters !== 'string' ||
        !spec.characters.length ||
        spec.characters.length > 32768 ||
        !Array.isArray(spec.textRuns) ||
        !spec.textRuns.length ||
        spec.textRuns.length > 128 ||
        spec.textProperty !== undefined ||
        spec.textStyle !== undefined ||
        spec.fill !== undefined ||
        spec.textStyleApplication !== undefined ||
        spec.textDecoration !== undefined ||
        spec.textDecorationOffset !== undefined)
    )
      fail(
        'requires bounded TEXT characters, stable id and textRuns without whole-node style/property overrides.'
      );
    const captureOffsets =
      false &&
      spec.textRuns.some(run => run.textDecorationOffset !== undefined);
    const ids = new Set();
    const prepared = [];
    let end = 0;
    for (const run of spec.textRuns) {
      if (
        checkDTO &&
        (!object(run) ||
          Object.keys(run).some(
            key =>
              ![
                'id',
                'start',
                'end',
                'textStyle',
                'fill',
                'hyperlink',
                'textDecoration',
                ...(false ? ['textDecorationOffset'] : []),
              ].includes(key)
          ) ||
          typeof run.id !== 'string' ||
          !run.id ||
          ids.has(run.id) ||
          run.start !== end ||
          !Number.isInteger(run.start) ||
          !Number.isInteger(run.end) ||
          run.end <= run.start ||
          run.end > spec.characters.length ||
          !boundary(spec.characters, run.start) ||
          !boundary(spec.characters, run.end) ||
          typeof run.textStyle !== 'string' ||
          !run.textStyle ||
          typeof run.fill !== 'string' ||
          !run.fill)
      )
        fail(
          'runs need unique ids, complete non-overlapping UTF-16 ranges and named style/paint roles.'
        );
      ids.add(run.id);
      end = run.end;
      const decoration = run.textDecoration ?? 'NONE';
      if (checkDTO && !['NONE', 'UNDERLINE'].includes(decoration))
        fail('unsupported run decoration.');
      if (
        false &&
        captureOffsets &&
        ((decoration === 'UNDERLINE' &&
          !offsetValid(run.textDecorationOffset)) ||
          (decoration !== 'UNDERLINE' &&
            run.textDecorationOffset !== undefined))
      )
        fail(
          'offset-scoped text requires an explicit valid offset on every UNDERLINE run only.'
        );
      const link = run.hyperlink ?? null;
      if (
        checkDTO &&
        link !== null &&
        (!object(link) ||
          Object.keys(link).some(key => !['type', 'value'].includes(key)) ||
          link.type !== 'URL' ||
          typeof link.value !== 'string' ||
          !/^https:\/\/[^\s]+$/.test(link.value))
      )
        fail('links require explicit HTTPS URL targets.');
      const style = ctx.resolveStyle(run.textStyle);
      if (
        !object(style) ||
        style.key !== run.textStyle ||
        style.style?.type !== 'TEXT' ||
        ((typeof style.style.id !== 'string' || !style.style.id) &&
          !(
            ctx.deferredStyles === true &&
            style.pending === true &&
            style.style.id === null
          )) ||
        !fontValid(style.style.fontName)
      )
        fail(`missing or wrong text style ${run.textStyle}.`);
      const color = ctx.resolveColor(run.fill);
      if (
        !object(color) ||
        color.key !== run.fill ||
        color.variable?.resolvedType !== 'COLOR' ||
        typeof color.variable.id !== 'string' ||
        !color.variable.id ||
        !object(color.values)
      )
        fail(`missing or wrong COLOR role ${run.fill}.`);
      for (const mode of ctx.modeIds) {
        const value = color.values[mode];
        if (
          !object(value) ||
          !['r', 'g', 'b'].every(
            key =>
              Number.isFinite(value[key]) && value[key] >= 0 && value[key] <= 1
          ) ||
          (alphaEnabled
            ? value.a !== undefined && !alphaValid(value.a)
            : value.a !== undefined && value.a !== 1)
        )
          fail(`unresolved or invalid COLOR ${run.fill} in mode ${mode}.`);
      }
      const value = color.values[ctx.modeIds[0]];
      const paint = ctx.figma.variables.setBoundVariableForPaint(
        {
          type: 'SOLID',
          color: { r: value.r, g: value.g, b: value.b },
          opacity: alphaEnabled ? (value.a ?? 1) : 1,
          visible: true,
        },
        'color',
        color.variable
      );
      if (
        alphaEnabled &&
        (paint?.type !== 'SOLID' ||
          !alphaValid(paint.opacity) ||
          !alphaMatches(paint.opacity, value.a ?? 1) ||
          paint.boundVariables?.color?.type !== 'VARIABLE_ALIAS' ||
          paint.boundVariables.color.id !== color.variable.id)
      )
        fail('unsupported native bound alpha paint result.');
      const item = {
        id: run.id,
        start: run.start,
        end: run.end,
        textStyleId: style.style.id,
        fontName: normalizedFont(style.style.fontName),
        fills: [paint],
        hyperlink: copy(link),
        textDecoration: decoration,
      };
      if (false && captureOffsets && decoration === 'UNDERLINE')
        item.textDecorationOffset = copy(run.textDecorationOffset);
      item.styleKey = run.textStyle;
      item.colorKey = run.fill;
      item.signature = item.textStyleId
        ? signature(item)
        : JSON.stringify(
            alphaEnabled && Math.fround(paint.opacity) !== 1
              ? [
                  'pending-source-style',
                  run.textStyle,
                  item.fontName,
                  run.fill,
                  decoration,
                  link,
                  Math.fround(paint.opacity),
                ]
              : [
                  'pending-source-style',
                  run.textStyle,
                  item.fontName,
                  run.fill,
                  decoration,
                  link,
                ]
          );
      if (
        false &&
        captureOffsets &&
        decoration === 'UNDERLINE' &&
        !item.textStyleId
      )
        item.signature = JSON.stringify([
          ...JSON.parse(item.signature),
          { textDecorationOffset: normalizedOffset(item.textDecorationOffset) },
        ]);
      if (prepared[prepared.length - 1]?.signature === item.signature)
        fail('adjacent indistinguishable runs must be one authored run.');
      prepared.push(item);
    }
    if (checkDTO && end !== spec.characters.length)
      fail('runs must cover all characters.');
    if (
      false &&
      captureOffsets &&
      node &&
      !['setRangeTextDecorationOffset', 'getRangeTextDecorationOffset'].every(
        name => typeof node[name] === 'function'
      )
    )
      fail('native ranged underline-offset API is unavailable.');
    const before = snapshot(node, ctx);
    if (
      false &&
      !captureOffsets &&
      before?.ledger &&
      decodeLedger(before.ledger).runs.some(run => {
        let values;
        try {
          values = JSON.parse(run.signature);
        } catch {
          fail('invalid ownership signature.');
        }
        if (!Array.isArray(values)) fail('invalid ownership signature.');
        return values.some(
          value => object(value) && value.textDecorationOffset !== undefined
        );
      })
    )
      fail(
        'owned ranged underline offsets require explicit source declaration.'
      );
    let ranges = prepared.map(item => ({ start: item.start, end: item.end }));
    let preserve = false;
    if (before) {
      const ledger = decodeLedger(before.ledger);
      if (
        ledger.identity !== spec.id ||
        ledger.runs.length !== before.segments.length ||
        ledger.runs.length !== prepared.length ||
        ledger.runs.some(
          (run, index) =>
            run.id !== prepared[index].id ||
            run.signature !== before.segments[index].signature
        )
      )
        fail(
          'run ownership changed, merged or removed; explicit migration required.'
        );
      preserve = before.characters !== ledger.sourceCharacters;
      if (preserve)
        ranges = before.segments.map(item => ({
          start: item.start,
          end: item.end,
        }));
    }
    const fonts = new Map();
    for (const item of [...prepared, ...(before?.segments || [])])
      fonts.set(JSON.stringify(item.fontName), item.fontName);
    // Fresh TEXT starts in the host's default font; integration must supply it.
    if (!before) {
      if (!fontValid(ctx.creationFont))
        fail('fresh target requires the host creation font.');
      fonts.set(JSON.stringify(ctx.creationFont), ctx.creationFont);
    }
    const currentDependencies = () => dependencyStamp(ctx, prepared);
    const dependencies = currentDependencies();
    for (const font of fonts.values()) await ctx.figma.loadFontAsync(font);
    if (currentDependencies() !== dependencies)
      fail('dependencies changed during font preflight.');
    if (
      JSON.stringify(snapshot(node, ctx)) !==
      JSON.stringify(before)
    )
      fail('target changed during preflight.');
    const handle = Object.freeze({
      identity: spec.id,
      runCount: prepared.length,
      preservedEdits: preserve,
    });
    plans.set(handle, {
      ctx,
      node,
      before,
      prepared,
      ranges,
      preserve,
      characters: spec.characters,
      identity: spec.id,
      dependencyStamp: currentDependencies,
      dependencies,
      finalized: ctx.deferredStyles !== true,
    });
    return handle;
  }
  async function apply(handle, node) {
    const plan = plans.get(handle);
    if (!plan) fail('unknown or consumed preflight plan.');
    const {
      ctx,
      before,
      prepared,
      ranges,
      preserve,
      characters,
      identity,
    } = plan;
    if (!plan.finalized)
      fail('deferred style plan must be finalized after import.');
    if (plan.dependencyStamp() !== plan.dependencies)
      fail('dependencies changed after preflight.');
    if (
      !node ||
      node.type !== 'TEXT' ||
      node.removed ||
      node.componentPropertyReferences?.characters ||
      ![
        'setRangeTextStyleIdAsync',
        'setRangeFills',
        'setRangeTextDecoration',
        'setRangeHyperlink',
      ].every(name => typeof node[name] === 'function')
    )
      fail('invalid target or unsafe component property.');
    if (
      false &&
      captureOffsets &&
      !['setRangeTextDecorationOffset', 'getRangeTextDecorationOffset'].every(
        name => typeof node[name] === 'function'
      )
    )
      fail('native ranged underline-offset API is unavailable.');
    if (before) {
      if (
        node !== plan.node ||
        JSON.stringify(snapshot(node, ctx)) !==
          JSON.stringify(before)
      )
        fail('target changed after preflight.');
    } else if (
      node.characters !== '' ||
      ctx.readState(node) ||
      !fontValid(node.fontName) ||
      JSON.stringify(normalizedFont(node.fontName)) !==
        JSON.stringify(normalizedFont(ctx.creationFont))
    )
      fail(
        'fresh target must be an empty unowned TEXT in the preloaded creation font.'
      );
    plans.delete(handle);
    if (!preserve && node.characters !== characters)
      node.characters = characters;
    for (let index = 0; index < prepared.length; index++) {
      const item = prepared[index],
        range = ranges[index];
      await node.setRangeTextStyleIdAsync(
        range.start,
        range.end,
        item.textStyleId
      );
      node.setRangeFills(range.start, range.end, item.fills);
      node.setRangeTextDecoration(range.start, range.end, item.textDecoration);
      node.setRangeHyperlink(range.start, range.end, item.hyperlink);
      if (
        false &&
        captureOffsets &&
        item.textDecoration === 'UNDERLINE'
      ) {
        node.setRangeTextDecorationOffset(
          range.start,
          range.end,
          item.textDecorationOffset
        );
        const observed = node.getRangeTextDecorationOffset(
          range.start,
          range.end
        );
        if (!offsetMatches(observed, item.textDecorationOffset))
          fail('ranged underline-offset native readback disagrees.');
      }
    }
    ctx.writeState(
      node,
      JSON.stringify({
        version: 1,
        identity,
        sourceCharacters: preserve
          ? JSON.parse(before.ledger).sourceCharacters
          : characters,
        runs: prepared.map(item => ({
          id: item.id,
          signature: item.signature,
        })),
      })
    );
    return {
      nodeId: node.id,
      runCount: prepared.length,
      preservedEdits: preserve,
    };
  }
  function finalize(handle, ctx) {
    const plan = plans.get(handle);
    if (!plan || plan.finalized || plan.ctx.deferredStyles !== true)
      fail('unknown or non-deferred plan.');
    if (plan.dependencyStamp() !== plan.dependencies)
      fail('projected dependencies changed during import.');
    if (
      typeof ctx.resolveStyle !== 'function' ||
      typeof ctx.resolveColor !== 'function' ||
      ctx.figma !== plan.ctx.figma ||
      ctx.readState !== plan.ctx.readState ||
      ctx.writeState !== plan.ctx.writeState ||
      JSON.stringify(ctx.modeIds) !== JSON.stringify(plan.ctx.modeIds) ||
      JSON.stringify(normalizedFont(ctx.creationFont)) !==
        JSON.stringify(normalizedFont(plan.ctx.creationFont))
    )
      fail('finalization context changed.');
    const current = snapshot(plan.node, ctx);
    if (plan.before) {
      const before = plan.before;
      if (
        current.id !== before.id ||
        current.characters !== before.characters ||
        current.ledger !== before.ledger ||
        current.segments.length !== before.segments.length
      )
        fail('target changed during style import.');
      for (let i = 0; i < current.segments.length; i++) {
        const now = current.segments[i],
          prior = before.segments[i],
          desired = plan.prepared[i];
        const expected = JSON.parse(prior.signature);
        expected[1] = desired.fontName.family;
        expected[2] = desired.fontName.style;
        expected[6] = desired.fontName.variationSettings ?? null;
        if (
          now.start !== prior.start ||
          now.end !== prior.end ||
          (now.signature !== prior.signature &&
            now.signature !== JSON.stringify(expected))
        )
          fail('unexpected range change during style import.');
      }
    }
    const native = plan.prepared.map(item => {
      const style = ctx.resolveStyle(item.styleKey),
        color = ctx.resolveColor(item.colorKey);
      if (
        !style ||
        style.key !== item.styleKey ||
        style.pending ||
        style.style?.type !== 'TEXT' ||
        typeof style.style.id !== 'string' ||
        !style.style.id ||
        JSON.stringify(normalizedFont(style.style.fontName)) !==
          JSON.stringify(item.fontName) ||
        (item.textStyleId !== null && item.textStyleId !== style.style.id)
      )
        fail('unexpected imported style identity/font.');
      if (
        !color ||
        color.key !== item.colorKey ||
        color.variable?.resolvedType !== 'COLOR' ||
        color.variable.id !== item.fills[0].boundVariables.color.id ||
        JSON.stringify(color.values) !==
          JSON.stringify(plan.ctx.resolveColor(item.colorKey).values)
      )
        fail('paint dependency changed during import.');
      const result = { ...item, textStyleId: style.style.id };
      result.signature = signature(result);
      return result;
    });
    plan.ctx = ctx;
    plan.prepared = native;
    plan.before = current;
    plan.dependencyStamp = () => dependencyStamp(ctx, native);
    plan.dependencies = plan.dependencyStamp();
    plan.finalized = true;
    return handle;
  }
  return Object.freeze({ prepare, finalize, apply, resolveFontInput });
})();
if (typeof module !== 'undefined') module.exports = mgRichText;

;
/* global mgRichText, module */
/** Guarded operation-local preparation. Probe writes are separate from pure preflight. */
async function mgResolveNamedFontDefaults(figmaApi, inputs, assertTarget) {
  const report = {
    operation: 'named-font-default-preparation',
    createdNodeIds: [],
    removedNodeIds: [],
    residualNodeIds: [],
    unverifiedRemovalNodeIds: [],
    verificationScope:
      'Recorded root children, node identity/parent/geometry/visibility/opacity/modes and TEXT ranges; recorded local typography/effect and variable/collection definitions. This does not assert every native property or consumer link.',
    resolvedFonts: [],
    errors: [],
    recordedSceneExact: false,
    recordedAssetsExact: false,
  };
  const page = figmaApi.currentPage;
  const fail = message => {
    throw new Error(`Font preparation: ${message}`);
  };
  const guard = () => {
    if (typeof assertTarget !== 'function')
      fail('trusted operation target hook is missing.');
    assertTarget();
    if (!page || page.removed || figmaApi.currentPage !== page)
      fail('operation page changed.');
  };
  const stable = value => {
    if (Array.isArray(value)) return value.map(stable);
    if (value && typeof value === 'object')
      return Object.fromEntries(
        Object.keys(value)
          .sort()
          .map(key => [key, stable(value[key])])
      );
    return value;
  };
  const encode = value => JSON.stringify(stable(value));
  function scene() {
    return encode({
      rootChildren: page.children.map(node => node.id),
      nodes: page
        .findAll(() => true)
        .map(node => ({
          id: node.id,
          type: node.type,
          parent: node.parent?.id,
          x: node.x,
          y: node.y,
          width: node.width,
          height: node.height,
          rotation: node.rotation,
          visible: node.visible,
          opacity: node.opacity,
          explicitVariableModes: node.explicitVariableModes,
          ...(node.type === 'TEXT'
            ? {
                characters: node.characters,
                segments: node.characters.length
                  ? node.getStyledTextSegments([
                      'textStyleId',
                      'fontName',
                      'fills',
                      'hyperlink',
                      'textDecoration',
                    ])
                  : [],
                references: node.componentPropertyReferences,
              }
            : {}),
        })),
    });
  }
  async function assets() {
    const text = await figmaApi.getLocalTextStylesAsync();
    guard();
    const effects = await figmaApi.getLocalEffectStylesAsync();
    guard();
    const collections =
      await figmaApi.variables.getLocalVariableCollectionsAsync();
    guard();
    const variables = await figmaApi.variables.getLocalVariablesAsync();
    guard();
    return encode({
      text: text.map(style => ({
        id: style.id,
        name: style.name,
        fontName: style.fontName,
        fontSize: style.fontSize,
        lineHeight: style.lineHeight,
        letterSpacing: style.letterSpacing,
        boundVariables: style.boundVariables,
        textWrapStyle: style.textWrapStyle,
      })),
      effects: effects.map(style => ({
        id: style.id,
        name: style.name,
        effects: style.effects,
      })),
      collections: collections.map(item => ({
        id: item.id,
        name: item.name,
        modes: item.modes,
        defaultModeId: item.defaultModeId,
      })),
      variables: variables.map(item => ({
        id: item.id,
        name: item.name,
        resolvedType: item.resolvedType,
        variableCollectionId: item.variableCollectionId,
        valuesByMode: item.valuesByMode,
        scopes: item.scopes,
        description: item.description,
        hiddenFromPublishing: item.hiddenFromPublishing,
        codeSyntax: item.codeSyntax,
      })),
    });
  }
  let beforeScene, beforeAssets;
  const probes = [];
  try {
    guard();
    if (
      !Array.isArray(inputs) ||
      !inputs.length ||
      typeof mgRichText === 'undefined' ||
      typeof mgRichText.resolveFontInput !== 'function' ||
      typeof figmaApi.getFontFamilyVariationAxes !== 'function' ||
      typeof figmaApi.getNodeByIdAsync !== 'function'
    )
      fail('incomplete resolver context.');
    const fonts = new Map();
    for (const input of inputs) {
      if (
        !input ||
        typeof input.family !== 'string' ||
        !input.family ||
        typeof input.style !== 'string' ||
        !input.style ||
        Object.keys(input).some(
          key => !['family', 'style', 'variationSettings'].includes(key)
        )
      )
        fail('explicit named font inputs are required.');
      mgRichText.resolveFontInput(input, [{ fontName: input }]);
      fonts.set(encode({ family: input.family, style: input.style }), {
        family: input.family,
        style: input.style,
      });
    }
    beforeScene = scene();
    beforeAssets = await assets();
    guard();
    const beforeIds = new Set([
      page.id,
      ...page.findAll(() => true).map(node => node.id),
    ]);
    const inventory = await figmaApi.listAvailableFontsAsync();
    guard();
    for (const font of [
      { family: 'Inter', style: 'Regular' },
      ...fonts.values(),
    ]) {
      if (
        !inventory.some(
          entry =>
            entry.fontName.family === font.family &&
            entry.fontName.style === font.style
        )
      )
        fail(`named face unavailable: ${font.family} ${font.style}.`);
      await figmaApi.loadFontAsync(font);
      guard();
    }
    for (const input of fonts.values()) {
      guard();
      const axisTags = figmaApi.getFontFamilyVariationAxes(input.family);
      let probe;
      try {
        guard();
        probe = figmaApi.createText();
        if (!probe || beforeIds.has(probe.id)) {
          probe = null;
          fail('createText did not return a fresh owned probe.');
        }
        probes.push(probe);
        report.createdNodeIds.push(probe.id);
        if (
          probe.type !== 'TEXT' ||
          probe.parent !== page ||
          probe.characters !== '' ||
          probe.fontName.family !== 'Inter' ||
          probe.fontName.style !== 'Regular'
        )
          fail('probe is not a fresh empty current-page TEXT.');
        guard();
        probe.fontName = input;
        const native = probe.fontName;
        const concrete = mgRichText.resolveFontInput(
          input,
          [
            {
              fontName: {
                family: native.family,
                style: native.style,
                ...(native.variationSettings === undefined
                  ? {}
                  : { variationSettings: { ...native.variationSettings } }),
              },
            },
          ],
          axisTags
        );
        guard();
        for (const requested of inputs.filter(
          font => font.family === input.family && font.style === input.style
        ))
          mgRichText.resolveFontInput(
            requested,
            [{ fontName: concrete }],
            axisTags
          );
        report.resolvedFonts.push({
          input: { ...input },
          fontName: concrete,
          axisTags: axisTags === null ? null : [...axisTags],
          nodeId: probe.id,
        });
      } finally {
        // A changed target never authorizes another write there. Cleanup uses
        // only the captured fresh probe object, never a looked-up scene node.
        if (probe && !probe.removed) probe.remove();
        if (probe) {
          let residual;
          try {
            residual = await figmaApi.getNodeByIdAsync(probe.id);
          } catch (error) {
            report.unverifiedRemovalNodeIds.push(probe.id);
            throw error;
          }
          if (residual) report.residualNodeIds.push(probe.id);
          else report.removedNodeIds.push(probe.id);
          guard();
        }
      }
      if (report.residualNodeIds.length)
        fail('probe cleanup left residual nodes.');
    }
    guard();
    report.recordedSceneExact = scene() === beforeScene;
    report.recordedAssetsExact = (await assets()) === beforeAssets;
    guard();
    if (!report.recordedSceneExact || !report.recordedAssetsExact)
      fail('existing scene or assets changed during preparation.');
  } catch (error) {
    report.errors.push(error.message || String(error));
    // Retry cleanup of captured owned probes even after a guard/load failure.
    for (const probe of probes) {
      try {
        if (!probe.removed) probe.remove();
        let residual;
        try {
          residual = await figmaApi.getNodeByIdAsync(probe.id);
        } catch (error) {
          if (!report.unverifiedRemovalNodeIds.includes(probe.id))
            report.unverifiedRemovalNodeIds.push(probe.id);
          throw error;
        }
        report.unverifiedRemovalNodeIds =
          report.unverifiedRemovalNodeIds.filter(id => id !== probe.id);
        if (!residual) {
          if (!report.removedNodeIds.includes(probe.id))
            report.removedNodeIds.push(probe.id);
          report.residualNodeIds = report.residualNodeIds.filter(
            id => id !== probe.id
          );
        } else if (!report.residualNodeIds.includes(probe.id))
          report.residualNodeIds.push(probe.id);
      } catch (cleanup) {
        report.errors.push(
          `Probe ${probe.id} cleanup failed: ${cleanup.message || cleanup}`
        );
      }
      try {
        if (!probe.removed && !report.residualNodeIds.includes(probe.id))
          report.residualNodeIds.push(probe.id);
      } catch (verification) {
        if (!report.unverifiedRemovalNodeIds.includes(probe.id))
          report.unverifiedRemovalNodeIds.push(probe.id);
        report.errors.push(
          `Probe removal state unreadable: ${verification.message || verification}`
        );
      }
    }
    try {
      if (beforeScene !== undefined)
        report.recordedSceneExact = scene() === beforeScene;
    } catch (verification) {
      report.errors.push(
        `Scene verification failed: ${verification.message || verification}`
      );
    }
    try {
      guard();
      if (beforeAssets !== undefined)
        report.recordedAssetsExact = (await assets()) === beforeAssets;
      guard();
    } catch (verification) {
      report.errors.push(
        `Preparation verification failed: ${verification.message || verification}`
      );
    }
  }
  return report;
}
if (typeof module !== 'undefined')
  module.exports = { mgResolveNamedFontDefaults };

;
/* global MG_CONNECTOR_NATIVE_TEXT_INSTANCES, mgNativeCollectionsFontPlan, mgNativeCollectionsSceneLedger, mgNativeCollectionsValidateValues, nativeCollectionImportSnapshot, mgNativeCollectionsSourceCapability, MG_CONNECTOR_NATIVE_COLLECTIONS, mgNativeCollectionsSourcePlan, mgNativeCollectionsPreflight, mgNativeCollectionsApplyModes, mgAlphaMaskPlan, mgAlphaMaskDocumentValues, mgAlphaMaskNativeValues, mgNativeAlphaMaskPlan, mgApplyAlphaMask, MG_CONNECTOR_ALPHA_MASK, mgFrozenSourceLine, MG_CONNECTOR_FROZEN_SOURCE_LINE, mgGradientTransform, MG_CONNECTOR_GRADIENT_ROLES, mgTextThicknessPlan, mgNativeTextThicknessPlan, mgApplyTextThickness, MG_CONNECTOR_TEXT_THICKNESS, mgResolveNamedFontDefaults, mgAssertExperimentOperationTarget, mgSvgSizingPlan, mgSvgSizingDocumentValues, mgSvgSizingNativeValues, mgSvgSizingNativePlan, mgApplySvgSizing, MG_CONNECTOR_SVG_SIZING, MG_CONNECTOR_SVG_SIZING_SOURCE, mgRichText, MG_CONNECTOR_RICH_SOURCE_VALIDATION, MG_CONNECTOR_RICH_TEXT, validateMangroveImport, preflightMangroveAssets, mgReadIdentity, mgWriteIdentity, figma, importStyles, errorMessage, MG_SHARED_ONLY, MG_IDENTITY_NAMESPACE, MG_CONNECTOR_SVG, MG_CONNECTOR_ABSOLUTE, MG_CONNECTOR_ABSOLUTE_START, MG_CONNECTOR_INTRINSIC_REVIEW, MG_CONNECTOR_ARC, MG_CONNECTOR_DIRECT_TEXT, MG_CONNECTOR_COINCIDENT_FOCUS, mgLayoutPreflight, mgLayoutLoadExistingFonts, mgLayoutContainerParent, mgLayoutReviewParent, mgLayoutGrid, mgLayoutLegacySpacing, organizeMangroveKit, mgWelcomeLegacySpacing */
// Native component construction from exporter-owned recipes. Bundled at build time.
const MG_KIT_KEY = 'mgKitId';
const MG_KIT_PROPERTY_KEY = 'mgKitProperties';
const MG_ALPHA_MASK_ENABLED =
  typeof MG_CONNECTOR_ALPHA_MASK === 'undefined' || MG_CONNECTOR_ALPHA_MASK;
const MG_ALPHA_MASK_KEY = 'mgAlphaMaskV1';
const MG_FROZEN_SOURCE_LINE_ENABLED =
  typeof MG_CONNECTOR_FROZEN_SOURCE_LINE === 'undefined' ||
  MG_CONNECTOR_FROZEN_SOURCE_LINE;
const MG_MAINTENANCE_POLICY_KEY = 'mgMaintenancePolicy';

function mgMaintenanceParsePolicy(node) {
  const raw = mgReadIdentity(node, MG_MAINTENANCE_POLICY_KEY);
  if (!raw) return null;
  let policy;
  try {
    policy = JSON.parse(raw);
  } catch (_) {
    throw new Error(`Invalid maintenance policy on ${node.id}: expected JSON.`);
  }
  if (
    !policy ||
    typeof policy !== 'object' ||
    Array.isArray(policy) ||
    Object.keys(policy).length !== 3 ||
    Object.keys(policy).some(
      key => !['version', 'owner', 'reason'].includes(key)
    ) ||
    policy.version !== 1 ||
    !['source', 'manual'].includes(policy.owner) ||
    typeof policy.reason !== 'string' ||
    (policy.owner === 'manual'
      ? !policy.reason.trim() || policy.reason.length > 2000
      : policy.reason !== '')
  )
    throw new Error(`Invalid maintenance policy on ${node.id}.`);
  return policy;
}

function mgMaintenanceInspectFamily(familyId, owned, collect) {
  const prefix = `family/${familyId}`;
  const set = owned.get(prefix);
  let policy;
  function inspect(node) {
    const marker = mgMaintenanceParsePolicy(node);
    if (marker) {
      if (
        policy &&
        (marker.owner !== policy.owner || marker.reason !== policy.reason)
      )
        throw new Error(`Conflicting maintenance policies for ${familyId}.`);
      policy = marker;
    }
    if (collect) collect(node, marker);
  }
  if (set) {
    if (set.type !== 'COMPONENT_SET')
      throw new Error(`Maintenance family ${familyId} has changed type.`);
    inspect(set);
  }
  for (const [key, node] of owned) {
    if (!key.startsWith(`${prefix}/variant/`)) continue;
    // The builder indexes anatomy below a variant as well as the main itself.
    if (key.slice(`${prefix}/variant/`.length).includes('/')) continue;
    if (node.type !== 'COMPONENT' || !set || node.parent !== set)
      throw new Error(`Maintenance variant ${node.id} has changed ownership.`);
    inspect(node);
  }
  return (
    policy || {
      version: 1,
      owner: 'source',
      reason: '',
    }
  );
}

function mgMaintenanceFamilyPolicy(familyId, owned) {
  const targets = [],
    explicitNodeIds = [];
  const policy = mgMaintenanceInspectFamily(familyId, owned, (node, marker) => {
    targets.push(node);
    if (marker) explicitNodeIds.push(node.id);
  });
  const set = owned.get(`family/${familyId}`);
  return {
    familyId,
    setId: set?.id || null,
    variantIds: targets.filter(node => node !== set).map(node => node.id),
    policy,
    explicitNodeIds,
    targets,
  };
}

function mgMaintenanceAssertSource(familyIds, owned) {
  const policies = familyIds.map(familyId => ({
    familyId,
    policy: mgMaintenanceInspectFamily(familyId, owned),
  }));
  const manual = policies.filter(entry => entry.policy.owner === 'manual');
  if (manual.length)
    throw new Error(
      `Manual maintenance blocks the complete component build: ${manual
        .map(entry => `${entry.familyId} (${entry.policy.reason})`)
        .join('; ')}. Record an explicit source handback before rebuilding.`
    );
  return policies;
}

function mgMaintenanceDependencyIds(recipes, selectedFamilyIds) {
  const families = new Map(recipes.map(family => [family.id, family]));
  const visiting = new Set();
  const visited = new Set();
  function visit(id) {
    if (visited.has(id)) return;
    if (visiting.has(id))
      throw new Error(`Component dependency cycle at ${id}`);
    const family = families.get(id);
    if (!family) throw new Error(`Unknown component family ${id}`);
    visiting.add(id);
    function walk(tree) {
      if (tree.type === 'INSTANCE') visit(tree.family);
      for (const child of tree.children || []) walk(child);
    }
    for (const variant of family.variants) walk(variant.tree);
    visiting.delete(id);
    visited.add(id);
  }
  for (const id of selectedFamilyIds || families.keys()) visit(id);
  return [...visited];
}

async function preflightMangroveMaintenance(doc, selectedFamilyIds) {
  const recipes = doc?.components?.families;
  if (doc?.components?.version !== 1 || !Array.isArray(recipes))
    throw new Error('Maintenance policy needs the full component document.');
  const ids = mgMaintenanceDependencyIds(recipes, selectedFamilyIds);
  const entries = await mgMaintenancePolicyTargets(doc, ids);
  const manual = entries.filter(entry => entry.policy.owner === 'manual');
  if (manual.length)
    throw new Error(
      `Manual maintenance blocks the complete component build: ${manual
        .map(entry => `${entry.familyId} (${entry.policy.reason})`)
        .join('; ')}. Record an explicit source handback before rebuilding.`
    );
  return entries.map(mgMaintenancePolicyReceipt);
}

async function mgMaintenancePolicyTargets(doc, familyIds) {
  const recipes = doc?.components?.families;
  if (doc?.components?.version !== 1 || !Array.isArray(recipes))
    throw new Error('Maintenance policy needs the full component document.');
  const known = new Set(recipes.map(family => family.id));
  const ids = familyIds === undefined ? [...known] : familyIds;
  if (
    !Array.isArray(ids) ||
    !ids.length ||
    new Set(ids).size !== ids.length ||
    ids.some(id => !known.has(id))
  )
    throw new Error('Select known, unique maintenance family IDs.');
  const owned = new Map();
  for (const node of figma.currentPage.findAll(() => true)) {
    if (node.type === 'INSTANCE') continue;
    let insideInstance = false;
    for (let parent = node.parent; parent; parent = parent.parent)
      if (parent.type === 'INSTANCE') insideInstance = true;
    if (insideInstance) continue;
    const key = mgReadIdentity(node, MG_KIT_KEY);
    if (
      !ids.some(
        id => key === `family/${id}` || key.startsWith(`family/${id}/variant/`)
      )
    )
      continue;
    if (owned.has(key))
      throw new Error(`Duplicate Mangrove ownership key ${key}`);
    owned.set(key, node);
  }
  return ids.map(id => mgMaintenanceFamilyPolicy(id, owned));
}

function mgMaintenancePolicyReceipt(entry) {
  const { targets, ...receipt } = entry;
  return receipt;
}

async function readMangroveMaintenancePolicies(doc, familyIds) {
  const result = {
    operation: 'maintenance-policy',
    phase: 'inspected',
    families: [],
    createdNodeIds: [],
    updatedNodeIds: [],
    errors: [],
  };
  try {
    result.families = (await mgMaintenancePolicyTargets(doc, familyIds)).map(
      mgMaintenancePolicyReceipt
    );
  } catch (error) {
    result.phase = 'refused';
    result.errors.push(error.message || String(error));
  }
  return result;
}

async function setMangroveMaintenancePolicy(doc, familyIds, owner, reason) {
  const result = {
    operation: 'maintenance-policy',
    phase: 'refused',
    families: [],
    createdNodeIds: [],
    updatedNodeIds: [],
    errors: [],
  };
  try {
    if (
      !['source', 'manual'].includes(owner) ||
      typeof reason !== 'string' ||
      (owner === 'manual'
        ? !reason.trim() || reason.length > 2000
        : reason !== '')
    )
      throw new Error(
        'Manual maintenance needs a reason; source needs an empty reason.'
      );
    const entries = await mgMaintenancePolicyTargets(doc, familyIds);
    for (const entry of entries)
      if (!entry.setId)
        throw new Error(
          `Build ${entry.familyId} before assigning its maintenance policy.`
        );
    const policy = { version: 1, owner, reason };
    const encoded = JSON.stringify(policy);
    result.families = entries.map(entry => ({
      ...mgMaintenancePolicyReceipt(entry),
      previousPolicy: entry.policy,
      policy,
    }));
    result.phase = 'updating';
    for (const entry of entries) {
      for (const node of entry.targets) {
        const raw = mgReadIdentity(node, MG_MAINTENANCE_POLICY_KEY);
        if (
          raw === encoded &&
          node.getSharedPluginData(
            MG_IDENTITY_NAMESPACE,
            MG_MAINTENANCE_POLICY_KEY
          ) === encoded
        )
          continue;
        result.updatedNodeIds.push(node.id);
        // Retain a valid legacy private marker when moving it to shared data.
        // Conflicting values have already refused before any writes.
        if (
          !(typeof MG_SHARED_ONLY !== 'undefined' && MG_SHARED_ONLY) &&
          node.getPluginData(MG_MAINTENANCE_POLICY_KEY)
        )
          node.setPluginData(MG_MAINTENANCE_POLICY_KEY, encoded);
        mgWriteIdentity(node, MG_MAINTENANCE_POLICY_KEY, encoded);
      }
    }
    result.phase = 'complete';
  } catch (error) {
    result.phase = result.updatedNodeIds.length ? 'partial' : 'refused';
    result.errors.push(error.message || String(error));
  }
  return result;
}
// Source-embedded raster media uses native image fills, never network fetches.
// Keep the recipe a FRAME so existing geometry/visibility/property ownership
// and normal instance image overrides follow the established update contract.
function mgImagePlan(tree) {
  const image = tree.image;
  if (
    tree.type !== 'FRAME' ||
    !image ||
    typeof image !== 'object' ||
    Array.isArray(image) ||
    Object.keys(image).some(
      key => !['assetId', 'base64', 'scaleMode'].includes(key)
    ) ||
    typeof image.assetId !== 'string' ||
    !/^[a-z0-9][a-z0-9._-]*$/.test(image.assetId) ||
    typeof image.base64 !== 'string' ||
    !image.base64.length ||
    image.base64.length > 4 * 1024 * 1024 ||
    !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(
      image.base64
    ) ||
    image.scaleMode !== 'FILL' ||
    tree.fill ||
    tree.children?.length
  )
    throw new Error(
      'Image recipes require a leaf FRAME, a bounded embedded PNG/JPEG and FILL crop.'
    );
  const bytes = figma.base64Decode(image.base64);
  const png =
    bytes.length > 24 &&
    [137, 80, 78, 71, 13, 10, 26, 10].every((v, i) => bytes[i] === v);
  const jpeg =
    bytes.length > 4 &&
    bytes[0] === 255 &&
    bytes[1] === 216 &&
    bytes[bytes.length - 2] === 255 &&
    bytes[bytes.length - 1] === 217;
  if (!png && !jpeg)
    throw new Error(`Image ${image.assetId} is not PNG or JPEG.`);
  return { ...image, bytes };
}
const MG_GRADIENT_ROLES_ENABLED =
  typeof MG_CONNECTOR_GRADIENT_ROLES === 'undefined' ||
  MG_CONNECTOR_GRADIENT_ROLES;
function mgGradientPlan(tree) {
  const gradient = tree.gradient;
  if (
    tree.type !== 'FRAME' ||
    !gradient ||
    Object.keys(gradient).join(',') !== 'layers' ||
    !Array.isArray(gradient.layers) ||
    !gradient.layers.length ||
    gradient.layers.length > 2 ||
    tree.fill ||
    tree.image ||
    tree.children?.length
  )
    throw new Error(
      'Gradient recipes require a leaf FRAME and one or two source layers.'
    );
  for (const layer of gradient.layers) {
    if (
      !layer ||
      Object.keys(layer).some(k =>
        MG_GRADIENT_ROLES_ENABLED
          ? !['stops', 'transform', 'transformVariables'].includes(k)
          : !['stops', 'transform'].includes(k)
      ) ||
      !Array.isArray(layer.stops) ||
      layer.stops.length < 2 ||
      layer.stops.length > 5 ||
      !Array.isArray(layer.transform) ||
      layer.transform.length !== 2 ||
      layer.transform.some(
        row =>
          !Array.isArray(row) ||
          row.length !== 3 ||
          row.some(v => !Number.isFinite(v))
      )
    )
      throw new Error('Invalid source gradient geometry.');
    if (MG_GRADIENT_ROLES_ENABLED && layer.transformVariables !== undefined)
      mgGradientTransform.validate(layer);
    let previous = -1;
    for (const stop of layer.stops) {
      if (
        !stop ||
        Object.keys(stop).some(k => !['position', 'color'].includes(k)) ||
        !Number.isFinite(stop.position) ||
        stop.position < previous ||
        stop.position < 0 ||
        stop.position > 1 ||
        typeof stop.color !== 'string' ||
        !stop.color
      )
        throw new Error(
          'Gradient stops need ordered 0..1 positions and COLOR variables.'
        );
      previous = stop.position;
    }
  }
  return gradient;
}
const MG_SVG_KEY = 'mgSvgAsset';
const MG_SVG_SIZING_ENABLED =
  typeof MG_CONNECTOR_SVG_SIZING === 'undefined' || MG_CONNECTOR_SVG_SIZING;
const MG_SVG_ENABLED =
  typeof MG_CONNECTOR_SVG === 'undefined' || MG_CONNECTOR_SVG;

const MG_TEXT_THICKNESS_ENABLED =
  typeof MG_CONNECTOR_TEXT_THICKNESS === 'undefined' ||
  MG_CONNECTOR_TEXT_THICKNESS;

const MG_ABSOLUTE_ENABLED =
  typeof MG_CONNECTOR_ABSOLUTE === 'undefined' || MG_CONNECTOR_ABSOLUTE;

const MG_ABSOLUTE_START_ENABLED =
  typeof MG_CONNECTOR_ABSOLUTE_START === 'undefined' ||
  MG_CONNECTOR_ABSOLUTE_START;

const MG_INTRINSIC_REVIEW_ENABLED =
  typeof MG_CONNECTOR_INTRINSIC_REVIEW === 'undefined' ||
  MG_CONNECTOR_INTRINSIC_REVIEW;
const MG_ARC_ENABLED =
  typeof MG_CONNECTOR_ARC === 'undefined' || MG_CONNECTOR_ARC;
const MG_DIRECT_TEXT_ENABLED =
  typeof MG_CONNECTOR_DIRECT_TEXT === 'undefined' || MG_CONNECTOR_DIRECT_TEXT;

const MG_RICH_TEXT_ENABLED =
  typeof MG_CONNECTOR_RICH_TEXT === 'undefined' || MG_CONNECTOR_RICH_TEXT;

const MG_COINCIDENT_FOCUS_ENABLED =
  typeof MG_CONNECTOR_COINCIDENT_FOCUS === 'undefined' ||
  MG_CONNECTOR_COINCIDENT_FOCUS;

function mgEllipseArcPlan(tree) {
  const arc = tree.arcData;
  if (
    tree.type !== 'ELLIPSE' ||
    !arc ||
    typeof arc !== 'object' ||
    Array.isArray(arc) ||
    Object.keys(arc).length !== 3 ||
    Object.keys(arc).some(
      field => !['startingAngle', 'endingAngle', 'innerRadius'].includes(field)
    ) ||
    !['startingAngle', 'endingAngle', 'innerRadius'].every(field =>
      Number.isFinite(arc[field])
    ) ||
    arc.startingAngle < 0 ||
    arc.startingAngle > 2 * Math.PI ||
    arc.endingAngle > arc.startingAngle + 2 * Math.PI ||
    arc.endingAngle <= arc.startingAngle ||
    arc.innerRadius < 0 ||
    arc.innerRadius >= 1
  )
    throw new Error(
      'Ellipse arcData requires a start angle in [0,2π], a positive clockwise sweep of at most2π and innerRadius in [0,1).'
    );
  return { ...arc };
}

function mgAbsolutePlan(tree, parent) {
  const spec = tree.absolute;
  if (
    !spec ||
    typeof spec !== 'object' ||
    Array.isArray(spec) ||
    Object.keys(spec).length !== 4 ||
    Object.keys(spec).some(
      key => !['horizontal', 'vertical', 'offsetX', 'offsetY'].includes(key)
    ) ||
    !(
      (spec.horizontal === 'END' && spec.vertical === 'CENTER') ||
      (MG_ABSOLUTE_START_ENABLED &&
        spec.horizontal === 'START' &&
        spec.vertical === 'START')
    ) ||
    !['offsetX', 'offsetY'].every(
      key => typeof spec[key] === 'string' && spec[key]
    ) ||
    !['FRAME', 'TEXT', 'ELLIPSE'].includes(tree.type) ||
    !parent ||
    parent.type !== 'FRAME' ||
    !['HORIZONTAL', 'VERTICAL'].includes(parent.layout?.mode) ||
    tree.position !== undefined ||
    !['width', 'height'].every(key => {
      const value = tree.layout?.[key];
      return typeof value === 'string'
        ? !!value && !['HUG', 'FILL'].includes(value)
        : Number.isFinite(value) && value > 0;
    })
  )
    throw new Error(
      'Absolute recipes require a native fixed-size child of an auto-layout FRAME, END/CENTER or START/START alignment and FLOAT offset token IDs, without position.'
    );
  return spec;
}

function mgAbsoluteStartSource(doc, tree) {
  const roles = new Map();
  for (const item of doc.variables || []) {
    if (roles.has(item.name))
      throw new Error('Absolute START source variable is ambiguous.');
    roles.set(item.name, item);
  }
  function number(name, mode, seen = new Set()) {
    const role = roles.get(name);
    if (!role || role.type !== 'FLOAT' || seen.has(name))
      throw new Error(
        'Absolute START source FLOAT is missing, wrong typed or cyclic.'
      );
    seen.add(name);
    const value = role.values?.[mode.id];
    if (value && typeof value === 'object') {
      if (
        Object.keys(value).join(',') !== 'alias' ||
        typeof value.alias !== 'string'
      )
        throw new Error('Absolute START source alias is malformed.');
      return number(value.alias, mode, seen);
    }
    if (!Number.isFinite(value))
      throw new Error('Absolute START source FLOAT must be finite.');
    return value;
  }
  if (!Array.isArray(doc.modes) || !doc.modes.length)
    throw new Error('Absolute START source modes are missing.');
  for (const mode of doc.modes) {
    number(tree.absolute.offsetX, mode);
    number(tree.absolute.offsetY, mode);
    for (const field of ['width', 'height'])
      if (
        typeof tree.layout[field] === 'string' &&
        number(tree.layout[field], mode) <= 0
      )
        throw new Error('Absolute START source sizing must be positive.');
  }
}

// A bounded source-vector subset, not a general SVG sanitizer or renderer.
// Reject unsupported XML before the native importer creates any canvas nodes.
function mgSvgPlan(tree) { return {...doc.connectorSvgPlans[tree.svg.assetId]}; }

function mgSvgTopology(node) {
  return [
    {
      id: node.id,
      type: node.type,
      children: (node.children || []).map(child => child.id),
    },
    ...(node.children || []).flatMap(mgSvgTopology),
  ];
}
function mgSvgGeometry(node) {
  return node
    .findAll(() => true)
    .map(child => {
      const fields = [
        'x',
        'y',
        'width',
        'height',
        'rotation',
        'vectorPaths',
        'strokeWeight',
        'strokeCap',
        'strokeJoin',
        'strokeAlign',
        'strokeMiterLimit',
        'dashPattern',
      ];
      return Object.fromEntries(
        fields
          .filter(field => field in child)
          .map(field => [field, child[field]])
      );
    });
}
function mgSvgMonochrome(node, field) {
  const paints = node
    .findAll(() => true)
    .flatMap(child => {
      if (!(field in child)) return [];
      if (!Array.isArray(child[field]))
        throw new Error(`SVG monochrome ${field} cannot bind mixed paints.`);
      return child[field].filter(
        paint => paint.visible !== false && (paint.opacity ?? 1) > 0
      );
    });
  if (
    !paints.length ||
    paints.some(paint => paint.type !== 'SOLID') ||
    new Set(paints.map(paint => JSON.stringify(paint.color))).size !== 1
  )
    throw new Error(
      `SVG monochrome ${field} needs visible SOLID paints of one colour; preserve multicolour or gradient assets unchanged.`
    );
}

function mgRichSourceStylePreflight(doc) {
  validateMangroveImport(
    doc,
    doc.modes.map(item => item.id),
    doc.styles.text.map(item => item.id)
  );
  const sourceVariables = new Map(
    doc.variables.map(entry => [entry.name, entry])
  );
  function sourceValue(name, modeId, type, seen = new Set()) {
    const entry = sourceVariables.get(name);
    if (!entry || entry.type !== type || seen.has(name))
      throw new Error(
        'Rich style source role is missing, wrong typed or cyclic.'
      );
    seen.add(name);
    const value = entry.values[modeId];
    return value && typeof value === 'object' && value.alias
      ? sourceValue(value.alias, modeId, type, seen)
      : value;
  }
  for (const spec of doc.styles.text)
    for (const sourceMode of doc.modes) {
      const value = spec.values[sourceMode.id];
      if (
        !value ||
        value.fontName.family !==
          sourceValue(spec.bindings.fontFamily, sourceMode.id, 'STRING') ||
        value.fontSize !==
          sourceValue(spec.bindings.fontSize, sourceMode.id, 'FLOAT')
      )
        throw new Error(
          'Rich scope style template disagrees with source font/size aliases.'
        );
    }
}

const MG_NATIVE_COLLECTIONS_TEXT_BUILDER_ENABLED =
  typeof MG_CONNECTOR_NATIVE_TEXT_INSTANCES === 'undefined' ||
  MG_CONNECTOR_NATIVE_TEXT_INSTANCES;
const MG_NATIVE_COLLECTIONS_ENABLED =
  typeof MG_CONNECTOR_NATIVE_COLLECTIONS === 'undefined' ||
  MG_CONNECTOR_NATIVE_COLLECTIONS;

function mgNativeCollectionsBuilderPlan(doc) {
  if (!MG_NATIVE_COLLECTIONS_ENABLED || doc.nativeCollections === undefined)
    return null;
  if (typeof mgAssertExperimentOperationTarget !== 'function')
    throw new Error(
      'Partition components require an exact guarded experiment target.'
    );
  mgAssertExperimentOperationTarget();
  return mgNativeCollectionsSourceCapability(doc);
}

async function buildMangroveComponents(
  doc,
  brandId,
  selectedFamilyIds,
  { refreshNarrowReview = false } = {}
) {mgAssertExperimentOperationTarget();
  if (typeof refreshNarrowReview !== 'boolean')
    throw new Error('Refresh narrow review must be a boolean.');
  const result = {
    createdNodeIds: [],
    updatedNodeIds: [],
    families: [],
    errors: [],
    audit: [],
    reviewRootId: null,
  };
  const created = new Set();
  const updated = new Set();
  const reportError = error =>
    typeof errorMessage === 'function' ? errorMessage(error) : String(error);
  if (MG_NATIVE_COLLECTIONS_ENABLED && doc.nativeCollections !== undefined)
    doc = JSON.parse(JSON.stringify(doc));
  const recipes = doc.components?.families || [];
  if (doc.components?.version !== 1 || !recipes.length) {
    result.errors.push(
      'No supported component recipes. Rebuild the token JSON.'
    );
    return result;
  }
  const brand = doc.modes.find(mode => mode.id === brandId);
  if (!brand) throw new Error(`Unknown brand ${brandId}`);
  const nativeCollectionPlan = MG_NATIVE_COLLECTIONS_ENABLED
    ? mgNativeCollectionsBuilderPlan(doc)
    : null;
  if (
    MG_NATIVE_COLLECTIONS_TEXT_BUILDER_ENABLED &&
    nativeCollectionPlan?.version === 2 &&
    selectedFamilyIds !== undefined &&
    (!Array.isArray(selectedFamilyIds) ||
      selectedFamilyIds.length !== recipes.length ||
      new Set(selectedFamilyIds).size !== recipes.length ||
      recipes.some(f => !selectedFamilyIds.includes(f.id)))
  )
    throw new Error('Partition v2 requires the complete family document.');
  const page = figma.currentPage;
  const nativePageId =
    MG_NATIVE_COLLECTIONS_ENABLED && nativeCollectionPlan ? page.id : null;
  function assertNativeCollectionTarget() {
    if (MG_NATIVE_COLLECTIONS_ENABLED && nativeCollectionPlan) {
      mgAssertExperimentOperationTarget();
      if (
        figma.currentPage.id !== nativePageId ||
        figma.currentPage.type !== 'PAGE'
      )
        throw new Error(
          'Partition current page changed across operation awaits.'
        );
    }
  }
  assertNativeCollectionTarget();
  const allOwned = page.findAll(node =>
    Boolean(mgReadIdentity(node, MG_KIT_KEY))
  );
  const owned = new Map();
  if (MG_NATIVE_COLLECTIONS_ENABLED && nativeCollectionPlan)
    for (const node of allOwned) {
      const ledger = mgReadIdentity(node, 'mgNativeScenePlan');
      if (
        ledger !==
        JSON.stringify(
          MG_NATIVE_COLLECTIONS_TEXT_BUILDER_ENABLED &&
            nativeCollectionPlan.version === 2
            ? mgNativeCollectionsSceneLedger(nativeCollectionPlan)
            : { version: 1, planId: nativeCollectionPlan.planId }
        )
      )
        throw new Error(
          'Partition scene ownership conflicts with an existing normal or foreign scene.'
        );
    }
  const nativeSceneSignature = nodes =>
    JSON.stringify(
      nodes
        .map(node => ({
          id: node.id,
          type: node.type,
          parentId: node.parent?.id || null,
          key: mgReadIdentity(node, MG_KIT_KEY),
          ledger: mgReadIdentity(node, 'mgNativeScenePlan'),
          ...(MG_NATIVE_COLLECTIONS_TEXT_BUILDER_ENABLED &&
          nativeCollectionPlan.version === 2
            ? {
                characters: node.type === 'TEXT' ? node.characters : undefined,
                fontName: node.type === 'TEXT' ? node.fontName : undefined,
                textStyleId:
                  node.type === 'TEXT' ? node.textStyleId : undefined,
                references: node.componentPropertyReferences,
                definitions:
                  node.type === 'COMPONENT_SET'
                    ? node.componentPropertyDefinitions
                    : undefined,
                properties:
                  node.type === 'INSTANCE'
                    ? node.componentProperties
                    : undefined,
                modes: node.explicitVariableModes,
              }
            : {}),
        }))
        .sort((a, b) => a.id.localeCompare(b.id))
    );
  const nativeSceneBefore =
    MG_NATIVE_COLLECTIONS_ENABLED && nativeCollectionPlan
      ? nativeSceneSignature(allOwned)
      : null;
  for (const node of allOwned) {
    // Instance descendants inherit source plugin data. Only index construction nodes.
    let ancestor = node.parent;
    let insideInstance = false;
    while (ancestor && ancestor !== page) {
      if (ancestor.type === 'INSTANCE') insideInstance = true;
      ancestor = ancestor.parent;
    }
    if (insideInstance) continue;
    const key = mgReadIdentity(node, MG_KIT_KEY);
    // Root consumers can inherit a main's canonical source identity.
    // Read the actual main; never adopt, clear or rewrite consumer metadata.
    if (
      node.type === 'INSTANCE' &&
      /^family\/[^/]+\/variant\/[^/]+$/.test(key)
    ) {
      const main = await node.getMainComponentAsync();
      if (
        !main ||
        main.type !== 'COMPONENT' ||
        mgReadIdentity(main, MG_KIT_KEY) !== key
      )
        throw new Error(
          'Inherited Mangrove variant identity does not match its actual main.'
        );
      continue;
    }
    if (owned.has(key))
      throw new Error(`Duplicate Mangrove ownership key ${key}`);
    owned.set(key, node);
  }
  // Refuse the entire dependency closure before font, style or scene writes.
  // An indirect manual dependency must not partly refresh a source library.
  mgMaintenanceAssertSource(["editorial-cta","horizontal-book-card"], owned);
  let frozenSourcePlans = null;
  async function checkFrozenSourceLines(phase) {
    if (!frozenSourcePlans?.length) return true;
    try {
      // Recollect current-page construction owners and linked copies at every
      // boundary. Do not collapse duplicate identities or adopt inherited ones.
      const candidates = page.findAll(node => {
        if (!mgReadIdentity(node, MG_KIT_KEY) || node.type === 'INSTANCE')
          return false;
        for (
          let parent = node.parent;
          parent && parent !== page;
          parent = parent.parent
        )
          if (parent.type === 'INSTANCE') return false;
        return true;
      });
      for (const plan of frozenSourcePlans)
        if (
          !candidates.some(
            node => mgReadIdentity(node, MG_KIT_KEY) === plan.ownerKey
          ) &&
          candidates.some(node => mgReadIdentity(node, MG_KIT_KEY) === plan.key)
        )
          throw new Error(
            'Frozen source line reflow-needed: orphan managed line ' + plan.key
          );
      const receipt = await mgFrozenSourceLine.preflight(frozenSourcePlans, {
        mainByKey: key =>
          candidates.filter(node => mgReadIdentity(node, MG_KIT_KEY) === key),
        instances: page.findAllWithCriteria({ types: ['INSTANCE'] }),
        identity: node => mgReadIdentity(node, MG_KIT_KEY),
        mainForInstance: instance => instance.getMainComponentAsync(),
      });
      result.audit.push({
        status: 'frozen-source-line-preflight',
        phase,
        scope: 'loaded current page',
        ...receipt,
      });
      return true;
    } catch (error) {
      const reason = reportError(error);
      result.errors.push(reason);
      result.audit.push({
        status: 'blocked-frozen-source-line-preflight',
        phase,
        reason,
      });
      return false;
    }
  }
  if (MG_FROZEN_SOURCE_LINE_ENABLED) {
    try {
      const selected = new Set(
        mgMaintenanceDependencyIds(recipes, selectedFamilyIds)
      );
      const records = [];
      function frozenTree(tree, key, ownerKey) {
        if (Object.prototype.hasOwnProperty.call(tree, 'sourceLine'))
          records.push({ key, ownerKey, spec: tree });
        for (const child of tree.children || [])
          frozenTree(child, `${key}/${child.id || child.key}`, ownerKey);
      }
      for (const family of recipes.filter(family => selected.has(family.id)))
        for (const variant of family.variants) {
          const key = `family/${family.id}/variant/${variant.id}`;
          frozenTree(variant.tree, key, key);
        }
      frozenSourcePlans = mgFrozenSourceLine.sourcePlans(records);
    } catch (error) {
      const reason = reportError(error);
      result.errors.push(reason);
      result.audit.push({
        status: 'blocked-frozen-source-line-preflight',
        phase: 'source',
        reason,
      });
      return result;
    }
    if (!(await checkFrozenSourceLines('before-font-preparation')))
      return result;
  }
  const organized = owned.has('layout/start');
  if (organized) {
    if (MG_ALPHA_MASK_ENABLED) {
      const selected = new Set(
        mgMaintenanceDependencyIds(recipes, selectedFamilyIds)
      );
      const hasMask = tree =>
        tree.alphaMask !== undefined || (tree.children || []).some(hasMask);
      if (
        recipes.some(
          family =>
            selected.has(family.id) &&
            (family.variants.some(variant => hasMask(variant.tree)) ||
              allOwned.some(
                node =>
                  mgReadIdentity(node, MG_KIT_KEY).startsWith(
                    `family/${family.id}/`
                  ) && mgReadIdentity(node, MG_ALPHA_MASK_KEY)
              ))
        )
      ) {
        result.errors.push(
          'ALPHA mask source candidates require an unorganized experiment file.'
        );
        return result;
      }
    }
    if (typeof mgLayoutPreflight !== 'function')
      throw new Error(
        'Organized kit updates require the layout-aware desktop runtime.'
      );
    await mgLayoutPreflight(doc, { allowProbes: true });
    if (
      mgReadIdentity(owned.get('layout/start'), 'mgLayoutPhase') !== 'complete'
    )
      throw new Error(
        'Finish the pending Organize file operation before building components.'
      );
    await mgLayoutLoadExistingFonts();
  }
  if (MG_NATIVE_COLLECTIONS_ENABLED && nativeCollectionPlan && organized)
    throw new Error('Partition v1 requires an unorganized experiment.');
  const nativeSnapshot =
    MG_NATIVE_COLLECTIONS_ENABLED && nativeCollectionPlan
      ? await nativeCollectionImportSnapshot(assertNativeCollectionTarget)
      : null;
  const collections =
    MG_NATIVE_COLLECTIONS_ENABLED && nativeSnapshot
      ? nativeSnapshot.collections
      : await figma.variables.getLocalVariableCollectionsAsync();
  let nativeCollectionState = null;
  if (MG_NATIVE_COLLECTIONS_ENABLED && nativeCollectionPlan) {
    const local = nativeSnapshot.variables;
    assertNativeCollectionTarget();
    nativeCollectionState = mgNativeCollectionsPreflight(
      nativeCollectionPlan,
      { collections, variables: local },
      {
        readCollection: asset => {
          const value = mgReadIdentity(asset, 'mgNativeCollectionPlan');
          return value ? JSON.parse(value) : null;
        },
        readVariable: asset => mgReadIdentity(asset, 'mgId'),
      }
    );
    if (
      nativeCollectionState.neededCollections.length ||
      nativeCollectionState.neededVariables.length ||
      [...nativeCollectionState.neededModes.values()].some(
        modes => modes.length
      )
    )
      throw new Error(
        'Import the complete partition foundation and modes before building.'
      );
  }
  if (MG_NATIVE_COLLECTIONS_ENABLED && nativeCollectionState)
    mgNativeCollectionsValidateValues(
      nativeCollectionPlan,
      nativeCollectionState
    );
  const collection =
    MG_NATIVE_COLLECTIONS_ENABLED && nativeCollectionState
      ? nativeCollectionState.collectionsBySourceId.get(
          nativeCollectionPlan.primary
        )
      : collections.find(item => item.name === doc.collection);
  if (!collection)
    throw new Error('Import Mangrove variables before components.');
  const mode = collection.modes.find(item => item.name === brand.name);
  if (!mode)
    throw new Error(`Import the ${brand.name} brand before components.`);
  const nativeVariables =
    MG_NATIVE_COLLECTIONS_ENABLED && nativeCollectionState
      ? [...nativeCollectionState.variablesBySourceId.values()]
      : (await figma.variables.getLocalVariablesAsync()).filter(
          variable => variable.variableCollectionId === collection.id
        );
  const variables = new Map(
    nativeVariables.map(variable => [variable.name, variable])
  );
  const textSpecs = new Map(
    (doc.styles?.text || []).map(spec => [spec.id, spec])
  );
  const effectSpecs = new Map(
    (doc.styles?.effect || []).map(spec => [spec.id, spec])
  );
  const families = new Map(recipes.map(recipe => [recipe.id, recipe]));
  const sourceLabel = family =>
    typeof family.source === 'string'
      ? family.source
      : family.source
        ? `${family.source.file}:${family.source.line}`
        : '';
  const chosen = new Set(selectedFamilyIds || recipes.map(recipe => recipe.id));
  const treeWalk = (tree, visit, parent = null) => {
    visit(tree, parent);
    for (const child of tree.children || []) treeWalk(child, visit, tree);
  };
  // Review geometry and content are initial specimen seeds, not repeat-build edits.
  function reviewTarget(tree, path) {
    if (
      !Array.isArray(path) ||
      !path.length ||
      path.some(name => typeof name !== 'string' || !name)
    )
      throw new Error('Review node needs a nonempty anatomy path.');
    for (const name of path) {
      if (tree.type === 'INSTANCE')
        tree = families
          .get(tree.family)
          ?.variants.find(item =>
            matches(item.properties, tree.variant || {})
          )?.tree;
      const children = (tree?.children || []).filter(
        child => child.name === name
      );
      if (children.length !== 1)
        throw new Error(`Ambiguous or missing review node ${name}`);
      tree = children[0];
    }
    return tree;
  }
  function reviewDimension(value) {
    if (typeof value === 'string') variable(value, 'FLOAT');
    else if (!Number.isFinite(value) || value <= 0)
      throw new Error(
        'Review geometry must be a positive size or FLOAT variable.'
      );
  }
  const dependencies = recipe => {
    const names = new Set();
    for (const variant of recipe.variants)
      treeWalk(variant.tree, tree => {
        if (tree.type === 'INSTANCE') names.add(tree.family);
      });
    return [...names];
  };
  const ordered = [];
  const visited = new Set();
  const visiting = new Set();
  function order(id) {
    if (visited.has(id)) return;
    if (visiting.has(id))
      throw new Error(`Component dependency cycle at ${id}`);
    const family = families.get(id);
    if (!family) throw new Error(`Unknown component family ${id}`);
    visiting.add(id);
    for (const dependency of dependencies(family)) order(dependency);
    visiting.delete(id);
    visited.add(id);
    ordered.push(family);
  }
  for (const id of chosen) order(id);

  function variable(name, type) {
    const value = variables.get(name);
    if (!value || value.resolvedType !== type)
      throw new Error(`Missing ${type} variable ${name}`);
    return value;
  }
  const alphaMaskOwners = MG_ALPHA_MASK_ENABLED ? new Map() : null;
  const alphaMaskRecords = MG_ALPHA_MASK_ENABLED ? [] : null;
  function alphaMaskIdentity(record) {
    return {
      get: node => mgReadIdentity(node, MG_KIT_KEY),
      expected: record.keys,
      readState: node => mgReadIdentity(node, MG_ALPHA_MASK_KEY),
      writeState: (node, value) =>
        mgWriteIdentity(node, MG_ALPHA_MASK_KEY, value),
    };
  }
  function alphaMaskResolve(name, nativeModeId, type, seen = new Set()) {
    const entry = variable(name, type);
    if (entry.variableCollectionId !== collection.id || seen.has(entry.id))
      throw new Error('ALPHA mask native alias ownership or cycle disagrees.');
    seen.add(entry.id);
    const value = entry.valuesByMode[nativeModeId];
    if (value && value.type === 'VARIABLE_ALIAS') {
      const alias = nativeVariables.find(item => item.id === value.id);
      if (
        !alias ||
        alias.variableCollectionId !== collection.id ||
        alias.resolvedType !== type ||
        variable(alias.name, type).id !== alias.id
      )
        throw new Error(
          'ALPHA mask native alias is missing or its exact identity disagrees.'
        );
      return alphaMaskResolve(alias.name, nativeModeId, type, seen);
    }
    return value;
  }
  function checkAlphaMasks(phase) {
    if (!MG_ALPHA_MASK_ENABLED || !alphaMaskRecords.length) return true;
    try {
      // Recollect actual construction nodes after awaits. Inherited consumer
      // ledgers are not an ownership or consumer-mask override guarantee.
      const current = new Map();
      const required = new Set(
        alphaMaskRecords.flatMap(record => Object.values(record.keys))
      );
      for (const node of page.findAll(node =>
        Boolean(mgReadIdentity(node, MG_KIT_KEY))
      )) {
        let inside = node.type === 'INSTANCE';
        for (
          let parent = node.parent;
          parent && parent !== page;
          parent = parent.parent
        )
          if (parent.type === 'INSTANCE') inside = true;
        if (inside) continue;
        const key = mgReadIdentity(node, MG_KIT_KEY);
        if (!required.has(key)) continue;
        if (current.has(key))
          throw new Error('Duplicate ALPHA mask construction identity.');
        current.set(key, node);
      }
      for (const record of alphaMaskRecords) {
        if (record.plan) {
          mgAlphaMaskDocumentValues(record.plan, doc);
          mgAlphaMaskNativeValues(
            record.plan,
            collection.modes.map(item => item.modeId),
            alphaMaskResolve
          );
        }
        mgNativeAlphaMaskPlan(
          current.get(record.keys.mask),
          current.get(record.keys.owner),
          current.get(record.keys.content),
          record.plan,
          alphaMaskIdentity(record)
        );
      }
      return true;
    } catch (error) {
      const reason = reportError(error);
      result.errors.push(reason);
      result.audit.push({
        status: 'blocked-alpha-mask-preflight',
        phase,
        reason,
      });
      return false;
    }
  }
  if (MG_ALPHA_MASK_ENABLED) {
    try {
      function maskTree(tree, key, parent, parentKey, index) {
        const plan = mgAlphaMaskPlan(tree, parent, index);
        if (plan && /^family\/[^/]+\/variant\/[^/]+$/.test(parentKey))
          throw new Error(
            'ALPHA mask owner must be a nested FRAME, not the native variant COMPONENT.'
          );
        const existing = owned.get(key);
        if (plan || (existing && mgReadIdentity(existing, MG_ALPHA_MASK_KEY))) {
          const record = {
            plan,
            keys: {
              mask: key,
              owner: parentKey,
              content:
                parent &&
                `${parentKey}/${parent.children?.[1]?.id || parent.children?.[1]?.key}`,
            },
          };
          alphaMaskRecords.push(record);
          if (plan) alphaMaskOwners.set(parent, record);
        }
        (tree.children || []).forEach((child, childIndex) =>
          maskTree(
            child,
            `${key}/${child.id || child.key}`,
            tree,
            key,
            childIndex
          )
        );
      }
      for (const family of ordered)
        for (const variant of family.variants)
          maskTree(
            variant.tree,
            `family/${family.id}/variant/${variant.id}`,
            null,
            null,
            0
          );
    } catch (error) {
      result.errors.push(reportError(error));
      result.audit.push({
        status: 'blocked-alpha-mask-preflight',
        phase: 'source',
        reason: reportError(error),
      });
      return result;
    }
    if (!checkAlphaMasks('before-font-preparation')) return result;
  }
  const available = await figma.listAvailableFontsAsync();
  const fontPromises = new Map();
  async function load(font) {
    const key = JSON.stringify(font);
    if (!fontPromises.has(key)) {
      fontPromises.set(
        key,
        (async () => {
          if (
            !available.some(
              entry =>
                entry.fontName.family === font.family &&
                entry.fontName.style === font.style
            )
          )
            throw new Error(
              `Font "${font.family} ${font.style}" is unavailable.`
            );
          await figma.loadFontAsync(font);
        })()
      );
    }
    await fontPromises.get(key);
  }
  async function loadNodeFonts(root) {
    const texts =
      root.type === 'TEXT'
        ? [root]
        : 'findAllWithCriteria' in root
          ? root.findAllWithCriteria({ types: ['TEXT'] })
          : [];
    for (const text of texts) {
      if (text.fontName !== figma.mixed) await load(text.fontName);
      else
        for (const segment of text.getStyledTextSegments(['fontName']))
          await load(segment.fontName);
    }
  }
  function nativeTextAssetSignature(state) {
    return JSON.stringify({
      collections: [...state.collectionsBySourceId].map(([source, c]) => [
        source,
        c.id,
        c.name,
        [...state.modeIdsByCollectionId.get(source)],
      ]),
      variables: [...state.variablesBySourceId].map(([source, v]) => [
        source,
        v.id,
        v.variableCollectionId,
        v.name,
        v.resolvedType,
      ]),
    });
  }
  const nativeTextAssetBefore =
    MG_NATIVE_COLLECTIONS_TEXT_BUILDER_ENABLED &&
    nativeCollectionPlan?.version === 2
      ? nativeTextAssetSignature(nativeCollectionState)
      : null;
  let nativeTextInstanceBefore = null;
  async function nativeTextInstanceSignature() {
    const rows = [];
    for (const node of page.findAll(
      node =>
        Boolean(mgReadIdentity(node, MG_KIT_KEY)) && node.type === 'INSTANCE'
    )) {
      const main = await node.getMainComponentAsync();
      assertNativeCollectionTarget();
      const key = main && mgReadIdentity(main, MG_KIT_KEY);
      const sourceKey = mgReadIdentity(node, MG_KIT_KEY),
        expectedMain =
          nativeCollectionPlan.instanceMasterKeys.get(sourceKey) ||
          (/^family\/[^/]+\/variant\/[^/]+$/.test(sourceKey)
            ? sourceKey
            : null);
      if (
        !expectedMain ||
        key !== expectedMain ||
        !main ||
        main.type !== 'COMPONENT' ||
        owned.get(key)?.id !== main.id ||
        mgReadIdentity(main, 'mgNativeScenePlan') !==
          JSON.stringify(mgNativeCollectionsSceneLedger(nativeCollectionPlan))
      )
        throw new Error(
          'Partition instance main ownership conflicts with source masters.'
        );
      rows.push({ id: node.id, mainId: main.id });
    }
    return JSON.stringify(rows.sort((a, b) => a.id.localeCompare(b.id)));
  }
  let nativeTextStyleBefore = null;
  function nativeTextStyleSignature(styles) {
    return JSON.stringify(
      styles
        .map(style => ({
          id: style.id,
          name: style.name,
          key: mgReadIdentity(style, 'mgStyleId'),
          type: style.type,
          fontName: style.fontName,
          fontSize: style.fontSize,
          lineHeight: style.lineHeight,
          letterSpacing: style.letterSpacing,
          decoration: style.textDecoration,
          wrap: style.textWrapStyle,
          indent: style.paragraphIndent,
          bound: style.boundVariables,
        }))
        .sort((a, b) => a.id.localeCompare(b.id))
    );
  }
  async function nativeTextStyles() {
    const text = await figma.getLocalTextStylesAsync();
    assertNativeCollectionTarget();
    const effects = await figma.getLocalEffectStylesAsync();
    assertNativeCollectionTarget();
    const chosen = [];
    for (const spec of nativeCollectionPlan.textStylesById.values()) {
      const hits = [...text, ...effects].filter(
        style =>
          mgReadIdentity(style, 'mgStyleId') === spec.id ||
          style.name === spec.name
      );
      if (
        hits.length > 1 ||
        (hits.length &&
          (hits[0].type !== 'TEXT' ||
            mgReadIdentity(hits[0], 'mgStyleId') !== spec.id ||
            hits[0].name !== spec.name))
      )
        throw new Error('Partition plain style identity/kind conflict.');
      if (hits.length) chosen.push(hits[0]);
    }
    return chosen;
  }
  async function checkNativeTextBeforeStyles() {
    nativeCollectionState = mgNativeCollectionsPreflight(
      nativeCollectionPlan,
      await nativeCollectionImportSnapshot(assertNativeCollectionTarget),
      {
        readCollection: asset => {
          const value = mgReadIdentity(asset, 'mgNativeCollectionPlan');
          return value ? JSON.parse(value) : null;
        },
        readVariable: asset => mgReadIdentity(asset, 'mgId'),
      }
    );
    if (
      nativeTextAssetSignature(nativeCollectionState) !== nativeTextAssetBefore
    )
      throw new Error(
        'Partition asset identities changed across font preparation.'
      );
    const required = mgNativeCollectionsFontPlan(
      nativeCollectionPlan,
      nativeCollectionState
    );
    for (const font of required)
      if (!fontPromises.has(JSON.stringify(font)))
        throw new Error(
          'Partition native font changed after font preparation.'
        );
    const current = await nativeTextStyles();
    if ((await nativeTextInstanceSignature()) !== nativeTextInstanceBefore)
      throw new Error(
        'Partition instance main changed across font preparation.'
      );
    if (nativeTextStyleSignature(current) !== nativeTextStyleBefore)
      throw new Error('Partition plain style changed across font preparation.');
    if (
      nativeSceneSignature(
        page.findAll(node => Boolean(mgReadIdentity(node, MG_KIT_KEY)))
      ) !== nativeSceneBefore
    )
      throw new Error(
        'Partition text/property ownership changed across font preparation.'
      );
    assertNativeCollectionTarget();
  }
  if (
    MG_NATIVE_COLLECTIONS_TEXT_BUILDER_ENABLED &&
    nativeCollectionPlan?.version === 2
  ) {
    nativeTextInstanceBefore = await nativeTextInstanceSignature();
    const styleAssets = await nativeTextStyles();
    nativeTextStyleBefore = nativeTextStyleSignature(styleAssets);
    const fonts = [
      ...nativeCollectionPlan.sourceFonts,
      ...mgNativeCollectionsFontPlan(
        nativeCollectionPlan,
        nativeCollectionState
      ),
      { family: 'Inter', style: 'Regular' },
    ];
    for (const style of styleAssets) fonts.push(style.fontName);
    if (typeof figma.getFontFamilyVariationAxes !== 'function')
      throw new Error(
        'Partition plain text requires native font-axis discovery.'
      );
    for (const font of fonts) {
      const axes = figma.getFontFamilyVariationAxes(font.family);
      if (
        !Array.isArray(axes) ||
        (axes.length &&
          !available.some(
            entry =>
              entry.fontName.family === font.family &&
              entry.fontName.style === font.style &&
              entry.fontName.variationSettings &&
              axes.every(axis =>
                Number.isFinite(entry.fontName.variationSettings[axis])
              )
          ))
      )
        throw new Error(
          'Partition plain native named font axes are unresolved; separately journaled default preparation is required.'
        );
    }
    for (const font of fonts) {
      await load(font);
      assertNativeCollectionTarget();
    }
    // Plain native named fonts are loaded through the documented API. Explicit
    // source axes are refused by this first profile; no rich default probe runs.
    await checkNativeTextBeforeStyles();
  }
  // Changing a container's mode can change text across every descendant family.
  // Prepare that whole subtree only for a real transition, before any writes.
  for (const key of ['main', 'review']) {
    const frame = owned.get(key);
    if (!frame) continue;
    try {
      if (frame.type !== 'FRAME')
        throw new Error(`Owned ${key} container has changed type.`);
      if (
        MG_NATIVE_COLLECTIONS_TEXT_BUILDER_ENABLED &&
        nativeCollectionPlan?.version === 2
          ? [...nativeCollectionPlan.collectionById.keys()].some(
              id =>
                frame.explicitVariableModes[
                  nativeCollectionState.collectionsBySourceId.get(id).id
                ] !==
                nativeCollectionState.modeIdsByCollectionId.get(id).get(brandId)
            )
          : frame.explicitVariableModes[collection.id] !== mode.modeId
      )
        await loadNodeFonts(frame);
    } catch (error) {
      const reason = reportError(error);
      result.errors.push(`${frame.name}: ${reason}`);
      result.audit.push({
        nodeId: frame.id,
        status: 'blocked-container-mode-transition',
        reason,
      });
      return result;
    }
  }
  const allowedBindings = new Set([
    'cornerRadius',
    'topLeftRadius',
    'topRightRadius',
    'bottomLeftRadius',
    'bottomRightRadius',
    'strokeWeight',
    'strokeTopWeight',
    'strokeBottomWeight',
    'strokeLeftWeight',
    'strokeRightWeight',
    'opacity',
    'minWidth',
    'maxWidth',
    'minHeight',
    'maxHeight',
    'width',
    'height',
    'itemSpacing',
    'paddingTop',
    'paddingBottom',
    'paddingLeft',
    'paddingRight',
    'visible',
  ]);
  function absoluteNumber(name, seen = new Set(), nativeModeId = mode.modeId) {
    const entry = variable(name, 'FLOAT');
    if (seen.has(entry.id))
      throw new Error(`Absolute variable alias cycle at ${name}.`);
    seen.add(entry.id);
    const value = entry.valuesByMode[nativeModeId];
    if (value && typeof value === 'object' && value.type === 'VARIABLE_ALIAS') {
      const alias = [...variables.values()].find(item => item.id === value.id);
      if (!alias)
        throw new Error(`Missing absolute variable alias at ${name}.`);
      return absoluteNumber(alias.name, seen, nativeModeId);
    }
    if (!Number.isFinite(value))
      throw new Error(
        `Absolute FLOAT ${name} must be finite in the imported brand mode.`
      );
    return value;
  }
  const gradientRolesScope =
    MG_GRADIENT_ROLES_ENABLED &&
    ordered.some(family =>
      family.variants.some(variant => {
        let found = false;
        treeWalk(variant.tree, tree => {
          if (
            tree.gradient?.layers?.some(
              layer => layer?.transformVariables !== undefined
            )
          )
            found = true;
        });
        return found;
      })
    );
  const textThicknessPlans = MG_TEXT_THICKNESS_ENABLED ? new Map() : null;
  const textThicknessScope =
    MG_TEXT_THICKNESS_ENABLED &&
    ordered.some(family =>
      family.variants.some(variant => {
        let found = false;
        treeWalk(variant.tree, tree => {
          if (tree.textDecorationThickness !== undefined) found = true;
        });
        return found;
      })
    );
  const richTextPlans = MG_RICH_TEXT_ENABLED ? new Map() : null;
  const richParagraphStyles = MG_RICH_TEXT_ENABLED ? new Set() : null;
  const richParagraphNodes = MG_RICH_TEXT_ENABLED ? [] : null;
  const richTextScope =
    MG_RICH_TEXT_ENABLED &&
    ordered.some(family =>
      family.variants.some(variant => {
        let found = false;
        treeWalk(variant.tree, tree => {
          if (tree.textRuns !== undefined) found = true;
        });
        return found;
      })
    );
  const svgSizingScope =
    MG_SVG_SIZING_ENABLED &&
    ordered.some(family =>
      family.variants.some(variant => {
        let found = false;
        treeWalk(variant.tree, tree => {
          if (tree.svg?.sizing !== undefined) found = true;
        });
        return found;
      })
    );
  function nativeSvgNumber(name, nativeMode, type, seen = new Set()) {
    const entry = variable(name, type);
    if (seen.has(entry.id))
      throw new Error('SVG sizing native alias is cyclic.');
    seen.add(entry.id);
    const value = entry.valuesByMode[nativeMode.id];
    if (value?.type === 'VARIABLE_ALIAS') {
      const alias = [...variables.values()].find(item => item.id === value.id);
      if (!alias) throw new Error('SVG sizing native alias is missing.');
      return nativeSvgNumber(alias.name, nativeMode, type, seen);
    }
    if (!Number.isFinite(value))
      throw new Error('SVG sizing native FLOAT is unresolved.');
    return value;
  }
  const absoluteStartScope =
    MG_ABSOLUTE_START_ENABLED &&
    ordered.some(family =>
      family.variants.some(variant => {
        let found = false;
        treeWalk(variant.tree, tree => {
          if (tree.absolute?.horizontal === 'START') found = true;
        });
        return found;
      })
    );
  let richContext;
  const ready = [];
  const blocked = new Set();
  const usedText = new Set();
  const usedEffects = new Set();
  const directText = MG_DIRECT_TEXT_ENABLED ? new Map() : null;
  if (MG_CONNECTOR_DIRECT_TEXT) {
    // Exact source profiles. Editorial native acceptance remains pending.
    // Validate the whole selected scope before any
    // style/canvas writes, including when other selected families are valid.
    try {
      for (const family of ordered)
        for (const variant of family.variants)
          treeWalk(variant.tree, (tree, parent) => {
            if (tree.textStyleApplication === undefined) return;
            const editorial = true;
            let sizeRole = 'font-size/300';
            if (editorial) {
              const p = variant.properties || {};
              const contexts = [
                'Base',
                'HeroPrimary',
                'HeroTertiary',
                'HeroQuaternary',
              ];
              const allowed = new Set();
              for (const context of contexts) {
                const states =
                  context === 'Base'
                    ? ['Default', 'Focus', 'Disabled']
                    : ['Default', 'Focus'];
                for (const state of states)
                  allowed.add(
                    [context, state, 'Short', 'NoPreference']
                      .join('.')
                      .toLowerCase()
                  );
                for (const motion of ['NoPreference', 'Reduce'])
                  allowed.add(
                    [context, 'Hover', 'Short', motion].join('.').toLowerCase()
                  );
                allowed.add(
                  [context, 'Default', 'Long', 'NoPreference']
                    .join('.')
                    .toLowerCase()
                );
              }
              for (const state of ['Hover', 'Focus'])
                allowed.add(
                  ['Base', state, 'Long', 'NoPreference']
                    .join('.')
                    .toLowerCase()
                );
              const identity = [p.Context, p.State, p.Content, p.Motion]
                .join('.')
                .toLowerCase();
              const expectedStyle =
                p.State === 'Focus'
                  ? 'component.editorial-cta.label-focus'
                  : p.State === 'Hover'
                    ? 'component.editorial-cta.label-hover'
                    : 'component.editorial-cta.label';
              const expectedDecoration = ['Focus', 'Hover'].includes(p.State)
                ? 'UNDERLINE'
                : 'NONE';
              const expectedOffset =
                p.State === 'Hover'
                  ? { unit: 'PERCENT', value: 20 }
                  : { unit: 'AUTO' };
              const expectedFill =
                p.Context !== 'Base'
                  ? 'color/neutral-0'
                  : p.State === 'Hover'
                    ? 'color/interactive-active'
                    : 'color/text';
              if (
                tree.textStyleApplication !== 'DIRECT' ||
                Object.keys(p).sort().join(',') !==
                  'Content,Context,Motion,State' ||
                !allowed.has(identity) ||
                variant.id !== 'editorial-cta.' + identity ||
                tree.type !== 'TEXT' ||
                tree.name !== 'mg-button-cta / label' ||
                ![
                  'label',
                  'mg-button mg-button-cta/mg-button-cta / label',
                ].includes(tree.id) ||
                tree.textProperty !== 'Label' ||
                tree.textStyle !== expectedStyle ||
                tree.textDecoration !== expectedDecoration ||
                tree.textWrap !== 'AUTO' ||
                JSON.stringify(tree.textDecorationOffset) !==
                  JSON.stringify(expectedOffset) ||
                tree.fill !== expectedFill ||
                tree.stroke !== null ||
                tree.layout?.width !==
                  (p.Content === 'Long' ? 'FILL' : 'HUG') ||
                tree.layout?.height !== 'HUG' ||
                parent !== variant.tree ||
                parent.type !== 'FRAME' ||
                parent.name !== 'mg-button mg-button-cta' ||
                !['action', 'mg-button mg-button-cta'].includes(parent.id) ||
                (parent.id === 'action') !== (tree.id === 'label') ||
                parent.children.length !== 2 ||
                parent.children[0] !== tree ||
                parent.children[1].type !== 'FRAME' ||
                parent.children[1].name !== 'mg-button-cta / badge'
              )
                throw new Error(
                  'DIRECT Editorial is restricted to its exact source-owned Label state.'
                );
              sizeRole = 'font-size/button';
            } else if (
              tree.textStyleApplication !== 'DIRECT' ||
              family.id !== 'toc-link' ||
              !/^toc-link\.(240|390|900)\.(default|hover|focus|hoverfocus)$/.test(
                variant.id
              ) ||
              tree.type !== 'TEXT' ||
              !['label', 'mg-table-of-contents / a/Link label'].includes(
                tree.id
              ) ||
              tree.name !== 'Link label' ||
              tree.textProperty !== 'Label' ||
              tree.textStyle !== 'component.table-of-contents.link' ||
              parent !== variant.tree ||
              !['link', 'mg-table-of-contents / a'].includes(parent.id) ||
              parent.name !== 'mg-table-of-contents / a' ||
              (parent.id === 'link') !== (tree.id === 'label') ||
              parent.children.length !== 1
            )
              throw new Error(
                'textStyleApplication DIRECT is restricted to source TOC or Editorial Label TEXT.'
              );
            const matches = doc.styles.text.filter(
              s => s.id === tree.textStyle
            );
            const template = matches[0],
              values = template?.values?.[brandId];
            const expectedFontSize = editorial ? absoluteNumber(sizeRole) : 16;
            if (
              matches.length !== 1 ||
              (template.type !== undefined && template.type !== 'TEXT') ||
              (editorial &&
                (template.source?.file !==
                  'stories/Components/Buttons/CtaButton/cta-button.scss' ||
                  template.name !==
                    'Mangrove/component/editorial-cta/' +
                      tree.textStyle.split('.').at(-1))) ||
              template.bindings?.fontFamily !== 'font-family/text' ||
              template.bindings?.fontSize !== sizeRole ||
              values?.fontName?.family !== 'Roboto' ||
              values.fontName.style !== (editorial ? 'Bold' : 'Regular') ||
              values.fontSize !== expectedFontSize ||
              values.lineHeight?.unit !== 'PERCENT' ||
              values.lineHeight.value !== (editorial ? 100 : 150) ||
              values.textDecoration !==
                (editorial ? tree.textDecoration : 'UNDERLINE') ||
              values.textWrapStyle !== 'AUTO' ||
              (editorial &&
                JSON.stringify(values.textDecorationOffset) !==
                  JSON.stringify(tree.textDecorationOffset))
            )
              throw new Error(
                'DIRECT typography needs its exact source template and brand values.'
              );
            const bindings = {};
            for (const [field, type] of [
              ['fontFamily', 'STRING'],
              ['fontSize', 'FLOAT'],
            ]) {
              const name = template.bindings[field],
                sources = doc.variables.filter(v => v.name === name),
                native = variable(name, type);
              if (
                sources.length !== 1 ||
                sources[0].type !== type ||
                nativeVariables.filter(v => v.name === name).length !== 1 ||
                mgReadIdentity(native, 'mgId') !== sources[0].id
              )
                throw new Error(
                  `DIRECT needs the exact ${type} source role ${name}.`
                );
              const seen = new Set();
              let current = native,
                value;
              while (current) {
                if (seen.has(current.id))
                  throw new Error(`DIRECT alias cycle at ${name}.`);
                seen.add(current.id);
                if (current.resolvedType !== type)
                  throw new Error(`DIRECT alias type changed at ${name}.`);
                value = current.valuesByMode[mode.modeId];
                if (value?.type !== 'VARIABLE_ALIAS') break;
                current = [...variables.values()].find(v => v.id === value.id);
                if (!current)
                  throw new Error(`DIRECT alias is missing at ${name}.`);
              }
              if (
                value !==
                (field === 'fontFamily'
                  ? values.fontName.family
                  : values.fontSize)
              )
                throw new Error(
                  `DIRECT imported brand role differs at ${name}.`
                );
              bindings[field] = native;
            }
            directText.set(tree, bindings);
          });
    } catch (error) {
      result.errors.push(reportError(error));
      return result;
    }
  }
  const coincidentFocus = MG_COINCIDENT_FOCUS_ENABLED ? new Map() : null;
  // This renderer is a source-family exception, not a generic focus-ring API.
  // Validate every selected recipe before importing styles or touching the canvas.
  if (MG_CONNECTOR_COINCIDENT_FOCUS) {
  try {
    for (const family of ordered)
      for (const variant of family.variants)
        treeWalk(variant.tree, (tree, parent) => {
          const ring = tree.focusRing;
          const focused = ['Focus', 'HoverFocus'].includes(
            variant.properties?.State
          );
          if (
            family.id === 'segmented-control.segment' &&
            tree === variant.tree &&
            focused &&
            !ring
          )
            throw new Error(
              'Focused source Segmented leaves require COINCIDENT_SCALE outlines.'
            );
          if (
            !ring ||
            (ring.renderer === undefined &&
              ring.outerStroke === undefined &&
              ring.cornerBindings === undefined)
          )
            return;
          if (!MG_COINCIDENT_FOCUS_ENABLED)
            throw new Error(
              'COINCIDENT_SCALE is unavailable in this compiled component scope.'
            );
          if (MG_COINCIDENT_FOCUS_ENABLED) {
            const selected = variant.properties?.Selected,
              state = variant.properties?.State,
              position = variant.properties?.Position;
            const fields = [
              'topLeftRadius',
              'topRightRadius',
              'bottomLeftRadius',
              'bottomRightRadius',
            ];
            const roles = {
              color: 'color/focus-ring',
              separatorColor: 'color/neutral-0',
              offset: 'focus-ring/offset',
              width: 'focus-ring/width',
              outerStroke: 'effect-size/focus-ring/outer-spread',
            };
            const templates = (doc.styles?.text || []).filter(
              value => value.id === 'component.segmented-control.segment'
            );
            const template = templates[0],
              templateValue = template?.values?.[brandId];
            const paintRole =
              selected === 'True'
                ? state === 'HoverFocus'
                  ? 'color/button-background--hover'
                  : 'color/button-background'
                : state === 'HoverFocus'
                  ? 'color/button-outline-primary--hover'
                  : 'color/button-outline-primary';
            const label = tree.children?.[0];
            const raw = tree.id === 'segment' && label?.id === 'label';
            const normalized =
              tree.id === 'mg-segmented-control__label' &&
              label?.id === `${tree.id}/Segment label`;
            if (
              ring.renderer !== 'COINCIDENT_SCALE' ||
              Object.keys(ring).length !== 7 ||
              Object.keys(ring).some(
                field =>
                  ![
                    ...Object.keys(roles),
                    'renderer',
                    'cornerBindings',
                  ].includes(field)
              ) ||
              family.id !== 'segmented-control.segment' ||
              family.source?.file !==
                'stories/Components/Forms/SegmentedControl/segmented-control.scss' ||
              !/^[a-f0-9]{64}$/.test(family.source.normalizedSha256 || '') ||
              templates.length !== 1 ||
              template.type !== 'TEXT' ||
              template.source?.file !== family.source.file ||
              template.source?.normalizedSha256 !==
                family.source.normalizedSha256 ||
              template.bindings?.fontFamily !== 'font-family/text' ||
              template.bindings?.fontSize !== 'font-size/button' ||
              templateValue?.fontName?.style !== 'Bold' ||
              templateValue.lineHeight?.unit !== 'PERCENT' ||
              templateValue.lineHeight.value !== 120 ||
              !['False', 'True'].includes(selected) ||
              !focused ||
              !['First', 'Middle', 'Last'].includes(position) ||
              variant.id !==
                `segmented-control.segment.${selected.toLowerCase()}.${state.toLowerCase()}.${position.toLowerCase()}` ||
              variant.name !==
                `Selected=${selected}, State=${state}, Position=${position}` ||
              Object.keys(variant.properties).length !== 3 ||
              tree !== variant.tree ||
              parent ||
              tree.type !== 'FRAME' ||
              !(raw || normalized) ||
              tree.name !== 'mg-segmented-control__label' ||
              tree.children.length !== 1 ||
              label.type !== 'TEXT' ||
              label.name !== 'Segment label' ||
              label.textProperty !== 'Label' ||
              label.characters !== 'Depth' ||
              label.textStyle !== 'component.segmented-control.segment' ||
              label.textStyleApplication !== undefined ||
              tree.layout?.mode !== 'HORIZONTAL' ||
              tree.layout.width !== 'HUG' ||
              tree.layout.height !== 'HUG' ||
              tree.layout.minHeight !==
                'component/segmented-control/minimum-height' ||
              tree.clipsContent !== false ||
              tree.strokesIncludedInLayout !== true ||
              tree.effectStyle !== null ||
              tree.stroke !== paintRole ||
              tree.fill !==
                (selected === 'True' || state === 'HoverFocus'
                  ? paintRole
                  : null) ||
              label.fill !==
                (selected === 'True' || state === 'HoverFocus'
                  ? 'color/button'
                  : paintRole) ||
              Object.entries(roles).some(
                ([field, name]) => ring[field] !== name
              ) ||
              !ring.cornerBindings ||
              Object.keys(ring.cornerBindings).length !== 4
            )
              throw new Error(
                'COINCIDENT_SCALE is restricted to exact source Default Segmented Focus/HoverFocus leaves.'
              );
            for (const field of fields) {
              const rounded =
                position === 'First'
                  ? field.includes('Left')
                  : position === 'Last'
                    ? field.includes('Right')
                    : false;
              const name = rounded ? 'radius/button' : 'spacing/0';
              if (
                ring.cornerBindings[field] !== name ||
                tree.bindings?.[field] !== name
              )
                throw new Error(
                  `COINCIDENT_SCALE source corner alias differs at ${field}.`
                );
            }
            const sourceRole = (name, type, sourceMode, seen = new Set()) => {
              const matches = (doc.variables || []).filter(
                value => value.name === name
              );
              const source = matches[0];
              if (
                matches.length !== 1 ||
                source.id !== name.replaceAll('/', '.') ||
                source.type !== type ||
                seen.has(name)
              )
                throw new Error(
                  `COINCIDENT_SCALE requires one exact ${type} source role ${name}.`
                );
              seen.add(name);
              const value = source.values?.[sourceMode];
              if (value && typeof value === 'object' && 'alias' in value) {
                if (
                  Object.keys(value).length !== 1 ||
                  typeof value.alias !== 'string'
                )
                  throw new Error(
                    `Malformed COINCIDENT_SCALE source alias ${name}.`
                  );
                return sourceRole(value.alias, type, sourceMode, seen);
              }
              if (
                type === 'FLOAT'
                  ? !Number.isFinite(value) || value < 0
                  : !value ||
                    Object.keys(value).length !== 4 ||
                    !['r', 'g', 'b', 'a'].every(
                      field =>
                        Number.isFinite(value[field]) &&
                        value[field] >= 0 &&
                        value[field] <= 1
                    )
              )
                throw new Error(
                  `Invalid COINCIDENT_SCALE source value ${name}.`
                );
              return value;
            };
            const nativeRole = (name, type, seen = new Set()) => {
              const matches = nativeVariables.filter(
                value => value.name === name
              );
              const native = matches[0];
              if (
                matches.length !== 1 ||
                native.resolvedType !== type ||
                native.variableCollectionId !== collection.id ||
                mgReadIdentity(native, 'mgId') !== name.replaceAll('/', '.') ||
                seen.has(native.id)
              )
                throw new Error(
                  `COINCIDENT_SCALE requires one exact imported ${type} role ${name}.`
                );
              seen.add(native.id);
              const value = native.valuesByMode[mode.modeId];
              if (value?.type === 'VARIABLE_ALIAS') {
                const target = nativeVariables.find(
                  value2 => value2.id === value.id
                );
                if (!target)
                  throw new Error(
                    `Missing COINCIDENT_SCALE native alias ${name}.`
                  );
                return nativeRole(target.name, type, seen);
              }
              const expected = sourceRole(name, type, brandId);
              const represented = (actual, source) =>
                actual === source || actual === Math.fround(source);
              if (
                type === 'FLOAT'
                  ? !represented(value, expected)
                  : !value ||
                    Object.keys(value).length !== 4 ||
                    !['r', 'g', 'b', 'a'].every(field =>
                      represented(value[field], expected[field])
                    )
              )
                throw new Error(
                  `COINCIDENT_SCALE imported brand differs at ${name}.`
                );
              return value;
            };
            for (const sourceMode of doc.modes) {
              const offset = sourceRole(ring.offset, 'FLOAT', sourceMode.id),
                width = sourceRole(ring.width, 'FLOAT', sourceMode.id),
                sum = sourceRole(ring.outerStroke, 'FLOAT', sourceMode.id);
              if (
                !(offset > 0 && width > 0) ||
                sum !== offset + width ||
                sourceRole('spacing/0', 'FLOAT', sourceMode.id) !== 0
              )
                throw new Error(
                  `COINCIDENT_SCALE focus sum/zero differs for ${sourceMode.id}.`
                );
              for (const name of Object.values(ring.cornerBindings))
                sourceRole(name, 'FLOAT', sourceMode.id);
              sourceRole(ring.color, 'COLOR', sourceMode.id);
              sourceRole(ring.separatorColor, 'COLOR', sourceMode.id);
            }
            for (const name of [
              ring.offset,
              ring.width,
              ring.outerStroke,
              ...Object.values(ring.cornerBindings),
            ])
              nativeRole(name, 'FLOAT');
            nativeRole(ring.color, 'COLOR');
            nativeRole(ring.separatorColor, 'COLOR');
            coincidentFocus.set(tree, {
              offset: nativeRole(ring.offset, 'FLOAT'),
              width: nativeRole(ring.width, 'FLOAT'),
              outerStroke: nativeRole(ring.outerStroke, 'FLOAT'),
            });
          }
        });
  } catch (error) {
    result.errors.push(reportError(error));
    return result;
  }
  }
  const svgPlans = new Map();
  const svgAssetSources = new Map();
  const imagePlans = MG_CONNECTOR_MEDIA ? new Map() : null;
  const imageAssetSources = MG_CONNECTOR_MEDIA ? new Map() : null;
  const imageHashes = MG_CONNECTOR_MEDIA ? new Map() : null;
  const gradientPlans = MG_CONNECTOR_MEDIA ? new Map() : null;
  for (const family of ordered) {
    try {
      if (dependencies(family).some(id => blocked.has(id)))
        throw new Error('A required component family could not be prepared.');
      if (family.kind !== 'component-set' || !family.variants.length)
        throw new Error('Expected a component set with at least one variant.');
      const variantIds = new Set();
      const familyText = new Set();
      const familyEffects = new Set();
      const propertyTypes = new Map();
      function recordProperty(name, type) {
        if (propertyTypes.has(name) && propertyTypes.get(name) !== type)
          throw new Error(`Conflicting component property type for ${name}`);
        propertyTypes.set(name, type);
      }
      for (const name of Object.keys(family.optionalProperties || {}))
        recordProperty(name, 'BOOLEAN');
      if (
        family.review?.genericLabels !== undefined &&
        typeof family.review.genericLabels !== 'boolean'
      )
        throw new Error('Review genericLabels must be a boolean.');
      if (MG_CONNECTOR_INTRINSIC_VALIDATION && family.review?.preserveVariantSizing !== undefined) {
        if (typeof family.review.preserveVariantSizing !== 'boolean')
          throw new Error('Review preserveVariantSizing must be a boolean.');
        if (family.review.preserveVariantSizing && !MG_INTRINSIC_REVIEW_ENABLED)
          throw new Error(
            'Intrinsic review sizing is disabled in this connector scope. Compile the selected family before building it.'
          );
      }
      if (
        family.review?.width !== undefined &&
        (!Number.isFinite(family.review.width) || family.review.width <= 0)
      )
        throw new Error('Review width must be positive and finite.');
      for (const variant of family.variants) {
        if (variantIds.has(variant.id))
          throw new Error(`Duplicate variant ${variant.id}`);
        variantIds.add(variant.id);
        if (variant.tree.type !== 'FRAME')
          throw new Error('Variant root must be FRAME.');
        if (family.review?.longLabelTarget !== undefined) {
          const path = family.review.longLabelTarget;
          if (
            !Array.isArray(path) ||
            !path.length ||
            path.some(name => typeof name !== 'string' || !name)
          )
            throw new Error(
              'Long-label target must be a nonempty anatomy path.'
            );
          let target = variant.tree;
          for (const name of path) {
            const matches = (target.children || []).filter(
              child => child.name === name
            );
            if (matches.length !== 1)
              throw new Error(
                `Ambiguous or missing review label target ${name}`
              );
            target = matches[0];
          }
          if (target.type !== 'INSTANCE')
            throw new Error('Long-label target must be a nested instance.');
        }
        const keys = new Set();
        treeWalk(variant.tree, (tree, parent) => {
          if (MG_CONNECTOR_ABSOLUTE && tree.absolute !== undefined) {
            if (!MG_ABSOLUTE_ENABLED)
              throw new Error(
                'Absolute recipes are disabled in this connector scope. Compile the selected family before building it.'
              );
            const absolute = mgAbsolutePlan(tree, parent);
            if (MG_ABSOLUTE_START_ENABLED && absolute.horizontal === 'START') {
              mgAbsoluteStartSource(doc, tree);
              for (const nativeMode of collection.modes) {
                absoluteNumber(absolute.offsetX, new Set(), nativeMode.modeId);
                absoluteNumber(absolute.offsetY, new Set(), nativeMode.modeId);
                for (const field of ['width', 'height'])
                  if (
                    typeof tree.layout[field] === 'string' &&
                    absoluteNumber(
                      tree.layout[field],
                      new Set(),
                      nativeMode.modeId
                    ) <= 0
                  )
                    throw new Error(
                      'Absolute START native sizing must be positive.'
                    );
              }
            }
            absoluteNumber(absolute.offsetX);
            absoluteNumber(absolute.offsetY);
            for (const field of ['width', 'height']) {
              const value = tree.layout[field];
              if (typeof value === 'string' && absoluteNumber(value) <= 0)
                throw new Error(
                  'Absolute width and height FLOAT helpers must be positive.'
                );
            }
          }
          if (MG_RICH_TEXT_ENABLED && tree.textRuns !== undefined) {
            if (
              tree.type !== 'TEXT' ||
              tree.bindings !== undefined ||
              tree.effectStyle !== undefined ||
              tree.focusRing !== undefined ||
              tree.visibilityProperty !== undefined ||
              tree.appearance !== undefined
            )
              throw new Error(
                'Rich TEXT forbids whole-node bindings/effects/properties/appearance conflicts.'
              );
          }
          if (
            MG_TEXT_THICKNESS_ENABLED &&
            tree.textDecorationThickness !== undefined
          )
            textThicknessPlans.set(tree, mgTextThicknessPlan(tree));
          if (MG_CONNECTOR_TEXT_OFFSET && tree.textDecorationOffset !== undefined) {
            const offset = tree.textDecorationOffset;
            if (
              tree.type !== 'TEXT' ||
              !offset ||
              typeof offset !== 'object' ||
              Array.isArray(offset) ||
              (offset.unit === 'AUTO'
                ? Object.keys(offset).length !== 1
                : !['PIXELS', 'PERCENT'].includes(offset.unit) ||
                  Object.keys(offset).length !== 2 ||
                  !Number.isFinite(offset.value) ||
                  Object.keys(offset).some(
                    key => !['unit', 'value'].includes(key)
                  ))
            )
              throw new Error(
                'TEXT textDecorationOffset requires AUTO or finite PIXELS/PERCENT units.'
              );
          }
          if (tree.textProperty) recordProperty(tree.textProperty, 'TEXT');
          if (tree.visibilityProperty)
            recordProperty(tree.visibilityProperty, 'BOOLEAN');
          if (tree.visibilityProperty && tree.bindings?.visible !== undefined)
            throw new Error(
              'A visible variable binding and BOOLEAN property cannot control the same node.'
            );
          if (
            tree.textDecoration !== undefined &&
            (tree.type !== 'TEXT' ||
              !['UNDERLINE', 'NONE'].includes(tree.textDecoration))
          )
            throw new Error(
              'Only TEXT recipes support textDecoration UNDERLINE or NONE.'
            );
          if (
            !['FRAME', 'TEXT', 'INSTANCE', 'ELLIPSE', 'SVG'].includes(tree.type)
          )
            throw new Error(`Unsupported recipe node ${tree.type}`);
          if (
            MG_SVG_SIZING_ENABLED &&
            tree.svg?.sizing !== undefined &&
            tree.type !== 'SVG'
          )
            throw new Error('SVG sizing is only supported on SVG leaves.');
          if (tree.type === 'SVG' && !MG_SVG_ENABLED)
            throw new Error(
              'SVG recipes are disabled in this connector scope. Compile the selected SVG family before building it.'
            );
          if (MG_SVG_ENABLED && tree.type === 'SVG') {
            const plan = mgSvgPlan(tree);
            if (
              svgAssetSources.has(plan.assetId) &&
              svgAssetSources.get(plan.assetId) !== plan.markup
            )
              throw new Error(
                `SVG asset ${plan.assetId} has conflicting source markup. Use distinct asset IDs or an explicit SVG migration.`
              );
            svgAssetSources.set(plan.assetId, plan.markup);
            if (tree.svg.sizing !== undefined) {
              if (!MG_SVG_SIZING_ENABLED)
                throw new Error('SVG sizing capability is not compiled.');
              if (
                typeof MG_CONNECTOR_SVG_SIZING_SOURCE === 'undefined' ||
                MG_CONNECTOR_SVG_SIZING_SOURCE
              )
                mgSvgSizingDocumentValues(plan.sizing, doc);
              mgSvgSizingNativeValues(
                plan.sizing,
                collection.modes.map(item => ({ id: item.modeId })),
                nativeSvgNumber
              );
            }
            svgPlans.set(tree, plan);
            for (const name of Object.values(tree.svg.monochrome || {}))
              variable(name, 'COLOR');
          }
          if (MG_ARC_ENABLED && 'arcData' in tree) mgEllipseArcPlan(tree);
          if (MG_CONNECTOR_ELLIPSE && tree.type === 'ELLIPSE') {
            const geometry = [
              'width',
              'height',
              'minWidth',
              'maxWidth',
              'minHeight',
              'maxHeight',
            ];
            if (
              tree.children?.length ||
              tree.textProperty ||
              Object.entries(tree.layout || {}).some(
                ([field, value]) => !geometry.includes(field) || value === 'HUG'
              ) ||
              Object.keys(tree.bindings || {}).some(
                field =>
                  ![...geometry, 'strokeWeight', 'opacity', 'visible'].includes(
                    field
                  )
              )
            )
              throw new Error(
                'Ellipse recipes are leaf shapes with geometry only, without HUG sizing, frame layout, text or corner radii.'
              );
          }
          if (!tree.id && !tree.key)
            throw new Error(`Node ${tree.name} needs a stable id.`);
          if (
            MG_CONNECTOR_FRAME_POSITION && tree.type === 'FRAME' &&
            tree.position !== undefined &&
            (!parent ||
              parent.type !== 'FRAME' ||
              !tree.position ||
              Object.keys(tree.position).sort().join(',') !== 'x,y' ||
              !['x', 'y'].every(field => Number.isFinite(tree.position[field])))
          )
            throw new Error(
              'Positioned FRAME recipes require finite x/y inside a source frame.'
            );
          if (MG_CONNECTOR_MEDIA && tree.image !== undefined) {
            const plan = mgImagePlan(tree);
            if (
              imageAssetSources.has(plan.assetId) &&
              imageAssetSources.get(plan.assetId) !== plan.base64
            )
              throw new Error(`Conflicting source image ${plan.assetId}.`);
            imageAssetSources.set(plan.assetId, plan.base64);
            imagePlans.set(tree, plan);
          }
          if (MG_CONNECTOR_MEDIA && tree.gradient !== undefined) {
            const plan = mgGradientPlan(tree);
            for (const layer of plan.layers)
              for (const stop of layer.stops) variable(stop.color, 'COLOR');
            if (
              MG_GRADIENT_ROLES_ENABLED &&
              plan.layers.some(layer => layer.transformVariables !== undefined)
            ) {
              const sourceSpecs = new Map(
                doc.variables.map(entry => [entry.name, entry])
              );
              function gradientNumber(name, modeId, seen = new Set()) {
                const source = sourceSpecs.get(name),
                  matches = nativeVariables.filter(
                    entry => entry.name === name
                  ),
                  entry = matches[0];
                if (
                  !source ||
                  source.type !== 'FLOAT' ||
                  matches.length !== 1 ||
                  entry.resolvedType !== 'FLOAT' ||
                  mgReadIdentity(entry, 'mgId') !== source.id ||
                  seen.has(entry.id)
                )
                  throw new Error(
                    'Gradient transform needs its imported owned FLOAT role: ' +
                      name
                  );
                seen.add(entry.id);
                const value = entry.valuesByMode[modeId];
                if (
                  value &&
                  typeof value === 'object' &&
                  value.type === 'VARIABLE_ALIAS'
                ) {
                  const alias = nativeVariables.find(
                    variable => variable.id === value.id
                  );
                  if (!alias)
                    throw new Error(
                      'Gradient transform alias must stay in its imported collection.'
                    );
                  return gradientNumber(alias.name, modeId, seen);
                }
                if (!Number.isFinite(value))
                  throw new Error(
                    'Gradient transform FLOAT must be finite in every imported mode.'
                  );
                return value;
              }
              gradientPlans.set(tree, {
                layers: plan.layers.map(layer => {
                  if (layer.transformVariables === undefined) return layer;
                  mgGradientTransform.source(doc, layer);
                  for (const nativeMode of collection.modes)
                    mgGradientTransform.resolve(layer, name =>
                      gradientNumber(name, nativeMode.modeId)
                    );
                  return {
                    ...layer,
                    transform: mgGradientTransform.resolve(layer, name =>
                      gradientNumber(name, mode.modeId)
                    ),
                  };
                }),
              });
            } else gradientPlans.set(tree, plan);
          }
          if (
            tree.expose !== undefined &&
            (tree.type !== 'INSTANCE' || typeof tree.expose !== 'boolean')
          )
            throw new Error(
              'Only nested instance recipes may declare boolean expose.'
            );
          if (false)
            throw new Error(
              'Nested instance property values must use overrides, not properties.'
            );
          const key = tree.id || tree.key;
          if (keys.has(key)) throw new Error(`Duplicate recipe node id ${key}`);
          keys.add(key);
          if (tree.fill) variable(tree.fill, 'COLOR');
          if (tree.stroke) variable(tree.stroke, 'COLOR');
          if (MG_CONNECTOR_FOCUS && tree.focusRing) {
            if (tree.effectStyle)
              throw new Error(
                'Native focus outlines cannot also use a focus effect.'
              );
            if (tree.type !== 'FRAME')
              throw new Error('Native focus outlines require a frame recipe.');
            variable(tree.focusRing.color, 'COLOR');
            variable(tree.focusRing.separatorColor, 'COLOR');
            if (MG_COINCIDENT_FOCUS_ENABLED && coincidentFocus.has(tree)) {
              for (const field of ['offset', 'width', 'outerStroke'])
                variable(tree.focusRing[field], 'FLOAT');
              for (const name of Object.values(tree.focusRing.cornerBindings))
                variable(name, 'FLOAT');
            } else
              for (const field of ['offset', 'width', 'radius'])
                variable(tree.focusRing[field], 'FLOAT');
            if (tree.focusRing.outerRadius)
              variable(tree.focusRing.outerRadius, 'FLOAT');
          }
          for (const [field, name] of Object.entries(tree.bindings || {})) {
            if (!allowedBindings.has(field))
              throw new Error(`Unsupported binding ${field}`);
            variable(name, field === 'visible' ? 'BOOLEAN' : 'FLOAT');
          }
          const layout = tree.layout || {};
          if (
            layout.wrap !== undefined &&
            !['NO_WRAP', 'WRAP'].includes(layout.wrap)
          )
            throw new Error('Layout wrap must be NO_WRAP or WRAP.');
          for (const name of [
            layout.padding?.block,
            layout.padding?.inline,
            layout.gap,
            layout.counterGap,
            layout.minHeight,
            layout.maxHeight,
            layout.maxWidth,
            layout.minWidth,
            layout.width,
            layout.height,
          ]) {
            if (typeof name === 'string' && !['HUG', 'FILL'].includes(name))
              variable(name, 'FLOAT');
          }
          if (tree.type === 'TEXT') {
            if (
              tree.textWrap !== undefined &&
              !['AUTO', 'BALANCE', 'PRETTY'].includes(tree.textWrap)
            )
              throw new Error('Unsupported text wrapping style.');
            if (MG_RICH_TEXT_ENABLED && tree.textRuns !== undefined) {
              if (!Array.isArray(tree.textRuns))
                throw new Error('Rich textRuns must be an array.');
              for (const run of tree.textRuns) {
                if (!run || !textSpecs.has(run.textStyle))
                  throw new Error('Missing rich run exported text style.');
                familyText.add(run.textStyle);
              }
            } else {
              if (!textSpecs.has(tree.textStyle))
                throw new Error(
                  `Missing exported text style ${tree.textStyle}`
                );
              familyText.add(tree.textStyle);
            }
          }
          if (tree.effectStyle) {
            if (!effectSpecs.has(tree.effectStyle))
              throw new Error(
                `Missing exported effect style ${tree.effectStyle}`
              );
            familyEffects.add(tree.effectStyle);
          }
          if (tree.type === 'INSTANCE') {
            if (tree.labelSizing !== undefined && tree.labelSizing !== 'FILL')
              throw new Error('Instance labelSizing supports only FILL.');
            const dependency = families.get(tree.family);
            if (
              !dependency?.variants.some(item =>
                matches(item.properties, tree.variant || {})
              )
            )
              throw new Error(`No matching ${tree.family} variant.`);
            if (tree.appearance !== undefined) {
              if (
                !tree.appearance ||
                typeof tree.appearance !== 'object' ||
                Array.isArray(tree.appearance) ||
                Object.keys(tree.appearance).some(
                  field => !['fill', 'stroke', 'labelFill'].includes(field)
                )
              )
                throw new Error(
                  'Instance appearance supports only fill, stroke and labelFill.'
                );
              for (const name of Object.values(tree.appearance))
                variable(name, 'COLOR');
              if (tree.appearance.labelFill) {
                const selected = dependency.variants.find(item =>
                  matches(item.properties, tree.variant || {})
                );
                const labels = [];
                treeWalk(selected.tree, child => {
                  if (child.type === 'TEXT' && child.textProperty === 'Label')
                    labels.push(child);
                });
                if (labels.length !== 1)
                  throw new Error(
                    'Contextual label fill requires exactly one Label text node.'
                  );
              }
            }
          } else if (tree.appearance !== undefined)
            throw new Error(
              'Contextual appearance is only supported on native instances.'
            );
        });
        function checkTreeOwnership(tree, key) {
          const existing = owned.get(key);
          if (existing?.componentPropertyReferences?.visible)
            managedVisibilityReference(
              existing,
              owned.get(`family/${family.id}/variant/${variant.id}`)
            );
          if (MG_SVG_ENABLED && tree.type === 'SVG') {
            const node = owned.get(key);
            if (node) {
              let previous;
              try {
                previous = JSON.parse(mgReadIdentity(node, MG_SVG_KEY));
              } catch {
                /* Missing or malformed metadata is a migration. */
              }
              const plan = svgPlans.get(tree);
              if (
                node.type !== 'FRAME' ||
                !previous ||
                previous.assetId !== plan.assetId ||
                previous.hash !== plan.hash ||
                previous.markup !== plan.markup ||
                (MG_SVG_SIZING_ENABLED &&
                  JSON.stringify(previous.sizing ?? null) !==
                    JSON.stringify(plan.sizing ?? null)) ||
                !Number.isFinite(previous.sourceOpacity) ||
                previous.sourceOpacity < 0 ||
                previous.sourceOpacity > 1 ||
                JSON.stringify(previous.paintPolicy) !==
                  JSON.stringify(plan.paintPolicy) ||
                JSON.stringify(previous.topology) !==
                  JSON.stringify(mgSvgTopology(node)) ||
                JSON.stringify(previous.geometry) !==
                  JSON.stringify(mgSvgGeometry(node))
              )
                throw new Error(
                  `SVG ${key} content, asset identity or imported geometry/topology changed. Explicit SVG migration required; preserve existing wrapper and vector IDs before replacing source.`
                );
              if (
                ![node.width, node.height].every(
                  value => Number.isFinite(value) && value > 0
                ) ||
                Math.abs(node.width / node.height - plan.width / plan.height) >
                  1e-6
              )
                throw new Error(
                  `SVG ${key} viewport aspect ratio changed. Explicit SVG migration required.`
                );
              for (const field of Object.keys(tree.svg.monochrome || {}))
                mgSvgMonochrome(node, field);
              if (MG_SVG_SIZING_ENABLED && plan.sizing)
                mgSvgSizingNativePlan(node, plan.sizing, variable, true);
              plan.sourceOpacity = previous.sourceOpacity;
            }
          }
          for (const child of tree.children || [])
            checkTreeOwnership(child, `${key}/${child.id || child.key}`);
        }
        checkTreeOwnership(
          variant.tree,
          `family/${family.id}/variant/${variant.id}`
        );
      }
      if (MG_CONNECTOR_REVIEW_SURFACES && family.review?.variantSurfaces !== undefined) {
        const surfaces = family.review.variantSurfaces;
        if (
          !surfaces ||
          typeof surfaces !== 'object' ||
          Array.isArray(surfaces)
        )
          throw new Error(
            'Review variantSurfaces must map exact variant IDs to COLOR tokens.'
          );
        for (const [id, name] of Object.entries(surfaces)) {
          if (!variantIds.has(id))
            throw new Error(`Unknown review surface variant ${id}.`);
          variable(name, 'COLOR');
        }
      }
      if (family.review?.specimens !== undefined) {
        const specimens = family.review.specimens;
        if (!Array.isArray(specimens) || specimens.length > 8)
          throw new Error(
            'Review specimens must be an array of at most eight entries.'
          );
        const specimenIds = new Set([...variantIds, 'long-label', 'narrow']);
        for (const specimen of specimens) {
          if (
            !specimen ||
            !/^[a-z0-9][a-z0-9-]*$/.test(specimen.id || '') ||
            specimenIds.has(specimen.id)
          )
            throw new Error('Review specimen needs a unique stable id.');
          specimenIds.add(specimen.id);
          if (typeof specimen.name !== 'string' || !specimen.name)
            throw new Error('Review specimen needs a name.');
          if (
            !specimen.variant ||
            family.variants.filter(variant =>
              matches(variant.properties, specimen.variant)
            ).length !== 1
          )
            throw new Error(
              `Review specimen ${specimen.id} needs one matching variant.`
            );
          if (!Number.isFinite(specimen.width) || specimen.width <= 0)
            throw new Error(
              `Review specimen ${specimen.id} needs a positive finite width.`
            );
          if (
            !specimen.properties ||
            typeof specimen.properties !== 'object' ||
            Array.isArray(specimen.properties)
          )
            throw new Error(
              `Review specimen ${specimen.id} needs named property overrides.`
            );
          for (const [name, value] of Object.entries(specimen.properties)) {
            const type = propertyTypes.get(name);
            if (
              !type ||
              (type === 'TEXT'
                ? typeof value !== 'string'
                : typeof value !== 'boolean')
            )
              throw new Error(
                `Review specimen ${specimen.id} property ${name} must match a named TEXT or BOOLEAN property.`
              );
          }
          if (MG_CONNECTOR_REVIEW_SURFACES && specimen.surface !== undefined)
            variable(specimen.surface, 'COLOR');
          if (specimen.instanceWidth !== undefined)
            reviewDimension(specimen.instanceWidth);
          if (MG_CONNECTOR_REVIEW_NODES && specimen.nodes !== undefined) {
            if (!Array.isArray(specimen.nodes) || specimen.nodes.length > 64)
              throw new Error(
                'Review nodes must be an array of at most 64 entries.'
              );
            const root = family.variants.find(item =>
              matches(item.properties, specimen.variant)
            ).tree;
            for (const seed of specimen.nodes) {
              const target = reviewTarget(root, seed.path);
              if (seed.width !== undefined || seed.height !== undefined)
                throw new Error(
                  'Nested review dimensions are unsupported in real Figma. Put shared geometry on component masters.'
                );
              if (seed.properties !== undefined) {
                if (
                  target.type !== 'INSTANCE' ||
                  !seed.properties ||
                  typeof seed.properties !== 'object' ||
                  Array.isArray(seed.properties)
                )
                  throw new Error(
                    'Review property seeds require a nested instance and named properties.'
                  );
                const dependency = families
                  .get(target.family)
                  .variants.find(item =>
                    matches(item.properties, target.variant || {})
                  );
                const types = new Map();
                treeWalk(dependency.tree, node => {
                  if (node.textProperty) types.set(node.textProperty, 'TEXT');
                  if (node.visibilityProperty)
                    types.set(node.visibilityProperty, 'BOOLEAN');
                });
                for (const [name, value] of Object.entries(seed.properties))
                  if (
                    !types.has(name) ||
                    typeof value !==
                      (types.get(name) === 'TEXT' ? 'string' : 'boolean')
                  )
                    throw new Error(
                      `Review nested property ${name} does not match its component contract.`
                    );
              }
            }
          }
        }
      }
      for (const id of familyText) {
        const spec = textSpecs.get(id);
        for (const entry of Object.values(spec.values))
          await load(entry.fontName);
        variable(spec.bindings.fontFamily, 'STRING');
        variable(spec.bindings.fontSize, 'FLOAT');
      }
      for (const id of familyEffects) {
        const spec = effectSpecs.get(id);
        if (!spec.values[brandId])
          throw new Error(`Missing brand values for ${id}`);
        for (const entry of spec.values[brandId])
          for (const [field, name] of Object.entries(entry.bindings || {}))
            variable(name, field === 'color' ? 'COLOR' : 'FLOAT');
      }
      const existingSet = owned.get(`family/${family.id}`);
      if (existingSet) {
        if (existingSet.type !== 'COMPONENT_SET')
          throw new Error('Owned set has changed type.');
        await loadNodeFonts(existingSet);
      }
      // Creating a text node starts with Inter before the source style is applied.
      if (
        !(MG_NATIVE_COLLECTIONS_ENABLED && nativeCollectionPlan) ||
        (MG_NATIVE_COLLECTIONS_TEXT_BUILDER_ENABLED &&
          nativeCollectionPlan.version === 2)
      )
        await load({ family: 'Inter', style: 'Regular' });
      ready.push(family);
      familyText.forEach(id => usedText.add(id));
      familyEffects.forEach(id => usedEffects.add(id));
    } catch (error) {
      blocked.add(family.id);
      result.errors.push(`${family.name}: ${reportError(error)}`);
      result.audit.push({
        family: family.id,
        status: 'blocked',
        reason: reportError(error),
      });
    }
  }
  if (
    ((MG_FROZEN_SOURCE_LINE_ENABLED && frozenSourcePlans?.length) ||
      (MG_GRADIENT_ROLES_ENABLED && gradientRolesScope) ||
      (MG_TEXT_THICKNESS_ENABLED && textThicknessScope) ||
      (MG_RICH_TEXT_ENABLED && richTextScope) ||
      (MG_SVG_SIZING_ENABLED && svgSizingScope) ||
      (MG_ABSOLUTE_START_ENABLED && absoluteStartScope)) &&
    result.errors.length
  )
    return result;
  if (!ready.length) return result;
  if (MG_TEXT_THICKNESS_ENABLED && textThicknessScope) {
    try {
      async function inspectThickness(tree, key) {
        if (textThicknessPlans.has(tree)) {
          const node = owned.get(key);
          if (node) {
            await loadNodeFonts(node);
            mgNativeTextThicknessPlan(node, textThicknessPlans.get(tree));
          }
        }
        for (const child of tree.children || [])
          await inspectThickness(child, `${key}/${child.id || child.key}`);
      }
      for (const family of ready)
        for (const variant of family.variants)
          await inspectThickness(
            variant.tree,
            `family/${family.id}/variant/${variant.id}`
          );
    } catch (error) {
      result.errors.push(reportError(error));
      result.audit.push({
        status: 'blocked-text-thickness-preflight',
        reason: reportError(error),
      });
      return result;
    }
  }
  if (MG_RICH_TEXT_ENABLED && richTextScope) {
    try {
      if (typeof mgRichText === 'undefined')
        throw new Error('Rich TEXT capability was not compiled.');
      const styleDoc = {
        ...doc,
        styles: {
          text: [...usedText].map(id => textSpecs.get(id)),
          effect: [...usedEffects].map(id => effectSpecs.get(id)),
        },
      };
      if (
        typeof MG_CONNECTOR_RICH_SOURCE_VALIDATION === 'undefined' ||
        MG_CONNECTOR_RICH_SOURCE_VALIDATION
      )
        mgRichSourceStylePreflight(styleDoc);
      // Nonzero paragraph indentation is a bounded plain TEXT profile only.
      // Rich ownership does not yet migrate paragraph formatting signatures.
      function checkRichParagraphs(tree, key) {
        if (tree.textRuns !== undefined) {
          const node = owned.get(key);
          if ((node?.paragraphIndent ?? 0) !== 0)
            throw new Error(
              'Rich paragraph indent edit requires explicit migration.'
            );
          if (node) richParagraphNodes.push(node);
          for (const run of tree.textRuns) {
            richParagraphStyles.add(run.textStyle);
            const spec = textSpecs.get(run.textStyle);
            if (
              Object.values(spec.values).some(
                value => (value.paragraphIndent ?? 0) !== 0
              )
            )
              throw new Error(
                'Nonzero paragraphIndent is restricted to plain TEXT styles.'
              );
          }
        }
        for (const child of tree.children || [])
          checkRichParagraphs(child, `${key}/${child.id || child.key}`);
      }
      for (const family of ready)
        for (const variant of family.variants)
          checkRichParagraphs(
            variant.tree,
            `family/${family.id}/variant/${variant.id}`
          );
      await preflightMangroveAssets(
        styleDoc,
        [...usedText],
        usedEffects.size > 0
      );
      const priorStyles = new Map(
        (await figma.getLocalTextStylesAsync()).map(style => [
          mgReadIdentity(style, 'mgStyleId'),
          style,
        ])
      );
      for (const key of richParagraphStyles)
        if ((priorStyles.get(key)?.paragraphIndent ?? 0) !== 0)
          throw new Error(
            'Existing rich style paragraph indent requires explicit migration.'
          );
      if (typeof figma.getFontFamilyVariationAxes !== 'function')
        throw new Error(
          'Rich text requires native font-axis discovery before import.'
        );
      const requestedFonts = [
        { family: 'Inter', style: 'Regular' },
        ...[...usedText].map(id => textSpecs.get(id).values[brandId].fontName),
      ];
      let fontInventory = available;
      const unresolvedDefaults = requestedFonts.some(input => {
        const tags = figma.getFontFamilyVariationAxes(input.family);
        return (
          Array.isArray(tags) &&
          tags.length > 0 &&
          !available.some(
            entry =>
              entry.fontName.family === input.family &&
              entry.fontName.style === input.style &&
              entry.fontName.variationSettings &&
              tags.every(tag =>
                Object.hasOwn(entry.fontName.variationSettings, tag)
              )
          )
        );
      });
      if (unresolvedDefaults) {
        if (
          typeof mgResolveNamedFontDefaults !== 'function' ||
          typeof mgAssertExperimentOperationTarget !== 'function'
        )
          throw new Error(
            'Rich native default axes are unresolved; guarded font preparation is required.'
          );
        result.fontPreparation = await mgResolveNamedFontDefaults(
          figma,
          requestedFonts,
          mgAssertExperimentOperationTarget
        );
        mgAssertExperimentOperationTarget();
        const preparation = result.fontPreparation;
        if (
          preparation.errors.length ||
          preparation.residualNodeIds.length ||
          preparation.unverifiedRemovalNodeIds.length ||
          !preparation.recordedSceneExact ||
          !preparation.recordedAssetsExact
        )
          throw new Error(
            `Named font preparation failed: ${preparation.errors.join('; ')}`
          );
        fontInventory = preparation.resolvedFonts.map(entry => ({
          fontName: entry.fontName,
        }));
      }
      const concreteFont = input =>
        mgRichText.resolveFontInput(
          input,
          fontInventory,
          figma.getFontFamilyVariationAxes(input.family)
        );
      const projected = new Map();
      for (const id of usedText) {
        const spec = textSpecs.get(id);
        const existing = priorStyles.get(id);
        projected.set(id, {
          key: id,
          pending: !existing,
          style: {
            type: 'TEXT',
            id: existing?.id ?? null,
            fontName: concreteFont(spec.values[brandId].fontName),
          },
        });
      }
      const byNativeId = new Map(
        [...variables.values()].map(entry => [entry.id, entry])
      );
      function nativeColor(entry, modeId, seen = new Set()) {
        if (!entry || entry.resolvedType !== 'COLOR' || seen.has(entry.id))
          throw new Error(
            'Rich COLOR alias is missing, wrong typed or cyclic.'
          );
        seen.add(entry.id);
        const value = entry.valuesByMode[modeId];
        return value?.type === 'VARIABLE_ALIAS'
          ? nativeColor(byNativeId.get(value.id), modeId, seen)
          : value;
      }
      const readState = node => mgReadIdentity(node, 'mgRichTextRunsV1');
      const writeState = (node, value) =>
        mgWriteIdentity(node, 'mgRichTextRunsV1', value);
      richContext = {
        figma,
        deferredStyles: true,
        modeIds: collection.modes.map(item => item.modeId),
        creationFont: concreteFont({ family: 'Inter', style: 'Regular' }),
        resolveStyle: id => projected.get(id),
        readState,
        writeState,
        resolveColor: key => {
          const entry = variable(key, 'COLOR');
          return {
            key,
            variable: entry,
            values: Object.fromEntries(
              collection.modes.map(item => [
                item.modeId,
                nativeColor(entry, item.modeId),
              ])
            ),
          };
        },
      };
      async function prepareTree(tree, key) {
        if (tree.textRuns !== undefined) {
          const richSpec = { ...tree, id: key };
          // The complete source-line group has already passed the separate guard.
          // Its metadata is not a rich-text style or a node property.
          if (
            MG_FROZEN_SOURCE_LINE_ENABLED &&
            Object.hasOwn(richSpec, 'sourceLine')
          ) {
            if (
              !frozenSourcePlans?.some(
                plan =>
                  plan.key === key && plan.characters === richSpec.characters
              )
            )
              throw new Error(
                'Frozen source lines require exact guarded source plans.'
              );
            delete richSpec.sourceLine;
          }
          richTextPlans.set(
            tree,
            await mgRichText.prepare(
              richSpec,
              richContext,
              owned.get(key) || null
            )
          );
        }
        for (const child of tree.children || [])
          await prepareTree(child, `${key}/${child.id || child.key}`);
      }
      for (const family of ready)
        for (const variant of family.variants)
          await prepareTree(
            variant.tree,
            `family/${family.id}/variant/${variant.id}`
          );
    } catch (error) {
      result.errors.push(reportError(error));
      result.audit.push({
        status: 'blocked-rich-text-preflight',
        reason: reportError(error),
      });
      return result;
    }
  }
  // Named-font and pure source preparation may await. Refuse newly edited
  // frozen copies before the first permanent style/image/scene phase. This
  // does not promise a transaction against edits after this last guard.
  if (
    MG_FROZEN_SOURCE_LINE_ENABLED &&
    !(await checkFrozenSourceLines('before-style-import'))
  )
    return result;
  if (MG_ALPHA_MASK_ENABLED && !checkAlphaMasks('before-style-import'))
    return result;
  if (
    MG_NATIVE_COLLECTIONS_TEXT_BUILDER_ENABLED &&
    nativeCollectionPlan?.version === 2
  )
    await checkNativeTextBeforeStyles();
  // Restrict effects to the recipes being prepared, avoiding unrelated updates.
  const styleDoc = {
    ...doc,
    styles: {
      text: doc.styles.text,
      effect: [...usedEffects].map(id => effectSpecs.get(id)),
    },
  };
  const styles = await importStyles(
    styleDoc,
    variables,
    brandId,
    [...usedText],
    usedEffects.size > 0
  );
  result.styles = styles;
  result.errors.push(...styles.errors);
  if (
    MG_NATIVE_COLLECTIONS_TEXT_BUILDER_ENABLED &&
    nativeCollectionPlan?.version === 2 &&
    styles.errors.length
  )
    return result;
  if (MG_NATIVE_COLLECTIONS_ENABLED && nativeCollectionPlan) {
    nativeCollectionState = mgNativeCollectionsPreflight(
      nativeCollectionPlan,
      await nativeCollectionImportSnapshot(assertNativeCollectionTarget),
      {
        readCollection: asset => {
          const value = mgReadIdentity(asset, 'mgNativeCollectionPlan');
          return value ? JSON.parse(value) : null;
        },
        readVariable: asset => mgReadIdentity(asset, 'mgId'),
      }
    );
    assertNativeCollectionTarget();
    if (
      MG_NATIVE_COLLECTIONS_TEXT_BUILDER_ENABLED &&
      nativeCollectionPlan.version === 2 &&
      nativeTextAssetSignature(nativeCollectionState) !== nativeTextAssetBefore
    )
      throw new Error(
        'Partition asset identities changed before scene construction.'
      );
    if (
      MG_NATIVE_COLLECTIONS_TEXT_BUILDER_ENABLED &&
      nativeCollectionPlan.version === 2 &&
      (await nativeTextInstanceSignature()) !== nativeTextInstanceBefore
    )
      throw new Error(
        'Partition instance main changed before scene construction.'
      );
    const currentOwned = page.findAll(node =>
      Boolean(mgReadIdentity(node, MG_KIT_KEY))
    );
    if (nativeSceneSignature(currentOwned) !== nativeSceneBefore)
      throw new Error(
        'Partition scene ownership or topology changed across preflight awaits.'
      );
    if (
      nativeCollectionState.neededCollections.length ||
      nativeCollectionState.neededVariables.length ||
      [...nativeCollectionState.neededModes.values()].some(
        modes => modes.length
      )
    )
      throw new Error('Partition assets changed before scene construction.');
    mgNativeCollectionsValidateValues(
      nativeCollectionPlan,
      nativeCollectionState
    );
    result.nativeCollections = {
      version: 1,
      ...(MG_NATIVE_COLLECTIONS_TEXT_BUILDER_ENABLED &&
      nativeCollectionPlan.version === 2
        ? { version: 2, profile: nativeCollectionPlan.profile }
        : {}),
      planId: nativeCollectionPlan.planId,
      collectionIds: Object.fromEntries(
        [...nativeCollectionState.collectionsBySourceId].map(([id, asset]) => [
          id,
          asset.id,
        ])
      ),
      modeIdsByCollectionId: Object.fromEntries(
        [...nativeCollectionState.modeIdsByCollectionId].map(([id, modes]) => [
          id,
          Object.fromEntries(modes),
        ])
      ),
      capacity: Object.fromEntries(nativeCollectionState.occupancy),
      reviewSpecimensDisabled: true,
      capability:
        MG_NATIVE_COLLECTIONS_TEXT_BUILDER_ENABLED &&
        nativeCollectionPlan.version === 2
          ? 'plain-text-instances-v1'
          : 'font-free FRAME v1 only',
    };
  }
  if (MG_SVG_SIZING_ENABLED && svgSizingScope && styles.errors.length) {
    result.audit.push({
      status: 'blocked-svg-sizing-style-import',
      reason: 'Style import failed; sized SVG scene construction refused.',
    });
    return result;
  }
  if (MG_TEXT_THICKNESS_ENABLED && textThicknessScope && styles.errors.length) {
    result.audit.push({
      status: 'blocked-text-thickness-style-import',
      reason:
        'Style import failed; underlined TEXT scene construction refused.',
    });
    return result;
  }
  const localText = new Map(
    (await figma.getLocalTextStylesAsync()).map(style => [
      mgReadIdentity(style, 'mgStyleId'),
      style,
    ])
  );
  const localEffects = new Map(
    (await figma.getLocalEffectStylesAsync()).map(style => [
      mgReadIdentity(style, 'mgStyleId'),
      style,
    ])
  );
  const failedStyleIds = new Set();
  for (const spec of [...textSpecs.values(), ...effectSpecs.values()]) {
    if (styles.errors.some(error => error.startsWith(`${spec.name}:`)))
      failedStyleIds.add(spec.id);
  }
  if (
    styles.errors.some(error => error.startsWith('Could not list text styles:'))
  )
    usedText.forEach(id => failedStyleIds.add(id));
  if (
    styles.errors.some(error =>
      error.startsWith('Could not list effect styles:')
    )
  )
    usedEffects.forEach(id => failedStyleIds.add(id));

  if (MG_RICH_TEXT_ENABLED && richTextScope) {
    try {
      if (styles.errors.length)
        throw new Error(
          'Rich scope style import failed; scene construction refused.'
        );
      for (const node of richParagraphNodes)
        if ((node.paragraphIndent ?? 0) !== 0)
          throw new Error('Rich paragraph indent changed after preflight.');
      const importedContext = {
        ...richContext,
        deferredStyles: false,
        resolveStyle: key => {
          const style = localText.get(key);
          if (
            richParagraphStyles.has(key) &&
            (style?.paragraphIndent ?? 0) !== 0
          )
            throw new Error(
              'Imported rich style paragraph indent must remain zero.'
            );
          return style ? { key, style } : undefined;
        },
      };
      for (const plan of richTextPlans.values())
        mgRichText.finalize(plan, importedContext);
    } catch (error) {
      result.errors.push(reportError(error));
      result.audit.push({
        status: 'blocked-rich-text-finalization',
        reason: reportError(error),
      });
      return result;
    }
  }

  function mark(node, key, isNew) {
    assertNativeCollectionTarget();
    if (isNew) {
      mgWriteIdentity(node, MG_KIT_KEY, key);
      owned.set(key, node);
      created.add(node.id);
      if (node.type === 'INSTANCE')
        node.findAll(() => true).forEach(child => created.add(child.id));
    } else if (!created.has(node.id)) updated.add(node.id);
    if (MG_NATIVE_COLLECTIONS_ENABLED && nativeCollectionPlan)
      mgWriteIdentity(
        node,
        'mgNativeScenePlan',
        JSON.stringify(
          MG_NATIVE_COLLECTIONS_TEXT_BUILDER_ENABLED &&
            nativeCollectionPlan.version === 2
            ? mgNativeCollectionsSceneLedger(nativeCollectionPlan)
            : { version: 1, planId: nativeCollectionPlan.planId }
        )
      );
    return node;
  }
  function matches(values, requested) {
    return Object.entries(requested).every(
      ([key, value]) => values?.[key] === value
    );
  }
  function getPropertyOwner(component) {
    return component.parent?.type === 'COMPONENT_SET'
      ? component.parent
      : component;
  }
  function ensureProperty(component, name, type, defaultValue) {
    const owner = getPropertyOwner(component);
    let map;
    try {
      map = JSON.parse(mgReadIdentity(owner, MG_KIT_PROPERTY_KEY) || '{}');
    } catch {
      throw new Error('Owned component property map is invalid.');
    }
    const definitions = owner.componentPropertyDefinitions;
    let key = map[name];
    if (key && definitions[key]?.type !== type)
      throw new Error(`Owned property ${name} was removed or changed type.`);
    if (!key) {
      key = Object.keys(definitions).find(
        item =>
          item.replace(/#[^#]+$/, '') === name &&
          definitions[item].type === type
      );
      key = key || owner.addComponentProperty(name, type, defaultValue);
      map[name] = key;
      mgWriteIdentity(owner, MG_KIT_PROPERTY_KEY, JSON.stringify(map));
    }
    return key;
  }
  function managedVisibilityReference(node, component) {
    const reference = node.componentPropertyReferences?.visible;
    if (!reference) return null;
    if (!component)
      throw new Error(
        `Cannot resolve visibility property owner at ${node.id}.`
      );
    const owner = getPropertyOwner(component);
    let map;
    try {
      map = JSON.parse(mgReadIdentity(owner, MG_KIT_PROPERTY_KEY) || '{}');
    } catch {
      throw new Error('Owned component property map is invalid.');
    }
    if (
      !map ||
      typeof map !== 'object' ||
      Array.isArray(map) ||
      !Object.values(map).includes(reference) ||
      owner.componentPropertyDefinitions[reference]?.type !== 'BOOLEAN'
    )
      throw new Error(
        `Visibility reference ${reference} at ${node.id} is not an owned BOOLEAN property. Explicit migration required.`
      );
    return reference;
  }
  function applyVisibility(spec, node, component) {
    const old = managedVisibilityReference(node, component);
    const expected = spec.visibilityProperty
      ? ensureProperty(
          component,
          spec.visibilityProperty,
          'BOOLEAN',
          spec.visible !== false
        )
      : null;
    if (old && old !== expected) {
      const references = { ...node.componentPropertyReferences };
      delete references.visible;
      node.componentPropertyReferences = references;
    }
    // Referenced main-layer writes can change the shared BOOLEAN default.
    // Compatible references own visibility. Assign source state flags only
    // after obsolete managed references have been detached.
    if (!old || old !== expected) node.visible = spec.visible !== false;
    if (expected && old !== expected)
      node.componentPropertyReferences = {
        ...(node.componentPropertyReferences || {}),
        visible: expected,
      };
  }
  function bind(node, field, name) {
    const bound = variable(name, field === 'visible' ? 'BOOLEAN' : 'FLOAT');
    const resolved = bound.resolveForConsumer(node);
    if (field === 'width' || field === 'height')
      node.resize(
        field === 'width' ? resolved.value : node.width,
        field === 'height' ? resolved.value : node.height
      );
    else
      // Opacity variables use percentages; native node properties use 0..1.
      node[field] =
        field === 'opacity'
          ? Math.max(0, Math.min(100, resolved.value)) / 100
          : resolved.value;
    node.setBoundVariable(field, bound);
  }
  function paint(node, field, name) {
    if (!name) {
      node[field] = [];
      return;
    }
    const bound = variable(name, 'COLOR');
    const color = bound.resolveForConsumer(node).value;
    const value = figma.variables.setBoundVariableForPaint(
      {
        type: 'SOLID',
        color: { r: color.r, g: color.g, b: color.b },
        opacity: color.a ?? 1,
      },
      'color',
      bound
    );
    node[field] = [value];
  }
  function setNumeric(node, field, value) {
    if (typeof value === 'string') bind(node, field, value);
    else if (typeof value === 'number') {
      node.setBoundVariable(field, null);
      node[field] = value;
    }
  }
  function applyLayout(node, layout = {}) {
    if (layout.mode && 'layoutMode' in node) {
      node.layoutMode = layout.mode;
      node.primaryAxisAlignItems =
        layout.justify || layout.primaryAlign || 'MIN';
      // Stretch is expressed through child FILL sizing, not an alignment enum.
      node.counterAxisAlignItems =
        layout.align === 'STRETCH'
          ? 'MIN'
          : layout.align || layout.counterAlign || 'MIN';
      node.clipsContent = Boolean(layout.clipsContent);
      if (layout.wrap !== undefined) node.layoutWrap = layout.wrap;
    }
    if (layout.padding) {
      setNumeric(node, 'paddingTop', layout.padding.block);
      setNumeric(node, 'paddingBottom', layout.padding.block);
      setNumeric(node, 'paddingLeft', layout.padding.inline);
      setNumeric(node, 'paddingRight', layout.padding.inline);
    }
    setNumeric(node, 'itemSpacing', layout.gap);
    setNumeric(node, 'counterAxisSpacing', layout.counterGap);
    setNumeric(node, 'minHeight', layout.minHeight);
    setNumeric(node, 'maxHeight', layout.maxHeight);
    setNumeric(node, 'minWidth', layout.minWidth);
    setNumeric(node, 'maxWidth', layout.maxWidth);
    const boundWidth =
      typeof layout.width === 'string' &&
      !['HUG', 'FILL'].includes(layout.width);
    const boundHeight =
      typeof layout.height === 'string' &&
      !['HUG', 'FILL'].includes(layout.height);
    const fixedWidth = typeof layout.width === 'number' || boundWidth;
    const fixedHeight = typeof layout.height === 'number' || boundHeight;
    const width = boundWidth
      ? variable(layout.width, 'FLOAT').resolveForConsumer(node).value
      : layout.width;
    const height = boundHeight
      ? variable(layout.height, 'FLOAT').resolveForConsumer(node).value
      : layout.height;
    const rootFill =
      node.parent?.type === 'COMPONENT_SET' && layout.width === 'FILL';
    // FILL requires an auto-layout parent. Main variants have a fixed specimen width.
    if (rootFill) node.resize(320, node.height);
    const previousHorizontal = node.layoutSizingHorizontal;
    const previousVertical = node.layoutSizingVertical;
    if (['HUG', 'FILL'].includes(layout.width))
      node.setBoundVariable('width', null);
    if (['HUG', 'FILL'].includes(layout.height))
      node.setBoundVariable('height', null);
    if (fixedWidth) node.setBoundVariable('width', null);
    if (fixedHeight) node.setBoundVariable('height', null);
    if (fixedWidth || fixedHeight) {
      node.resize(
        fixedWidth ? width : node.width,
        fixedHeight ? height : node.height
      );
      // resize fixes both axes in real Figma. Preserve an unspecified FILL/HUG
      // axis, especially for nested table rows and cells.
      if (!fixedWidth && !layout.width)
        node.layoutSizingHorizontal = previousHorizontal;
      if (!fixedHeight && !layout.height)
        node.layoutSizingVertical = previousVertical;
    }
    if (node.type === 'TEXT') {
      const wraps = layout.width === 'FILL' || fixedWidth;
      node.textAutoResize = wraps ? 'HEIGHT' : 'WIDTH_AND_HEIGHT';
      if (wraps)
        node.layoutSizingHorizontal =
          layout.width === 'FILL' ? 'FILL' : 'FIXED';
      else node.layoutSizingHorizontal = 'HUG';
      node.layoutSizingVertical = 'HUG';
    } else {
      if (layout.width)
        node.layoutSizingHorizontal =
          fixedWidth || rootFill ? 'FIXED' : layout.width;
      if (layout.height)
        node.layoutSizingVertical = fixedHeight ? 'FIXED' : layout.height;
    }
    if (boundWidth)
      node.setBoundVariable('width', variable(layout.width, 'FLOAT'));
    if (boundHeight)
      node.setBoundVariable('height', variable(layout.height, 'FLOAT'));
  }
  function applyAbsolute(spec, node, parent) {
    const absolute = spec.absolute;
    const offsetX = variable(absolute.offsetX, 'FLOAT').resolveForConsumer(
      node
    ).value;
    const offsetY = variable(absolute.offsetY, 'FLOAT').resolveForConsumer(
      node
    ).value;
    if (
      ![parent.width, parent.height, node.width, node.height].every(
        value => Number.isFinite(value) && value > 0
      ) ||
      ![offsetX, offsetY].every(Number.isFinite)
    )
      throw new Error(
        `Absolute geometry must be finite and positive at ${node.id}.`
      );
    for (const field of ['width', 'height']) {
      const expected =
        typeof spec.layout[field] === 'string'
          ? variable(spec.layout[field], 'FLOAT').resolveForConsumer(node).value
          : spec.layout[field];
      if (
        !Number.isFinite(expected) ||
        expected <= 0 ||
        Math.abs(node[field] - expected) > 1e-6
      )
        throw new Error(
          `Native absolute ${field} did not retain requested sizing at ${node.id}.`
        );
    }
    const start = MG_ABSOLUTE_START_ENABLED && absolute.horizontal === 'START';
    const x = start ? offsetX : parent.width - node.width + offsetX;
    const y = start ? offsetY : (parent.height - node.height) / 2 + offsetY;
    if (![x, y].every(Number.isFinite))
      throw new Error(`Absolute endpoint overflow at ${node.id}.`);
    node.constraints = start
      ? { horizontal: 'MIN', vertical: 'MIN' }
      : { horizontal: 'MAX', vertical: 'CENTER' };
    node.x = x;
    node.y = y;
    if (
      Math.abs(node.x - x) > 1e-6 ||
      Math.abs(node.y - y) > 1e-6 ||
      ![node.x, node.y].every(Number.isFinite)
    )
      throw new Error(
        `Native absolute position did not retain endpoint geometry at ${node.id}.`
      );
  }
  const built = new Map();
  async function focusDecorations(spec, parent, key) {
    const roles = ['outer', 'separator'];
    if (!MG_CONNECTOR_FOCUS || !spec.focusRing) {
      const retained = [];
      for (const role of roles) {
        const node = owned.get(`${key}/focus/${role}`);
        if (node) {
          node.visible = false;
          mark(node, `${key}/focus/${role}`, false);
          retained.push(node);
        }
      }
      return retained;
    }
    const ring = spec.focusRing;
    if (MG_COINCIDENT_FOCUS_ENABLED && coincidentFocus.has(spec)) {
      if (parent.type !== 'COMPONENT')
        throw new Error(
          'COINCIDENT_SCALE geometry is written only on canonical Segmented masters.'
        );
      const plan = coincidentFocus.get(spec);
      parent.clipsContent = false;
      parent.itemReverseZIndex = false;
      const decorations = [];
      for (const role of roles) {
        const id = `${key}/focus/${role}`;
        let node = owned.get(id);
        if (node && node.type !== 'RECTANGLE')
          throw new Error(`Native focus outline ${id} changed type.`);
        const fresh = !node;
        node = node || figma.createRectangle();
        mark(node, id, fresh);
        if (node.parent !== parent) parent.appendChild(node);
        node.name =
          role === 'outer'
            ? 'mg-focus-ring / coloured outline'
            : 'mg-focus-ring / neutral separator';
        node.visible = true;
        node.opacity = 1;
        node.layoutPositioning = 'ABSOLUTE';
        node.constraints = { horizontal: 'SCALE', vertical: 'SCALE' };
        node.fills = [];
        await node.setEffectStyleIdAsync('');
        node.effects = [];
        node.strokeAlign = 'OUTSIDE';
        node.strokeJoin = 'MITER';
        node.resize(parent.width, parent.height);
        node.x = 0;
        node.y = 0;
        paint(
          node,
          'strokes',
          role === 'outer' ? ring.color : ring.separatorColor
        );
        bind(
          node,
          'strokeWeight',
          role === 'outer' ? ring.outerStroke : ring.offset
        );
        node.setBoundVariable('cornerRadius', null);
        for (const [field, name] of Object.entries(ring.cornerBindings))
          bind(node, field, name);
        decorations.push(node);
      }
      result.audit.push({
        nodeId: parent.id,
        status: 'native-focus-outline',
        renderer: 'COINCIDENT_SCALE',
        rectangleIds: decorations.map(node => node.id),
        geometry: {
          offset: plan.offset,
          width: plan.width,
          outerStroke: plan.outerStroke,
        },
        sourceBindings: ring,
        paintOrder: {
          itemReverseZIndex: parent.itemReverseZIndex,
          roles: roles.slice(),
        },
        outlines: decorations.map((node, index) => ({
          nodeId: node.id,
          role: roles[index],
          bounds: {
            x: node.x,
            y: node.y,
            width: node.width,
            height: node.height,
          },
          constraints: node.constraints,
          strokeWeight: node.strokeWeight,
          strokeAlign: node.strokeAlign,
          strokeJoin: node.strokeJoin,
          corners: Object.fromEntries(
            Object.keys(ring.cornerBindings).map(field => [field, node[field]])
          ),
          bindings: node.boundVariables,
        })),
        limitation:
          'Coincident SCALE outlines retain source strokes and per-corner aliases; ordinary reimport/rebuild is required when token values change. Matched raster and joined middle-focus occlusion need separate native acceptance.',
      });
      return decorations;
    }
    const number = name =>
      variable(name, 'FLOAT').resolveForConsumer(parent).value;
    const offset = number(ring.offset);
    const width = number(ring.width);
    const radius = number(ring.radius);
    const outerRadius = ring.outerRadius
      ? number(ring.outerRadius)
      : radius + offset;
    if (
      ![offset, width, radius, outerRadius].every(
        value => Number.isFinite(value) && value >= 0
      )
    )
      throw new Error(`Invalid native focus outline dimensions at ${key}`);
    parent.clipsContent = false;
    const decorations = [];
    for (const role of roles) {
      const id = `${key}/focus/${role}`;
      let node = owned.get(id);
      if (node && node.type !== 'RECTANGLE')
        throw new Error(`Native focus outline ${id} changed type.`);
      const fresh = !node;
      node = node || figma.createRectangle();
      mark(node, id, fresh);
      if (node.parent !== parent) parent.appendChild(node);
      node.name =
        role === 'outer'
          ? 'mg-focus-ring / coloured outline'
          : 'mg-focus-ring / neutral separator';
      node.visible = true;
      node.layoutPositioning = 'ABSOLUTE';
      node.constraints = { horizontal: 'STRETCH', vertical: 'STRETCH' };
      node.fills = [];
      await node.setEffectStyleIdAsync('');
      node.effects = [];
      node.strokeAlign = 'OUTSIDE';
      if (role === 'outer') {
        node.resize(parent.width + offset * 2, parent.height + offset * 2);
        node.x = -offset;
        node.y = -offset;
        paint(node, 'strokes', ring.color);
        bind(node, 'strokeWeight', ring.width);
        if (ring.outerRadius) bind(node, 'cornerRadius', ring.outerRadius);
        else {
          node.setBoundVariable('cornerRadius', null);
          node.cornerRadius = outerRadius;
        }
      } else {
        node.resize(parent.width, parent.height);
        node.x = 0;
        node.y = 0;
        paint(node, 'strokes', ring.separatorColor);
        bind(node, 'strokeWeight', ring.offset);
        bind(node, 'cornerRadius', ring.radius);
      }
      decorations.push(node);
    }
    result.audit.push({
      nodeId: parent.id,
      status: 'native-focus-outline',
      rectangleIds: decorations.map(node => node.id),
      geometry: { offset, width, radius, outerRadius },
      sourceBindings: ring,
      limitation:
        'Absolute outline offsets follow source values at build time; stretch constraints preserve resizing. Rebuild if the focus offset changes.',
    });
    return decorations;
  }
  async function treeNode(spec, parent, component, key, rootNode) {
    if (MG_SVG_ENABLED && spec.type === 'SVG') {
      const plan = svgPlans.get(spec);
      let node = owned.get(key);
      const fresh = !node;
      if (fresh) {
        try {
          node = figma.createNodeFromSvg(plan.importedMarkup);
          if (
            node.type !== 'FRAME' ||
            !Number.isFinite(node.width) ||
            node.width <= 0 ||
            !Number.isFinite(node.height) ||
            node.height <= 0 ||
            (node.width !== plan.width &&
              node.width !== Math.fround(plan.width)) ||
            (node.height !== plan.height &&
              node.height !== Math.fround(plan.height))
          )
            throw new Error(
              'native SVG importer did not preserve the explicit viewBox viewport. Verify native SVG acceptance before using this asset; path-bound scaling is unsupported.'
            );
          for (const field of Object.keys(spec.svg.monochrome || {}))
            mgSvgMonochrome(node, field);
          if (MG_SVG_SIZING_ENABLED && plan.sizing)
            mgSvgSizingNativePlan(node, plan.sizing, variable);
          plan.sourceOpacity = node.opacity;
        } catch (error) {
          if (node && !node.removed) node.remove();
          throw new Error(
            `SVG ${plan.assetId} import failed: ${reportError(error)}`
          );
        }
      }
      mark(node, key, fresh);
      const descendants = node.findAll(() => true);
      for (const child of descendants)
        (fresh ? created : updated).add(child.id);
      if (node.parent !== parent) parent.appendChild(node);
      node.name = spec.name || spec.id;
      applyVisibility(spec, node, component);
      // resize only changes a frame viewport. rescale also scales source paths,
      // stroke widths and positions. Equal-size repeats perform no rescale.
      if (MG_SVG_SIZING_ENABLED && plan.sizing) {
        const sizingResult = mgApplySvgSizing(
          mgSvgSizingNativePlan(node, plan.sizing, variable)
        );
        result.audit.push({
          nodeId: node.id,
          status: 'source-svg-sizing',
          ...sizingResult,
        });
      } else {
        let scale = spec.layout.width / node.width;
        while (scale < 0.01) {
          node.rescale(0.01);
          scale /= 0.01;
        }
        if (Math.abs(scale - 1) > 1e-12) node.rescale(scale);
        node.layoutSizingHorizontal = node.layoutSizingVertical = 'FIXED';
      }
      if (spec.position) {
        if (parent.layoutMode !== 'NONE') node.layoutPositioning = 'ABSOLUTE';
        node.x = spec.position.x;
        node.y = spec.position.y;
      }
      for (const field of ['opacity', 'visible']) {
        if (spec.bindings?.[field]) bind(node, field, spec.bindings[field]);
        else node.setBoundVariable(field, null);
      }
      if (!spec.bindings?.opacity) node.opacity = plan.sourceOpacity;
      for (const [field, name] of Object.entries(spec.svg.monochrome || {})) {
        const bound = variable(name, 'COLOR');
        for (const child of descendants) {
          if (!Array.isArray(child[field])) continue;
          child[field] = child[field].map(paint =>
            paint.type === 'SOLID' &&
            paint.visible !== false &&
            (paint.opacity ?? 1) > 0
              ? figma.variables.setBoundVariableForPaint(paint, 'color', bound)
              : paint
          );
        }
      }
      mgWriteIdentity(
        node,
        MG_SVG_KEY,
        JSON.stringify({
          ...(MG_SVG_SIZING_ENABLED && plan.sizing
            ? { sizing: plan.sizing }
            : {}),
          assetId: plan.assetId,
          hash: plan.hash,
          markup: plan.markup,
          paintPolicy: plan.paintPolicy,
          sourceOpacity: plan.sourceOpacity,
          topology: mgSvgTopology(node),
          geometry: mgSvgGeometry(node),
        })
      );
      return node;
    }
    let node = rootNode || owned.get(key);
    const fresh = !node;
    if (node && !rootNode && node.type !== spec.type)
      throw new Error(
        `Node type changed at ${key}. Preserve the old node and resolve the recipe.`
      );
    if (!node) {
      if (spec.type === 'TEXT') node = figma.createText();
      else if (spec.type === 'FRAME') node = figma.createFrame();
      else if (MG_CONNECTOR_ELLIPSE && spec.type === 'ELLIPSE') node = figma.createEllipse();
      else {
        const dependency = built.get(spec.family);
        const variant = dependency?.variants.find(item =>
          matches(item.recipe.properties, spec.variant || {})
        );
        if (!variant)
          throw new Error(`Dependency ${spec.family} is not available.`);
        node = variant.node.createInstance();
      }
      mark(node, key, true);
    } else mark(node, key, false);
    if (node.type === 'TEXT') await loadNodeFonts(node);
    if (node.parent !== parent) parent.appendChild(node);
    // A variant name must remain valid while reading its set's property definitions.
    if (!rootNode) node.name = spec.name || spec.id || spec.type;
    applyVisibility(spec, node, component);
    if (MG_ABSOLUTE_ENABLED && spec.absolute)
      node.layoutPositioning = 'ABSOLUTE';
    if (
      spec.type === 'TEXT' &&
      !(MG_RICH_TEXT_ENABLED && richTextPlans.has(spec))
    ) {
      const style = localText.get(spec.textStyle);
      if (!style)
        throw new Error(`Text style ${spec.textStyle} did not import.`);
      await figma.loadFontAsync(style.fontName);
      if (MG_DIRECT_TEXT_ENABLED && directText.has(spec)) {
        await node.setTextStyleIdAsync('');
        node.fontName = { ...style.fontName };
        node.fontSize = style.fontSize;
        node.lineHeight = { ...style.lineHeight };
        // Copy the imported template, including native defaults, without
        // reattaching the shared style that couples linked state range paints.
        for (const field of [
          'letterSpacing',
          'paragraphSpacing',
          'paragraphIndent',
          'textCase',
        ])
          if (style[field] !== undefined)
            node[field] =
              typeof style[field] === 'object'
                ? { ...style[field] }
                : style[field];
      } else await node.setTextStyleIdAsync(style.id);
      node.characters = spec.characters || '';
      node.textAlignHorizontal = spec.textAlign || 'LEFT';
    }
    if (spec.type !== 'INSTANCE') {
      if (MG_CONNECTOR_ELLIPSE && spec.type === 'ELLIPSE')
        node.arcData =
          MG_ARC_ENABLED && spec.arcData
            ? mgEllipseArcPlan(spec)
            : { startingAngle: 0, endingAngle: 2 * Math.PI, innerRadius: 0 };
      if (spec.layout?.mode && 'layoutMode' in node)
        node.layoutMode = spec.layout.mode;
      if ('fills' in node && !(MG_RICH_TEXT_ENABLED && richTextPlans.has(spec)))
        paint(node, 'fills', spec.fill);
      if (MG_CONNECTOR_MEDIA && imagePlans.has(spec)) {
        const image = imagePlans.get(spec);
        if (!imageHashes.has(image.assetId))
          imageHashes.set(image.assetId, figma.createImage(image.bytes).hash);
        node.fills = [
          {
            type: 'IMAGE',
            imageHash: imageHashes.get(image.assetId),
            scaleMode: image.scaleMode,
          },
        ];
        node.clipsContent = true;
      }
      if (MG_CONNECTOR_MEDIA && gradientPlans.has(spec)) {
        node.fills = gradientPlans.get(spec).layers.map(layer => ({
          type: 'GRADIENT_LINEAR',
          gradientTransform: layer.transform,
          gradientStops: layer.stops.map(stop => {
            const role = variable(stop.color, 'COLOR');
            const color = role.resolveForConsumer(node).value;
            return {
              position: stop.position,
              color: { r: color.r, g: color.g, b: color.b, a: color.a ?? 1 },
              boundVariables: {
                color: { type: 'VARIABLE_ALIAS', id: role.id },
              },
            };
          }),
        }));
      }
      if ('strokes' in node) paint(node, 'strokes', spec.stroke);
      node.strokeAlign = spec.strokeAlign || 'INSIDE';
      if ('strokesIncludedInLayout' in node && node.layoutMode !== 'NONE')
        node.strokesIncludedInLayout = spec.strokesIncludedInLayout !== false;
      for (const oldField of Object.keys(node.boundVariables || {})) {
        if (
          allowedBindings.has(oldField) &&
          !(oldField in (spec.bindings || {}))
        )
          node.setBoundVariable(oldField, null);
      }
      for (const [field, name] of Object.entries(spec.bindings || {}))
        bind(node, field, name);
      if (spec.effectStyle) {
        const style = localEffects.get(spec.effectStyle);
        if (!style)
          throw new Error(`Effect style ${spec.effectStyle} did not import.`);
        await node.setEffectStyleIdAsync(style.id);
        // Spread on frames/components requires a visible fill and clipping.
        if (['FRAME', 'COMPONENT'].includes(node.type))
          node.clipsContent = true;
      } else {
        await node.setEffectStyleIdAsync('');
        node.effects = [];
      }
      if (spec.textProperty)
        node.componentPropertyReferences = {
          ...(node.componentPropertyReferences || {}),
          characters: ensureProperty(
            component,
            spec.textProperty,
            'TEXT',
            spec.characters || ''
          ),
        };
    } else {
      const dependency = built.get(spec.family);
      const variant = dependency.variants.find(item =>
        matches(item.recipe.properties, spec.variant || {})
      );
      const currentMain = await node.getMainComponentAsync();
      if (currentMain?.id !== variant.node.id) node.swapComponent(variant.node);
      await loadNodeFonts(node);
      const overrides = {};
      for (const [name, value] of Object.entries(spec.overrides || {})) {
        const property = Object.keys(node.componentProperties).find(
          item => item.replace(/#[^#]+$/, '') === name
        );
        if (!property)
          throw new Error(`Instance property ${name} is unavailable.`);
        overrides[property] = value;
      }
      if (Object.keys(overrides).length) node.setProperties(overrides);
      // These are primary nested instances in the owned main component.
      // Review descendants inherit exposure; do not write their inherited flag.
      node.isExposedInstance = Boolean(spec.expose);
      // Explicit instance bindings override only the declared inherited fields.
      for (const [field, name] of Object.entries(spec.bindings || {}))
        bind(node, field, name);
      // Contextual CSS colours stay on the native instance; geometry and identity
      // continue to come from its source component. Never detach nested actions.
      if (spec.appearance) {
        if (spec.appearance.fill) paint(node, 'fills', spec.appearance.fill);
        if (spec.appearance.stroke)
          paint(node, 'strokes', spec.appearance.stroke);
        if (spec.appearance.labelFill) {
          const labels = node
            .findAllWithCriteria({ types: ['TEXT'] })
            .filter(
              child =>
                child.componentPropertyReferences?.characters?.replace(
                  /#[^#]+$/,
                  ''
                ) === 'Label'
            );
          if (labels.length !== 1)
            throw new Error(
              'Contextual label fill requires exactly one Label text node.'
            );
          paint(labels[0], 'fills', spec.appearance.labelFill);
          if (fresh) created.add(labels[0].id);
          else updated.add(labels[0].id);
        }
      }
    }
    applyLayout(node, spec.layout);
    // Apply wrapping and decoration after character property references and
    // sizing. Shared styles carry them for editable consumer text as well.
    if (MG_RICH_TEXT_ENABLED && richTextPlans.has(spec)) {
      const audit = await mgRichText.apply(richTextPlans.get(spec), node);
      node.textAlignHorizontal = spec.textAlign || 'LEFT';
      if (spec.textWrap !== undefined) node.textWrapStyle = spec.textWrap;
      result.audit.push({
        ...audit,
        status: 'rich-text-applied',
        identity: key,
      });
    } else if (spec.type === 'TEXT') {
      if (spec.textWrap !== undefined) node.textWrapStyle = spec.textWrap;
      node.textDecoration =
        spec.textDecoration !== undefined
          ? spec.textDecoration
          : localText.get(spec.textStyle)?.textDecoration || 'NONE';
      if (
        MG_CONNECTOR_TEXT_OFFSET && spec.textDecorationOffset !== undefined &&
        node.textDecoration === 'UNDERLINE'
      )
        node.textDecorationOffset = { ...spec.textDecorationOffset };
      if (MG_TEXT_THICKNESS_ENABLED && textThicknessPlans.has(spec))
        mgApplyTextThickness(
          mgNativeTextThicknessPlan(node, textThicknessPlans.get(spec))
        );
      if (MG_DIRECT_TEXT_ENABLED && directText.has(spec)) {
        // Typed aliases follow all literals, property references and layout.
        // This ordering is proven only by the isolated native TOC diagnostic.
        for (const [field, native] of Object.entries(directText.get(spec)))
          node.setBoundVariable(field, native);
        paint(node, 'fills', spec.fill);
        node.setRangeFills(0, node.characters.length, node.fills);
      }
    }
    if (spec.labelSizing === 'FILL') {
      const labels = node
        .findAllWithCriteria({ types: ['TEXT'] })
        .filter(
          child =>
            child.componentPropertyReferences?.characters?.replace(
              /#[^#]+$/,
              ''
            ) === 'Label'
        );
      if (labels.length !== 1)
        throw new Error(
          'Instance labelSizing requires exactly one Label text node.'
        );
      labels[0].textAutoResize = 'HEIGHT';
      labels[0].layoutSizingHorizontal = 'FILL';
      labels[0].layoutSizingVertical = 'HUG';
      labels[0].textAlignHorizontal = 'CENTER';
    }
    if (spec.effectStyle && ['FRAME', 'COMPONENT'].includes(node.type))
      node.clipsContent = true;
    if (spec.type === 'FRAME') {
      const expected = [];
      for (const child of spec.children || []) {
        const childKey = `${key}/${child.id || child.key}`;
        const childNode = await treeNode(child, node, component, childKey);
        expected.push(childNode);
      }
      const decorations = await focusDecorations(spec, node, key);
      expected.unshift(...decorations);
      expected.forEach((child, index) => {
        if (node.children[index] !== child) node.insertChild(index, child);
      });
      // ABSOLUTE excludes children from layout before dimensions are read.
      // Position only after child construction/reordering has settled the parent.
      if (MG_ABSOLUTE_ENABLED)
        for (const child of spec.children || []) {
          if (child.absolute)
            applyAbsolute(
              child,
              owned.get(`${key}/${child.id || child.key}`),
              node
            );
        }
      if (MG_ALPHA_MASK_ENABLED && alphaMaskOwners.has(spec)) {
        const record = alphaMaskOwners.get(spec);
        mgAlphaMaskDocumentValues(record.plan, doc);
        mgAlphaMaskNativeValues(
          record.plan,
          collection.modes.map(item => item.modeId),
          alphaMaskResolve
        );
        mgApplyAlphaMask(
          mgNativeAlphaMaskPlan(
            owned.get(record.keys.mask),
            node,
            owned.get(record.keys.content),
            record.plan,
            alphaMaskIdentity(record)
          )
        );
      }
      // Retain user-owned additions. Report obsolete importer-owned children for review.
      for (const child of node.children) {
        if (mgReadIdentity(child, MG_KIT_KEY) && !expected.includes(child))
          result.audit.push({
            nodeId: child.id,
            status: 'retained-obsolete-child',
            key: mgReadIdentity(child, MG_KIT_KEY),
          });
      }
    }
    if (
      MG_CONNECTOR_FRAME_POSITION && spec.type === 'FRAME' &&
      spec.position &&
      parent.layoutMode === 'NONE'
    ) {
      node.x = spec.position.x;
      node.y = spec.position.y;
    }
    return node;
  }
  const surviving = ready.filter(family => {
    let failure;
    for (const variant of family.variants)
      treeWalk(variant.tree, tree => {
        if (
          tree.textStyle &&
          (MG_RICH_TEXT_ENABLED && tree.textRuns !== undefined
            ? tree.textRuns.some(
                run =>
                  !localText.has(run.textStyle) ||
                  failedStyleIds.has(run.textStyle)
              )
            : !localText.has(tree.textStyle) ||
              failedStyleIds.has(tree.textStyle))
        )
          failure = `Missing text style ${tree.textStyle}`;
        if (
          tree.effectStyle &&
          (!localEffects.has(tree.effectStyle) ||
            failedStyleIds.has(tree.effectStyle))
        )
          failure = `Missing effect style ${tree.effectStyle}`;
      });
    if (failure) {
      blocked.add(family.id);
      result.errors.push(`${family.name}: ${failure}`);
      result.audit.push({
        family: family.id,
        status: 'blocked',
        reason: failure,
      });
    }
    return !failure;
  });
  if (!surviving.length) return result;
  function container(key, name, width) {
    let frame = owned.get(key);
    if (frame && frame.type !== 'FRAME')
      throw new Error(`${name} has changed type.`);
    const fresh = !frame;
    frame = frame || figma.createFrame();
    mark(frame, key, fresh);
    const parent =
      typeof mgLayoutContainerParent === 'function'
        ? mgLayoutContainerParent(key)
        : page;
    if (frame.parent !== parent) parent.appendChild(frame);
    frame.name =
      organized &&
      mgReadIdentity(owned.get('layout/start'), 'mgLayoutVersion') === '2'
        ? `Operational staging / ${key}`
        : name;
    frame.layoutMode = 'VERTICAL';
    frame.resize(organized ? frame.width : width, Math.max(frame.height, 100));
    frame.primaryAxisSizingMode = 'AUTO';
    frame.counterAxisSizingMode = 'FIXED';
    frame.paddingTop =
      frame.paddingBottom =
      frame.paddingLeft =
      frame.paddingRight =
        32;
    frame.itemSpacing = 32;
    frame.clipsContent = false;
    frame.fills = [];
    if (fresh) {
      const right = Math.max(
        0,
        ...page.children
          .filter(item => item !== frame)
          .map(item => item.x + item.width)
      );
      frame.x = right + 160;
      frame.y = 160;
    }
    if (MG_NATIVE_COLLECTIONS_ENABLED && nativeCollectionState)
      mgNativeCollectionsApplyModes(frame, nativeCollectionState, brandId, [
        ...nativeCollectionPlan.collectionById.keys(),
      ]);
    else if (frame.explicitVariableModes[collection.id] !== mode.modeId)
      frame.setExplicitVariableModeForCollection(collection, mode.modeId);
    return frame;
  }
  const main = container('main', 'Mangrove / Main components', 1200);
  const review = container('review', 'Mangrove / Review', 800);
  result.reviewRootId = review.id;
  paint(review, 'fills', 'color/neutral-0');

  for (const family of surviving) {
    if (dependencies(family).some(id => !built.has(id))) {
      result.errors.push(`${family.name}: a dependent family did not build.`);
      continue;
    }
    const familyNew = [];
    try {
      const familyKey = `family/${family.id}`;
      let set = owned.get(familyKey);
      let pendingFirst;
      if (!set) {
        pendingFirst = figma.createComponent();
        const first = family.variants[0];
        pendingFirst.name = first.name;
        mark(pendingFirst, `${familyKey}/variant/${first.id}`, true);
        familyNew.push(pendingFirst);
        main.appendChild(pendingFirst);
        set = figma.combineAsVariants([pendingFirst], main);
        mark(set, familyKey, true);
        familyNew.push(set);
      } else mark(set, familyKey, false);
      set.name = family.name;
      set.description =
        doc.kitGuidance?.families?.find(item => item.id === family.id)
          ?.description ||
        family.description ||
        `Reusable ${family.name} controls. Source: ${sourceLabel(family)}`;
      set.layoutMode = 'NONE';
      set.clipsContent = false;
      set.fills = [];
      for (const [name, property] of Object.entries(
        family.optionalProperties || {}
      ))
        ensureProperty(set, name, 'BOOLEAN', property.defaultValue);
      const variants = [];
      for (const recipe of family.variants) {
        const key = `${familyKey}/variant/${recipe.id}`;
        let component = owned.get(key);
        if (component && component.type !== 'COMPONENT')
          throw new Error(`Variant ${key} changed type.`);
        if (!component) {
          component = figma.createComponent();
          mark(component, key, true);
          familyNew.push(component);
        }
        if (component.parent !== set) set.appendChild(component);
        component.name =
          recipe.name ||
          Object.entries(recipe.properties)
            .map(([name, value]) => `${name}=${value}`)
            .join(', ');
        component.description =
          doc.kitGuidance?.families?.find(item => item.id === family.id)
            ?.description ||
          family.description ||
          `Source: ${sourceLabel(family)}`;
        await treeNode(recipe.tree, set, component, key, component);
        // Tree labels are useful internally; the root name must encode variants.
        component.name =
          recipe.name ||
          Object.entries(recipe.properties)
            .map(([name, value]) => `${name}=${value}`)
            .join(', ');
        variants.push({ node: component, recipe });
      }
      // Scoped connector batches retain prior variants. Include every retained
      // component in the main grid so later batches cannot overlap them.
      const layoutVariants = set.children.filter(
        node => node.type === 'COMPONENT'
      );
      if (typeof mgLayoutGrid === 'function') {
        mgLayoutGrid(set, family);
      } else {
        const columns = Math.min(3, layoutVariants.length);
        const cellWidth =
          Math.max(...layoutVariants.map(node => node.width)) + 48;
        const cellHeight =
          Math.max(...layoutVariants.map(node => node.height)) + 48;
        layoutVariants.forEach((node, index) => {
          node.x = 24 + (index % columns) * cellWidth;
          node.y = 24 + Math.floor(index / columns) * cellHeight;
        });
        set.resizeWithoutConstraints(
          24 + columns * cellWidth,
          24 + Math.ceil(layoutVariants.length / columns) * cellHeight
        );
      }
      built.set(family.id, { set, variants });
      result.families.push({
        id: family.id,
        setId: set.id,
        variantIds: variants.map(item => ({
          id: item.recipe.id,
          nodeId: item.node.id,
        })),
        propertyIds: Object.keys(set.componentPropertyDefinitions),
      });
      result.audit.push({
        family: family.id,
        status: 'built',
        variantCount: variants.length,
      });
    } catch (error) {
      result.errors.push(`${family.name}: ${reportError(error)}`);
      result.audit.push({
        family: family.id,
        status: 'failed',
        reason: reportError(error),
        existingChangesRetained: !familyNew.some(
          node => node.type === 'COMPONENT_SET'
        ),
      });
      // Remove only objects created by this failed family, never existing components.
      for (const node of familyNew.reverse()) {
        if (!node.removed) {
          if ('findAll' in node)
            node
              .findAll(() => true)
              .forEach(child => {
                created.delete(child.id);
                updated.delete(child.id);
              });
          created.delete(node.id);
          updated.delete(node.id);
          node.remove();
        }
      }
      for (const [key, node] of owned)
        if (node.removed) {
          owned.delete(key);
          created.delete(node.id);
          updated.delete(node.id);
        }
    }
  }

  const reviewPadding = 8;
  async function reviewFrame(key, name, parent, width) {
    let frame = owned.get(key);
    const fresh = !frame;
    if (frame && frame.type !== 'FRAME')
      throw new Error(`Review node ${key} changed type.`);
    frame = frame || figma.createFrame();
    mark(frame, key, fresh);
    const destination =
      typeof mgLayoutReviewParent === 'function'
        ? mgLayoutReviewParent(key, parent)
        : parent;
    if (frame.parent !== destination) destination.appendChild(frame);
    frame.name = name;
    frame.layoutMode = 'VERTICAL';
    frame.resize(width, Math.max(frame.height, 40));
    frame.primaryAxisSizingMode = 'AUTO';
    frame.counterAxisSizingMode = 'FIXED';
    frame.paddingTop =
      frame.paddingBottom =
      frame.paddingLeft =
      frame.paddingRight =
        reviewPadding;
    frame.itemSpacing = 12;
    frame.clipsContent = false;
    frame.fills = [];
    return frame;
  }
  async function reviewLabel(key, text, parent) {
    let node = owned.get(key);
    const fresh = !node;
    if (node && node.type !== 'TEXT')
      throw new Error(`Review label ${key} changed type.`);
    node = node || figma.createText();
    mark(node, key, fresh);
    await loadNodeFonts(node);
    if (node.parent !== parent) parent.appendChild(node);
    const fontFamily = variable('font-family/text', 'STRING');
    const font = {
      family: fontFamily.resolveForConsumer(parent).value,
      style: 'Regular',
    };
    await load(font);
    node.fontName = font;
    node.setBoundVariable('fontFamily', fontFamily);
    bind(node, 'fontSize', 'font-size/300');
    node.textAutoResize = 'HEIGHT';
    node.characters = text;
    node.resize(
      Math.max(1, parent.width - parent.paddingLeft - parent.paddingRight),
      Math.max(1, node.height)
    );
    node.layoutSizingHorizontal = 'FILL';
    node.layoutSizingVertical = 'HUG';
    node.name = text;
    paint(node, 'fills', 'color/neutral-900');
    return node;
  }
  async function intrinsicReviewGeometry(instance, master) {
    const current = await instance.getMainComponentAsync();
    if (current?.id !== master.id)
      throw new Error(
        'Variant review geometry refresh refused a changed consumer variant.'
      );
    const horizontal = master.layoutSizingHorizontal;
    const vertical = master.layoutSizingVertical;
    if (
      !['HUG', 'FIXED'].includes(horizontal) ||
      !['HUG', 'FIXED'].includes(vertical) ||
      !Number.isFinite(master.width) ||
      master.width <= 0 ||
      !Number.isFinite(master.height) ||
      master.height <= 0
    )
      throw new Error(
        'Variant review master sizing must be HUG or positive fixed geometry.'
      );
    instance.setBoundVariable('width', null);
    instance.setBoundVariable('height', null);
    if (horizontal === 'FIXED' || vertical === 'FIXED')
      instance.resize(
        horizontal === 'FIXED' ? master.width : instance.width,
        vertical === 'FIXED' ? master.height : Math.max(1, instance.height)
      );
    instance.layoutSizingHorizontal = horizontal;
    instance.layoutSizingVertical = vertical;
    if (
      instance.layoutSizingHorizontal !== horizontal ||
      instance.layoutSizingVertical !== vertical ||
      (horizontal === 'FIXED' &&
        (!Number.isFinite(instance.width) ||
          Math.abs(instance.width - master.width) > 0.01)) ||
      (vertical === 'FIXED' && Math.abs(instance.height - master.height) > 0.01)
    )
      throw new Error(
        'Native variant review sizing did not retain the requested geometry.'
      );
  }
  for (const [id, family] of built) {
    if (MG_NATIVE_COLLECTIONS_ENABLED && nativeCollectionPlan) continue;
    if (!chosen.has(id)) continue;
    try {
      const reviewOptions = families.get(id)?.review || {};
      const section = await reviewFrame(
        `review/${id}`,
        family.set.name,
        review,
        736
      );
      await reviewLabel(`review/${id}/title`, family.set.name, section);
      const grid = await reviewFrame(
        `review/${id}/grid`,
        'States and resizing examples',
        section,
        720
      );
      grid.layoutMode = 'HORIZONTAL';
      grid.layoutWrap = 'WRAP';
      grid.resize(720, grid.height);
      grid.primaryAxisSizingMode = 'FIXED';
      grid.counterAxisSizingMode = 'AUTO';
      grid.itemSpacing = 16;
      grid.counterAxisSpacing = 16;
      grid.primaryAxisAlignItems = 'MIN';
      grid.counterAxisAlignItems = 'MIN';
      const specimens = family.variants.map(item => ({
        id: item.recipe.id,
        name: item.recipe.name,
        variant: item,
        width:
          reviewOptions.width ||
          (typeof item.recipe.tree.layout?.width === 'number'
            ? item.recipe.tree.layout.width
            : undefined),
      }));
      if (reviewOptions.genericLabels !== false)
        specimens.push({
          id: 'long-label',
          name: 'Long label, editable instance',
          variant: family.variants[0],
          label: 'A longer Mangrove label to check resizing and wrapping',
        });
      if (reviewOptions.genericLabels !== false)
        specimens.push({
          id: 'narrow',
          name: 'Narrow layout, 240px',
          variant: family.variants[0],
          width: 240,
          label: 'A longer Mangrove label in a narrow layout',
        });
      specimens.push(
        ...(reviewOptions.specimens || []).map(specimen => ({
          ...specimen,
          variant: family.variants.find(item =>
            matches(item.recipe.properties, specimen.variant)
          ),
        }))
      );
      for (const specimen of specimens) {
        const key = `review/${id}/specimen/${specimen.id}`;
        const preserveVariantSizing =
          MG_INTRINSIC_REVIEW_ENABLED &&
          reviewOptions.preserveVariantSizing === true &&
          specimen.id === specimen.variant.recipe.id;
        const surface = MG_CONNECTOR_REVIEW_SURFACES && (specimen.surface ?? reviewOptions.variantSurfaces?.[specimen.variant.recipe.id]);
        // A preserved FIXED master can resolve a token width absent from numeric recipes.
        const row = await reviewFrame(
          key,
          specimen.name,
          grid,
          MG_INTRINSIC_REVIEW_ENABLED &&
            preserveVariantSizing &&
            specimen.variant.node.layoutSizingHorizontal === 'FIXED' &&
            Number.isFinite(specimen.variant.node.width) &&
            specimen.variant.node.width > 0
            ? Math.max(
                (specimen.width
                  ? specimen.width + 2 * reviewPadding
                  : specimen.label
                    ? 704
                    : 344) + (surface ? 2 * reviewPadding : 0),
                specimen.variant.node.width +
                  2 * reviewPadding +
                  (surface ? 2 * reviewPadding : 0)
              )
            : (specimen.width
                ? specimen.width + 2 * reviewPadding
                : specimen.label
                  ? 704
                  : 344) + (surface ? 2 * reviewPadding : 0)
        );
        await reviewLabel(`${key}/caption`, specimen.name, row);
        let consumerParent = row;
        if (surface) {
          consumerParent = await reviewFrame(
            `${key}/surface`,
            'Source context surface',
            row,
            row.width - 2 * reviewPadding
          );
          consumerParent.visible = true;
          paint(consumerParent, 'fills', surface);
        } else {
          const previousSurface = owned.get(`${key}/surface`);
          if (previousSurface) {
            paint(previousSurface, 'fills', null);
            previousSurface.visible = false;
            mark(previousSurface, `${key}/surface`, false);
          }
        }
        let instance = owned.get(`${key}/instance`);
        const fresh = !instance;
        if (instance && instance.type !== 'INSTANCE')
          throw new Error(`Review instance ${key} changed type.`);
        if (!instance) instance = specimen.variant.node.createInstance();
        mark(instance, `${key}/instance`, fresh);
        await loadNodeFonts(instance);
        if (instance.parent !== consumerParent)
          consumerParent.appendChild(instance);
        if (fresh) {
          instance.name = specimen.name;
          let labelTarget = instance;
          if (specimen.label)
            for (const name of reviewOptions.longLabelTarget || []) {
              const matches = labelTarget.children.filter(
                child => child.name === name
              );
              if (matches.length !== 1)
                throw new Error(
                  `Ambiguous or missing review label target ${name}`
                );
              labelTarget = matches[0];
            }
          const label = Object.entries(labelTarget.componentProperties).find(
            ([name, property]) =>
              property.type === 'TEXT' &&
              name.replace(/#[^#]+$/, '') === 'Label'
          );
          if (label && specimen.label) {
            labelTarget.setProperties({ [label[0]]: specimen.label });
            if (labelTarget !== instance) created.add(labelTarget.id);
          } else if (specimen.label)
            throw new Error(
              `Review label property missing on ${labelTarget.name}`
            );
          const overrides = {};
          for (const [name, value] of Object.entries(
            specimen.properties || {}
          )) {
            const entry = Object.entries(instance.componentProperties).find(
              ([key]) => key.replace(/#[^#]+$/, '') === name
            );
            if (
              !entry ||
              (entry[1].type === 'TEXT'
                ? typeof value !== 'string'
                : entry[1].type !== 'BOOLEAN' || typeof value !== 'boolean')
            )
              throw new Error(
                `Review property ${name} must match a named TEXT or BOOLEAN property.`
              );
            overrides[entry[0]] = value;
          }
          if (Object.keys(overrides).length) instance.setProperties(overrides);
          if (
            !preserveVariantSizing &&
            (specimen.width ||
              specimen.variant.recipe.tree.layout?.width === 'FILL')
          )
            instance.layoutSizingHorizontal = 'FILL';
          if (specimen.instanceWidth !== undefined)
            applyLayout(instance, { width: specimen.instanceWidth });
          // Apply content before geometry, then resolve fresh descendants again.
          // Nested property changes can rebuild instance descendants in Figma.
        }
        if (preserveVariantSizing && (fresh || refreshNarrowReview)) {
          await intrinsicReviewGeometry(instance, specimen.variant.node);
          if (!fresh)
            result.audit.push({
              nodeId: instance.id,
              status: 'variant-review-geometry-refreshed',
              width: instance.width,
              horizontalSizing: instance.layoutSizingHorizontal,
              preservedContent: true,
            });
        }
        if (MG_CONNECTOR_REVIEW_NODES && specimen.nodes?.length && (fresh || refreshNarrowReview)) {
          if (!fresh) {
            const current = await instance.getMainComponentAsync();
            if (current?.id !== specimen.variant.node.id) {
              instance.swapComponent(specimen.variant.node);
              await loadNodeFonts(instance);
            }
          }
          applyLayout(instance, {
            width: specimen.instanceWidth ?? specimen.width,
            height: 'HUG',
          });
          for (const seed of fresh ? specimen.nodes : []) {
            let target = instance;
            for (const name of seed.path) {
              const children = target.children.filter(
                child => child.name === name
              );
              if (children.length !== 1)
                throw new Error(`Ambiguous or missing review node ${name}`);
              target = children[0];
            }
            await loadNodeFonts(target);
            const values = {};
            for (const [name, value] of Object.entries(seed.properties || {})) {
              const property = Object.keys(target.componentProperties).find(
                key => key.replace(/#[^#]+$/, '') === name
              );
              if (!property)
                throw new Error(
                  `Review nested property ${name} is unavailable.`
                );
              values[property] = value;
            }
            if (Object.keys(values).length) target.setProperties(values);
            created.add(target.id);
          }
          if (!fresh)
            result.audit.push({
              nodeId: instance.id,
              status: 'composed-review-geometry-refreshed',
              preservedContent: true,
            });
        }
        if (!fresh && specimen.label && reviewOptions.longLabelTarget) {
          result.audit.push({
            nodeId: instance.id,
            status: 'existing-nested-review-label-preserved',
            anatomyPath: reviewOptions.longLabelTarget,
            note: 'Nested label seeding applies to fresh review specimens only. Existing labels are preserved; use the exposed nested Label property to edit a prior specimen or explicitly reseed the review.',
          });
        }
        if (
          Number.isFinite(specimen.width) &&
          specimen.width > 0 &&
          reviewOptions.responsiveLabel &&
          (fresh || (refreshNarrowReview && id === 'button'))
        ) {
          const label = instance
            .findAllWithCriteria({ types: ['TEXT'] })
            .find(
              node =>
                node.componentPropertyReferences?.characters?.replace(
                  /#[^#]+$/,
                  ''
                ) === 'Label'
            );
          if (label) {
            await loadNodeFonts(label);
            instance.resize(specimen.width, Math.max(1, instance.height));
            instance.layoutSizingHorizontal = 'FILL';
            instance.layoutSizingVertical = 'HUG';
            label.textAutoResize = 'HEIGHT';
            label.textAlignHorizontal = 'CENTER';
            label.resize(
              Math.max(
                1,
                instance.width - instance.paddingLeft - instance.paddingRight
              ),
              Math.max(1, label.height)
            );
            label.layoutSizingHorizontal = 'FILL';
            label.layoutSizingVertical = 'HUG';
            if (fresh) created.add(label.id);
            else updated.add(label.id);
            if (!fresh)
              result.audit.push({
                nodeId: instance.id,
                labelNodeId: label.id,
                status: 'narrow-review-layout-refreshed',
                width: specimen.width,
                preservedLabel: true,
              });
          }
        }
        // Existing labels remain editable, including during explicit layout refresh.
      }
    } catch (error) {
      result.errors.push(`Review ${family.set.name}: ${reportError(error)}`);
    }
  }
  if (organized) {
    try {
      result.layout = await organizeMangroveKit(doc, brandId, {
        zoom: false,
        allowProbes: true,
      });
      for (const id of result.layout.createdNodeIds) created.add(id);
      for (const id of result.layout.updatedNodeIds) updated.add(id);
      for (const error of result.layout.errors)
        result.errors.push(`Kit layout: ${error}`);
    } catch (error) {
      result.errors.push(`Kit layout: ${reportError(error)}`);
    }
  } else if (typeof mgLayoutLegacySpacing === 'function') {
    result.presentation = mgLayoutLegacySpacing(main, review);
    if (result.presentation.changed && !created.has(review.id))
      updated.add(review.id);
    if (typeof mgWelcomeLegacySpacing === 'function') {
      try {
        for (const id of (await mgWelcomeLegacySpacing(main, review))
          .updatedNodeIds)
          updated.add(id);
      } catch (error) {
        result.errors.push(`Legacy diagnostics: ${reportError(error)}`);
      }
    }
  }
  result.createdNodeIds = [...created];
  result.updatedNodeIds = [...updated];
  if (result.families.length) {
    const focusId =
      [...chosen].find(id =>
        result.families.some(family => family.id === id)
      ) || result.families[0].id;
    figma.viewport.scrollAndZoomIntoView([
      owned.get(`layout/family/${focusId}/main`) ||
        owned.get(`family/${focusId}`) ||
        owned.get(`review/${focusId}`) ||
        review,
    ]);
  }
  return result;
}

;
const doc = (function decompressJSON(encoded) {
  const header = /^(\d+):(\d+):/.exec(encoded);
  if (!header) throw new Error('Invalid connector data header');
  const width = Number(header[1]);
  const count = Number(header[2]);
  if (
    !Number.isInteger(width) ||
    width < 8 ||
    width > 16 ||
    !Number.isSafeInteger(count) ||
    count < 1
  )
    throw new Error('Invalid connector code width or count');
  const alphabet =
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  const bytes = [];
  let bits = 0;
  let buffer = 0;
  for (const character of encoded.slice(header[0].length)) {
    if (character === '=') break;
    const index = alphabet.indexOf(character);
    if (index < 0) throw new Error('Invalid connector data encoding');
    buffer = (buffer << 6) | index;
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      bytes.push((buffer >> bits) & 255);
    }
  }
  if (bytes.length !== Math.ceil((count * width) / 8))
    throw new Error('Invalid connector data length');
  const codes = [];
  bits = 0;
  buffer = 0;
  const mask = (1 << width) - 1;
  for (const byte of bytes) {
    buffer = (buffer << 8) | byte;
    bits += 8;
    while (bits >= width && codes.length < count) {
      bits -= width;
      codes.push((buffer >>> bits) & mask);
    }
    buffer &= (1 << bits) - 1;
  }
  if (buffer !== 0) throw new Error('Invalid connector padding');
  const dictionary = Array.from({ length: 256 }, (_, index) =>
    String.fromCharCode(index)
  );
  let previous = dictionary[codes[0]];
  if (previous === undefined) throw new Error('Empty connector data');
  let decoded = previous;
  let next = 256;
  for (let i = 1; i < codes.length; i += 1) {
    const code = codes[i];
    const word =
      dictionary[code] || (code === next ? previous + previous[0] : null);
    if (word === null) throw new Error('Invalid connector dictionary code');
    decoded += word;
    if (next < 65536) dictionary[next++] = previous + word[0];
    previous = word;
  }
  const utf8 = Array.from(
    decoded,
    character => `%${character.charCodeAt(0).toString(16).padStart(2, '0')}`
  ).join('');
  return JSON.parse(decodeURIComponent(utf8));
})("16:191736:AHsAIgBjAG8AbABsAGUAYwB0AGkAbwBuACIAOgAiAE0AYQBuAGcAcgBvAHYAZQAiACwAIgBtAG8AZABlAHMBDABbAQAAaQBkAQwAIgB1AG4AZAByAHIBFwAiAG4AYQBtARYBDQBVAE4ARABSAFIBKwBzAGUBBQEHAG8BKgENADoBEwBvAHQAIgB9AF0BGAB2AGEAcgBpAGEAYgEFAR4AOgEgACIBIgEkAQIAbAE8AC4AbgBlAHUAdAByAGEAbAAtADgAMAAwASsBLQEvAVMBAwE8AC8BWAFaAVwBXgFgAWIBGAB0AHkAcAEwACIAQwBPAEwATwE2ARgBHABzAGMBSQBwAQgBCgEkAEMAUwBTADoAIAAtAC0AbQBnAC0BVAE8AC0BagFbAV0BXwFhATcBAgFzAU4AWwAiAEEATABMAF8AUwF2AFAARQBTACIBRQAiAGgBIgEcAG4ARgETAG0AUAB1AUwAaQBzAagBEQEMAGYBXQE4ARgBAgEcAFMAeQBuAHQAYQB4AQwBAABXAEUAQgEkAHIAZwBiACgBRwByACgBiQGLAY0BZwByAZABWQGSAW0BYQApACkBQwFGAV0AdQEdAcMBJQEnASkB4QE9ADAALgAxADAAMgEYAGcBDAHnAekB6wAiAGIB7gHoAeoBGABhAQwAMQB9AfsALAEhASMBDQGOAHIALgFMAd8ALQA5AZUBGAFkAXQCAQAvAgQAZQIGAggAIgFxAXMBgwF3AXkBKwF8AX4AaQGAAQkBCwExATMBNQAgAQIAcgBwATwAYQB0AGUAIAIOAC4AIABBAGwAcwBvACAARABFAEwAVABBACcAcwIqAVwBJwIqAGwB3wGHAjMCNQI3AjkAbwB3AG4AIAF8AGkAZwJHAGYAaQEFACAAbAFLATkCOQB0AagCOQBzAHcCJwBjAGgAIABcACIBMgE0AFIAIABCAj4CKQAtACAAQwE8AiUBXAIoAj0B3wJeACABEABkACAAbQFIAGsCOQBpAHQCYwI7AGQALgBcAG4CfwGEAYYBiAGKAYwCAQAtAg4CEAFvACIBfQBvAZgBHwGbAZ0BnwGhAaMBpQEYAagAZAGqAawAbwGuAbAAbAGyAbQB7QA6AbcCLwBlAboBGwBlAb0BvwHBAeEBxQHHAQ0ByQHLAc0BzwKFAdIBVQHUAokCBwAwAdoB3AAiAUcCZQFOAQABJgEoAT0BAAHmAewB9AAzADAAOQA4ARgB8wA6AecANQA2ADgANgH3AfkB+wB9Af0BUQH/AQEB0wAuAGkBvwBlAVwBBwBpARUBYwEuAgsB0wAvAuACKALjAQgC5gFwAXIBdAF2AXgBegAiAhkBfwGBAh4BdQGFAYcB0AKGAdMALQLsAuIAYQLkAvACjAGXAeABTwKRAZ4BoABPAaIBpAGmApgCmgGtAa8BsQGzAuACogKkAbkC3QG8Ab4BwAHCADoBxAHGAcgBygHMAUgCtAHRAocDAwLuAuUAZQK8AtkCvgHeAwoCwgHjAsUAIgFdAUoBTgLdArcCDQJlAooBQwH8Af4BJABmAQoAdAAtAHMAaQB6AGUALgAyADUCiwIKA0QDRgNIA0oAZQAvA04CiwITAXQARgF4AEEAVAIYAR0CGgIcAYIBDQKCAv4CtQNFAb8DVANLAC0DWAGWAo4DCgGaAEYATwBOAFQBnwBJAFoARQKWAacBqQBlAasDFQKeAqADGQG2AbgCpgMdAqkDHwKsAyIAIgKuASQCswL/AC0DaQNHA0kDbANYAdsDMQK/Ad8CwQHiAsQB+QA0A0IC2wNSA2oDlANMAsoDUALoA6IDkwNVAC8DpgErA1oBJANcAE8DXgNgAX0C+QIdASQAUgBlAGcAdQJRAHICKgEbAHkAIAIoAHgAdAJ+AoAAbgNmAoQB0QOSA2sCDwOtARgCjQKPAwsDcwN1A3cDeQN7AxMDfgKbAp0DFwKhA4QCpQKnAx4CqwMhAyMCrwMyAc4DkAPMA6QALQOmA5cB3QLAAeECwwHkADoAMQA2A6ABUgENA+oDVQAuA08DpwFlA/kDUwOkAC8D/QOuAvIDsANdA18BewNhA7YDZAL8AoMD6QQBA1UALQQEA9ADCQGZACID1AN2AFMDeAN6AxIDfQN/ApwDFgKfAxgBtQKjA4UD4QOIA+MCrQMkAQ0DjwNoBBEDbAP9A+4DMgPwA4sD8gE9ADIAMwP3AtwD+gNLAgMBWgB0AYICCQOoBAADowOrAGIEQARCAhIEBgENA7EDswQKA7UCGwL6AYMC/QPKAYwEPQIPBEgAdARBAQsEFQNwBBcEGQPWBB0ClwQfA9sEIgOCBCUDGwOGAbsEKQMgBCsD5gQuA8sEMARZBEkAbgQzA5kDNAOcA/MBAAM5AGEDOwRYA1cDTwNBAtkDQwRFA0cBtwBtAk4AeQAuA8MBQgRDA/8AIgPMBIgEigAvBI0EBQIUAQ0AUwBUAFIASQBOAEcDtANiBFMETQNTBJMAbAPBARMBBQIsAEwCJwLgA0gEoQAgAbcAYwIpAQoEpgA7Ai0BXABiAGkAYwJxAjwBQQBoAuIAIARRAYACOQJ1AHADwgJWACAEqAIpBEEAIAS+BMAEsQEdACAC4AAgAF8DkgBzAC4BfQBzBNcCfwKBBFUEEANqBKUAeQAtBJYEXgPSA3IDdAN2AEYAQQBNAEkATABZA9gEZQOAA90DgwQmA+ADhwKqBG4DiwONBC0DKATfBIcBLgSKBOMAZQPEBHcDMwObBDcDuABvAGIBQQBvA0EC2gP4BJEEpAUABKYALgB1AGkC5wSQBJIFEwB5AC8FFgSXAXQEmgScBJ4EoAQMAvsARgUSBIkEpgTJAQMDTAAgBKsBCABuBK4C+QSwAwUEswBuBLUEtwFLBLoEvAJzBM4DvgTCAHQExABhBMYCVQGyBSsCTwTMBT4FNASyAngCRwTVA0YE1wTZBNsDxwPJBP4DkQUbAC0FHgTlA3EEGAToAF8E6gTsBO4E8AKZA9oE8gQjA94E9QMcBGwE+AOKA+UDjgT9BC8E4AVYBRYFBQQ1AzUDnQENAFIFCgUMAmgBCgGqATgBIwQ7AWYAbQIlAVgBvwAuAGUAZAJ5ATwBSgFeAQcAYQIDAGEAZABnAg8EWAUYAukFhAEKA34AdAAvBYkFiwFJAZMFjwINBZIFlAORBHMFHwQHA7IECQMIBF8CkARhBBsD1wQeBWQEIAPcBWcE9ARqBFAEoQO3BJkAbwB1AHIEsgJxAVoAaAE8BYkAIAAxADgAcAB4BMEFvQW/AikAZwSmAHAAaAAsACAAbgFBBLwE0gECBTEDkgTBAbAAcwEIAHQBWgNMATcFzASyAeECTQEFASQF3gWMAR0ALwJpBZkFhgVBAC8AQgR1AHMF7QHABfMEWwEKAC8FjwKIBHUE2ABjBNoBKwKfAVgBDAAyADkEOgQoBWwD5AOYBQYD8QM2AfkAOAH7AaYF3gB5AU0B4QSWAU8EhQLdBe8FmwWIBYoEQQWgBY4BwAAuAlEAYgE5BZcBJAEPAREBEwEVBfsCnAWFBZsFnQYfBYwFoQHAAC8GJQYnAvEEmAAiAFQARQBYBasAcgEGApwBLwEnBYkD3wMcAjAFvgXlA4sF5wF0BeoBSQXsBe4GMAG/BfUF+ARcBfUAQwX3BHUF+wHABf0F+QBuBf8GAQEYBgMBMAYGBggC9wQLBFIFuwAiAFMF5AIpBXoFCwTMAhMAbwESBUMAaASLBS4CUgBsAmgBhQA2AWECdAJaBL8COQRIAScBBQJzAEIBAwBkADcGfwTTAlUCKQGyAQMCJwXFAGIBEwB3ATgAcgS2AGIFpAaPAjkAYQXCBcQGigFhAiwATgIxBdsAcwXdBd8BWgIdAiwAVQZFAHIGZATNAGYAZgE4AnoFRgUDAmsCKAJzA0UFPwBoAUgFxQYUAk8CcgXUBKwBFQPCBQMCegBwARMBcwByAXECIgEKBqcBLwByBNcElwZ0AVwF0QB5BeYDRgBXAGUCSgBoAHQDuQBxA5oGuQEMBn4AMAEYA5IG2wbdAHQF8waFBkYAOgaLBuYFEQG/AFMBcQEFBuwAZAaGASQGiABsASMG5wNGAQ8AdAJbAFIErAEKAV0BdABCBpUGlwJoAEQAUAbOAG4CTQByAG0CVAa9AnoCggblBoAHAQS/AnMGSQXNACAGcAUMAC0G+wahADAE0gJHBo4CdABlBH4FvgaTBwkC4gAuBgIC4ABlAEgG3ABnBt4HAwGBAfkGYwcxBzMG6gBCBH4BsgEkAkUF2gWnAUYC4gBpAk0AYwcEAvsAQQEHAHUBXQAgAEoAUwBYBTwEsAZBAbMFKgECBYQCTga/Bm4HKAcqBkECcwTTBpACUQa5AmgAaAGtAGkAdQBtBLYBLQLvAikF2wBlBuEC5QcGAG4EsgXTBc8BcgJcAbMFQwIpBsIAdwbWAnEAYwSyAYABEAXABkECdQTTAXMBJwMZBy8DMQS5B4sBEQObA5IARgUbA6kFVwUpBRwE5AbyAHQAUwNVB5YEAgRaBFwCvQR4BQcGDwZMA0YATgREAQAE4QUJBnEFDQPQBvUHBwaJAr0DkgedA0sDngc6AVgHPAc1AUIENgBuAnkBJAGiAFIAQwBFA3UBKwR4AfkBYQMxBI0ARAZCAmwGawBOA3QDegFwBscHzQIjB0oATwayBrQGDgfAAQ0AQQBVAFQATwK9BI0AVwbWBvQGFQF0B98H4QSDBQ8C3AdZBlMDxQWeBiAFjQGNBiMGOAFeBcMBFQEqBI8BdAYqARIBFANWB+8FmgG/BjIFnwf0BaIH9wAtB/kC4gWoAQ0GPQY/ASsGQQdZBkQBHAH/BbgCjAZuBeYHWwXpB/MGUQYvCAMF8QZWBs8F9gBhCCIAbgZcAGEGXgRcBmEBHge5BmUGBwMxAvgGagQNBm0GSgZvBXsGcgFyBtUGdgZ4BKsGJgZ7BxYGfwJ1BxkE0QaEBvgFxQciBvAHJQTHBpwGkQdlBpQCRQaXBpkGmwTSBp0GnwdgBvAGowalA0YF3ABiBd4CeQaqAQoGrAauBrAAbwfaAGUGtQI5BrcBPAdlBrsEwQa9B2AEwQexB1QHbQMuBsYDxAAgBskDcAbMA8EF2QbQAuIG0wY6CDsG1wbZAb8G6Qe8BuAG4gbuBuUG/giGBzQG3gb3BvkG7wFhCI0HnAexCJEG7gAiByIBKwOSBwAHAgdKBwYG+gctA74AQwcMBw4HEAcSBMcCJwZ8AFMHFwhDAlsHXAg2Bx4IOABvByEGiQhKBo0EvwdeBqcIcQhQBpYHLgcwB7oIjwbfBwQHOQAiBmQHuwiQBz8DOwdCBaYERge3B0UBSQdIB0oBJAdMBeAHTwdRB1MGwgBmB1YAaAdYBi8HWwcbB10BLwdfBcUHYgIwB2QFxQBDB2cCnAdpB2sGwwduBLAIXAdxBRYCvwN+B3YAIAd4BdEIbwd8B1QHfwVDB4EHgwHAB3UCKQeHAGEHiQN+BYoBEQeNAs4C4AkKAGcHkgNGB5QHmAeWBOEElQbHCJwDRge2AXQEgAehAYIGDAV2BHoDNwOSB6kD/werB5UFeQi0ATcHsQb6B7MDMQe1B54D9AA0CC4IyQe9AzUH3QAiB8IHxAfGA+8B3wfJADAHywfVB84I1AIfAjMAUgBMBJ0H0wISCUIH1wL6B9kGswhoB9wHvQk5AEUHwwfFBasHyAA6ADIJQAfUA8QH5QVDB+cF6AfeB+AH4gLYB+0FgwfwBh4IBgY1BZAICQNFAGMAdQgtASwERAEOARAH/wYtCAIF8AgFB/MJbAY3BnoFpglwCXIDrwgOBj4GQAZCAG0IFAbuCBcHHAZLB6sIGwENBk8AaQgeBhwGVAXyBfQIJAgmCCgIKghiBVIIwQgvBmcIMgNjAvsINQcdBx8IOQIlBnUG1wSqBnoIrAiuBoEIRQLDBoYCYwi3BowHJgi6B2MGkgJzCL4IUgIqCFQFRgaeAlUGoAhZACAGpAjyAb8IXQhfBeAC+ghjARwGrwcxBrEJUAhpACAIawbMBcUIbgd7CHEGwAd9AjwIdQbFBI0IeQbKAuIGzQh+B2oIgAcvCIIJqQZ3CIUAdAiHBzYI9AEdBuMAOgiMB5sJ7QbrCbEG7gbwCJUJYQBlCJgC3AibCJUIngBoBzcCHQihAQ0HCAhRBMAIpQcNBdkIqAcTCKsIQQckCK8HGgXLCLIJpgi1CEkJtQhMCLsHKwm6CKMJ5wjHBzsIwwoDBQ0D9Ak0CMMHPgNJCMwCRgjOA6oI0AK+B0YI0wSiAZsHTQjYB1IHVAjcAR0I3gh9COAJsgmMAikI5Ai8COYCRwm4B2UI6wdoB2oHbAbEB28I8wdyCPYJBAd3BdAHega9AXMI/geAAwUJAgeFCQUAZQeIAkcHigkPCQwB8gkOAxkJEQG/CRMEigkVBRsJFwPECRkG8wkxB5sDzQINBHUHowYNB74FeAerB6gHqgSRCSgAIgoWCSsH6AktBvwHtAkaCTEAMQkzCiAIwgbqCVIHwQlVCTsJWAMzCT8JQQPEB9YCJgoyAmAJVQlIAE4JSgfMCUMJTghnCTYB4gk4B+oJZQldCewH5gksCWMH6wlmBhoJeQYdB/IGNAYiBZAGmgWTARYH/AYpCXYGLAgBCB8JegquBiEH9QBhBaMKswgNBjwJhQgRCYcJiQgWBCcIGAg2CBoJYgKMCB0GWAq6BZsGVQmXBlkIJQZbBfwJHgZgCZ0ILgEMADMAMQA5CDEGaQmiASQJpAXAChYDwgg6CekIPQmsChAHGAiwBoMJ9waHCbQHJAi5CE0I6QodCggGmAm9CrMIVQXBCcEIWAaiCcQIWwnHBqcIXgapCcsAIAatCc0IZQqeCv0J1AhtATwI/AnZCHMGwgndBMsGxwngCHsJ4wbPCeUG0gofBnMK6gnrCfUIiQnwCfgIlAn0CicK8QEMCfkHmwn7Cf0KgAb9B5sKAQojAS0KzQrlB30IVwXFChYIWQmeCTUKIwjGCMgKJwjLB0EKKwWWCNEHRwS6CUQKMwjXBnsI2Qo3CN0I3wdaCj0I4wcpCkEHYQpDCOgJuQdmCkcI7wsWCcYCegj0B3MBBQpPCPkKUQj8ClQHfgpWB4IAZQeECQQEyQpbCQcKXQkJB4wCvQePCQ8KZAB0CmYEpgpoB5gKagSOCy0KbgqsCAQKvAgHBjYKsgWlBZYJIAOaBg4KdgebCSUBMAknCRQJKQeuCn4KzQibCS8Kgwe3A/QCzQqHBzIIwwqKAQ0JOglXB8cKjwP0B8oKpAqTB88EDQfRCpkDrglMCpQCHQlPB9sHvgqhCWQH4wbHCV8AcAn7CNULtgqqA6ECAArRBYcHSQByAGQB0gLhBYcF3wXoCrUBDQf+CrgGLgmUBZwLwwvFBdkCKAgEC8kKtARLBjsIDwmGCBMJCQmKCskKPgrMBk4KzwXtC8EF8QBDAUgAZAZYC+kF+wvpCCwJngH5ADIK4QVABmsARQB4AwUCego+BnkFMAVLCdsCcwsgBtYGdwdsAjELBQnJBeECcwJpBkUAbgWAC18CLAoHCL8DvgpABysK8AbtBroFNQpJCPEEkgdbCdMKTQd0BcAGwgfyBYkDAgwLCQMFwAnaCxkAcABhAGcHSgtvClwIeQtzCQsG1AshB6cIjgbqCyQF3gsmBvEG6AspDBULKwsnB7UIlwsqCgYHswomBz0LQwENCM0LRgovCNILSQoyCNYHTgtNCjYAdwJ5AlwKOAGzBs4FhAEFAm0BoAGFCEsKRAjqCOwEiQdqBdMCYAIhBS8C4AajCkoJAQtsDCUCKQpeC3QHjgpiB5EJ6wt6BtgEhgeXBJQFWguAC5oKbwQCBAQLigR5BQgMNAB0C48F5gp7CucMCQV/BkYHsAp/DEMKgQuYCm0LmgQ5DEUHvAugCVQJVgk8BDQJPgP0A04KkQB0C6kLSgusCpoLuAqmDI0ImgGcAEEATgfEBQ4GGwfwAQwBWwHfBIQLvwytCCAALgvSC8YL1QPFC9cALQYDAGsGKAvMCrcIAAvPB/AL7QvEDLgGMQy7DL0KwgvbCsUL3QZFCsgE9gvhBkwJjwrOBesK0AvQC+sLxAzZAGQMxQJ9CtsLnQvxC/MFugQNC/YL+AoUBx0MZwJMBTUHVAwACDwMAwnICwcI6gV+A34MDAOSDA4IowobB1YCKgrxC/0MGAh2DBoCTwthCk4MHwI8DCELxQLgBd4KWQhyB+gMKAwqDCwJBgkIB5AAZwsfCukMAQx2CncMNQiICe8MOAH/CywMOwc9DEINHgkaDEEMPQyOCzELQQxGCikLRAdDCM8L2Af6C0gHSQxOCjQMUQdTDFMCVQdVCjkMWABwDFoCKQxcAFMMXgtZCkUMYQjuDGQCIAJiDOkMaQjxClcMbA0KDG8MMQxxDRILeAx1C3wMeQUXCfoKbgSADH8JPQyBB6YNGAyECnkHrAuTBXwMiQz0DIsKzgymC5cNVwySADMMlAbeDJYLogyZCVkAMQydC6gKnAZrCpYJRwlJC64JXgylC5YMqAyqA3oB/Ay0BfAMrwByDLEJZwvAC9AMtgvpDMcFhwULAGQG2AvLCXUGKwzCC4IL0Q2MC9QGMQ2PDZEL2QF0DMwBGAgSBkML3gzQBkgIGQzTCs0JkQmTB/AM2wzbDN0L7wrcDJwM4gUlASQM5QEHDOcFwAzpC/0M7A0VDO4F1AwEBqgIYApFDPMMCwnWA0YM9wr5DPkJsAwVDP0I8Az/BKQMGw0CDB4L/gnTBh8MIg0IDG0NCwJPCHoMKQwrAvoMLQtxDC8NEg0UCagNFgsiCiINGwnxADQMPwbaDDwIRwH/DeoMOg0jB+gLLwV5A7oDvAFICz0LQg0qAQ0C4AS/AUkGuQHSBYQMBwKIA8AHxwowDE0GawxPCjUNNQxUDTgMVwfvDTwAIA0+DUAITgxgC1wNRQJhC/sMaAnEDGoNSwttBcANTg0TC3UMcgkQDHQKewUaC30HmgkwDHwEgAOtDIAHpQuNCSQNYAyHCSoMjArNA7kDuwO9CoIMkQEwA/UNbQqfASYJOABQAEkAWAI0AaQNWwYFA58NdQlNB9AH0g17CqUJYAqnCTkAUgBFAFQAVATvDYINlg2FDYcKqwvmDYsMxg2ZBYcH9wy/DZMJdwq5C9AM3Q2NBZwOYwY6DZ4KxA2gCsYNowZHA4YM0gmODagL5AZSCCANrAXtC+wL0g2vDOANsQW5DbMBDQ21C/kHXQ25BNANuw3kDb0F1QzwDcEM8gwKDPUNxgJ7DcgMEgz6CEYJsgTQDP4GxQ0AAikN0QtjDQQCcw0GDCMNCQtuDCcN2w0ODd4NEAtyDeIMMg3lDIMLIw3oDDkIlQn1DfQNIgbzDSQN7gswDfkNKQdADfwAbg3+AnkMIgfvDgMNmw4GDEwNMQ4JDTMHUAxSDg0MVgJcDhAIaA09AoIOFAr3C1sI7QxjCwkNRg4aBmAOHA1KC2sOHwxuDDAOIg1QC3cOJguSCm8JFgx6DisJHARzBIEBYg4vC4wEewuODjMO6AyIDcMFgAuVB7IMjw1qDj0Khg0oDJULtAlTDkMORQBMDkcMmgZlDkoJSwqSDXYLqw5OCqQLuQu7CqgJZQMxDloAOgywAGUBRAEYAGUGsgEGB70BUAUQB3sAZAJFAC4BXAGyDWYDUQzADZQGLQ8iAkUALw8mDvkOgggzAvsDyQRxAYwPLQB3AC0PMAWJACkCLABJDcQCegULC8QC4gXTBkEGyQEdBZsFxQR+BdcC4AFYBrwFkg8kC6QJIQyCAVAPHABmDx4GFwRMACIEnQqZAFIBnwBIAEEARABPAFcBKwIBAeUCyQH2ACICogHnAsoB8QLPD2wPaQH4AtADTQ8KCGYJ0QHhAyEG8Qx2CVwAIgFcBYoJcQHuA9APRwWSCMYAdgGyAGkBTAEwDxgCzgtjAGQATQKoASQH0QBSAE0BnA4jDVEB4Q9mAQ0PVg8eArYBaA84Dy8JBw75BhIPowKnDNgB4Qf6A0kDZAAxBucFEwmSAZkGGguECWwOZAvNDMIARQYzBiECaAI2ASsAawkOCWgIIANICVED0A2mDnYL4wzWC+UM2AmWBl8GWAZaBl8JmAX+DakE1wBqAHMBwg2wADUANQ2yDzMPkQXWBNMCIwIpA9EDTAJ/AFMAdQBwBrgFxQfyBp0CPAKfBIkFQQGHBt4AdABwAHMAOgAvAC8AZwxUAbAMtgKcBR0HvwBzASgP+gLEAYoMwQYtAUwFCgAvAHMAcABpAGsDVgJNAGcCdQTjAG8QCQUxBpQBIgWUBZ0L9wxZBewQCxANDTsAdQ/1CCcBdg5UAC0ASwBJAFQALQSaA14AVQBTAC4AbQBkACMBHA9XASkMIgJyAogBVQBjEAkLxQB3ATwMvgHdBaAGVAEfD7APtwuFCrEEfgNMEC4GngBsA8UBswhsAVcCjgZBEC8I9wvYDykBdQNGBscAPQooAqYOEgHAAigAPQfNAbcDvAB0BdMMCQy5AD0AUwXDBswF0w+PAvoAPQakAFAQTQLiEE8BKw3bCeIPrgHhEGEJGAoGEEMBKwb0BpIBJBBcEEYLfxB1Ab8K5BBlC38QaAfQAG8QbA8cEG4JBAfjBkELkA2dA7AAUgTrCUoQUQHRCtkCdAGMCtkKvgErBRAQlQR1EJcJmwUxBY8InAJOAGwBDABuA7wAbAewARMQCQ++CXoCDAGSDAsMKQZBEIEQqhAPAR0PPwBjAj4IFQ8/BKsAeQW9B70PiwjHAGEQvgFaAeEBGgEcASQASAF5A3gE6A+VARgMUwBkAlUQyQBVBJ8ClwufAQ0ASBDUASsEiQBuCTUQrQYxD7EKsAAvENwAaQBtB2oICgufAfcCnwJLAYMJVwlVASsMKwBwBekMKQBjAxkALw7wCQ0PlwOLAiMPTgcDD38DOw9+B2kF9QrZCSsQqwBlCfUBJA9CCc0ALRDQAlUKcQZfEHAFkgkPAFQCjhDzAwUQ9gSCARgMKQKZAxkGiAX5AG0RFhD1AREEAwKLERsJDwBMDxwJUxAGERcRIxElERIDGQBSCokNiQzEEOEKvg8vD0gAcgEVDQcFNwcxAC0JCQK9AlsCTgEoA34QPhCPCYQIEA2SEJ0GXwq+ACAALwJQBnoQmwLcEUoEXBCfEJkFohFTAQoRTBFODmwBAQhwC/gIgAiiCggCcQEECHkDgQ7JBs8OTxBsCxoMdgAiCD4GOQ8LCJYH6ABBD+QCnxFnAvsARABJDlQAQwWrBI0PEg2DCq0QQAlsBiQRUA5LC7APDgutEYULqgBuC7IJUQ8CC7wKqQ8QBtYRjwfiBucQpAFmAz0HmgXeEQYQphCoBmMQwxC/AeERDQBoENMQ1QGnENcAIhDZBJ8DoAmDBBgQkQBNEJMJdBFYEKEBwBFNCvsFlBFRASQRshFVBHURNhGyEVoRtgvYBecQpQvAAz0DLAv4Ay4RBRC2EZwBBBGeEMQKnxDHAXQQygScAFoQzQBMASsRohDfC4MRgRDiC4cCDwOkASsEvxEyEX8R2glrEdwGmwPNASsAaglxAQgAZhFsCo0Q7xDqAkoPNBDuAvYQ8REhEPYQ+AphEPoBABD8AuIQ/hECEdkFnBE1BaIR3Q86BZISABEaES8BEREoAGYJUw2WCXsKrxE2EgUCjgEIB0kBXgLgBmQDSAHABswREREcARERHgRBESARMwggEhAKvRIEEecSFAtJAV4QAxA1ET4BJwK9AUsI6AXhAeEQZQNKA0YBXQ20ATMOxxIVEjgDZRH0ASsPdga0AFgSARIlEEEKwAWlCQkALRJBD8EAIhJLAHQE7wmQEPQR+BFAAagG/BCzEUURrA2fCXMEkBG+BY8RtQv6CLAAdgETBF0MsxG6El0GNhJnAGERtRHdEOMQmBG8El4RThJgBL8SYgRKAlsBSBFfBtIBJADiAIAAug5PEX4NlglqCXwKsAWRCsERiQfYCp4MlgqiB7QRlhHEAWgBkQFsAC0CixGaEcoAOhCnEcwQwhHOEaEBIhDSENgQ2hDWEeIRqQu3A8QCLhHyEO0DdRDvAUQSqQyyBRASAwYjBpoBOAAuCW8JcQTYEIMQSw9HEE4Qiw2SEHUDxBBVEEMF0xB6EFoFJwmBEGAQUwG/EGMQgxBnAUECHRBqEIcQbRCzBeURGgnhBswQcwOLErsJUxBWEHkQWQNbAG8JgQErEIAJUxBkCGwBKxCFC6sSzRCJEs8BFgfLEI0PWQY7AEYRrhGwElwSbgZfEbsRSxCiARgQnBLyEVQSaRCjAQQRyxCpCs4RmxIjEK4C6hCwESsQswt/EpMQCQBzELgQugWJELwRnxDFDxcNhgOGAlESmQOLEdAQyRDLEdQDdRDOACIR2BKdEaUR4Q8BEagSngEZAuAQ3hMCEOAR2xG9AuAQ5RDnEyINbhHxEOwSPhKnEfUFQxH3ES0Plg7mEPsBPBD9EgcPgAKwEz8RAwpyELUQCREIAQ0RCgLiEQwSmwBoEQ8HohIJEh4AZxEUEPISUREsAGcRJBIdCQ8SIAKcEzgTVxEZACIRJgMZEgwRKhJSEzkTUAkPETETIxIPEq0KvwdWAuIROgwjEhkRPw8VElURQwIeAVASWQ5vElsBdBJpEbURXBL4EKAS9ARcEb0S+RFZEnARTwg/D2URXgEHEWAKBgctEWMGewBwEWYHSgmCBscRagbLAXEBJBFuEKUKpAn7EXMNOw4IBA0ReBF6EXwGxxJ/Dl4TbBGDCD8JgA+AEoYKlQEzCpcNehOuC7ESiBGODxMSog5QE1QBmwu2EZUS/RKNAHILfhHJEKwSlRGdEpgRoAOLEx8TJBMhEacSoRGrD1oS7hCSDmQTfRFOEd0RuAENEmYThRGzCr8T0xHAEvwRwwM8AWgRxgMGC9gTCQEwEpYS/xMVE8cBABMYENgTGhHVEdcTTBJEE2wSRxHeB54SnxNqC+YSRQl9EgUR3wEYEeoIXxHtEqYGPQL2AzkTMwF1Ej8B7BM3E1URIhNXEfkLdgpjD5gTPRH+E0IT8hMrEicKsxIGEP8TWRNiESkUFRHlEhISKAIcEhYTcRE9DQkSHBNnER0BQRIhFB4SghQgFBgSKRQjEiwAaxIuBYEB9wheAQMSMwOLEjUAehI3E98HxQBEEjsSKhQCEfASTQqeEkMTKRHkFC0UFxJIAScSShKIARgSThJQAowTZRQNElQRQhJXBhkRRgrDEUgTexG5E9kRvxJyAGUSdBJkE4AQlhJpEm0QoBG/EmwT3BRhFGMTihJ3E4wSeQENEnsSfROdDlISgBOpE9UTswEKEYwOQAe/CVMSigkvEowT4BPAEo8BkxKSAVsSlBPnEc0T6hMeE/ETIBHgE8wQ2gyeEqQUBhHvATYSqQGmErIAcxExBCUR/AHTEZcBaBSbDzoDgwPQC2wSdwYgAmkCtxShFIUB1hKQAosSTgNSCYEUpBEjFLEQzxSPBREUswFJESMR2A2gFBQTQRD/E04EShC/FBMUGhRIEgIUFgY2FKMUxAHUEQEPgAu+EqwUyRBCErAFigBzAUsGhhK0EEoF1RK3EIoS0BRdA2UQUxK8EFYSvxLaEFsBshTXBYkSxAvHAHQSxwhsEskQaRBrEs4QbxLRCxoS1AEAEtYG+hB4ARgSwAF0AEQU5w+JCzES3xCCEuIBGBLkAvsU8RLnEG8S6gBlEI4RrBPQEa8T0hPZE4IThgHAE9YBGRUSEvsTvRHDFIsTABKUEeML0RMEAjsTBgWbE8IQtwd1Ew0AZBMPExYQwRPpExET6w+QE+0R0xPvFLcQ0RGjFJAT9w1uFTcTJhDdEacTaxTSEOMTLRDmAG0Q6AqJEzIR8xM1EPAUChRTE1YQ9xM6FBATPAByEz4Uxg99E0IUwhJkE+UTRwHyATwRCxGiFVYUGwERE1MTXRNYFCgSHxQqE1wUCxEYES4TURNjFWIVahNoEeIVPhQfBaITbhE5DdYRPAFYFDQUVhJWEUQUWRN5FFwQlBRfE4cTfxFSFRgVgRJoFYYSahFbEYQRXRRwAu0DOwwPATgTkBFlAbERdhOVA8QTlwniEWwTmxJ+B7ETnxF1C0oTowBFEXsVnAymFHgU0hOqEW8Kmw5MEYcMow8MFasRixO1CTcUgAu9EZEVShKKFRoUrBPBE0UT5hPFFS0KnxPJEqEVOAlTE80MshUOEu8VERRpE4cUehJlFYUVyRWHFc4ViRPdFbgTvwLrAuEDLQMHE+US/hSMFS4BGRUwEagT7hMcEdYVNBKcFR8T+hHmFBgT/RGmFXAT+RPzE/wT9gAiE/8R7BHuFAgDOBDrFUcUAxVJE7oRKxQMFU0O5RVPFJ8VURTFEgAUxxXmFC4FpRTOCXITYRILFB0WBBXtFCESPBIXFXcR3hIbC38WCgBnE1sSIhXlFg4ULxQiAZMUMhV5AzESMRQ4AigSNAWMFDwCqxQ+EjoI0RYQFEMC9hJOFEcWGhU/EgUSSRS2FEUJ0RRSFfsSUxN0FFcVfBN4D1oSWhWAFdASXwddEmESYxUWE9gV0BRoEVYRtBPUBpsWShJvFkwNtwIpFkUSdROLFY4SehJ8FaQKzRWmFXISrgabDk8MoAqdD3cTthO7EZAEkRSDAgwUhgFeFIgTARUcFb4SmhU1EaQUkRKgFJMKpBSVFfcSqABdEqoNiAAiFHkQQwAuCAsCAhBJBswSthTyErkU3xBSAuEU4hK+EFgGkgA9AEgIAAByFOoQYhLhEGYAIBUGEswQiBK4FN4QcRLTBHkU+BB3ATgS2RB7ENgWkRLeEsUS4BCDEuMSyhLlFpoU3RLpAXAS6wOLFcYT0RFJFc0WSwH4EvcVhBOBFRkWZxO+FRwV2RYEEK8VIhCyFSQVuxMLFScAdRC7AG4QvRPHFSwTEBHPFd4R0hDMFeET8BZxFToTMBXDEyUQ3BMoFjEWXRPbFUETLxDpFfUSpRM0FfgUCRX6FFQV/RD5EzsWABVSFgMVVBTBEQQVuxVZE0kB1BVdFvMTYBIKE1IRFRVoESMTXxYWFhgVYhcAFvsVbBb+FFUVZABnE2kVORbeFEoGNhV0E3ASGBE9E3MBuhN1FFgWPgvaE3oWQRa4E34VixRlEJ4UZxPcEVwSdgLuE40ImhOPAV0TkROTAvoVlgB0FZgIfBOaFYsRfRWdEXQToRF3EXkVohOlA8QTpw2KE6kICRaBFmAPDQL7DXgKmBWtDJ8XQhR9DW8KjAujDkgJWg98B+QRkhO3FdMUhBXVAu0RxwEVAC0XVxPkFIkTwxZuFtAWcBXkFcEV6hMjFcQC2ha0FRAWthZCFk0ShRXMFrwViBZPEvUWURXLEcIVuRPiB24XWRPjFSUV2hPGFdwT7BXfFTIW1RXjFTYXDRIRFEsT9QouFtkULBeFC4YR5xXpFfEHRxXzFUgVRhYtFfkVbRVODHMVUBbvE0AXhBImF4wUGBYIFV8AZxcGF5wSRhITFh0WERIZFCYWFRb7FwIWDRYyFg8SKhAzEtwUMxcUAzgUNwI+FiQUOhYmFD0SORRAFisUQhbmFEQWLxeKF50KvxIFFoEUNBROD3cUUAqeFjgW6hH5EUEVexN3AQAVfgWrFxsWUBXRFG0WRha6FF4XbhZJE9wUaxWIFkMIshZUEmQXJBJ4AzsUdBZaBZgJaRZ+F2wVqhGGFbAWYxWyEZMSixO+F1QWahKRF3oTxBKXFm8TyBS4F2IXiRSQFJQV9heUFJkFgg+aFacSrwNMFoEU2RaEB2AAdRTeEFES1hK9AbkWjRBaFpAH+haTBZsU7RaWFpgDuQBkGBEL2BadAQgWnxThEtcU+gZsEtoQyRamARgVAgSZFqoVBRasAvsYIBgiEIwVDBLsA1sVxxdpFGYViBZHFrcX2BPeF3sWwRXlFsMBEBUjELQVHRMKEwwWyhMOFswXXxMSAd8V2xbREMgVMRbUAjYV4hSOFtcTyhZzF2QW2xMnFT0V7BU/EOQVQhVEDJUXkxfBEzYW6RVMFA4OJAObEf0AchH/F5sWCBVeFvQRpxb2E0sVNRh1FvoTURVhFwcVYxh8E1oVZhYZFjkW/xVuFBwSDReWFwkXCxIOGGIW3xE3BpcXERYSFiAXFRY8F9MUWhZAEbEX4hWKE4kX3BPXGEAXcRPbGJsTiBFvF+cUcRWPFygRZBOSFZQTlBFpEtITmQENFZsUdhFyFzURdhB8FzgVoxizFlsTqBWnFz8YLRFwFmENdxOwDXkRiBjAF0gVsQqgDwMXSw1xC6UJWwyeC7kX9RdTAgwXdgMuF3gHbhf7F14TFgEAFcATJRgCGFwTzhLtGDsWiBfgFl8YnhUXF94WuBdwE4MVyhjlFr4T3xjTFdYXWhjWEcgVuxd7F/4VLxhVF38YVxMdE8kVcRcOF8YXjRXvGN4Y/heLGQAV6BXvF48UARhpASsUBRZ4GGoXlhX+F5gW7hYCF5sZBBfFE/QUGRIIGIEYiBiNDmgWGwWlFDABkxcSFXgXqhehF60XpBP7F7AUMRA0F7QSLxYhF7cUOQEAFDsXvA6EFioMSxYsGQsXzAnRFjAZFhelEecWNBRPFjYGtBfOGGwVehN2ElgWPxcaGJoXahZSAiIScxfbF20YPRffGKMX4RlMF9oWVRWNFyYX6hi6F+wMtRfuEbcUexfyC7MX9BO3FIIX9xZpFK4UhxjYFb0YUBjbGAAY3RSSEaoWdhgFGQsYBxKrAtwWfhTUDxwQfgYkAQoNExTbFoYYEgl0GBQU4xgXAGUQWxl7EF4YGxLGAEwZfhTvEssVCBabGCMYrxT2FokGGAiaGCkU/BB8GYkQRxanFOsTmhl+FqsKMhmRFq8YNxUNE88Y4hfXEvMWvRcfGasYPhXTFsAXXBldEwMRmBbEBr4YSRPlFsgQuRhNFSkYTxUrExMYUxDGFtIV4BhYFtYV5Bk9CX0BVQERC8YIfxb3E/EVwhZyARgW3BhhGR4YYxbhFUMXiRhoFAcXkg9qFUoYhRRVGREOJReZGRQRABVVFvkVWBh3FVsTShb4E0QZGxVgFv0VSxX8FwQTURknGd8YgBYWF6MZ9hiHAREYjBfEEkYXEBV2E3IZLhiVF9IZSBcZFX8ZSxccGJwRbxmtEvoXbxciFYsYphZXE44RYhcpFZMVnxcsGK4RaxcxGJ0RcBOeGLUVoBi4FzoRcRi7Fz0YvRcyC68Rig+RDw8YxhWvF0kWZBSBFbUTuhW3GO4VuRGZGbIY9hltGFoV5ABGBO0YWRjeF2UX1BmoFrUY4xlUGO0aDQEKFRMT2hjqFRQV0RdzFmgC6hjUFdgaOBf8E+gaOhd+FtMTGxnFF4IZ/hkpGQcXiBnUETQXrxpfC9gZCReRFucW5BSWFfQR9hh/GG0R+wLdFgEYcRS/GSgV5xYHFBQXCRejGcgadQIPGSEXqBQlFhQZJhiDGl0aexJKF6cXshItF7UWIhe4EI4ZMxYoF70UQRIWF5QZOhJCGoMWBgIPGUAXyxlCCGgZRBX8F9AXFhY9GkIaBxfWGgkX2BfjBx0X5Rg/GOgX2BpME9oSaxZOFGwWRBlPGVgXJRRyACIZWxoeFHcYvBbfEoQZYBotF/EaLxlkFmUKoxo1FdQX+RZsFIoZbBjaGjsXgxgBGXETuBZ3GAYWehZ6GXcBJBOpDf4QTBDlAUgEixBFEF4YDgPFGYAVCRaHGBMYJxaPAuISzRrZAHIAeRTkFo4QfRmKBX0U6xgdEF8WlxgzFpkZgRmTFPUYJhaKFcMa5hBsGugNnBmaAQ0a7RmdGC4WqBUDFCcBDhgzD9oWrhLoGaYYORCQGkQZqhoOFdAaqRlSFrgYQhpVGPUWwhUhGEcWxRm4GbIZuhUoFSoWzhnAF3wYVBHRGcQY/BlvE8sWdBGlGdMV6xnVGI8YZBbiFUUaaRkOF5UabReXGeIZExpyFVMYdBnnGbIW9RnqGc4Yehb5FhYYfhnxFWkagREfFwMZ+xeiFgwbSBNmGe4XChsvGmIYjxoAETsaAhQ1EV0YlhoGDm4aCBLxGUwVgxfdGxUaqxoQGh0aEhcmFZAHfRiqFysCHRctFy8YsBFtGigXOxc0E6AYthsBGiIX6xIBEoEZBRWoE5wavhoqAQ0MohdBGi4YyA5BFbMWZhdQFbYTvBrEF/gZaRZrGWsX/Ro6GNwbKxheEaoVxRpDF2gaRRlMFcsaSAJHFyEaRhdsF3QaxRuPF/obGRjZFI0aWBsoGFkY/RiOGP8ZGBXpGQMbrhkFG7AZCBHrF5Aakhs1G7kabBtQGeAW7BX/GnAXmgM7GnoalhkZE60bUhp5G7MZFxemFhAUJBkkGoAXCRknG8QXhhqFG80WHxqJGTAXuRkyF7sajhk1F74ZNxfAGdsaaBfDF64YjxYzFE0WNRRRGRAaBBlHFX0ZSRtfE3wYoxlXFGQWuxtkGKEarBRqGq8b8hqxFGIZUBtoGrUatxczFaUauhj/GrwL2BfwEYoawBjJF/UZZhjvAuoa1xuRGlYayhuUGF0XDBPNGXMW5RviFnkWexA/Grsa1wbJGv4SsRLcErMWgxrfEEwa4RmCBJAYFAczARMa/QJ1Guka6xLBHCMAcxmLFOwWlRryFpgZpBsMFPQTmBmVFqARqBr8AUkcLxr/GCsEoxLdGwQZnxgwFQQbCBmjEuYZkhsNFrMbmRLwG/EaqhihGxQXIBmvGsQZsRMBGEUbGxCxGbcTCBsfGEwWyxbNExEWzxrKG6oXgBpbGssZ0RdjHBYYXxU8G1QSJBPzGzIZ2BbjGQ0buxneF88bORhvFBIbPBbwGz4Z7RnoEeIYeBnsERAXCRtHGfYZ8xiCG0sYfxyLGRwYihtSGf0b5RuvG1cbzhqXGgMbWxoFG+4aohXIGgoYpBt/G54aShOEG2EaERZWG2kYqRcqGKwaGQqkG3AVmhtzGiQAZRWeFzYYtxOkG3oUxxt8F8UbfhOsFy0YwQQNF0QTshuAEocX8xwLGWUaMhjRG40ZaAFrGWobpxrJFI0cFBnQGAMbmBjhGxAapBihGq4XbByiG6AbnBjtG6MbjhzLG5AczRuSHGgZwxxqGykYWxvTF54FpRuxGmEccxpjHOsbthQAGmcURBx4GTkZ3RhrGp0cfBQRGnEYchvDG8oZPhefGncbyBtPHOkZBhkgGoYZIxYTAUgXqxn0GoIclBu0G8wXsRvXHJkaihkxAacb3AHAFikb3wf6GTgcGhYuFEYalRvUGpgH2xqTGpsb6xyaG+0XGBteGqMbYByfG/McVxmuGVMc3AqzG/gThx0vFxUZWRwAFlkZXBt7GV8cBxopHMMZYxzFGsIX9hwOAz0cEBziHBIczxsqHBUW2hlyEXAa0Bl1GtIG/gmBFJ0CohSfFKsV1BSjFLsBjALgD6gT5BSnAmwBPBSqATwVuRrGEkATtRp0ETYa1xy8F8odJBxsHQ8ZFx1sFKMUvRbxHIAZ5hntFMwc/R0hBjYdcxwzEkoF4RTNFBQU0Bl4FaccHxxCGtoWgBaRGt4WhRwoEFAZgxrkHCwa5xxDHDEZhxgZD0Qa7xaUEsga8xTwHE4ZpRw8EHIa+RmXHZIcLhraFqMXuRGoGL8YLwZsGDEcTBCGGwsVChaxGDgcURzUG5obERpJGawb9RxYGxMZsBPFGEQSDxhGHF8TBxUlGyAZvBsiHGYbJBj3Fd0Y+RpZFTMdcBhcHNEd0BU7Ft0dBRVAB78YZRnZG7oc9hu8Gfoc+hnjHH8Ycx14HIcYShEHGekPQxtDEQ4bRRb7HIkW6hyPFWUcjRu9GfcXBRtPHd0YixxyCrsVPxyWHQkYlB0oFxcaoR0rHJ4apRoLHKEduh0xGOkbZhilHKcatRtqFZIYqxoYG24aGhOYHK8aHRwCAQUcsxt3ACIVoRi5GrgcAxomGrsYvgf6G4QX8QEkHMAYxRwIHUERjRrBDXAKjgJlBgUXTwykG4sH6xjSAuodZx1JGcEX/xhbGs0bLAUOHf8bDx22HNYY6xdyGkceBRsSHgcboRq9HN4cygHXG6Yd5Bo5HOQdzBurGcYXgx3VFe4aYB33Eyob5hkBCi4aZhu5HPUdHhs3HfEabhbtG8EZ5B18HQYCDxegGngdBBz/Gl4dBxvNHfsZJRvRHQ4dahvUGn0ahxktG1odFRvaHRcBSRYnHRkajxe/GpEc9hvkHnQc6gIPF8gdIxJMG+obOBY7HJsdKgEkGJkdLR4CGU0aqBjmFkgeRh0zEBQasBfkGrIX5h4KF+kdOx4cGiUX7RgKGO0eJxZiHUIbhxwMHjMdRxrmHBEeNxluHjkZcB47GAQcGRSXAUMa0hgIFn0dhhrmHCAcQx2KB/odjBgQHCkC8x2RHEEa/h2VFo8WkRw1GvEZjwEKAD0YNRacGZQdohB2HEAcLR2IGukdpxHRHaobBRxKGwcVBgO4BYkYNhULGacdtRxTG2MduxsWHpYYoB5BFrkcWh2+GlQcXRm1GxwcYB3EHGMYThxlEMAdyRpXHOUY+xusHUwd0RdiGy4T+BswG68cdRhmEzEd2h5fFugdJxQPGRIeZB3gGeUW8hyCG0Ad5hVcE0wYextGGfAcihtNGfUd7RtNGfkcex32HwQbVRyVETgYkhtZGUYd/hiYGUoekhzXHgMdMB5FG2UYoxcjHp8RYQi/Hg0bbRFoHK0Yrx4TFakTpht1Hg8Toht5HTwcuBc+CX8XQBlhHiQYwxdFHiIcCRuGFH8KiwyYHiwMmxjOHMcXUhzJHjQbpRrHF10czhXcHNAcbh1OHjwUWhUPHucYnx6ZC9gc2hoPHkcRwRpQAz0eNR5NGxgbJRnCHlAc5h7/HOgebBqEHOweVxRJHRAeWhplG7cZCh8LHwoetx8MHowbvx8PGHAdex1xHQAadhQaHmoYiR+MHm0afB0IGJMecRtSG9IfeRvFHnYdEx55G9kajB0YEj0AIhQ/GpAfoh+FGpoAdBk8H5odIhvoGUEeix5hHyoaoB8sG/Ae6B8vHpQenR8xHbgfax9oHTUWUR03FYwatB6gFHUeohmzEYAauxXLHqcTtBzEHqocxh9ZHq0BEx6vH3MeOBdhHrMblhrPGXQeXxl2Fnwa1h69Htga2xmcA8UZyhl/HCccTxK6HsYe1x7IGYYZiBBdEEcezBmNAREezgBuGvUdjhBwHtMDmxw/HaQf3h7aGZsf7BB/Ht0RbRmhGDIcTR2wEIse5BsOBE0ZqR5AH7odvBlRHukYQR29EpcdvxP5HcEYSBxhEQYdxRxkGFAcZxupHv0aWhznGccfqwY2H+IZzAsdGHkQ0h8BHHAd1CAhFuAd1xszGGcfhBprHHoZRRnhHH0c/BpzHIEd4xyDEyMchR8YHeoYfR8bHx8bShQrHI4fIB30HyIckh98FMgbVh8nGgEXExyZF9EdKR49EUcdLBxUHJ8bYh9nG/Ye7R+9FdEfNR05GKgaFRtsHKseEB88GhsYsRywGh8bdhohHLYfRRUfHLkQQRt+H04MoRosH8kUfB9QC7UbiR4wGjMbjB5JH1oc4B5MFsEbqB9fFLgaPQGdHU0WchjgGDoc1R8uHu0c2Bq9H2odMhyfGk8ZZyB9HksfXBW8HOMgHB91Hv4eUh5mG7UeVh8kHO4eWRpkEekfgRzzFAQf2B+nHdwceyA0HPsbwiCdEgUeaR0DH5EehR5nG9UXsR5wG9AfmB5zHlQZKhYeGSwd/B56H6AefRk0H6MZNh0cG+Efpx6EILwUGB6JC38frx3dHo0gUR+zIFQftSCMEnEb/BRuHuscVSBaGOQdNB6bGqcfuB04H8EWWB/DHhUfxQWHHT4gcR6oHikdQxoxH84BaB1IH3EggRW/HwAfYSCHHBgaahVIH9ocHRwFGtcC7QEIHYka3BBHHYwa4B/lFogcKxrmAFQQchraHskbAhryEt8ezR2cGZAdnhw7E2Af9hB0GCcQySEJIQse2RT7HEUeGR/gGZ4MuRsGEIQbCRuCIRQdsQISFrIgUhGtIIogVSAOHFYg2iBZGk0bFxxbFR4dwBxeIBUe9hbJIBkZvxhSH9IY+BsnH3YgnBbYGs4Z0hhgIEkWBRFXGdcfCAt/Hl4gqSAyHPkgrB3fH4sddglxGHsgOhcMIDwbRBntHxoc+BtJHnId8B8cF6EfIRlFHyMXDB3VHfoYkxe1IFAfKxfVHgEftiBXGOchMxpLHggbfxv/IF8fOBoWHg4XNhtvHz0aHB8/G3QYtCBpCjIeGhojFzwepB4fHLAcvhUHIHMdQCDrFH4gdxrDG4ogeh4yIO8UrSB+IJYeTh1LHrIblRxvG5cXZhxSIXAg1hXSIA0eBh8zH2gbFxzfIJUf0R3KHGkgmxpcH5IfehkCHO0d+CCiHPAeWyClHl0gqCAxIV8TOSFTGzshVSDLH44ZGhn4HmsfBR9+Fhwebx+WILkXASC7ICsZGB+cIL8b2BIyHnsajR5/G94fpRPfIMkdICGyG8UgzR1oFjcdJyFtH7Ihbxg8HpMfvyCPHpggkRv6GVYg2Bv+HzYUcx6hIOYdPR6lF+8hjx/KHqkfUR/NIHwfbxulArohrRuTIPUaQBZ1HVAhvCD6Hrka1BgJHB4a5iD/AUoa6RwiCYEhBB/kHZ8hBx/nAG8hChLTIQwf6hLCCXEezBw3H/Ef8yEGGCQcPiEZENghGyIaIR0YKhakBBgcMyEiFSQe3iElIAMa9hxQISwfZSGjIAse6iGmHzIhMR7vIBEe8SE4HvMdwhbGHeQgGB74IBoe+x5PIUIhsB3PHjof1iFHHHEgoCG2HwYhTB3ZIU8hvR8NGG4grR5lFMARAiFYHxUchBtCICYTTSA+ERMgQBVMHe4WFx5zIWMfkBNkIWYgSCJSHlgfJhiRIE0VeCFsGp8YlyHmG5sgVhceHkQiOSGoInwbZyHxFycgYByqH0IMCx4RFZkhgBt/IOYeFyBqFzkctyBtH0cTqxSbIOoYwglGH00ZYRwKH8wdRBjPF1EdRB6sEo4fWyIBHBMiAxrOIIgePh9mIXMekxudIn4bnx+7Iewboh9uIqIhmSKkIJkiSyAeH3cgICHIG8sffyCGId4b1BeOIboc9iJXGdwgqiAzH4gbOh8QIcIh0CCwHQIhxiCzIcMflCHLF6khzResIc8ivB+NItMdEiHTHRQfnxYlIMMb3SDFHRsQch6CH4MgyiLNGT8frRqZIM8gqxvsIW4b7yDUIFgh6CHvBEoh6iKAIqwh7R0uIvUeniBeIOQikRZcHAUfyCH4IHUfyyH7Ip0ioSGYHksiAB42IUAiTR/VIZ8f1x62Ej8UmR1UCXEdVhQRHVkXVB1bAxkMIx1fATcdYQInHWMUoBukIrUdJRkdHyUbtB1+FLMWNRutItkJfSMrCXEiYwgRIDcd4hNPEk0dgSLMIy8Q4iMxAHMdgALtG8YBHh2EGtUevAETIg4diRgNHCUdjSEGGuMa+hrlARMiGSEAHDAf6h2XFpIdmRgcIiAhEh7PHDoU8yEWGvgf9yImHtYiGCEcHEQiLCNVIi8QgSIxGaIdryI0IAYdtCCJHj8giyJ/Ij0i9yI9G6MhNhPDHvIBaBMFGx0gFhC2IkYZvR75DlsTFB78IJoiuSFEHdIiBBstIUgicR99GRcfByJWIgcaaCLHIVIiySA1IK4iXSFXGz8RBhtBHeciYx8ZHesiZxnyHx0iayBBIm0ckRYWHJMgtBiQE28idRyYG1oh5CJ5IvEiOBqtHzAhMiEwINwfNBymIv4aFCF6IGEihyF+IGUbch4UH0AhgyKHHLUikCBsIwEbfR4gCAwfSglFE7EeJiMEGWIg7CKcHisPUh9VHi8NfB4xEZQhlwFpIqMjDR3KH2Ajih9jF2ciqiDdII4irhyjEVcfbCGqHkoUryK2F30gHR3OIy4jKSK9IKMd0SLSEegT/iLDH4MixSOTIVEWOiOWIlsfESCvEecgsSLQIyggoRuvHREUIyC4HQsgQhVnI6skDSC+F7MgwCLfF7oi4SHYIuMh2hu5IugjOxvFHogi6x1vIu0iyB39IeUjsyHnH7Yh6SPqHNsisR6aG/senBv9GrMX6CL/I8ocBBt9IwMVrhq/IHYbiBrDIf0itCMLAhEggB9eIPQhnSK/GN8g+Bs2IPsMsx/cI0YjZB7ABy4jSh7DHY8cKiIXI1EiDxrqI1QeyyNXEsYjWRgfHuIe0iNfIRga+iEaI1AjZB/7FqUeIRxIISMjaiACBmse0RawISodsyI2IAkjciKvIAwjdR7tITUe8BxcIkEjexm2HcMWxx73I4EiSCE/Ia4j8xeBIw8hnh9iIlAgKiQgIUsgLRx2GzQj/xREI5QkAhH6HmMfiiM1HxMgOSJgIDsiYhyGIzchXhtMJBEYhCOmILIibhz5IWckCiJTG7Qhah8pINEi8BydJCohpCFyHpci+CFxI7sg4yO9FZEhex86IoggZB4SIosX6yKOIYUfRB/EIfUhihOrH0kcwhOvIpgcwSB0I9QhkRjKH1Mj2AZlI9oTuRzIJEAjCiPwI+EiAiRHICghoCR1IS4g1RpNII0faSQtIrAi+SKyIJMh/iMmIPIkRR90Irgj9BS4I/ofeyONIEokDCK+I/wc8iG7IxMixiQBIb8kAyFUGnMj+iQIHfMi0SLpIcogtyHMJBAhYSBDJBMgvRIrIt0fniHVIMISNiLiH6QegR+mFfQkHyP2ItoXyRvpF80h4yJ4G10ekB8tIS8kKyL8H7kkeCHrJOwkMCHuJDIg2R/AJDUh8iDlI8UeoxleIfYavSTSIpsjByDuJNwj3yB+Iwwk8SCYIIIk4SD2GAMkShrRHBwkTSNFAUEkUCECH+EZfiNLIhUjTQSNI08jYyIpJFoU/B/rEH4f7hmOI1of8iNcFociJB7UCmsiJyRnJVwkaSEgH/0jaAlTH+8B7SRvFq0jbR2yHuUjcCPnHuwhNCO3IacjdhKMI3gg5xUgIkIhOiSDITwiRyE+I4QiShMZIUMhsSOrICMJ5AbRIzMk4hDbI4whaCHQI5AcdyOSJJYlAhu+JJkbwCSbGz0jNgRKIVkJUyFbHekhXSOhIb4TXiOkIWIkqCQJI6gW+yOqIWkgTBtYIE4jsCUmHJweACS1JOcjtiI7I3MjuRylIoIjvCKEI74ihiF9IokXMCBmI8Qhgh4WGiAkxyBrJMkfRhonJcwXRxWvGisj0iQ7H08jBiGSE7gY0B9YJUIfcCREJUckRho8Gj4kSBpBH2QkdiUqIaQirSTmJS4kuSXtHN0isyTdHMwlRh1KI/IjhiT1H3gkkB6GI/slSiUSI/gV8CP9H6cklRkPH4clnx+JHH4jOiUgH5MjQSFkIccmDRqEHnYkDxsHIc4d8CP6IdIkFiHUFiMlGB5+H6IlGxvgIuYh3Bk7JAYgzCQjHoolJCYII7ElJyBTI7QUYCUsJX0iPCXBJC8DViDfBcAelSU1GKckNiXSIpIlPB0/JdoeKCTUHqsj3hf5JUUl4yX4JeUazCMQH2IetSD5FfgkTBTRIgwBEwbhBpIVUSEBH+AiExTcIRUlWBBUHZIAUQdOAu0BLSNTJV4hDiIfHZscOSEoJWYhFxLVI2EmXyZhAuImYyNlHaghDiVwISQjayV1H/QjbiTkI3El7CXAJXwlvyXwJX8WvyR9ITcgEyE5I30hOxm7IT0bIySHI4Uk9CSKI+MhRh3TIbUichu0JZkklCWbJgcfsCHAIssknCJeI5sQtiOdHxchXB3jJKQgRCSmJKUjpxs4JKwgnSSwJbcfsSOyJLQiex6TJLcleyF1I7olwyS8JcUkviO/JcgkwiKKJcshgRyxJMYGayGGIwAkOBy6EVwk0iXYF0YhjCU/Jd0iniPcI+4glCTeJfcesCSLJegUkxzTJXkmLxjsHNkk6iCQJTAfbSTuJEEm1iZIJtghryOHJY4k9yG0IUkZHxeHH4Ak/iLEJpoeYCDQJQQhwSUGJQshxBvHJbAiwCX+JhQlDiYWItcmGCb7ItsZKyYbIt4lFyLgJRkkGyYhIMcmIyUeId0mARRMC8UlIyHiJisluR6PJi4lvCO1H7ckMxv0Je8j6xXPJjUgWxqmJjgg4SY6GhMatiHzJTklgiBuEYIkOiXWJDwl3CQ+HUUVuQdgAZQhmh9yI+Iiph60JUwdUiVOJlIg/RrmJlUmYh2JFJsmWiI0H+YjTiZvJlYmch7JIh0cNCRdHDYmaBr0JWUkYhw9JWga+wETJmAnTx2mIR4iLCdSJnYkbh2uJnkcTyZ7Jeok5SLzJX4keyYyJn8T2iR8Ij8kfiaHJYQmiSWGJosliCaNJYoityWMIkwmkh47JI4mlSOOEkYmmCAvJgYm9iLuJgkiyiWhHXcknSM3JaURCSShID0lqSA/Jasd8h0NJa4iaCBFILMd9SJwJZcl/RNtJbUclx38JiwluiUoH7QnbCS2In0nIiQuJrUkuyU2JrwbayXHFZUlyRtxGLIfxCbFH0Ml0SH0JdMkywE5HLwilhy/H0wk0SPTJtAnNibSIZUj3SXhI+Am1yMOJ4Af1iKoIAgnayKrH7Yl7ieqJ3AcpCY1JtQk7yGsJN8lixhWJusdzybtIJ8noCYSG8UiwibzI/4m9R+GJpwm+CaeFVMlByLPJQkkrSaWI/cebiUNItUlDyC6JwUnoSHRGoYfnRIwJBgb2yQaJiAgxiLlJR0Z3CUfJAshyScVHW4mKScYJ+4kJyayJbsmtCUrJTMZUCR6Gk0nJhdrJTEi+ygYJDQmOyU3JsgeHiMCHqYnxiQ9JkQlQic5AW4j8SZKHG0j5CZOJEsdUxS5IxcE9B1YHWUdWh1/HVwjHgiAHWAQsiMiAHIdZAE9Iasm1hSxJv8KvyM9KA8LfyP1KAwdchrmHW0ddRegI5kTQx3jHXom+if+KEoUzCYPI0MiCydEJlQmcCZXIhAjSRK1IQUlVx2QJ00a5ideJ0cmZBTlI1UmZxTuJWMiIiIVJWcjYCRlJWoAbyhrJnEnYCIrHagjZyRsIjAdrBxLHuAhJyAEBeUnaSPmI7QnIx7uKBoncSAQEv8gEg5oIBQndyJFJIQdxx76Jo4n4Bj6J+In0CMRJ4Im7xnWJJIhTRkMJ+wc9yJZGm8njR3hJ48lpCSfIVonkyalJKMlqiaqJ/wlESJsJKklsRNRJbMh0CavInYgTycaISwekSZ+Jx4mtiDbKBshdhRvJrseDCS/IGIfOxFwHK4kxBlcJ7oXNye8Jy4kyhwFI80H+yTOIpcj0SbOGMcnNR9SCo0k1x4uJ8kk2yX0JUMn3ifOJz0lSSgxJtwiqSbeHkIm4CetJOsn1iXzJuUl9RzhKOkmjyd+KJwk9icGJf8bsif+HlUm8hXyJP8mTyWcJ5ceYiWgJgsoWCfnG9QlCBVrJhEoTiUhJwEn+icDJ5klESYZKAAlFSgCJwskGScNKAYi5BLTJxEoCicTI/okIicWH64mKigSJ6YnGxRbIvIn1SGkJCwo8ibiKPQg3iQxIOAnICjIJ7EcASjVJ74oJiH3JkEhkBKJFbQj3igsJEMaVCDzF2AmSySMIPciBiUAJlAiCR/bJVAnRih7KGMdiyRTJGEkVR7FKGknXShhJ1AkWxgaJ1QhESRgGCEnWR2hKHYdoyhqKV4ofBsAHakkaxmWKIEcNyZ4GDQpWSI1J2omfSkzIjoojRCaKI8bGSN6E8AjfB71J3gbIRm+J3sm6SSJHGsonSSNJpQooBsxIlUlmilPKQcopySaKQsloiirFVcorSWmKK8lqCamKLImqCUQJBIotib+H7AmrShII6wVdSW2KL0luBtcJ6cnHCgWJ6saHSl7I+wlwh4JJcQoyia+J7UmwCXKI8MmwyBoI8cbeCjUJc0nLyKTJ8AkzSbMI9AYxCjdG4Uo3wuhGMsfVCTYKOQl4CjmJeIpSCTyH9MpSybaJOMpdyV6IaknbyaCJjQm4yfcJuYl9iboIw4m6iX7IrspDSX+JPgn5ikSJg4n6SkEJvQpkSabJvcniyOXIlwnFB5oJ/MpECUKKQElEyekH5cmFykYKP4mGhqIJwomHScMJh8dGiQdHoMpJSj+IeAjJxqcJJgpLCjAJSkl7yYwKCAnISfYKd8oxh9sKBwnHyU0IXgmPCe9Jj4fxygnKUEh+SPVJUApRCgrDCIoLSffIZwf1ClMJUspTikGFJgpUSD8G30a1ylUKGIf3x/9GX0JCyhmJlwoaCVZJ04obCVdFOUmZiliJXIiISdYGvcnWiloHtUqRilVJnMU/SEhKIAjaSAAAbUldBUHJmoohyV3IAchLSl4KhsoiyUtKmUpfR9xKX8ElSSBIkQZuSiWKYUdyCiZJ30n4SnoHlMh0CWQCxwlkh11I+QonyT5IUoSaCmPJpkp8yeJJCYfDieMKZUnjiagHxQjnB8WGesnlCmdJ5YosyoCKaElryf0KLgVbyp+E/MovCOvJrEmLSkuKO8gXCesKmQnriS6JronsSm3J7QYrSm6J7cgZx9BHLQpwCPJJj0jyybKIYsXQibNJ8Ik0ylDIHgj2yfKKeIo9yB/KdUl5ClKA7Al5yWUJ9IqYincJ9sp3iiLKh8gkh1GKeMo+CnlJIgl+iaRKP0p/iYCKQAp6iC1KfAbuCnyKjYqhCOVKfYkBCYMKe4ahCkPEScpESSuJ/cnBxkiJwIdDByMKgMq1yf4JwgqBiUWKggpHioKHoAmIigJG+MqDiryI68oSyHhGUMlJSmsKS0owSoXHTYmMSaBKswj6CY2KTcnKCk5IOIpOyctKcIo1iQ5KicnMyXbIfom0SMJETcLxSovKPkipSjrIqcnQB/ZKjglTyomErAYDR/iJVYqQyRWI04ZhSVeKG8qSyViJmkohipPKWckZBmXEtgnYSh+HtwcSSpaJXMnZipdKzcpdiiJJx0qZysLFr0jdyaFI3kkfymAKmwbHiAXKm8jghhRJ3wl+SaQKYkq1iraBjcZfiAkKnoZzyYAHwIllif1J4QJfSeGHwkniCftKfUqhin3JAUoVCJfKowiYSOeJKIESianHfEiaR8eJ5smECedIEcjqSmNInMjrSmpKpwksiQoJrMdtyjDKqIpMCfZKbMigSm1KMkcqRoXJr8oziF/JsIijCcuKNIjyB4bKiQqsyBvKNgquB9LJNAl2SsZJkIXSiTWF00fVhFwJd8ioCPeGlICDxdaKC4qwwRNKsUrYibbIaEe5iqgJOgqZiqkJfIk7SrPE8ArrhjzGlMWbSnWIUEo+yp1JiYhuAvYKtkq5SfoHPEp8SfrKoMrayeKK20q4ykMK80pDin7Kugp/StcJBQafhvPJ/sqkxYZKRkb1ikbGS8pHSgEKR8qCyUcIdsnEiYlKaYXxxaRJSIpKSgRKfUqFCDTK7kg1yoZK7so8yu9KB4i9Cv7KxIoIicsJTgrFSk+KxcpQCukKUIaMCosKdMnzSrSJOAqMinZIxIq3yZRHYUrKQNMJ0krLCpCI10mXRaLGBYlXidSJWEf8ChyKk4f9SRjJm0odxmYFqIrPRLbHEcpcCpZJXIpcxsKJXYkcyV4KO4rSB25KXkgDyI+KJAiQCd1JIAe9CSCKJUlhySFJYkphyrUK1ol/CtcKngMCyAlKnsmkx8DKe0q6ieFKoEnhyilJJclAyriJQUpliqKJJ4rciSgK3QqjyixKpEpnyi0KpQreyarKaQnnytlJPokryejHfsidysFKhUnqSuLK4kpsSbhJS8qpSuPKqcrkSF8KbkrlCPCJ7gijSXPJsYkyCucJskrngl/IpUjzwJfJ8QroybPKCkfzSGUKOUo9hW6KyEqMReDIIQaPyKnKO0n0ypjLHYb+SjxKqMr/SW9IaUlQiuuK7ETFymIIB8qdir/KP8ngyxuKusl/x5cKt4bNivTKoUiWixcFvAn8h+PKLcr8Cn/JhUq7xQpJ/0r3Sn/KAEr5yr3K+kq+SHZK+wkHir+LMYmJykoIuwpKiv2KL8r+CcdKhgpOCU0KbInJCbjKh8fvyoiKCMkNyglLAglPSgoKcwjCCZFLA8qwSZJK7IjiSskKjUoMw8aKDUUnCg3FIQVuSMcKlsCjCMhFKkjJChFJfYoRyz1FLQTVyMtFLgs+hNXKFImnyOaHXkjOSvXLFQJfRTLHYEoXAYSDnAPhgBlAHcB4QWUD04EuhObAU4IFxMfADMJWxA7AUoG8wW+BNADmyROGtgevyVTJ0of9BXUIPEtKh6+J0gcMy0uHE8tMB6uDxslUC0zKVYewSNKLBwQiy04H9AtOiZTLSsjSClXErUkVBW5LTEtOx/eAC4tLSwbIhQbDC1CB68euy1FI0ciEC0tLT8tUhBvIyUkQgKLLSotWASLJ0ktWyZbLV0tAAFeJUUtYSRQKGQU2i1cLUEtaANALUQoXyVRJVwkURaCLUkpdS1eEpAtaiVQLWItTyZZLVEtZi1wI+8Bky19LUUqPCZyLYAqPy1lIjQV1ClGLWApUylrIhAtZChlLW8GSxdULZABKy0qLYktRy0+LZYtgy2YAgwtmi1zKjonRS2TBIstbRgPLXotmSouAhEtnC2oLYsZfC2CLY4trSsfAZUDMRAGAQYQ5Qz0EUUFECAjGAsOZAs3ADIGfgXJAlAZfgJjEEMHgQRTLSQBEAqfHD8rPCh9KlYlbypYJXEgAStDLDQmeiGxLcQG8Q3XClkAVytbK9ggIiteJZEqjhZxHaAWngObFZsU4CxOEEcEwARBBeECOQFNK5IVlQXcA74CUQTJAMMAqSllDd4BfATJAbIG4QTRARwCIgInBH4UiQXREukiCgjHK14dhxr+LcIGbi3cLcYf4gAgH/ka/i3LA7ctzSNpFPcmbh7HHEMlbSZ1LdUZoCz7KIQAIiwmAzETHy3cEvcMJC3fLeEtEBDiLE0ZzSWTAowtJwU1LUstOSNeKlAB4S3rFokGpy3uA74t8AIoLfIE0Sx/E5Qt9hFPLfkt+xgRLf0E0QFJAHMuAQI5LgMNMS4GBsoEvx9jLb8uDCINJGgNki3DLcUFyi4THZIkWBraLhcESgHNLSUtzy4cJWsjUipVH/wQfidkK0EsMyiFLDUuKAZ+LioOpQSyLeAsSy3iCr8uMCxPK2EIvATQHWYh/wIRKHUuOhFQLewuPQLtA8IUxC5CAjkuRBcsLkYt+AByLfot/AIdAkguTC4AA5ouli4EAcASky4ILlYC3CAjKjstqC4PCDYuES5eLcgqUyo9LmMSZC5lLc4rOipSKWonXyIqKW0uICwwLdYuIyEmLiUqXiRyLnMt3S4rCQQueCnpLnorXRnLLeUd6BGjA9AuNC2iAuotpC44KzkDiy47DAkuiC3vLosCUC5DJMACVwW+Lkcuki5JAuQaSS3+Lk0uTy6aLlIunS5VHrotwBBDCAoYvxBRLlwAMC4SLcgQVi4UFpEuqwukEDwuZywqLdEpbSh/LrYuIitCLiQuJi3bLnQBUS6/LncuLSf2EkYufCtgLecuzi3pLoUTiS6HEF4u1C3xLtYujS7YLpASai7cLpQu3y6XLk4umS5RLgUu5S4JFnwu6AE4J8EuWy4QLl0txwERLckVkSdSLvQuGS73KzsZmSEfJ2MuIRixLdcu/y67Ar0uvS51DG0uwSyuLEwt5Cp5LeYgJy8MGCUt6i6GLjwvES4/LtUt8y6OG24vFy5ILxoCRy7gLpguAhZTLyAuBy7mJ0IC3CHXFh4AbxAPAY0L6Q+zEAEDVhaQKAUGewaIEA8CaC9jARgPvBIvFMcPwBMIBm4DuQBmC+IIHA/GDnkF8A57C+gLxAAvL2cr6i9qAGsvfQJ9D9IP1A6AAekP2ArjBKMu2gv4DFAZTQZPA8ENCS5BAnEAdAA2DeoulgBzAGsEQQTGAnIAMwIHAnQFCgdbAiwOhQAgD4YDSQ+JLf8CWwXcCYgdiQrFLRctGQOLLRsHRgBjLR4OcxLRIEwAVgFILmYHtgT0DxgDMQ/qAnkYrQMLDbkARQERBWcEsBMtAm0SYBaoBM0FNwZ4B6kHbgAvBT4DfhAdDG4AaQB4AlMF0wFIBLkBkhrpDdQCeQX1CP8P5AMZBdMGlAJyEAUErwbCL08aSQ4eDdgOIQofBXoF1hbZLpYQBwEHAjkL0gO/BcoEtAB5BLYL+gbHKHsAbAHpLcYcLxAdDgQRHwIqATkZfgJUAjEIAgNJDd4AZgFVAHcKHwBMAuAQNgPCAnkCTwvDCGgvzgUqBqcP5AhsLlABBgO9Br8DGQEFDLwJzwJNA8QHKzAYAHQBTQ1JCHYYCwZkD/4C4gsMCdEHVC/cAnkBXC/fDqML1wAgL+MQBy8rBr4NvgJ6L+4FiQofBogNkAAgCXEE0QJVEI0HDgEIA7sFvQhWCv8KQgawDYYMCwXTDo0AdwXDMCcRmgMZDToIIAwoFZkCLBT+CBICega7CEMOADBYL+ACeg2hB/oEpwE5D64vzghVDhUCcwFJL6sL2y4EDCkEuQKfAXEKHws3L6wcQwS8AlsLEQdnDxwAPQJeACMCcAVGD0cidAtXBygBwABkLgUHVC+nD4gwHgexAGQOmwIpAEgOVgBQDT8GdwbLDL0EzQ/rBrkwWgIxHV4PSQJzAXwFMAdKCh8OCghAD8wRVC+6LvYRewBBC28wTAI5ASYhfAGzD+YU0i8sFlMTdTCnMGgQpAhIBf4JxAslAnMuxjBtAjkGQQdyBkENzQbFL+4KWQofAEYv2AXFEaIF9QECB/oI+QFJAnMIegBqDx4ZTQF8L5sCjgP1Lu4Fyg+oCXEvoTB9AGUJWzDoEAAw6QGyDFACLAO5EAYGzwh2B1YDSjBgBsIFSgRcLkwLcATTA3AGYAN7Lq0QPRRZBRAvXhIrL2AUMw5+LS0vlwP+AXQQiAa0JV8a7i8/AD0xECwnLjkDizETEY0lbi5tARgvPwEkMRkBGBEUBgQLoR/6KIghohjmAUALfxBRMS0j7gvsBpoQNQf/AsMGAij6KnQq1S55EK4NmBaoAC8RogAtMSQrtRGlLFkTVwHpAosQuQIbAHMYLwRqK4UoFCw4DLMvpwxQDmQxUhI4Kmgq0wF0G4Mm7CATMT0U6wYuB/oOBAB4ImMALTDnBVcCpSRIHcAxXQy5MV8TSgULMWIW2TFkBn4xZiwsAQECnw/wGC8vvyLvK4Ym3RjmMNsjzhaIMX4o2StMKsIsqxj5MVon4zFcDmAxPjGBDCMUMzFAMOcxaDGJC9MxiyvyMBYhTTFxGp4rBQGmAiUwDwW7AQADIQ+rACIMdgH6EvcCdRG3A4sEfga0AEkH7jFqBZsCiAM5AC0AZwBwCVsAMgAyAdIpbxgLL5cBJAAvADkAagAvADQAQQBBAFEAUwBrAFoASgBSAGcAQQBCMcIARQBBAFkxyjHJD2EP8zHJADcAUQAxAEoARgBRAFYAUgBQAFUAagZ0AFoAMgBRCQMCZABaAHkAQgAyAE0AUwA0AHcASQjrADEAYwAyAj4x5gBCB1EAawBjAGcAUwBsAEIS7jHnADIATgBqAEkAcABMAEMAQgB4AGQAVwBGFNYAWABSADUASQBEADAAZzIAAEEASzG8AHMxwgB3DKkAQwBRAG8yBABnMhIAQxA4AEwARABnADQBMwB4AE0AZxLuMeoARQBoAE0Q3QBCADQAWDHuADQAcABNAjYAdQBLAFMAMABzAE0AegBwAEsAUABqAE0AMgBSAGoGAABMAFUAQgBYAFEAVQBaMjcAbABKAFQx3gBJACsAVwBtB5QQ1ABCAEsAVQBWAEoAUDIWMhgARQBPMiQANBQDAE0yWABSAFUAbQBUAHoAVQyEAFUAOQBQAFQCyzJzMnUydDJyMngydjJ5MncyfTJ8Mn8yezKBMnoygzJ+MmAAODHBAEUAUQBnAEQyGQBMAFEAQQB3AEUAaTHBEXkxwgBNEJEAZgAvMc0AQjKHMogE6gBRAcYxzDHLMcEypDKlMcoAQQBnEa8AQgBRAFkASABDAEEAawBLAEMP8zHNMkkyjwBBAEkxywB3AE0yBQTrAEYyqzKgMqQAQgBmMqAyrzIZAEUyiRAoECMyvwBCAGgATgBSAFkAURD1AGMAUgBRAHkAZwBaAEcAaABDAEMMqgF9AEUAVjJvAEgAdwBKAEQATgS6AG8ASQBKCOsAWQBYAEcAQgBrAGEHUQBZAG4ysgBrAHEBMwBVMf8AegBnADUATwBrD10yTgBIAFMARQBsMlwAMQBSAFYAVgb8AFkAVwBWAHAAajLZAFYAbTHhAGgMKQBuAE4AMABkAFgAWgAzBzIAbAA2MiUAUwBGBcMAZQBJAGkAWQBxMcQANQBTMwsBcwBZMxQAcQEJADYx+gBwAHEAZQBvAHEAYQBxAHkAcwA3AFMAMQFbAGUANAGwKEIAdwA4AFQARgB4AHMAZgBJAHkBfjI7ADkAVABWM0EAZgBZADIBKABoM0QAUABrADUAZQBiAG4ANgBPAG4AcQA4AGYATAB6MnIAWAYGAC8AagA1ACsAdjKaMcoAODKjAE0xyzKgM3cyoTLBMqYxwTHLMqkBxjKsMq4ysDKyMrQBnABVEJEyuDN+MsEAdwBRAEgywDHNAEEVogBkMhkzfjKXMcsAVTIuMqwAUzHaAEUASDLtDlUASQBqAEsAQjIFB8My8QBHAHgzjABrMkMAMQBMAHcARgBXAEoAeQAwMhwzsQBEAFQAaABKAGYGPjLvMvEASjLoMjoAbwAxMgAAYwA0AE8AVABwATQy4ABHAFIAMDO5MfoATjJdAFYAWgBYMgkCUTNXAFIAbABaECsAbwBhAFcAcAB6AGQASABWM1gAMwBoM14AbwBLAEQAaABJAFcy2gA0AGkzvzJAAFQyUQBXAFcAbAA1AGkz2wBxAEsAajJAMlcAcAA2AhsAcQByAEsAegB0AEwAVwAyAHQANwBpADUJcTIjMigy7gB4ADgAajOyNAgAVDPDM9UK3zMRADIAdQBMM24ATwBYAG0zbzP+ADYAdjNoM2ozbDNuM3AALwBhMcEAdwBEMcIAQQfEAFEylw9hMocAOQBPL2AvYDIUAEs0PzQ0AGk0QjHJL2AyQABBBSc0PDQ+NEAAQzRCAkoAQTQ8AG80SgBLNEE0QzRPNEk0PzRLNE00RDRXNFg0VDRONFA0UjReNFs0PTRYNFM0TDRVNGA0ZTRiNFY0ZDRdNGc0XzRcNFk0aDRxNGY0WjRsNFE0ajRvNGM0eDRuNHY0aTR9NHM0bTRyNHA0PQBRADkASwBxADYAagBxAEUARwBtADIAVAAzAFYAeQB4AEUAYQBEAHQAMQBQADAAcQAwATkzXwArAFAATgBXAGEANTNxMUsykgOyADUAYjQuNKwANgAxAGEAVRLcADgAcgBHMggAcAB5AFIBsA/zMcEQpzG+MocAUABPADcALwBBAE8ALwBZMT8AQQBhM1gASQAxMO4AMQBpMf8L9wBGBEEGmgBRMewAUQBhADgAYgBGNKwAZwA3AFYAbgAwNJIAMTQWAEoDuwBNAEsAdwA5ACsAeAAvAHo0rwAwADE06QBsAEczYgEQM/EATzMTB3ECTgBxAFAAegBZM6kAWABYAtQQKABLM6k0BQNFAGEANAByAEgAWgBkAEQANgBLAFQASgBvAHo0Ni3gBQoAYQBmADcQkQIwAFgESAB6AHczVgA0Mzo0RAByAE0BWgBiAHQANABMBskAWjICAHAANQBVACsAKwBJAGsAMwBiCNwAVQAxAHYAcQBkAHYx8TSRL7UAWgBqMqAAdAB4AHkATQBkAFEAUgZ+ADcATQBWADAAWABhAEsJEAA3AHUATwA5AHQASQA3AG0ASABQBKYARAlwMcg1JQBEATIAVQkQAEcAajObAE8AOABrFsox9zSlAFkANAA5AHEATABkAEEAdgBwAGMAdjJdAG4AMgBPAHIAUQBYAHM1gwBxL5oAVQB5AEQATABSAHkGzABiAEgAcgBVAEUAMwBpAEMAMgdpAFoQhwBJD+My2gaaMywJSABCADYAKwB0AEg06gB1AGoAWDM5AG4AcAArAG8AMjWvAHcAbQBTADIAWQBrAEEANABZAEUAWQBLAG4AMwBGNREAbABiMzYASwBXAEQATQBmM1wmYABvAHgAeABnAFUAVzLtAFIBAjQEMxsAMABWAHIATABCAEgATAEnAE807QBNAEQAdgBqNKMAYwBtAGsATS3gAHEARwBvADYAcgBCM+AAeABKAE0AawbMMjozsABOAGQAeABPAEsAYgBaADYAegBiAFgzkwBJAEYARQBrAFUAeABHAFEy9zM/AFIAVA/TAFgEngBpAHEAMQZBAHgAMwBVAGsANjINAHoAQwA1AGoAYgBJNUkASwBzAFozyQUnAHEAbgBCAHEAVjVBAFgAMQB4AFoyKABUAEwAYgA0ADMAOAeCAGo2FTNUADQAagB0AGIAUwBSAGsBiwB1Bt4AZgBaAHUGPgBCAE8HggBjNPI01AAyAHMybQBJADI1VTJuADEAcQcIAEsAZQA3AGUARzPwAGoAZwBHNKYATQBqAHcAUwBQAGEAbzTIAEURrzOiAUEATAAwBLk0NABZAGUAUANPAX4ANwBCAHo2VzQ/NgIAegBXBiYAMABtNccAYgGdAE8AeQA3NCgAaQBYAGMAdwBIAHEAZgBTMgMARABWBO0AOAGgAEwGADHFM0cAYgBqNYwAOQE1Mz0AZgBNAGk2pABXAE4xPwBrDyMAWABrAFYAWTUuNgsANQBSNocATABLADUAQgB3AQYAMQBiAE8AcQAyAHYAOQBtAHQAcQBDAHUAVwB0NVMAYwB4Mk4ASQXtAGoAbDW9AFMAWjM4M/wAQwBkAEoANDJrAGkATwBVAGMAWjYtNZgAMQBLADMFvgB5ADUSTwBXDwY0CgAzAHoATwBPAEIRizZ6AFU18ABkAEYAeQGyAC8ybwBXAGc08gBvMxMzLQAyAG0y6wBpAE4ATgB4ADQ07gBqAFQAYgBUAFcASQByAHEANDIJBKsANjYNAEUANwBwAEkAOABEAtQAZgBLADcAWABEAG0AVgA3AEcAbABSAFcAUDbcBt4vujVNAHcAMwBFNLkAYzcuAEgASABsAFYALwBHAHIGmgBuNqEAVABqAGY2wgArAZwAdQG+AE8AYTT6ADky/QBrNVQ1BwXHAFIAMgBoNyM1DDJYAFcANABENLkyMgLUADEAMQBZD481uzOdAGsAWTPdAGEAMzZOADQLeQBGGj0AWQBVN3EAVTRHAEYASgEaAuMORTbAM0oAaDSQADgAaQBSAC8AUwBnC+g0QgBrNRUAQTXrAGwANzYuAHAAWQBJAEgP4zOrNk4y8AA4EOYAYgAxAFQAeBCoCGgBwQBXNdQAagBIAHoAbDKHADUzzAB4AGoAMwBxAGwyCgBsAHoAUwBPAHYBPDXDAG4v2TWgAEUAYjcFADUAZDWIAFMzqDOiMUYBExEoACsC4ABDAGcASDSlAFU3xzM4NoM2pwByMf8DTwBLAGsASQBxNxEAagBMAFYaPQBENgkAdDJOAEI2EDUgBUMAUABvAE0AMAB5ADMAbQA4ACsAMwBqAG0ykABKAEU0MgBIAHQxxTRRAVUCjgBNADQGfjHKNRY2qzM3ASkReABzNZQAaS/GAEkAYwBZADUASDScAHIARjMbAEEAagBWATwzFDKLM6sAWQfZAHoAcQArNkUAYzNiAGsBPDItNM4ANDMmACsAWgBDMvgAdQAyAGIAODKHACsAcABGNhMATgB1AFoByQBTACsGngBBAHI04ABQAGY3ajc9AGs3bDVnAGsFHAE1Mmox+wBSMwQAMTXBNnoCdzSeN2ozKAcMAHI1uDE/Bz4AQQBKM/wASxAwAFIATjecBwwAbQBxN+g2OzdnAEE4AQBWNssATAAyAEc04DYfAFMAZDYiAFc13ABRAssATABsAEgAbQKfNLYAMDarNcAARgO7MlM04QBENxIARwBHAFY37DIVADMAdAGrAFcAMAB1OAcATABmAHoAMABZAEcAUDS2OIY2EQB4MgwyzwBXAGMATgBYAGcASTU5AEo13BDdAG0GJjYmAFgARgA3AEQAYgBRMgMASwBmNq4AZzLpAtI4eDXTNZsAcQ9jAFo3Zzh1AGI3iwBqAFAARjcoAGoAVQBJBiYATwBGADM32gBUAGYAZABDOFAAMDX2AGcAMjdQND8AcAJZN6AAThAiNNAAbQatN0kAWQBGAE4AawAxMyMASABkAFYBhQBROAU2iwBMAGsCNQJYBRY2pDjmAGI4wzcTAGUATzUtNUU3ZgBLAHAAQQB6NkYAcjdcMt00tgBqAGgAVgBHAFQAUwBzM0oAOTHZNAsAejjkLcQAegB4NaczGTZaMpA0fzSDNHsPYTclNKEAdABHADM3pzaZAEU4IzVhAGwAdwBPADMAcjaQAEgAcABYAFAAKzV4MtkzIABjAFYAaQBLAS8AWDUzAEIARzdFOTMAVQBKAHUARAB1AmkJcTgZCF4AODi3AEsANjLjNLAy3ABLAFgzDwqFAGoAKwBTAEE3kAA1NMMyuABEACs1TABmADgASgBMAHEAWAA5OUo0xABMADk0CQFcADMANwA2ADUP5ABXNSA1dgB0AEMAVwffAFkAMwBvC2wAQQA5AHM3IAA2ADYI3ABmNeAx3gBGADU3EQB3MdczwwA3AEYz2wBMAHMAegF9Ap8AUwjcAFY3rjlmFy4AdjMLAHkzZwBQAEQAagAyAHEQCTUbAGI2ag5FNh0QkQBsEYsAQjSTAFMAYTVhAHEAYzM2AGE3aTCfN2Y0OzKtAEkzTgBLAGQ5nwBHMvwBrAHBAHc46zcIMhwybgB2AE4y1AA5MmsAMgbSNIk3LTKHOOgALwBxNjoAejSTOF4AbDE/AEQASABoAEgAOQBXOdgAUTgPEBwAYQBNMo41mQGoADE2ZgBtN44AUAcBMgc1gQ+UMpc5mjPpAGUASgBONfUF3jHEADAvlwJOAE0AcQBNADgvzwBiAGgBLQEGAFY18QBONgIzWAB4AGYzWAA3AEwASABEAEoAOQBwAGs1uDdmAEwAdTMTAEw4DgBQNlsASwAyAFoAYjfUB+UAeTh0Mx4PjzZkOJsAaDevAFA4ZTMcAVgAeQBOOUsALwB5AEwAdDG+ADEAeTHZMooAUwBlOeQCdwNeN8cAbwBGA1cGAAAyAGMAZgBYAEEALwBLARQ5WjSJAGQGiDThAEgATgBxAEY5oC/YMqkAcgBUMrI1EQBZN64AbQA0Bt4BojeaAFoANTOwNugANzjlNtMASgArAFUQBjiTA34AOABWOWAAeAA5AaMAYQBqOgA2jzcROkoAWjauAFc28gBvNSUAcgBaARA0ywBPDCk3qgB3AHoAQjJHOgIAaABjNNsyagFuAFc5eDlfAFEAVwBzBc80CjJGAEk5SgBJBq0y7wBuCoUAcABtAG45YgEtOnkzPAAzAGQ3agBDAHoyMwBJNggAZwBYAGoAWTotNOIARQA5Ogs1YzfmNJkAZjSKMiQAUQB6NYsAWQBCOR8AeDOrNlsAaAMPAE4Q5jnHN6EATgBiADMAUwBxAGgAejTEOf0AZjZ1NIcAazg0N70AYjbLAFEAczSSAHIR7TKRNtcAagB5NQEAeALTM60GmgBWAHEAbzVTNykwFQBBAFIAdjYMAFYASzqSAC8AaABUM1gAeTrUOTQ2FwBaAEQAWABlD9I32jnHAFozcAB5NsYAdzbJA3Q0ijqBOL4AYwZtBt4ANwFVADU10jHAMrkALxAHB2oAaDeYAFQP1jXcMsM4iTZBNdgASjayAG4yhwkHBZI3UDpXNrYAMQBaNOU1PQBUNLY4sQUcMl8ASAAzCQcAMQBDNmEANAAxADMAVDcTAGQ0zjdMAFIHdTmvNzsAMgBuOlsQWTUtAHI2qwBNAGgAdTU3AGw0FjciAHUAdQBSADk0CzNAAHM64jqNOIkEQQBvNU4ASTpDNVoAazH5OCc7DgBoAEQ3gQB0Nzw1pDnLAFQAdTHHAEI2Qwb0MpEyazZVBvQ65DtWADkzCABMN+g1LDarADAAeABDAHkAUwBCAFQ1pQBPADEAKzG9AVoASgBXMJ00DQBLNdkAcTOHAEs2dQBoAGcATwLSAGYAVAA5AGEzUwA1EXM1BzI7N6U0CABtOYcynABBOR8AZDsHAGo4UDmFADk4fzNaAG8xPwBDOJMAMwAvNaQ0yDTEAEUASQBWNBkAVzmHAGIAKwB5AVsORTWMAGI7pABxAHEAdjdNNf0AbQAxAHU3FgaLAFc3mjU0Og4KmTV1L5oAVjNrAGsyBwBHOS0ARQB1OS4Pti0XAFAAMzoSAHUzww/8AGQ0nDbOAFcAOABOADMARwAwAHIxwTPqM10AeABUAHYARTNxNDQ4cjuGAHoANTV4AFAAcABXAGgAQQBQADkASDG+DKk1IwB5NT8ATDgMO0gAMBD1AFQ2BABZBZM7jgB5AEkAZznsAksASAZ+AGgCRjXlMh8PYQAyMfoP/AB6B042hwBVADAARwFYBJ0yRgB1OmcAaAArOEgASjMwAGsATwAwAE4AZzLIAEE04gA0AC8ATxBHNTAANzkfAFQ1+gAyOGoAQzkeAcU6NQFyNokARTfGAHY4SDX1NwAAZjarAE40CDNDO1kAYgB5AEcBeQBiOeoAbDiaAFoASAA3AHg0BABtAE4AdgArAEUAVzTQAQIAeTrEAHQASjfvAHAARzTpAYU1/RTWAFoAWgBSADMAKwBqNIo8awBBOn87eztGOAc3oQbfAFAAZThaACs4zTP4ETEVKTW0AFU7CjIkN5gAdDLEM0A8LDaQAiQHajYENVwAVC/TEGQAazaTAHAASAB5Ono0AgA4NOoATjYtC2wyGzhBNkQAdwB5AFA6pDXgBq8ANQBvNKY8bzeaNNc2mQB3MlsAcDNtM448LDXQAC88BjgZAGoAMQBRNUAATBNNMoc2ACEKAGo3KgBzAFEANgAvNUwG2wFcNhMAZDuQAEkAdzJPM0wBQTIzH6k1hgA2OTs4qQBjAEoASwA4AGEw1gBGMJ8BQTkFAGQ2UTNhAHk1QDqGMdc7vztYNnkTkgBVAhsyPDd8NqcAejn/MpcBFDd8AHkQODT2OrM82QBKOlQyTwBCNy05hzM6AGo4DhHqM6gANgBBOgIAVgAzAFEATjkINyQ01zazNxU2ZBBHAGs8MzVJAE05izevAE8AaABxD9I0rDK4AFI1ZzqmAFEAcQBKO0AQkQBSMvw3ZjgYAHAATjp3NoQ0xABGNw42oTdUEk8AWjI1OW087gBxAHg4BTZVAHg5yzv4Mf83bABPNSw1fAaLAGk4ZDTwAGc5NDSKN7c7pxcuNuY8/zbGEXMxzxC5AEcxyjshMkwAUgBPAEo0zQBrAFEANQBWN4M1EQA1PUYzSgBRN8MAaTXlOpk3bjduNDQARwbhAG0ALwA4Nl8xvABkAHAymTORAE00sABxD+QzcQBIAHYASgAvO0Y51znPAHozzQBGM60R1D1lMm8AVQB2Mjw48gHfOS0AQzeoNIkBOQBjBpQH5QBuPEI9fjwXM/YAQzf4ONIx+DWvC6w5ugBWAE4AUQAzAQ8AOTLhNjkyLwBYOoU2pABEAGEAaABFNAczJwAvN7E7jwBjAEQAcwBWADkAQjSHAG81wAd1ADYSTzHyNLA8wg5WAFIAZjt7AFE0DgOyAGM2lAB5Aw8HfwBwADkASQRBAEw5bABEOkc0BTmvNak32gBaNOwHZzrzObgGQQBQAHkANDTNNUY2+QBVON4zYzryAHgGdzfYNZsQOAAwACs61AA3AG4ztwBhNdQAeTSvN7cAaQAzAGMAUQBCAjQ93zHsAEYzzDsvO6E5uwA1NugAWgBuAE0HSQAvMj4Pji0YNxQAOD0DN34WyjabAFc0TABCAFo28TkJOR0JcD41AEQAMwA0ADc2MgP1OOsANwBvADkVDDW+Nf00/QB0DlUANgBKBiw6AgZBMkoAVwA2AHg6pDTdAigy9DdaAXg7ygBwPDozDgBzAnUy0jNhNJg1qwA5AGw9TwFBAFkF0Tc9AG8HqTaGADcAVwBaAGwyIzSwN3E0JwBVAQQ9pDywMdY18TvDNDQ4qgBYNZYAWAArPUUAZTywAFYyYAdqPno0xja7AVs0xDnHAFU53zcsAHYy1gA2AGw1iABqB+UQBgXeMjUHNQBjAC8AUABnADg9bAbhAHcAUgBHNks9iz5bPoAwAgBtPqYANDgjPR021DN2Nr0BqwBYMksyTwAzOwcAcjp0O5oAYwBXAEsARzfJADUAbQBPEMow7gAwAGY2WzUMDlYAdAArNykPIwAzPtMQNTp6AE88KTkrNjYyWABoAEIAdgAyNno1CzW+AGc2XAB4AHoANwBjADU8TwKOAEoAdj41PvIzBQ/WOMQARxD3PG0+2QBjAHo8+zg4PYIAbTwdPE4PlAKZAG824QBHOIc7JjZuPn8HNQBrADg99T6FNPUGAAB2AGY1gDXaAGE6ZjeXOSUAaQBTMeoATgLSPHYARAB6OI8zKgAzM6s7WQbbADA7fDqMAE0AdjVjPkQ0hzz6ADY3bjWBN60zQABtPOU+WABZNPM7jzJVMvAzpDpIAGw7vDPkNiADuwBBNyI2sTbfNRY8wzP8AHg+zABqPOw1FDNTMjsxvwINO8MGLDKHPSgASzSZAFYXLjShM2w7EgUWPZQ0TxFzAEkARz5gPCc/ajO+AHU9oABzNnoOwgNJMmAzvjx6AHYAWTiOAEYzmABTAEsBJgBBADI7uTbiNWEAVDVKAGsMCzqSAEg5WwBhM500xAfEOtQANgBMP5Iz/DBcM0oAcDeZFpAAegBOACs2fjXRAGsAUDuhADkANDTnAGQ/YQBUL5cASABXMzcBcQBGN40HTjQ2ADYz4gA2Pqw/ngBVNsk61QByPloAZTYHPwQ0xTczMykAeAGAADcAYQB3ADYG3DfmMeoGpzH4AHUATTNSOZ8ARjgHAEoz4jw/AEE62DcjP4E+NQA0AHo4dQXNAG44cAA1N1AANwBBL5c4kgBMAFA5RzWPAGkyNwBhAE48jDfzMxYAUTewAHMAMQBYP9YAUgB0M8g9EwBKNTgARjN2OpIANQB4O4w2WwBDOCQ6pz5BAE1ADABKBKYyczcAMo4ARzYmN6A+5jHyOFIAWgypPfg9YDZ6AFYHMwBPFNYAYQBTPvM+zjk7Ojo6HQB1BqQByjtaAEU5hTbqNMU+TDSONTkzMkAiADAzogBxARICdz3dM+k0yzq7N647WTUtAGg5ewBUNA02TzThADIAMTkOON42YAA4NgoANRC5MjMAKwBWAHM7lgBhAEMAWABsAHI2VwB5AEsz8ABkOI875zH1NlwyzwB0OLkASABNAiQ01DolNY46+AArAEYHnQBtNY81gwBpPDsAVwA1N3w7cy+1NiIAMD5NAGE7NgBqPnMyCQBmAHYAVBGvOAk+TQBrN0MFCwA4OG46NwBOADQ3xQBQPLYEAzaDBL8L6AA1OzY1XQb4MvoANgS5M+4AYwBFD/M71gB1AHgAUABWNXABiwBXADkAej7MMiU5BTl3AFAzjTvEODU0nAB4Noc26wBkAFQAdDlXAG0+tC/GADczPjJGADZAUzTzAXE+TDfeATU+hUDIMtUH3zdyN3Q9jwBBNJ8+kDT6NkgAcjXlOkgANgBzQIA0nj7rPPwycjCfP3U4lwBwL30F0QBDA0kEmz43OysAKz09AFoyjgLTM7A6/DheOsU2xgBUAHcP1jtFAGk2VzusADIQDABRNa00DD2GNO4MUwrfNMkAOQA3PLAAdgA0OV00NDUoADEAb0DrNh0AczstAHA8dQBpAHIEGz3zNAQ8VwA2AG4AUEDDN3U2UUA2ADIAOBExAEk3gjUMARMEmj3VO78AbjsDNrMzqweCMsgAWTzmNss5owEVAGEAWDlgB1E8bTJeAuUAeTgjN+wyOT8sAG4vmwByM7kANDObADYARQBGBLICKDMGNJgAWQA4P+s4YgB6AEQ3mjUMMnEAawaINOAAWD4ZM28NcwEyAHcAVT7OMtU2zzV2AHM5Kw5FAX4/ZDjNPZkyhzcLN4A2LzKHADA0zToiD+QymTnaOdw53gA5Mt0+YABHAEo5O0C5M94AODorPtEMhALTMmM5bDOwQAE1mEBSOeMAUTsAO282IgBqAHYzDgBwAGQ3QQ5FADIAbwBHQFY6CDoTNuIAWjXnOf43ZjVcM7sATgBuP24AOD6APjM45j3uADU2DT1sM2cyxAZ3NscGmgBXACs1tABRMxQ01D67M+M1zzy4AGYASABKPfgANjujEAgQDABWB3E06jX9ADQAdj1KNmkAaABiAGIGBzpHADM5ajTEAEIF+zTuAXg5STo1QEQL6ABlAEMAODlyMvg4CQBNAEoPYTl6Nw44czXDNkwz1ABSMgg5JzVcPIAASQA0Nc0AeTJ0ON8AZTvQAEoAWDZoNU05jgBmAHhBMwAxAS87LQBOMfI1ezcIDIQ26gBMD7Y4cz6QMgg1EAFYAGIFegBnPvEyBABEAEMAKzUcOiU1Gz2CAFAATDPUAEs9sEH+QCk9yQAvM9Q2xgBsB9k53Tl0M28AbDJtOU82QgA0OrsAeDduMfc61DYgQbk0pTHVOSkAVDg4O5A1YzQEBj8P9TV9PV08dDsvADY6IABiM+o4qQBzO1wL9j2LMg85VDq7AEsASDguD9M1EwB0NXk+bQBsP/kBowB5ONIyQwJbP+c6FTzWNwk91ABSAGIAegN5OIcASA8/ACtBmzbRP64AZgS/M0EALwA3PCg3owGuAHo4/ABmPGcC0gmINh0ARABZAHYyhwBiNWMAUjOvBJU0IABMP942PQBuNuMGigcSBLk9E0E4AjUAdwBiB0wJSDLuQNEAbgBXAG4AUgBYD+8ATwAyPGxBxgBrAGYAKwA2O289ozkIOqg2bgBCMw0U1gV6AEkQ5gBZN0cATz05AGg8o0GVADEAcDirAFE7AT2HL7Uy1D3BONUz9DsSODo15TRMAYs15zWqAi8ANzxnMjwAMDXqAuIATQB3AWk1lDU0Mvc6NTz/OmYAQhC+N54x+DTiOWE1ND/XOZoAKwBlO3Q8FABvPlsATAkQAGQ4OkD2O/8AMBAoBR01+wBmAEcIpTu5NegAbABjOb0+MzQfP78AUTAVMvI6SwBDADcAMjj8OVs8jT3+P2QAQTnSM64AeDJGO/8ATz4nQG4vtQA0EAkEmjSGBz42GwXgNuIASjj9Mqg6SwKfAHVCqwA3OScQ5TUPB8MANzciAFgANzZ6Nb83mQB6ACs2Tz/4AEo1MDc7OjYAbQAzADUAbDVBA046uEHDAEM1jgBRMdo8BTSeQCozYhhxMcU0MjelEGw0pAA5PugAWjIJPhoGADMFMxEF4D+/Om40hwB4QRczXgBmQfEzGTTRAGIARTYyN/A87jkuQNYQ2Tb9MnI8djkFOYUz2gBuPFUASDYDN2Y37wBjPQY/7jLgOdk/qUKcAjMwAgHBP6cAQjUGOBY9XDriPjw2QgBwPigE7ABnAHc2ujE/ADU0ywBrOhM2YTZhQyUAOQavAEI6GzY0AG03Vjz2Psc/4jTNAHYARkAIB5QATkKHQ6g6mz2FAHEAdDV2Lu4CUQBNNhM7agBKP/gAegBGPho7qQA1NboAWAB3Q2I2CTHGNSwFNwHFADUAegA4AHYAUDpLQnEM2gA3NxA2IgB3M/ABCDUzAFk8zzMYNwozQABFPU4GpwBTOq04+zrkQEkCMzbiAEEzkwMPP8UAYgaKAGUAWTQIAGI8Bz7cPJM3ZhDKM2M5CA9HOTsAeAlIAHMAMA/iO300MgBZNjRAXABZQ+sATj/rNbUBQTINAGM6rjd1P+RCujM0OSwyBjE/AEk4ijoGOq5BqEAMOIoyTQ8jAGo2ZAA1Nb4AKwEtDsAAMDmNAGc87AB5Pc0AQjpnOXYTTTQxPE40o0CzNLwzzAFdAHQ0jzU2AHI6ADLpADAALzKxNzk+egBQN9RBOQA2AFVC8jYgL5syzjNiPM89XDsYPcM0RwB6MgRAiTcfLRgMqUKHAGgANgB3AVs9qC/GO90BBAI+NYQ2rgZ3Pqw1jzkIDIQBoDenFIk0DgBFODsAVwEcADEARASaAEU0jwBpNYQBJgB5McILxDxXOA4H3z+BOtw51Dk1AFMASDgGMvQx4zHNNEwyPT+9PHMEfjmjQioAVy0iAGU5lDXcNsoL6jxnM8w0nDeNAE0AVUBNMyYAbQBYAHFB9jlSNotBLQBYAHYFCzXeAlpDQTVMAjAAcEIiAj423UKsNgE8SgBWOf9Ctj6+N9MAbwBPAFM5DjpLQCAyTAA5PGcAWj5YAGc1cDvJAGxEwzXzNV06EQBKAGI/FTNtOJozGQB2AGc5fkC7Pn47XDXpMqwAbgEtAEdDkzT6AEQ+0QBkBEgAR0IJP/s+YjdLAFMzGT2AOJMzPTQBAEYAVABrAEc7ZQBSNA1ARAcMMu1DJTZsCHwAZjtFM6kBEDv8OV0AZzofMb86RDsSAGgARzg+OGdCwgBHAHA7ygBUOS48mjywETk/ljz2AicAMTw5O8MQKEELOwkAWD6cMuYDeABiQJI4Wj+pPT1CpABVAHAAMS+bQiMAOAF5Ab44WjcIPABDmDLRMw407QWLAGw/NDYCADkAdQSaACs/8Tr8M/4HETisAFU5T0QkAFgyzkP6RIEBoEO7RTg5BTQ2Bfg2+UH/AGE+lQBQQm0BtzlgPfAATjujAEwAMwBQD4ZDKjZEAFo1wQBLQ0o2RQBVNi43uDYWADM1eABINlg/dT0+KEIATEHEOSU1gwArOioBvjljQNYxzTHGOXo2g0SdPAA3mUNAQLsAZDtvNk8AbjXkRDU3qgBLNUsASjuUAHcz9Ds/NfY1gTZeRI0AUTUdMXc2rAB0EAwAdQFgN1Q2lUGcOOUAVTZgPYs9bDUABYlABDYDAEUyOgBNNc4AaAAwOAg9ggrfPAcyPQZtAGkAaDIcNc8+ngBZM8g6LTVSAHoz3jdwAHMGPzlyAjVAqkAFPHo2lDz2PpgEAwBCPps2MjywADAy4EIiOdEIJwypNPIARABwPosIpTYDDy8C4C/TN9NA6zNpQmxB+TWPN0s3DzgnECM82TdYADE+HEPwADgANDHhOVJDOT6tOIcAOD2cADEARTbIM7EANC3EOok+nj6mAEIAUABZOY5CGDn9BJsWzDr5AHc4aDpIAG41Uj+FN0s1+zaPL8YAMgaINxI2wzq8BOsAODpmN6dBHjSwNVww4TLWPYkAZQlVOVQ1iDIdMiQ+10M4AFYAUQAyADQAZzdEOmYAaj7xN9oASwJKAFlAqwB5NLEEngBKPORB+QBiQX88gAXzMx4AZzV2BslBEjZoRKQ4iQBoNQFBEjdWAG8AeTu4AjM07D+BGHE8fQB4AEFFBQBoMk8ATTWuOTgAbTSKM54AZTupQKsBBwBENjRCXTbDOmEAVTxrN683hEC7MupFWQAyAGU7Njl0QuMy4za3OisFkzkzObA18zMbRdUATjU3Mq9CgQB2NDE68jQLBLkAMzexBNoAWj6VNkQAUjenOUAAKwBsQSo9AwAzMhREHz7pM/A/pwAvBKs2ejZbOIkxyDH5Qag4cjJGMtQ15TpcNNc18zM7O1EvfzNeOdgyDEELADAAQS+6NAQ1GzNmN4o4Ujb5P2o+Jz5+RSU1jUOxOMQBoAA0AtQAVg3qOepD6zkOAEI30wB5ATkx3jUBNmICPjOyOfVD1ABEAEQANzGyQZw6lkaYNy01/kGQADU99TcrPAUH5T8kMgJCuABjADkAUT3BBxI8eDvDAHM1/kbGNYo/fwOsEPUGyTSvMDo+QTMjODczSwB2NV0/+DUTQ7sAMjp0AEcyCjb7Q6kPHDuyNiYASzo6AE5E6gBYENkASDYVD/AzAEVnAFAylzk/NDQ2LkKtNVE2ERAjB0lFHgBENmZEHQBlMcg/Vy+1NehEQABYQoc4ATU4QMBEWEO5Pgw4VQB5QFxFOjLXADQ3pRDDP70AQzbnAncAbABnQwcASjzIP4QAOT8kOlQ1CzI2O8gAeTskNiYxwgFZAGFBUQBFEPUAaDIMO5A35TxQMjs9DgBpA1w2YQBOPMIAUj7OAEgyigEyOaM4JwA5AQMRKDgtMlNFQDuORR0AZQBLRogAUzarMw4BoDr4ADM0AS9gAGQAbTfFAEYP4zupQ2U11ECnP/E03TZmMtJCcTeuMjU1VTLNOEMyjzdyN3M9jgTqQMsyjwBHAbBBJEHXMjs4vgB1AC9AbgBkAEc9uDUsAbIAajz/OhMAVTciAC8zaznHADI6/QBsAEQ85QBjO2wAdQbhNQEBEEQdQKo8ggBiQFc0oUO/Mb49AzoGM/cBGz9JO9cAQQA3QIAAMwBIADgAeDNwAGFDzAB3Lu5AozJxR8U8GzSPAHo1qkC7PMkzzAKcADMyOjKMMzhBF0FSMzQ1r0KuMfcAa0eyNcEAdTNNQfY0h0bkMrsU/jegMnMAbT8bApkJ7ESsNNE96jk1P386TTHBD2ADczCfAko8fjOiA7w52EF5Od053znhMh0zBAYGIxcAYkH+AFA6HTdLBdUARTIBQvg92jVMQLMAbQByODAAMjYINZYzGTT6Olc5lDQNPZwzPABhN8dDzDz6Bd456DLZAEwE7AA3RapF/QAwMgY9DkDDAcFAnUX+Q5M1dANPMtk2Tw/8AHdFi0OYMm0t4DoVADczAAakAHcAUABCAE0F4A7ANVk2ujVWPCIARDRRQ9Q1dEfOP0o1fkJOMJ0ASj59Bn43lTrIR3UKmTUNNiMIpQPEP7VDsTlvBnc70DVcEAVG2wFgNbcAODK7M6k70DMhM/5EmQBHNNE12AYVPV0BYDVvQ9gAaDh1AFoAdz2wRf0+jjS4P4tGOD4QBt8/JDuPNV5CAz/qMiNAIgBYOXMAcwBZRQREOwBkNMg1yUF0MbM1qjmjNe80jDcKAEE73ABzPbwysQzaADk+10Y1ADIzPzLXD9MATAA1AEMQCTYjPHM93ABrR6FEQwBrO1wx9UcfNTkASTmBOMIAbzfaO7wAMkb5RxEBCDoZMwYN6jzWPOwFnAHAMhQAMABpOxs7WjSPRZYCzDu5RTo1aw5FAHQAejghR2wAYz4cSBQ9Uy+fADY8sDnbNiM7oTZrMtQ5JkPtMmsAWToSD5QycgInRnw7bAA0AEI5OjH5OeRB5Q+UAEMAbANFAEYzFA7AQQs7rDfJNr8Q9zTNNVJDdwF4ADY/Jj/qNeM1HDHrAHk3EjJyMdYAdDNYOP8x4T0YAFE7nTWqNvNBHQBVPYY00QBoM99ExTbbBEgATToxOIs8jTaoBwxIKjwFAHYAdTDWNSwG3j/ePfhCwjORPe0AYTU3B38yyDVjNMY/rkW7AGYGmjY4CRAAMzgVRfIAMkVAOrE83UWJMuk5mjWRO0Uv4gBCQLc1LD+nNYwASTtlN381FABJOQ4ASUUqAFQFhDxrMtc/fEP9PQM52zNUQAQyHza7N4E6K0ESN5o9nEUaAGs1lQgnPsQ52EXNQEk5IgBrM4wANj3UNYUQwwB2M15CwQBVRU9BFj1HPIY1dT4KASkANTW3AYs/vzZqNIsAVjNgNshEmAB4NkM03QBQADcASzpERN9HdAAwBvMzojczNmYAeDXkAHgAbzYiN0wAWRYXPHxB/jW5NBQyOQA2AnUATzmHP7EEqxUpADUOwDeaNaM4UDYAOPAx3T81Mw86DELBPG8z9gBLPEc5jztRRzw67jeBC8QyPzx5AGNHCjjSP24AR0Y7QeMz9ABTNOs+PAInQfkHUgBZAGw02T02AFoQKABtOIoATkBTMgI7CTrVADI5YDOeOAE28jJsAHo2FTNjADZEBEPBO6k17wFMEOYAbzPxOj0AdUkXO5FJ6jJfADQ1UgFbRQoBXDZqQxY3fEXrAaM0wjmoRR49XD2GMO41XDriQ/0AMTsAAaM6NjvKOREAU0B3PrAEWzxQRbs+8TkSMjo46zSTRVYAbz48NxwzOBC+PxY8sD8fOKwzDjukNRE1uQEpNrkAegBoSIw3LjSZNQc8DjOROD4zaUAiOY8yHUm8BJwaPTeeNn8xwz+JFGIz3zb3Mu49zwBPAqlAVwB3OfYAOTr6AHMAUzSPQk45WjIKQnE+rQepPDtAwwBZMtVFi0TKADdAGTLpOPYAODc5Nls4Gy+6NkowFQ1zPLY71DmODYZApjtfMnM1kwBLPP0FCzPkNcBDVj8kRtI/+Tp6NJlHCAAwOrA7OjzRNUpHwjvEAGQTTTVRBzM7ewGiRCEQvEaLQIU2kjW7MxA4GTYWMJNCbDlPMuRGbkFIQwcAdAAzNhA9PABJAswARTYoMb1FCjeNPMMy60gSMhVEbzevRyUAajflBJoP4gwrNf84cDVdOLxApzmcAbcAcwA0PBAAc0KiADI8ETUDNqQAQxGLCVU3QwF9OM07/TgtNjA5Py+6AGE+tTHJPag/JDphAEQAMTa9AS4Ac0QGNAwAQzICOiIAZj7SADU6IANKNck2GzeVAGkANgAzOrAATTE/Ne49lEqdOnk/DQBUN2kUnDYXOQgNhgBLN0436TKwOhQy2D9/PU5FyUUFMvEATjQNAaMWzDgtSR82lDzPNQwx4zZgAEsAMTH5Mu8ysDSXN8U3uzn1Md0AYzw5NLVE+QNWRr8+9TKHAHJBCkaONQ8vgzO7AusPlABaNWE6CwArPWwzGjZCNyxH3kHpAHU4/D1TM10ANUncNgM7SEMxOnQAMgAvPSsAWkDAPs4ycUr8Nf0AYToVNJAAS0r/RGo3fEKkQVIAMgBKMd4yIT2eADkAaQBCAGc00DUjQI82Lzc5ADMAWDbKMq0AMTh0MJMAMkFdAEMAMABQAG1EkTtsN6UATDoyQGc8Gzo9AFQxyTNmOQQBWwBDNLBCOABuQbA5dDKUOvpEmEN9Ne0AczvQAGFGKEBYAUgyY0TsAXI5JkFKAGQAZjkmOh02FjW6OMRDBzMLQUoylwOsADAAYQAwOLkASUmCPBI2CQSeADYzPz5KON81hje9A8QAWT/HS1g03DyGRYdABABTAQc12z4hO/M71gA2AFo0yQBlOgBHoQBlRRpC1zSwPck40jTnM/oAQz70Nq40yUtKDy829wBZNxRJV0OxO6kASjLUBc9AATLoOwE0owBxNIYyXAb8Ps02ET4cMlIFwzawNXA+sD1CQg9FJkjcNi4x8AJaMjM2rkh2Bpo3IDXNPM8HaTSmMnJDsjHjAGoAQjmwAHUAUTgqMpIU1jKMA7wBA0RYNSg4OzIZQh1BqUrnO0U7ADPpAGpAVzlgRm4AbgBTAHgyXjUjPWUAVEtyNqk8Pzu8Nq4HEQBUM+IyDzyzOaM49QAxNstLcj/nNtQ8FECsS/U28kJQS5UzWkDtQSMAOABFAtQyUTPkOkw9PDupB05AjwEdFSkAeQA4QOYFyEL9ADdBwzbRPHE98wBENZMCqROSM1MAcgAwSPU47DMkNKVCqDgXNLY97jOrL4M+WDVpDCkANgMFRLg9tUZeAGoAekKTBeAAd0tfPVI8sDORSdw0OkXIPpsMqUsURDw2JkApNUox3TMpSwoyQwGsQhtE7UmcAHEANQA5Pd04Lj8xQq47NjeKN2kyb0tKNiQ1vAB3AHUy8DanPBAAbkCAO6FI3DjfSak4nDdLAHUIZjmOO4gx2DyzQ7sAbTS2RuQ9qAFcQwwP7z7HAGwQKDV5PxxKRhHtOJc32ABRMzgyBjHbNfA9K0IqQSMAcDsHRMVA/DfUP0oAcTsHAGc/AzadQ+Az7gmIQro3ZziqOZ0ASABmPBEBEz1CAFQy1AE8MgIz5DYbD9YANzltSEoAOQB3D7w13ABWP9AAK0pYAgc1djPDQCAyPEpcMc0+/zu1P3U2QDSvSRdHLQBKAGg4xzV4PY4zMAB3MuE8pz9mADk7xD+VNMQ+4zjNOwk2bkEmPxVBhDKtNoMxy0N5McE7IQBRNRU8eDZLRksMhD36PSQ3NzoSQ1YF7QFYAHQ9nD3tDlc3kDomOlwAN0c/NYY5WgBSAiU7SDakAGk7mgGFAGlCGwGAEOM1E0AeMvoARULtPeY1dT3nDCk/xQBBPzE6GAvEBoo9UzWlAFEL9z7EQnEAajccSIoAZjkzO/MyswwrO/g0BklzPckBJzo1OSc9fQBaQINEajnBNK8JBz+BADAAdD3wRpg2Bz8bAHNDiDUpO7IHUjO3AGxFCjdmSOY3njnXMvFGbwBqQ2o2FgB1Mz81qQA5O/hNZDsvPvQFvURWPHFMDA2GSQMALwBJNOlFyUK+Md87pTpbP381dTLnMxFEZDIZPqEBBj7rAHk51EaFAFNHsjKyNE02CUeKMcpHhkDNN3FAz0eLTZBHiE2TMcoBMjYCNhk55DhGM6IATjhIR2VIEQJLMx02RUrqNMc4OwBIQnpC1D3RRLlKLkHOQvJIikPJNK83ZwBxAFkAMDcMOOI4cj6FO5lCikeKAFcAUU2OAEI0TTROAHgAUz53NVUPYU3BTZA3ZzRXRJhNkk3KNFpIQgBVMjk0QABEPiw0XU3WQBM0QAv2Mes0SUSYTcw0UU3fTd5NljO/R5w1jTKPAG05Tj2OMcpNwzHJPvFNlUDOTeUDXEDMAa47Cj2hR1MxwU3aNEtHnD2PR4w5dU3jTeA0YTR6NE9DFkDMTZZAE03OR4lN603+TZZNygE1R4dAzk4OTgZOEU4LTfBNz04VTg9NkU4KTf1OFk4bTZROGU4NThhOE04XThxOIE4UTiVOI04eTY9OJk4kTh9OKU2XTgxOJ04uThBOLU4rTi9OEk40TipOMU41TjtOOk4dTjBOP044ThpOQE4sTj5ORU5ETik6SjR5NH40dDRrORc0dTSBNHw5GDR3TgJOTDSCTlA0hE5STlg5GU5LTlE0YT3XShIAckjUACs/0ThuOFI1VD9qAGZB2j/FQogykBDmOuc4KjckPdotCTLdQzNDGRVROXg7qjhaA1YyhwvoPec0yQA4TnJE0DG/PtY5XjM2O8M0wQAxQnpKuDKHNw4+cwTtBdU0pD2cOVcxPwmITnBOgUUaToMN6jwJAEEJiABxP2pOiU6LOS46MjYnREYAZUK+ODIAejvDMs5J3AQDSt07w05qAC8/xUKsPdc3mAFpN0EAZgLMTak1a0lAN08DujzITmI0vBAjQKY1HBBHA6w1Izz8O+8AeT/4Trc1OjKHTrFJnDG9SVU8czpDAEYPHDnYQAgANjzRAQc8egArO3QAajeANbMHcTg7NjdOc06EBQM47EKjADY33jpKQVY+pABuADlCY06iRTo/ljWzOokDrE7lAZxKuEU6AFBIFED2Mxo2xQdpQdoyZjVnQnpOxgAzTsgDBTiTRQlO+DSsTpo0njWzEMpBlDQ/Srg0xBAjNWcAdjsbBZxPCDldNLEAZTlmAFMFHTneAC9O0D5SMi4ATzPiO/g4MgBoQQsAaDo2TyE2yg/zTtAAcABSN2wAMTbRAHdPIzlVTwlF/gBUAERCoz7fNVUANASyNXg3gE8xModPHDz8NzcARjnXOtU7dAB2SK47Ek6kTOY1HUN5NZs6sQBGQQsAQy+6BZQ00U8yTmtEqzx7M8IAUAXeTxtPPEW3OKgAUjfHOW0AYzYyAEpATQA2RLcP/DwJAE5KYDc9PZM5XkSdOWI35jvATt4zbTuoMi42bABvQzEATgBMDkU5XUH+NP4yhwEHR5VPfk7gMT8BBTu/NTlBCwA3Tvs6MjTOQocBwTknNRZPh095NP5O8T6LNeBO307hT5E4Uk98T5VOowBIT5hGbwEiAHY+uznHPAg3oD6eNW4EQU12ODsP7zTJAS4xvwBTNX41HDyzTyQ9o0mcACtOYj3+ADBAugA2PZw5EgXtAFY0ijznBZwyh08PEB40pDwYNd0ymU8PAGYAVkB3P8c9RzduAGM1yUd3T5I4jTKHT6hFOj2jAHcAbEq8TuQ9mkKQTqNBHj75QqUFfjJdAkY0xAIuOCxP6k7mT1JNqUBXT81PjE/QE1dOmzNlR8M1mTtKQqQAQ09aAFg0igAyRI1M80+ORIA+FEvSD/QAdE7dQu5EFDnRSGg1WzcbP55BnQA4Pq04vjYKBfJOzj9OT2AAaDTbNm0AUDUtTw5P/0mVQbs9bDbtAFBHWjz7ADQAYj7xAHFC2wA1MeE8CTLjTx0/fRwsM/43x065ACs62TK4RG40uAcDNkZGyU/ZQqs3kDNMTnFBCAQ5TrI9yABQRlNLCzldMz5MYTmWOdg/fzoZEeoDfjXYQE85H0tyQqsAODM+MmA+6jvDTAwATVBSStEUhTPaMbxCc0eVOk07HT/RNLIa6UiuN7c8EjTJMz4/llBmUFBQaT1dADFQTDWGUHtQTzIZMdszPUrRBIk9ojcgBvQAY02pNDQzPTx6Ag0ymT9/Qts91zsJNdgxvjlqNKw1JTbTMq0AcjhINnkAbgA0RltBUjJWOIM+nEG5Odg2FTUbB0dLHAQDQ1gyYEzCM3FJ6DHIBQMyXUcyNMkyjk6KNMRHPDctTyQAcFCzNP5Abj28AEk5LjybPBg/nz2TNDFQtAWUQAVGwTvDRFhBVkHaMhk0202pPbBQZ0AeBe1LYj+RP6RC2zsSPNZBC0wMTv1CnAA5OB0AckmaOv9Lsk0gAWk21FBuPZMAKzhXMjsAdj/FQc5MHTcPNMtFgDyNDyNHdTp6O0oASABzS0pApDSKM0BDODW/OZ818E6yQ7YfqQBsAFAAWDrsEL4ASD/kPYY7wz+QOXdLdUW2AHlHPEuUC3kz1EdhIQoHRzcrNC41lQEKNTNO6E8SOBA12jfqA0tRIDthT646dzpMOZ4yKQNPAV05izoMPhpPxjlHOewAOFEWUSUAeTyzAE9IuFEpNvAG3DARUS0AbVEvM/1OvVEzN6tNSTWxAGJRODT+AHRRO1EkPKNRPk8SUHQATFEqUUQ3K0pLUUdAoVFJNWlRS1E1UU5RUFE6UTxRVVE/UUFRWVFDUSxRXVFIOZ5RYUuUUUxRNlFPAFQ5RzuSPzEAc1FvUUpRG1FjUTdRdlFRUVNRF0H8UWk0skV6UW5RXwBsUVpRLEmQMtJJAwBPAbI+8gBkAE4+WkBSRWlAnTVTUTkAWkSAFDw5+jQGOew04wEUNTMys1FeUTBRfAWSOYstIgA2QV01BFFRAHM8ekYmOGYx+DZ7NpA0lwBPAG1HIjV3QTg3sABXPZwyPAJNMvIAKzxEO5I2fjk0NAlRkzxGPrU+lTtqAhtJFwB4O6E28jNjPLc61w/kSJwFHUfqMqwyP07xMpc6+jo9Me08ETiKST04Bk6fNkMx3DZeA1Yy2UfBNwk4MDdUETkAWgqZNi873TPRPgRHTDPrOtwGyQ+2NfwASj/FQPkANzyjNKQ1EjZDAFhEmQByRo404UWrE002mDYmPwhFNDMcTYlAflD/O5o2bT8PNt80sDpNUgwASzHYQBM/dQlVOZ9FUQJ5NxsAazPuB98CjksUMyk76QBCB51HnDOjAjY0xTfkB05N4g5GNwAxskdKNiBPNEruLeAwXDg1ATJAhQAwL2ATC0emNgk+80rRDKkAUTYoNlEAQwBKBUFLOzdnADgAbzx0MzYEnUttPMgAMQdMMu0WkEdKNrI3OjJTAGk67DjVP0k3TDWbNPpAaDSHAFM7VjelADYz/ABZUmszTz1cPXNSAwBYAEtA6zYTN3YxsziHOv84kQKcBc890Tk7NlwyUzrfN+UyaDh1AHEzt0ThAE8/OjdwN9w5qABhOrE2MgA1D5Qyw0eYS20zKQBxM98BAzLZAEQ1BzXcQwIQD0F8QfdKmUOdPBBQHABrMvwAQjYnM8YRMUy1OF04uDyFP9Yv2Ec/NedBnAR+MlI/8DerAEY4QUZAObIAUzIQSdxDsgN4NAYx8TVVUkk5TzrXNbcwkzrERl5ADBJiTdM6XEGwAFozMjYABQM1ZwUvOK5H3kGdRNgznhtONqRRegY/PlI4GT7cTy48GDkGTvA4+kPhNLc/VTv7AGsx3EzGPIU1GzJoPigz3wS/MlgzOj/FAG9SKTZYOl9MtwdMM84BLjSwOTUANAA0NlU9RQ5DTOwDXDq7RP80C0wsOJwHcQGjROw6EEk9O7k1qzcqPzo6hjjMAHFCjDUWOq5EATdLP4UIrT3fMvxC9Dy6BwYySzmtUT4AUBghQl091D+gQhYAUTVjP4kB30jtODc85AB2MwNP6DZbSLFG6kPJM2YTVzPNOktP3jp2ShIz4Dx7NVw4BjQVOAk/QkEJNc09SgdMSK5E0TLXTIQ6MkqfN8lGmDrPMrkLxEtSSm49fTLtNdE10DNXNbxDEzG9PPwAcgAzOag4DD/7NacAZ0tbEXNPyA5WOoY7WQZBNt0BMzZoOZ4DdU/ZAVsEiTv+BKY0rTUpPT5LdTBmPBJP5QEbAHM0Oz3XO2FHEUPKBRw7RT6AADNNv0X4QLE0PzVXAHVGhQhmPWVGiD2AO4Y2TzxlOAsASThFTg806TinMcdONDfFNE8MKTRTC/Y4RkL4OFROQTIxNc0yO1OqTyFIO0DNNExTaTJrM940TjzmN4JN0zuqPGFBnDZ0ONU3S0IWOawAQUPLPmAQ3UaYMkYzUgxZSXcAUkUUOdw4VzZDO5RC90BaOIoAWDV1Mo80/wBLT0YAMQWTU9s8TgA5NgQAU0hTUe8zMDXGAGpAiTYgADEQRwA0Aj5EOzNeUrcWkDpnNLECTQB1AFQ8dAQ5NdxShD7ESsAAcToOO4Y5NQBsOJBTH0P9AEw181GbO8Q56D6eN0M0hzyCNew1OA9gSLI07EaaPYY1SDJBNkBFOjUURh9E3VKkRtNFJkUpNyc5DjcdNAg6/QBaASI+/ztHARo1DzVrMq0+Hz7ENhkAKzNHAE085jHWTqdCBjYhACs3ujo3PzEAcUdcL5s1XzZoGCEMqkHCNvtRADIMAEo2vQfFAFBQJEKkUMUANwB3NxU1pVPVM7tS6gB4ADU2VTyQAFlPhUEGP04JcTczNJxLiDKHAGwxpkH8QmA61wbSSp0AWjn6QzM6jUBEAhsAd0L0TIRQY0KrM/kAbjZgN2kJR0YrONFKmTPjS384WUDDNlREIQBXADdSTgBWTAw02Q9jOY8Q1At5CZIANEN3D2NSTkaOONhHjjXoNJ5Hn1BjTto08DIzUCc4f0EWU5w87wBoP8c1UQpbOuUAVD2eVDs8bDSHNdgAUwlIOx0yrDM5NZtSEjJYAXYzOTiLAFQy1jXlMfxAE00OAG0AeAepAHBMLE85AGU2Cj5iUDUARzkzAEoFA0EjNWk01ASyNX0GzDYkOVs68jlOPhA4ez2iAw8BOQBEBfMy0jltPLVBFzKoAGQzozcgOIpPcQFgDIQxSz0tAHo0GTxvM8JE7AE1P4s9bDL1P4FT4UoeOOEAb0acAFlN1kYoBUFApQb0O89CXUjJAG48zzSLNQs95zQKQ2I9eEBINPIAWjwpMgAAVkRWNOk17j7HSQM+KEP9VE4x5gOyAGgDxDWlNqs2MTVZP4U0y1EAAHo9R0QLAaxIyQUcQg8520M8Bb5FY0pOADkBTDLPAFJO1j0dAEM7jUS4PiVGyTSkAGhDQT2GN3YBEwBjAS09E0tcMl04XTJoEAxGSwd/AE5D/DMjN9c5vTU8BYQGvT02NrJJxhOSQtQ/JjCfAHBQMkAiNWkyAgfZBm02A0l6NU01pTTLAG4ORDaxRidIETw7BzI1MkrVNFMzNwbJRO0AdgBkPEc54zj7AEYQp1HSADk/Tk9tTYY5YUjINrJK8QBPO44+rwArRhZNtjjkP9A3gQX1Ni8w1lTBQdMyUzgOMlU+HxNNO5IHATM2P65B+UO2PaI56kbbAEZMW0XyVQ06rUsZOqE2BwUdAnk5ukhTFJw7NzZmQLtBf0c2QYRA2T/rUowL6DhwQDg4PgBBOZox2gAyMFw/MTWRATU0KElPEhY56jHAENk7RkJ3Twg4njAuOBc2ujoiSVM5nzcLP+sH2TV0BL82sEFRNA8y4TE/B2lLLgA1AiQAUxAoOOs+HzMyOao0NDZkD2E/mzgBAC8E6gNzRioRc0sUOR07nQB4Myg1zTYRENQWFzV2AEYAOE1qO6w9oU3TATxREQwrOJM0GTvWCGg1yD5gSzI010ZeNuIAVwGwAGQ7iAUnNho2cD41ADEANUT5AGk7jAA5PzQ2ZDy2RVlO1jl8O1YyMQB1AWE0Iz7SNY9UAFPxONgAV0vxM45JAzgLP8Uz5EP8OdkAYQcyRQxCGzmYVN856DaYRW46IjU5P2I+szlKOUAAWABpPJ04CzevPpU1+kKQAEwAMTUcNi04rwfhAFJF/QB3RuNA0UNiONg3VTJROSs5CwNcTQE8WTXQMjlHp0DNVN80dQBsTgUAYzJbVj8AawwpQvIASUAiAVU5LATrP7o0VTi/AEY/rTXQN3Q/jgcpVl1OAzc9Ak4/tUsUAGwAQQv3ATU3qAKOS4lN4TdxTcxUxTp0EA80ijknNIc71zoUAHE9zUAdADAAOFY/AcE6SEOoS4gnRjruD+8+nkCnTHZHaQA0P381dzPiSu4BeDn1M+wATzx2PlsAVja9B2dBdBD+QAwG0gfZPok1LgFVPSwz/BJPB2c4zAA1PdcTUjIhNaVHPEs7B2kAdjTiPrRPby5OQgM3qjUVMvc5CwBCRo46mlZNNXAPYjm7Prsx/ENpOHU8GwBPOl845gBXOP0y0jM6ADEx2wBQPJQ2uTp0OwE6twBINglJ2kaOMvIBZwBBN68ycjMOA/UBD0TAAE4yUkU4Mgk4MTWjRQk2LzevNO5ImjPIS5QOQ0FIPS5UIEGUNY4yHUP8OOFGijH5OjVVYQGsRipMkDL/NYhQL0kaMfU3dVUzMy0zDj6hQE1M7EXUMqw/A0KnUCRN0z4nRMo95E6FAEE1pTMPAaIzD1H7Ohs85jLxQjYylwAwNf0BHTIRT8gBXTghOg85jz5NETlSZjLYPn85LUFROT49+Di+OQ5CJTwACN4P40DRUI08uj67VXA0uEcINYA/8T81NsVJ3A+2AG41FTMENyJKuEn5SVdIKjNmQvI00Av3QKw6EgNOOkhJF0x1AEQ6Yjv1ADY8GxAFMmoBJjHeNuY8yEDaNOJWMEgHAb45RwGAAFlSZkUUBjc7+we/Qf4ORUKrT2QEfjTZD+86ADxfRYs0AjmeRo9Shzb6NjM0lABzSWIztzcPNvJT20yQOfo6SDqhN0s7YTo2Nrs3lQAzRAZIozfaQoxQ5wIwQR9GKx+pNQMEiUjtN1U4jjQFVABL0jnaO6E1qlIDRapDu1NrAnk/5zNNNsFHwTpWQWhR10ZbMedSRi3gTMZAfgByPEc/LTJvD+QP0gB3MlYCKAScUZNQEgBPAHUyrksnNV4B3wBwRmcx/zzuPltAfgWLN9ZJqTHbMdc18DYXAHhEKjPdOR485wB3NmQ4hz6kM2k2MUC3PGwysVftN4s2AEBJP/dHx01kPxVKgwfDBw84gwBrQ9Ew1jNEQT87yg5ENlsAbTiPSHpGZznwOD403QBYNbU6oUaLAS46VzISAHlDzABXPxU8SDxINbVYGj8kMwg9nElTAFU5KDJvD9IQIzP0OuRHaQG/Mz821jIqAFg3SzXvOGtW7kQGRVo0R1MtOV8AY0DmRSUARQJVMekGP0eXEOZW3DVcOAlAaTcAAC8EnEiaADACWTs6PfBT5lbgS1xT1QvEDkNMRyZgMmQReU11NJM3KEy1Ph9J4VQiAuJALTpWPs86vDcpPYYPhkCXPBsAcwSrP04AdzL9PlsAbUe+NuEBEgTrNRw1TgY3Ovw2RDsdNn9CBDnoNxE8/Dp5QRIBfUO7TR01twBrNaVW9TJANnVQLz38NVtLWTeONswAU0c/AFQCeTX2PcFF7DqxVjA14zPrECs9yVYfPOc37D0uRVpApz5aADQ83Dg1NPpGS0NDRoA2hDi+PAA44jPmAaA9flPrAmkx0TfHBRYyOjSTNqE9GTIUBYpWfVZnQHQ4kD+bNhAyFABsAahAaDHZMO46eTguAjVHTD+JUZQ43j5ERYBGfDSMNXQ0hzmyFQwEmg5WMl4yqVb1N0MzLTKPR2oyKQ+8PJsAaDXpRJhGjjV2MBUOQzKaOINDVjPDPCk7XzZENyk/9z7NSWk80zX6AHAAOABROPJCtEUlRKM6sTKSOF4/vTP6ADY/pjs3OVoCyzh7NwYFnT+CQQIHzUJZCr9HxQfZE002XDskT2k7rEuYNJNA0UC9VIE3zh+pVzMzEDcPQek0tg8jBEg10jkzNOlL8zVKAHBWqDXYOe41W0xaP+Q2DQA0P24VUQEpPmIBwTq2Q0pIozwbNmg2YTrKVC8AeEX3NkFLO1HvNeoAOEPuOjY4BUbbMzg+TTgpM+Q1QDriA35YfkwLOCw/5zu8OrE7yj8NNr8720U4Uo9S9AdJO0A9GAreNfw10TaJAFI0BEXtQXQ4lz+pOYE6IkRYRtMAOTUwN2EC6za6N7Q2eU91Tv1YJDLuRDtLZDx9NboGskEKOXJE7TqROK85MweUMj82RQ+2OdQCjjnjNJMzJFXcNaYMKjJbM+pSPkeLWZEE6gBDN3ELeTkWL2ACWTOkMm9WaTb/SdQ1jT2LREM5VULsTeoASTXGNekyOgJOP2tSTj5+QAU/Qj36Q9Qvl1AnO+cDczXxAG8F3kGXROxBdEzQUrM7n0QoRzxQ0zYmQPxFBTI1PeE2Ez1OS1lCvDsmNa9T/ExBOjkBJzuSOcc4qQNcMjc1M0PwO7k33AGLPu8BoDLcNDtUOzeCSyc4IwBuQ9hRwktRC+gvxk8IOTY64lGTTJc9fjQxNIdT6zXSOMw4jkvSRQwFnT72NmFEVkTdM1gLbEjISrgFqj5NCUk2J05tO8o3IDULWXIAMgBIPsQ2LjjrAEEzbzKtMf87qEBYS5ZCpT2qNDtLiTj9Qa8ARVAnMwg7LzQiOVQ30jZrBH40oTJeTbc3WjW4VhY0sDzZNowy7gBKAFEI3ELBELk3LQBVN0sReEFdAGU3GTJPNTpMn0VpNQsAZw9XARsAR0dcNkFEjTIxEOVPszZoOZ8ANj9zOpo7vwjcQLQ2GjXWQuMv2TbxMlc1C064NMI1SkK8Sk091QBLD7ZT/AlHTuA71EKBTVZGmDlbMmgAMFToAFo8QUBPSyQS3EQkAEUEOTLSM/pAtkm8AGE/ykD1AWlLOTqJS08FQ0ruOAwASgBuTSc1CkwdPCg6JQBUVCRSPjSjPU4BrzNOO/hPPjy6OoEGFUCmNpgAK0A2O/M3pUHKS38PvEFGV5MAQkUUOeg1djshRPFWTTVKPEo7uTiQOnpLQVWcVBVQHEK+ATRAXAB4Qhs6pzfTAGs7jDSjOWA5KDSLVs0zsEqdQFhGLkJRQjJXNz0GR6RMF03TNepFCUuUMyZEywbMRwg2azHIP4I53jbfRLIy8EaLRwo0rDJXRtM0BkaPAGlFJD/RPVNBJDaEN4M0y0qdO5BIETaxOyE1lTPNNTRFBDz7QZVUaAArRzIDcwBGVhZQJ0kaOf1HJQecMnNG5DbmM7NJc0L8PKMAUTznO8o+xD5hM2VI0zQiAG0PVwLSPd5AZT6FPflRPjIkRYM9yFgKOXdMBgB3SD0yPDeuMeo1ST3VOw45sg5WS6s7yjW3VRgEuQEKAEkAWQBjNeU1E1S1DCk9DTPxNgk8QkS4NeIz6U1ROctE5heiNsY9GD5rPZpDPEX0D+QHTDW2PJAz0zQIMtZADDY9Bb4BWkXJNyk9y1YRNTc0lzSaVglD8ABMOjE6rjmoPgs8LjHdS1wATTlXOldDYkBIQipMVTJYAGk1BTivOH9CQQBXAHZOqkaLQ301MxUpNPU8FFsdTxY00DYTADg8DQHFMmY2MjnUDz8HlDIcDClCUUicEKcANUY4AktCHD7vU/RDFjWAR0M1djrVPEQ1mzhUQrxPbTQBERQ6ljM7PI4AaTKRRLc2IDjGAEg7RU7rAG9FQzm9Ras4BwFMSPc7YDuPPe4TVwb0Ngda4kA2QEIAR0XyPdU0BABCQDY+NTyaRotaRERWO0Y+uzx7RAZNtzXxWPs2jwINQq0AUD/JPxwyTD0kVn4AMDCdN3U06j8kP4tHmD9iATUAbj+eL4M4ITW3Qhs07jpNQtxWoEGAPWxNwlCiNARNXEDIQsQ3vVZpRQw2WzNkOpY1sUKhMz86xTLDPFU4m1Q7POI/5ABsSU88ujNkU8xBFznkQcZG4zLvORFXoj5+NYBEnjMgTEE+TUmuOSxK4zYhVn0AdTw2NhsReDTgU2QG/DiXL4M1FwB1OII6AzfTAEo+GULwQFlBFzcqMr9L0gBHAEUyazr9OEYzKTHJWZtWaTTFAGQ8/DsSMgw3QTWnR+pWRzhaARU6oVt7Mg007j/3Nrs4kEEWVoMARzW1Bcg7WTYIPoU2ljj9PSsz+DXGQSQ2HVGTOWNJ2DJfGBE5WgIoT9hSaRUpRQk5rDsJCUgw1kYrQFNAX0iTR8hWRwEPR94+gDQUVHQAcTj9SCdYGEuxOyE5lABWD446pD/iNAUyZFu1MshDmAGoNkg/8EVpPk04qkTtSzs8Oz/eMy02KDlfMh0x80AFNewDTzbIWBgyDS/YAHEHTEgLMdhBOTQKBt41eDazNXky8TkLN8c1xTNPQHE8ATXGN4UCLi9qQfdBfzI7PIJBmzIUPFVWWAIuTfMBaQJKMlsQbDyNOW1UtVyvThxHU0IbWkQ2/zWAPE9WZgGcR4ZEKjfwNhFLXDh1VOhGHTw7QBk9hktoNvMy/ABVOcFcKTjPNjc95DgkMsQBYTmOSk01STQZOfYz1EBET8gB3zYLRWBIb1ueNXxYSzcqOdQ2yTvyNLI59lL2OyIQZDlhMs9NLkLUD2FDwkdcOqc9aTTuP383SxDUUl08fEvyNvMx/zi/MexDMT7JPFUz7VKVO+k+x1MXTto1vj7HNuMzDzX6Sy4ATQEGT09A5gfFNrdUo1ZAR04yPjcCQgYybzoVOSI1zjP3WnwF8lUgTNE6pAjrAHY0r0C2PqM93j08RppGWxWiPnQBJzaYD45Rij6wT6o13DreAFVAw0CgMks8GgHJO9w4oVXnN5kYIVfVOH8GswBGWhk78laoVXBIQ0VWPIs+dD8DAuI5oxScADUTVzSIQc4AMzlKDNwK3kv1AHMARUEPOT1XfE0gPx9RvTh4WDoHAzrkMhAyAjqaNkM9gQIzNpUAbTO3PNozLFpwVylHHz7jB04DBTZbMeldYTNXNho541ENR0FEVzSXPPkPLzNnUU9QQjotNLU7twvEOlcBdgkHRzgfqQbbOII80Vk0TNRQUj9/M0BLiDbcBrM+f1JKPHU/qzMTR8BIdzUzBR07/Du8QWM8BzhQB9kySUZbAHQ0IkWSNJoyVjfXQ+cASQB2WqRB0jlHEg1KnUD2AFc/ulYWSKc2FgTuT4c5dzVfD4YQhzM+D9Y8OTgbXG5IjABHM08AVgazAXhKEi+DBb1PbUHEQypOqg+PVTM44QFhVmE6hjiqAGtDhEfOPBMDVkGVRWMw4T2ASroPjkXNOKw260zsEa46FUw4OOFUBFqNSBQxyE1QDXkATzcqPVs7wDnHO1JHDFKHO/VPJEdFN8k3rzf4Vs0HAUBPUgM1OABVADQWkDSIP+I3lzdiM8M0GUEUMxRMr0GAAQQ6IkH6TbY8ADvQODE+bTWABFtFDkc2PcFNZ0qDNgRJA0q4BEEBo0CqVSFT2UWOOAwAMFIZRmJBYgEoOxhHv0MLPf48OUdsVmFQjkcGPaoAKzheP3w1DAGgWy02PTLVUC8y8jbAN+c291UnPeI2wgA5WodYcDcuUZM0njhSOMo1/0ijOVQyCD0oUcA+HD3tMfw2QjWITJA7e080OY9DMzu/PHY8dkFLOyFHnwJ1Ml5CrT+tNmw0BjiNAHhI9TZXNtwy9FZPNpNEbzpnMpJajTc0SXoFekgLQWNBnDHKPAUzFBDURyVA0VXaNiY5x0OyNyxEykiNM9RJmkv1QywH2RhxUOUCPgBVPko2ETHJNk4AVEEdSxQ4kFP0AFI+M1JVNxUyCQBDNvA2QzaVD+Q36EkJPLxGrkfARCE7qTLYUwBObTeoVEtQNz8qNBYDXDz9SKg1b0YJNmRLpAffSMhEtzoOOAMAcjreNYsAVVZfBJsyOUdpOgM2h0b/ADVYMD9/Ue9KTkePWnwPiECxM+Y7OjgjA7szQwNzP4I5JjceNU418zeqUSo8tjxGVnE7VjZFAWE7qUeXAHU+kVQVS1A9yDc0Vgs23UFSAE4AckPdEOZAaEkxT95TzEK6ARJb0DrsFy5IHgB5P7pPagfESEoyczbSRPEz7kAFOr8S3DMNEa9HoUHDNLUAMTe0XCgBLTdVUBI2qFarQRdAwAypAb89YABwOeA1/kDaS2MzY0SZXT02bjkeR1o3qUOIPNoybjhwAWFBuQGLMls4cDVcObI0Tz/IVDEyTzwVOOFHMk12P4k7dDmtAtRQ5THwDepAnTTEN8c02znXPr0yXz+mNO82KwA4TXZK9FAkW1kzX1ilQOdahzWEQYQ6tjTOATg5czMeNz4AY0DrP301kzHdSHc8ugBjMjo+pFZNU6g/ujRnR5wASTutLeBTaTqkVoILulzQMuY9jzRRPAYyOzaVRjI3clZ9MqtFhzZRAHRNj1iRAHYxxAAvNv8/5zfJT68aPTpLSG9arzT/AE45VTHfB9E2LQ5DNXw0sDKgAnUAVQBNQ0oxwwF2NSU0ojPqNhE2ujPbD+MByUxaPIVBwkG7AkU6eTeuNwAANwBDSAVImjJkAFY38EoSWbw2ujoYQZczCDWbNfFDDV10RmczMjMeADk++Dj7Nw8y+DzaOkQKWzW0NXxSIlIiMes7qTJtNIg4IwbwQT9ZcjgxB51W3AdRByk4+kScN6kzQDbTPD9M5wypOP1AGVQ7QGg+gEtjNeM12VqbPpA07ksfQqQ7lgBzOGgC1AFyNfNCbQEzS0QBKT+mNpNGMVthTHczbUSZStI0qzLaQ6gATEOoMx09vDwWRNhCwUrlSZxIJzr5AHI/6wOsTzQH2VYnXXQ+gDU1NTgMCzZrPHZAgFJPQRcAaU0qVqszLEXsEN06c0VpO1k2uz2eADU06zuqOo09r0VjNNA1LTSZQUo8kFb7OOIyZkSrMkE/oENqCYgyTT/FPJoS3DYKPsc7YDU2OGY5/z/5Sp1G/0clAGY9qjBcAEdDOTNKOR8/aj3RNkY4Oz1GPHg85TXqS2MzHTNmNNE4/QBHO4g8BVkFBH4zNkhFPbkHvwBDOAlV7znGAGwARTXwTWRCcUSdNyg5BT4zNn5KhwdOTCg4zEzWQ9E2L0X1PUVXMwGLNU1RkzShOKQ/ykMBMkc2OlKkOhAASDNkNfw5kjgXSh4Aakg1QKU2WzSiOPIzNERzPutUJD+JQgMDdQAySas6SU0dPLpQNzmeNIc12jqxO79GKzMjNkIATEpcNb4ANz4aNxxLmEtyStJHOjZYBIk8/Vp8SYg0iD7OVmFbe0fdNltDATSyA1wCeTHnOkMPBkH3AHg0NkVPNDJGK1DFR8U4OkO8Odc2sz7yEJFc6z2iUlg7vAByT283ETdpOwo/BDoGPIwQCTnoPI891wNLNT0GyThrNZs59Q+8QnFFLDmtEe00pQHBOBdHRUgqMw4yxAArMjlB5AB5PpU8AAEUAEIzOAHANKUyrjvgQUwznkhARQxB1DkzPZE+MzQ/NgBVMDY0O/sAYkAMAX06ZkRDSuRBYzfGO0U19D4mP/wQ1D+xAHIzKU9bRHM+EDP/UiJWaQA4Bcc6rkh3Tzc3WgGiARwCd0dpM2ZBJEpOM9UJzj6sMpcz91AvPEk/njnUN4E31wFJR2xU9zIOOMc1yT2COqQ/+AS/QKEAMgBENJ01WQJpR5883jg3Ao4AdgLKRQwyZgWTB2lCijJxOhg3kABwOKEGijzlPxUReF5iOtY6iUl3NalYGAkHXf43rjJKQC1bWTVgNhs7L0uVAHRcTwAxNW5WkjinAHNATUj3EAg1UTifXeVLUjWwRUNB/AwrMtZNXDiQN8dAgAGsN7g3ZgB5AHVAq0wKAGIBM0PgXVwAZl6wUnE8njXZAE5Ab0qaNiQ5BD14QBQ5LD/qC+pAw1hqWZFWaTdmTOdGfEXVMgJLcgBNM9tafAQ5NpYxvj5tUzRLqzVKAGY1PDQnQc4AbV0UNWwzxTqxAGw0TDrnMe0zSVCfNmk0NjZhNTpFZ1ewNvs5mAXyPaMyNTbCOSs9vDu3Nek9KF09AGsDXFPhNHo3cDdyN4NOVjRRRG80si9gAEcyuUpOEAg0fC3gN+009TlOPPxFYFmaMm9ZlzdxSXc3cwdRQvg3c08fRuNckj+rNz45a0GiVkcEukJ3BJsAWVHTOudCYEwQUAYH4Dt6NU01jg/iSAs2t0YzNE9U6DcdMg5ScUwLQNphXziBNpgyAzbgQnE9g2HMMJMAVzNAN4Y9GDJfQZU681AIAUo8jDYaWU82eDdhAERCMkBSAFFBfwWUAlEyBD3LSzIoeTX9NUA431SPW/tiGDuUQI87YUvyPE41HDZ1OspLJAczAG82lg/kSuUQBgBZObIyXFwbBxJUTkIqB+E8sDmEMclYdzLWMylD/EK+Nqc91QMFVIQzrU85AYBE4UJjOoYAakE4N6lAuzwpAGVJcT5gOJxUMTcIAFY8TF1QUTs3qV1iAg1B2jXtPA0yJTk2PMk7GzbtAmQRdAbhSc4zIVzYRU85wQJkEGwOVjJJOQY2EAY9IQo/fVYnAHpgUjdMBZIy5EP6BotWwzvnPahXrT1TPRNSPjL3RDU3rTXUS3I262CePZEAdTSKX6FStzkOQsENOzljAGdfvlhLMuVWaQBiQHdavVKVN6I9izx9H6kQCDs/MelYcABkACs8bTuhNaZF8jboXJJQ803WOiA2vUzCVIQy/V/BOf0AR0U3Q+sz1TtDPyRCvBGvRjsBSEe+OU9Eoz7vRtMyqWHqMcQ45TOMNKUzNEyDNoBFNBAJMxYBcgyqP+QAVgArM1NAcT4ZNo1AdzfHNmo5CAFZS5ZXKDV7W248EQWUEPU1wDTjOuw8DQBTS3VNOUZvAGRDvwR+VVhD+gE1NVZEYjcVAstSSTYRPqw9mTIfTcBSSjHENJNRdhTWVhZUNwbSNt02qxLuAFJhsjIUNKU/KUukND88cTbMQFozQDdhNt08ggBuWhMP5DYJAEg2Yj4EN+Q52TPOA1xfLWKeOIIQykTCAGg1EDiQMuA2XgyEM9EyMTZbCVUAZ0l3M/AATTYDQJI7RTK/RBRVKzgFNmg4DkUpAlEPhjV3O9ABWUQLPFdNv0bZNZIEsjhePqMAZzQMTx8C4juNNkRCek+DCNw/rl+VV9ZfXj9uFQwBeTYhOjc6WTjMM2NGmi3EPzg2zzjMN2IAZAE1OEdCtDW2NkAAWUqrOFoBDxLcPqNQjQINOFo4lzn9RotDtjHPOrg1PDxOOaA8sDzPW6UzpFHcDkM4wD5YOEZMRk+VBQMTwFftPA0yuAMFPvU7yWMHNtc1zTUgRh8+U1QvOeM4pUxHBTdU5EPLERQyXGIYWAI6oT7HFpBDzQXJO8lMCz/mBxJflTMbQZQ2fQcRPe1NdkNpOokyczjANgM5El7hNZtSxgBHSzg1xlcoRR453EE4EAYzHlS7CYg4DwVFQUxMd1JaBm01zTwTVVYyalEAP7EBNDe9FhcztzZRDepHx0uKM2YAM0EmNmo1YDoPQBM36TJdPtY+pjfpS5QBslj7ECNP5kMoOS00PzM3WCdT9WOpACs53DJgAZwzGUyXRWc2CDKyRm5DYgG+TYk4vFLPEEc2OFEZMdg+nkG7AUc3LABkQXw3BwPISdoCjmB7PoU3blstXtMz/DYTNDROBzVVRYdHiU36Ms1NxlOlVeI5RwedNFsMKTORL2BEQ1+STcJIrgBLOdc9tTz8M5EMKVvKND00tDcRRMs5XQecN0U/YjzlRB88hTp3RAs2vTTqNltGJzsIWGoEq0glVj81FTl+Njo85UH8VIw/eDKHVXEBEASVVEUzxwBGQiU82kT5Ojk3ZkFdM7Ay4DLEAFY3XAB5NZg2iTcSWIZFqjX1N1VSZlvZO+s8ujaUUe9ADjMsPHU2qjMmTzdEQ0FEAFJUkFd8OkhIdzeaOudHlzMAOY1BuDe6Na459knaW9Qx9VCjWAtSjDb/QLpCSzp6Lk4AND/wPh0yEDdLRf46YjM7Wy40mj0+SYg5hzmNQekAQj/xAGw5dz8mRQkyRQA1EGw+ni3ESyc31hEoP4E3gABlPvVGCTJVAExe0D61VgkykDaTE1dhtTYVMjlPNEqaQOM3CTu8OT9WFkb4T65S6jxBOYtCewG+SO403TtGM/BFgzL6Ry4vYENWOJo9qAG+Mas3LWEMViFZcmLqL5tFshIbZDYOQxbKX5U3jUTCNf8/8FpHAX0z5C3gXaZRAE6fAS42cERWEAxXk0W7Mjo6zldYSepFJTVvNUU/iUIjSfFBD0nUO2JUgjXiTtYz/lYwScoxvj0rPtZAsUQSQr4M3FAyWEs5y0OoAX41pk08NAY+MTvuS/U4GFsuXCky/QBiMcsGzDUEM6438zczSp8/jj3NAFdA9RGLPI5ZHju8M1MzJgJbRy5X6EDaDKk10jgLEdQAekJ3RI1bojYxAXY1VEFRStE/QgO5Qzlk1UB3O283njjDMb02yzGzBRZDagUDBH4F7T7qNLU0tl9vNlg3EQB2QeM8UD4nO9szsDXDOC1WElAnQR0HlE+xRkdMPDsDS3I3fjZLRQVCikK6QwEBBTWFSNNZrDauN+YzE0S4AS41vmHMCF404TVUOJdJVTCfSdoP5DbnEJFHiD/mR4pfrGGHMgYBoBCzOJpDskcfQSMxxFeTOnZLCgXJAHVCmzasMhkyVQBIOgsFHABhPlE97logPLdVgwBhO7xVMBCRO9Y0T0f1Nyw/ZDmLQqhDSkFGM5BNtRDmNUox3jj2Sy5CpE7WNUs5LjuPPZk0MTuOQ3kyuVkFU/wQ1DXsPuoDuz35O1o2JzknUnI/xVkfU8M3bAecRzlJaUfeN45gPQBlNNlWFjh4QYQBWkcMB79O6wYAQLFTETxGAaBMpzcjM642LUBYW1IWzD8WV9VAHjwJREBg7TUVVRg8RzegR5gP1gN1NZNNwFJmPABE8T+xA1w2q0LENw8BhFYSO2893TkoAHpJylSBMlY7/DNpARtEjUAZR1w1UmXNPulLUktcPIxPUDtsAFo1PjULOxA+WDWjQQlAfjlSNr80xT+gMi87dDYxAVwzAzt7Nx9iR0tyRwhDk0G6RYcAOUb/C+o5NjMEAG1WaTmyRxpBkABuR+o5AzrPPvlCHktSFDwCJFM0Q8IoQk2pON4JcD8pRLI6D19vMrA30kTFMhVlyDgwBrJQxTSHQzEAYzTFWJNAKUw4BykAKzU4Sc4yKlPpMd4Esj08Vo9DsQBsQx0/0DwBSnw07joONlE72zadPnRBdVOMNsA6jQA4SUA3OQBZOZRDsgA0URk9IEjIPI9avTrBOlcFQUTYVTZCNgHKSQ0HKQnsRUM2lDKHOXJj8EX0MlY370LyO01BgEmRMg43rVQxNK9flABYQ/o2JDmaBb4AVDUtYupCBwBmQzwyW0BIAFcAZjxKUIBZOz36RW44JWUfNmJB+ToRNiRGEDZPT207SjJtNz9CbAJkAas2fzklMgAAakEdNrw/YkWeXBIATT3LNZsAdjtZOIo8izqRWBhbLTl0Nb0AbzYgVhZM8C7uMxoL9wglBq84qUN5AE1iGDgYLeA13hDdOfU1kTorN685Bzo6URk2p2IYPSZJ3DtFPKM/JjLWBzUoeUcfPrRLll8QBZQ4ATpfS21i2jhmPyQz2kTKP1dCJQYHAEo5fzxxM/47UVIDARoAdzYEQVUAQkccTbUEnGELOTZFqlSfNA444jtRASIRKD4EPMM+HDScFDwJiEJjMvA6PWTESoMxyQXVNaM8nj0OARQ21DngMzo0ikBvAENHdWNLOjkQ2QI1OQc5bVOmOFUzNjf4AVs/bjqiMfBLugF+N/kAdgB2QFRRilJmYmQyigBWOTNEnlX3VZk0HzuPNUUHdTXOPhA0h1MtOqc6Xz5NL8YFijqJModLSjqkTTkBvQAvQelbYTYZMJ9flURXTmoCnz/qOOg+zUMdCCc6PmHMOStBuTbnNh1TpFZqQOM0bzXpN3FcKVXzSdROIkeNTfxHizTZNFkxvlZwTjZAbjHKQG5bokDOOAkvYDTENuFGXjHKU0FkZQTqRww0IzPqTFpaIEuURQoYIT41AC8x1jjCMmw0r1M0VDE50j3KPfAPjjUiMgVHHEmVEN1UTUPNQ6k7RxPATz9gtTHXRohCrTipPPZFJTQoD/xHPDXJNstLmGDtUDNa+WVcSadFOk01S1xEQ2TEMos5KEHaOR1JYEEHPc1U6ABHYxVVg06fMqk68lEAPNk/I0FSSa4x4zSMAFM31gBQNhVfbwHfOJoxtTOTSQM1Sjk0XbJG2AJKU+EFNz2cSRphfwJRQOYy7gXPN0ll0E8ZWHABB0cRADc5IjPgMuFIEUnGYLExvEE4P6sy5jVVOGc6K0D2M1NiNlP1S1g4vkBuAGVJ2FfJZtI09jYiQ9gz/DVTOfo/6jeLNA0AYlpQQ4g8RkdOSK406TcdWqQysDfJOVsAWj8WVTNWfTauM7cz7Df5Sak3PTlyWptMVVRGAEVXk0EPTyg6jFiGN5g5f09DRKQAcDcAO2VglDpHNMgG9ABJMtJQ5UoSQYA27VriM+I4nEVuPckAdjNrXW86JQB2H6lcvEerPKc5WjSPSMg0TwFMOps8b2c9ROY5r0AuMcAxSwWTQhgzHDWOO4Y2k0bjM0lJvFlCFy4ARECrXWI44TVuNAo1ozJLSzJLQUs6P8o8Z1m8OY47YjbUYehPbTpWTbdXmTZoBww36ztSSnM1OhFzTak5fj/HQv0S3EaYAGJAHl2NYYk0I0knNNo17TlPMx5X6EsyTHVCrQB2OkszcDclPqM7lGXON69Gbj3dSXNWwlpuVkBA/l+IRo4y1DofM9tEQDcRNdJX7T7PMd5MEDxnVUg4vjdLND87CDaHSakHnQJOWbwCLjQ/P7pHqzv8QG4ElTQCNKYG/BAjO4ZOpxqbBq1OkEBdATxb0D6VT1tAgBNGNOU8izSNZoxDvjXqVUhIQDw2Q481IwFINys7GGhNPiwzQT0TS20xyUCgEOZUgjT2QB48kwbSMrBK3TUTNaUBBwBaTKc8OT4LZBBmjDicNbBEc0cfOC1InAECOJI0mj2jQqE9cgKORJxm/laoNl9YJF+VPfVTF1RhX34yTjdLA8RNn0JzaJQHAzTlPOw7TTZ+TopDYjfYY/Bhh0dFN9IzTj3BPDs1VmRfBLo0TEj1Mk4ANUxBBFs+c0IGQcYykEbGNmtOeTbDBOsCZFPpQE9MxzZrMzdGGTUEUDMAaAGiSAs/TmeqVKg6/0EcADc+ITyzOkMxs0hKO/g2VzSHENE3j2WyNRMzZFYwMv5C2wZtMq0Aay0XAFVFuzznNlU+HUIWQG5Rm0wyEMNIozXZO78yh1S1TB07ADciVW1Q4jpIQyA5+gBDM/ABskMxQIMCeUmCO4894j4lM2M+0T9zSKk4UFTfUxc6RwBODClAdD0sP4JBCmASNxA9bEAtQV07TQY9UZsz/QN1SNoF0TZ4MlE35DSiUzRKXFPpNaMRMTbKARMvf2izO5VTLTq3QZxbyhVRP4IGPTZBBfI9T0NWNoZNalgkOjFGMQ8/ADk2IRR/YDI05Tk+YTNBkAcDZBBah0ttPd4y0kuIOSxRlEGAMjFAoDJDEL5UBBF4RCg5BTiBPtcLxDe9RSY4wkRDQ/xWoGY6McYRrzVYPv851wflRQRfAgJYPZM8m1QEPiw+1kBCRERUYTIcZws8ZUOxRKQ+3zNhQ9FDzDpIOa0HnDLIAXFThgb0Uf5AWjliBQoJcDJKSVUEsj6AQzwxwzyAAYU6GELtYdU8ZUmdP2RE2joZV5NW3FBCWkc1VUQhSTk9+kgnMhcBBDPHN6BFCk7LQ/0zYk/oOEw35j5gQC1A/ji9PttCXTwdOdk3xVPhAEE2qRYXNs8xyQu6ETk+ejU0Sa4z9jcrRGwycjbOOixQUjWpRfg6c0YfMok/FQA0AFI++DenEg0+9TqJAEJR/lwyNaUAWVP0N5cPBhMLNn1EREdYOao5dDUOAbAAN2VsNckzOjjLVWM5zjV6YJ5EQ0GcNIhLy0FjATQ16DI2VuAv2DZYQbtSpDbWNFFLvzoRSXNcODr6Ne1i6js2NrEQBmXNN6gROTKaAEY/lTMDT2wyAV4RGuk8jTPeMw88bUwLRjU6hTKSBllHXF8DNIo0nTIKN/hVCjctEIc6mkLUUZNBSDgyMrwAKzLuVugyNzNMSfk5VUEeOyE3njZ0MnM6gzTlOA8E6jMKPXgx6FDAN7RC7FsuW9kAQUWYOZ418ALlAHI0qze9aakxzzj1T0xpPzjnVn46bQdOM/wR6kPrYs5HqTY7Qm1iflgwMiE23DkGOZ48EUWJBxIBEzkqVUM1YzryN8wS3EDuMtlQ52H5RMJfwGcVB5RfnE3zMjsCMzRQQX9felOvTEc0NDXoNFc+CjRcTfE4RgFgYgk9SjhGXLJN6l5UU6ZDFl+KNUYynD43V9tkxDvbap0GpEfeMd075zhQNNIy0kWeO6c0P0ukOusyRUzGRl5N2kWAQF1e0zM0MvVMrzIXT206G1JxQQc+8Uq8UvY60zVrNVVVL1uIPvhT2WPwSt1biAIkAjVAI2PwNx5ckkLaAutK2y+WNmFXWFAIVMVXbWIVWnxJ3z0dPTZIPQtsVqBB1ABqMjIxz1MnO/NqmQBvE005KU0ZADc1AQA2SPRj+kYrPxY7SjWqM+A08TOpEwtA2VRuO6oztDq/NrNEsk01PEpG0jPhDlY4KDHdZNo//Ep8P4Ez4wFxBdU8ZU/oSqsBEzziNUsxxTxnNX4AaUUMN+03DEFBOlEyuzVSP4s0lEhrOJ85R0muOL8YITT2SRZcLD1KUgNg11foVbZLCjbbFhcOVFJpVZxlXGBhMeE32EzWAQQ08DgyTWsGB1pjADdfwGAmR+FF1AFgOAhUJDQFMshKyzdhP4QxwD/UM08C5TqJN+w5NFtfL59acgXPNrk2rDXpRlM/kkPMRls6OTNXO4YBfjh/UIAHUU3TZF9jgE8rOXtjaE+bT5xdYjQMMwM4cDM5EQc8NjPtQqhMgwZBTOc+tGlfBchPqjz/AlFHdDXxZCdRkzqJTtoyrja3A3VH4UDDTtoykkmcMolmrjHIRq8BvjukNh9RvUkNPUo2Vz3iMks3JTwARZYYcTJEMe05OgF2WvMyh0dMAFIP/DNgNw5GdULbaA0QKDo+T9lDvzQVLcQ6+lBuYcI+N0/GNVJJSjYdN+QKhUFaMl816ABDOZg3cUGAVnEBNQLlYBdZmjQjPOZB1ENWADMwEUSdNmw5NTI8OHI4a0xbNz1cMjcQNrc+tABJQ+01HWvFOtlCQTjRQZs6xDIlNYFPPznLPZk53E85O91ffhyyYsBL9DYtRYM+dzfyX6tE2EIBQ49DiE0nRz87ADYVBtwF4DSeNr882kmIQfk2W0tZNx44KgjcPqY6Xz5hAnlbogO6S3IHajTuOJI9gj2JObg53F8uXkNLsjZbCoU6GDZgM7M0JEbNP39D7VWACGhBXUe9NmVPgzw/RbJGRz31AEZKuFYJPAZgXjNKOPo9Uzd6UC84/TlSNrIzxjM6PnQ2Ija5AHhroUOTUl0JR0GlPeFCIgBlPDY7ZTZwMg41XQFgNRtDnzQuR3cYcT/QQFw9OT+rO0ZVDUFIMrE+UjpqQUw3lWGuDy9oPwUWDIQ5jTpbVuhDkz7/UzQ44TSiNXdCk11vNTg35E8ZADBPrjH4OGZERDTEZiJdwVijOzoyqTvbPbkxxjIGNbECJzXQNhEF1TNjX15KDDbPAGJmjAWEPZECKAGgSwpExVRGP384dWh0OgA2myEKWjVGKTZPMyMR7TUMD5RGNUbNMuY7GESAU/xDQz+eMchPbTJvORIAcAERNw43AlvQM01YcAB6A041ozfwOSw3mQE1EDgykjjoP3wxzj0+EA86Hz67Vs9fflG9McY1JVSBZwFDE2HQPX4ARznZYMJnFUAFPlNAZUyeOiJYMDxQNd4Bsj50QIVKmT4sOAM6/TQWAuteEgMPAFg1rTJdNUE2GgB0M0cH4TuNMh9Bkz4KSWI3+AXtNtRcclSBSQ0mYEt9RGpBXTSvM/dhiToyNyUGiDxsA3gBBjcMR8M33AEbOHRLSz8kAEM1wURONaRDwgYGNCc1TgY9PEwHEjeiXrAyPUcjAX46DGbTAEYAMjuNVnFG0QNWOOY1S2SrA3U1G0vLTYZPvABjVqg6XDkEMrg/tTgZN6k950SkMhxGr0MHPhlD8EIdADBAAQI+SfE1awS6VvVH5gbfN7FGfDONVSEHDzn+NR03mW3wNJY4nlJPN3Az8EgSX6s3CUHEQjgATTPRMio3rj4EQCI4tx+pNsJD9jM9Zgk28gWkQxlJ0ELwDTtKt1PmYkRMdTQ0MgM6YVo9XBw4dVWDNPNE7FGUa6NR7zTLPFM5lDoQPIZNZzjeB3EAMkJ3QmMG3jQyOGtQ5zP9NCBCcVutPvFo8lCiTS5nQzXtB1I7bwYVTIRJTEfAbSxjCAIoRB0BCTjEOk0+GThIPO9nmzsJAGVDOU5kM9NVMDdzOk0y7zXQADdBFzIRB98yOTQ+PidjnAAwQhtWZk3IQ91kTWRZTcVTqTHHU6g8SmtOOJBGjjeIXWIzEDUXN6dbWRCHP6A4JQi8OX838EknNJNJqTzIP+QAQg8jNQxOnUBNLcQyl0mOSFMQRzu/PskAT1AzTMYxSzj0RAY1PzyOA1w1X0EzQ7sASjnLMxY4WjbmPLBmnG42PlFMDEdsRTc9mVlyOxhHwQEQMvU5hTV7W1k1mT2kVmE8CDdhMuEwAkEHMlU1YwBoPBg2uU9RMltqkj8jEDU/i0NBMkBYMDWnSoNCkA/wOHM1WDudPvIxyVn5MlE3bEzCB5QFlEOWAbA2T0mVNpZK3TVhRosAOEPJNQc5YzP+Q8o2VQaLQZsyBE1cNcY0jDd1Y5wyFEL8NrZM7DSiRlhTzBo9Ozc6/0I2AwVT1UVZECM7LzwUQMM1SABSOCo3fjmODlQtxDohPjxCxDgsDyZWPz98NAE1TQNPWXIPvDRTNrpQUkdqQm0AVQ5DNNcCSj9uAa9afDcfQUxeOxHUXGw7pABRNQ1Ad0mnAHNCTDZVWBo//BCHV2o7zjwnPyZGyD6TQMMAbzLgNfEUnDcAPJ02aEb/Oa9nTw5UQGUHlEMsPFdT9BD3Yqpr2D+LSKlDvwIkNUwDdDgwUFc2BjbiOI5Mn0HkOj5BQUdFMcc40VUhVFRhcWixY2g3RV6rO1pV9z+BOCdK/2LqQ0ECWzIVPjU14jk0R8c72BNNSsszc0icMfdV2jIQPBY44UATYa45XzxJQOYyPTckPGE2wTgLWJNP6FFAASZHnAvEPXg4y0ZHbhBUjFKMRNA1jF0UMhQ8FlQAOQZQQT2CVdxcRQ+TOrgx2jxsM2EGs0wdUik6TEJ/Nbw2GQavMgdoOkWWM0cy7jqJOtxLiRbMAGM5izeXNCg8kDZ9XbU4DDCTNRs0yzZeNVRUTgLgW3tFOjiJPhA+8TZrOEgBwTixNyk3ikC9OmIP02nSPtFHn0b4S/RJOTwAN6hFt0TxEMpMpwJ1Onc2TE/FVDtRwj+BR8I5BDvbN4g/agFhSzg5KVENBL821jZrWJEAQQjEOa0+Hzt0Zm9pTEgHO6k7WTO7VXU3QDUOMeo2BDGyN+I3ES9gQ0gyi0T/Qrw3uzVvEmIP71KKFso1STaGXhI8/AHqMeMAejtGAXkQ5mBhWas7xC+6UZRQNQY3NVRIozi8PJs5mDTZP95GKk7wO6k7dDohRo434kc2ARFUqgEoP+pPSElTNaUG3FnLMrNBVmb+Qgk5V1vgOqhksgcMRAY5vU0VaE01HEA4TMI+QVT/OXo3ETcLVgpXEEVRODc05z2kOZpUTUSrOmI7vDtGAFFWYQFBNP5HWmx2QvgDT0NAREBCYDUTNzQBW0TYQgNB2kioN9I7xDs3EL5EwFwSRAsYET/eOU8zu02pMrE6C0x3OWw82wFLR5gCKF1LNi9K0RCnOGRjCTI5SBRO4DKcRbI1TjHOYO0AOE/iSMlLsjQxWDBFllTfQm5GQFfPPoAy1WqiNUVt8DHubek8hUmVQFkMn0S4AQY36QnsEBw4tzgMbSFTY0vSNIdJymEzYmQ1I0b/L59UADQiVs07qja2O/s1C1dqR0484jMhC3k+CgbhPE40v0MTOvMySVqNPmI7RTv4AGVLlDuGNAo0mTS2OUcy/VYWUBxFCjhmBtJCdz/HSwo5ZzaVAcZmrjmfP6tMiEBSRjgydFPMbz8+0VaoNTYHaTqJP+cPjjpJM7BCejaoaT9LHDK7VcIH4UdxOFJQHDpbNjEyCTKhMeEC60HKNUBOilGKSdxLMm2ZMBU0PzdhB9lFnjl8ENlEITJdSPcAWjUHO2pJDjSsNPo5SjulSqtQNTMQAEE+xDJOSepAWj/uBgc5dktjPyQ0FTTnB0xC5j1MOIlYajq1M7c67ESZOmo2GUKBS/FQJzXoNY8/FTM4TR0z+T2LOyZBOVU+NMQ5Oz6cRLJLUjmENN0z4jlHT4M4KUc/NVk+S01QAiQBMm8uQGg7YEL9NcFBw0eYOcY3WjM/Mt061jXPMh8yH27kcBYGN1K7NYoElQXzNS1AIjZAOXdIo0WzRuUyRQWcNZNYxTvBaJQ38kmRWIZbb0ChNhdA/jofOXszZ0FjBOtuX0OIOxg48j/nWxg9YEYxB5wyTTcqM8k02UIbR0oOVjJuUs9BdDZoZlwynDCTVWoGlj/eF6I5YzdJOOI/OlnoQfk8XzKtTtYHUjOTBgc/WDolQzwJkjrcQRpWqxF5NJw3aQFKBZI7bF57EYs8FDbYNgE8z2h+AVpK7kg9UnE7zGGhNRw3C06yNQ0QuQEnOUoP8AE5S7E03TenMgY3rUx7Pw1sGwScNe43cU7VX35g2RNpYfEASEy3OnNDnzDuEwtLYw5FS0EFikLbRo9MhGzravdD1Vo5CVU8jgGrM9Mzu2mMXkYxyURAP8U2kUw8OHA0kzJoaJBMzTuONVY+czjAOfVPvE1JaJA9rzImbO013jy2Mz49mE22P25jm0U6M9Mz0UiMVG5ASVxFSak0oj4mOYpi0TctPVw3rjp0Aa5CLThQPkBPIT3nPHMAL03WM9M4v0hBWmRB2jnGEOZRkzO/N60zTEpwOuUAaRDZMuU0FTyFPBVI9Tz8C7o+ozaVS3U3i1sHNNdYd2BeM/Jw6DK7b0w/TkX/Trk8yQ07VqgzBDb3D9JW9VIlPhAFvTMkU0RAfDduQF01Y1wqPOxFQEF/Ako10AFHVmY6Sj69UPs1sV+rB4I4SDe9NIRF1U4CBb8/sTlfEMNK5TIqAFk3CG8AXYw71ji3NxFNXE1kOCMx6DftNdwz8DMyBtIyTEudDlc+c2NLN7ETVzQjCexbLXBROfoANTfpFQxLS1buPuk120x3TdZHxUC9Uc86FDW9S79OnTmYO6hLXDl6PiVAcVqkR8M5xwdnWrs77U+DNxZbe0l+QUpRE1MBODEzwje9RWdVtkbRBiY4LVHvVn0DT0Q1UQ1UVVJMaE8BR0UFUydqAzQkOw45XzbgM8kyAji+NjY6UQBXOiU1UgE0MUsLxAF2B2cAekqfRmJHzjhaRFZafA/vQ0NdsmxbU6Q8BjpDROYG3wW+QtVhDjeAAEUzrwSyL9g+3zXwMlI/7gEcP9E5STpJZc1SYjMUQR40k0EORFc59TybNJQ7LTthNMtDY0AiZqs5nDNlBtJaUABhZpIxv00ZMxA2BkIlbZ417ktcSfkvmlo9b+c8Sl92aYxTYzTEbtNQwE3WOvRGizzABeBBfDJLMJM1VgRbMyRChnCzbrEy/DPhSBFP9DYyZNVodFY/VrsykDcqVQ1DOTlJSuRMiEkhMusDTjJ0NxMQKwfgAus0CECSNptLUg+PADNTOTwgMvdNNTP4PkEBFDyDOL84JDU2Fy46pEOfNVU2kES6VPc8uFAkNks1UlarZXRXsDTfNY43imnADkM3UFTQB9k3IzKwCGhCq0VgNpU72F/AAEQAZEHONy0PYDlCO5IBHFUYPHk9aTV+SJo1/DKxV2pTZG1oOGxJVzrIbkY+k0W3NtYDxED+NIczZj3nEeo8Iji3U5I1uDn6N2w9XTSiOMw0UWesWTQB6WAyO/05VQBLYmQBNQrfP4E4/ToyOlY5/jiJARBCrUBdQgM1NTVMMC5bFWoePAdcKDl6MktBHTDhbx0CJDktNzRtfz3hNM1Cd0HOaFg0rDSxM+Q4MmmnUCRObTpDNzM12kCAMktmMgcMMhU3GzUrAVkAdjHmNAYFvz4zN6Bamz+Ccw5Io1SBBfVptjYvQJg/ZEKsREAyYD+/YL89ygE4XSs1KT+8Okg5ijneP65AFz6wT35zpj5tQ5hD+lXUNTZPA1qHNMg7Ej8/b6s2FzzRURExv0wKPBhHagdpOKdFVktiRKMReDcLBrM8ekv0O1Y5iw7AWUheNzolO8c6OkdKSBIBrjdxQB42T1H+Pdo4dAwpNUZizVG4PeFSTjgtU8wxx0TmO3o08022MvEx90vxOnQARVXCW25duQfFTRU79TphWAoG/EBIA0U1/Tp3OnM0AlvDNLhFWkZML7oFyDlfNggzUjYXL7pohWkZNmlBDj0OOa1HvQEtaT81DkurAGZvUALlNyZF0WnSPmE4qjwVNvE+9US3AihBzzmKNgs4+z+FRLcHf0Y4No83Zwv3OQgJcGaxSR83jjqfCls5qjOtO5BE7QBSac41Sjflcw41LDL0McVp8TM/Of9G20HaP65VPnI1NBk6bw2GSO1JVTeYNSNJVz6kO5k5xznZNblGjjPMO1o1SjSLOf8HaT8cQSRJkTKMVLw8swBHQEk7C1+XB5xBY0DtA7tUuTfaNmBbRTvgAEw+tUIiMpICLzHhNVhBTUKkT+g5qEF/Mdhq5TKzafdHtFijL7o7EFPhTXU7bwBRWx0zsTK7SAtI0we/Bq9ZclG3CYg5HmZqQ9Qz21iGMvQ2fgJOOegyKV26O59EJjNXPs0yLzt9N6FPqjzWXSs0zkMTVYEyyDjNO/M5mjx2Mec2LwNJUIBAAW4KBdEMqkThAS47lkpwM90BFQTuSBQ19jgGQlkz9z3dUQw/rVKENKs9fU5tBQMORTIlPVw4OzwiSQ1OgVdYQVEtGDx3AQky5AHGUAQ2RQF9QNEGyUnhOYc3jW0nBBs65zx0V+0+9DljW3twjkkbMddsXUHTB3UQbDnLQGU3uEKuO5YATTShOQhDCEAgPn8yTgWTapkBqzLWNjFUvkhDNs4P9G42PYIx5zVFQH8zUkruVqsH4FQ7OjlB+W5iSudC+DYVNTgz8TpIOIsRewSVOTMyJV+8Dlc6bjHXAE497jWxQjY1BD2cMws0sD5zZ1xUn1QERicQCEBIM0pGEDelP6M5j2UMObISB1IrPkwPYmKsUfcL6A5XPPhFBTcFQpMyQFSEP1c5HVIpWMVHcTVsSVVB90suP+YyQDp6OYU040fBOU5CD0epOI45LDIhQq5QwFRNN05QUj1OE8BYsEkoOyQ6CD2LNng3KT8VOAE0MmD1T4U9/EQ7OrhoGho9SUpYpRNSQG4//0NWTbsyjzwNNt8QODjEO/UDdFozO7VoWjXoADJKwDVrZ85EcTgdAo41lzRNN+1HiABnPX5HpjJCRQo61QBnW248TjKgbwIL6DbCPMI5DgBIOEYCJ0RDbgw8+jfaPIU74F66TCc2SEX+QJ1MXgUcOmZF1THPVZdFWTwRN0U2wWBhNkg2B0BIVn44VDcCWrcS3DZwShJX1jJvNOI/+TXwM7E7YkhDVO42yQ/jadI9fjzIPAVB01GQQGVR7zTZdUE/kENYNqs9HEzBNN0x9z1TNDJbLQBvMcY7EjPZRB1IrnVDMeMBrwE8OGc+zDQVEJE0qwdpMvE26FuIPjc4zWdpHLI53jfjNdk91DVQOctAsTSmQ/o0rAyqO308ATP8O8w1FjWtNzw5hzXnDlYGPULtC/ZXKDPnDy83KAEyEMoiGGqZTHU6oQ9hRjs14kx3SMg6mTiDDkQ6+TWARCY6wTLhap03wzX+cbw1bgG9Ty5qQjPDAX419ETvO2wD9QGoNxE+Sz5tcCtDI0BvPtdDrAJ3OKpNtjXUXeVR+z4Qa8xNXDJFTzRApz1lWJFETzTLPus3o0J/Mpo15UBfdZg6t2ujOAEAZkRvCVU3oDHPNJMOwGJ8bYc95DKuaHQR7QepM201tjgjS38DujVFRo4OVjPONlE+o1RNRIFYiAFgOg8zoThBXZtK7m7VOII/owQbOFIBwQXyPeAHlDyNWjQ8gzm4NEdStUcfAidT6xHqN+NGR143VFgy7jmsPS1CHDrPP8UDD1SESIpWTzc0NnlUTQbMUzRGi1j5NIZLJEDDPWBCozgjOlYBJkBaQohJp0Q4Aw467kSkQIwzZgbSV78BYE8ZB0408jaMEEcxtWd8RAFMRkzRXUQFvjpMPaJrCwA5dxA7pWmUNck2WzQEAbM6oUKlVhFPLD/fOg9XWAvERSltsQdJP8cHAWn1OCk2ADiRP8gPBkkfRU4FigcpPhw1IwBFRMpGKTlCAE80jTeYOS1AakdqSgxZNDTaOy82EDQuOtM4MUDRQgkyS1KVNRZtzFfNADAHwzrcUOc/tVUhOf9EVm/RPGsDujauVIJUSTVsPkQQ90VZP2AGWTVMMfA+SzsISG9gJjL0WctE5jgQRQw59RHUPn05jTG8RDAAbgEyCCcyGU08NnlCokmnOBtDAQgnTocC1ABiVPcBHFq3N6kAVlj6Rf43TkQ7Ul0TTUqaPYMAMUK0R5xUvl9JNrJW9UbTOjdU6DruQqxIUwNXQ7s2UTV+SQAP0kCYQ1YANl25Moc/gjWRLeA82z3+BJszSjPCEIcyhzoUO6E6TQA2dao6VTCfVKF0IwBUMehBm0CqUikAdwGAUkZZBTSKPEY2HTTIP6A3Pl+ZNWwJO171Mb1NJQIkRR47JkgnBRY7iFqHOoNBVjepTv13bz01NuA52zodOcc8YT0uNpA3JE2fNfRG20clCYgx7TyLM6tUag+Uafdro0AgSmBWezm4Y5s3fz8IQCMAUV9JS4g0rz88OJdplEcuU4x3n0suNk9MLERqQLUP8DSNNhw24wEuMwlB5DQ0TrkROUsbMd4BXUkxRVpIrlJGYO05jgaePLcZjQ5WPiUzPkotOsQ71FwSQJJbb2bXdqMEQQE4NLk8tTwUNlwycj7RQS1LlTFGL7VQaTJrW6U73D6sEPU3oEv0AS4+vTw5WUlKt2aSQOZorFkFcv0x4TYmT641EEkNPlM2uktfNvc31AY3BswDrFKpNyQ91zu3OS0yhzHtO4w1gTPdXVhyNTrFOf4LbDJuNvQR6nXQMeM7YDP0NapEsz4nPdw1Uj5zBpQxy1KEUJ86EjmyP2RNGQBFRlxh7jPOM+k0jkyXPjQ6eThVNbhy2TTJMJNAu28uSUBajUHKOTgG0gepAHZUADzWPlsCS13lVyhX0T3LPFNHWAFgBnc5DgepRVhng0c2NytK/V/FQTk+NUDRRL46LUqZRFgAYUVuUZMNkAIuQoc1qTSwWIE3TEWqQ3czFjdOQRJATwA4R+EC4kK+VgJjHkDaMBEyTj6TWvY94jcRUy0BCQB4QsE1/TxvWwcyGU8hQjI4zTtSSLYzrzHuOzpFYGD1ZKtPzECkNz066zeKZNoN6hJVaRo7AFKZO1I6pxEHE1c52zk5P/UxyVKVOPw1FwbcM0wQOFQ/NRZRwjMqMwA7bD4kYx4/oHWjUklJjzy3RfIx1zhGans2VALiULw3xTYzQNk8djNJVmk9eDrFS1xflTTgPeFN3Tj7D2BR/gBFPDo4HT14cYwz6jKPMxZZrDj7NfEyXGs+PFlWZjkHYglV3EmnAEcxyUZ8VLVNyD19NDwQBzRMVWNBlz7vM1I8OQ/vCpk8P1JVbDI1UTO0ZEU3dTfWBqRPcT6OQXw4LUfFPEE1mTQfCZI3TTHFM+dJVTj2MT84Czi+OTpafEHROhFjaGVXMq8AZz0YA6w2wjPpAWAybDU0P4Q/xzOzS0pYN3LaRxwAN2c4NJw0CkiMQiM0FkK0W4hIQWk/NclGCSh5BJ4zFEFGS1wmVzhXPCIDvDrkNqc7WjPJPqNlwEEPQB4zJwrfN41G0UdsM2Y2VVq7TINhTz+kO8M2EzXJO1YDVgBpMJ8+DD43Ul1HMTgZO8FAmG1oAcBiqjpJPFk2hgSJRlY97jVYMb84gzewMgU+EEGoQf9VgDNNN9JAwGwxO6kBCkREMj5UwQXeNYhDdzLYQ6w4dTc0QUgAZTfrNcM1CwWdNMY3EzzdMC45TzVrSQlkkzL1OVJQbQBYdGJJegUDNV5I1ABrUCRMNwBnPctrgjf4OUo5mFU1M6tX1EeyNbk/KjHnU+FBODZoPXY5eFjlQv1p9XnON5k6DwS6Q4g23D0GQ6gz1VMXO59SPj7JR74FyQWSNV9FBD0dNuY9SkcuO00zYTaxAVgAT1HvNAtAOABQQ0g/TmdmNYMEq17aPaI/5zORU2k6sWBhRWBQHDbfNxY0o0vGMdFLOzp0PoU2EUQoOOs6/z8kPU9Bl0G5BOsQ5jTiRm8zQkX4CVszOz41XeVqnGcBMzw7Wg8GOmY6hTJRNiM5YApbNudhrjQoZOM4JzPuOI4+zzH4RxwQIjw5BvxiyABMPZVQjjSWS1g7ITzRMdYJkjcbPltCoTWwMhUy5VRhRphL7Da/BXpt22b+RMpGOzPFR1wx1zGzNYBLC0BxP4UAQ0VYeMMHqUApPiU6FVbDMuAyQzL+M5E/6zNlRMVD60lTODs37F+VOL9I015WQ/0yjwAvbfo+UgLTVblLqzXjRGxLOzgFM8gMnwRBNRw16k81ZrFoOD+ncR83+Q1zNZlYGhDRNb0zh3eBPA02ZDSTRCEyuzjEQH5EnTIcMpo7qUg9OrM9aVM9PAUvmjjKSRc8dQEnQioMn2NOOW0zBD+OS4lOYj+CUVI6SUrbNYVAU0FWROE5EgdOMg4wkzikef9I3F4SaDA2lDeeNao9LTYXTCw3PjZpciZAwDTuNss31DqmN9w6PW/tS1hWZlPfOFUOVnPsOS81kjvHNexOjBFzTz9xQTgPQc9JnTlgL4NWRzJfNBVHn0geQpAG20kNQXg4C1WkM+Be0zI9NU1Kqz+6PIVkqVfWS/UzR3FAAQlLJEaITGlDvzCTbII1a0PwMuBs9DfeSyc18BAPP9E+ajZuN+VaDjyFP4JVeD24P10zk01cAmlpPzKoNOBEygB5OKdXZDv/NtM6PT5UNuoNhj5iPGxF9D2iQcI31zUTNdA0TjKtBLlA7AEDUmtDYkGUP448hTm9D9I1sDg1RZIQ3Ubqd/Y3xTrlMtJH6jJfTScIZjdVNJ1Rr1v9R8U8AD+BNAIPjzNBP7812kEHTbVb+1E+O7U8LDV2C/c2jTvNN41EEFGbPItBlFJrTXV0YjupOxA1j0TvOcFRET8jTTxYSzaUAV0yPjWtM8xIPRDlNbQ7kjQnQJg+pDTqbT82dT/1TQ5iGD28NeJF8jTjaLE780QhN25Y5QlbM5g5VTliWmIC0kCkT8Np/zJRMpFIKWbQNJZig0YpEOY++TNOM0xaIUF0NwxJiDcPNdEEQVySOVUzNzVaO/tJiDUBRWBNtzuMNIxWfk21VjBSjB+pPbA+GTrKdC4HTFOaQRY23zVuP6lQwFIiN6c71DXdVIRCMkKlTstT2wSaNk87XDfJB+UAbUsnSEpF+ETFaWk7Hjg3bmo3D0JsN75atD9tOoFj6FYJS7Q1xjh0NAcCqXpMNic5yxCnWnw+UlV6Ouxat08+N0NK7jW4M8ljnFyoYew4+0E7bu47OmwaQq5GfEXJVmljmze9adI5ulXcNmVMR3JPRQlh+ThGRSRU91MXWmxJIzU2N3MDD1gaNwk5/RaQUfcReEmPNQ08ujlVMjVtGG2rNoY+9TsbQF06dlZpM9t7g1IpNzUzOATqYV8z/Ui2O5Y5B20deSRAV0Z8Onk2vUsyQBM5VTYoQ0gGfknaATk7/z+6AXc0PDrXOCU2ljXcMl1su0QdNcg/gQIbSRIGnlK3S0oyakLXN3YBt0L9X5c16TobNgg1AVI+NdE5STXtBDk38zvceFYzqE23O5AyDj+eQ20/SUC6Oksyh2LSMgU74HhYOfpLXC+DNRRVCjmSPD9IQEDDC7pHdDh9NkBDL0dYQh04cjT1RPk37AdnSuNM7DZBBqQ67mZCNls0qzV8P4kzOUKbMvpQYzuUAic1ezUdA046PTaQOVo4MgBWNk88M0LwS5g3DjcMONgEq1o0M185R2FnOwo2JzXRPLc8RwA4SPc1+mdGSS1aE1IiAcYJkjtDNiY4Blk0RVE/m1ISRSY3KTP6RFZAizbHQ/pHzjNkMzlV50PYNY41XDc1TDwyX1JmAGZjFDWTYaU1vzcVSZwzRzmHRARGJ0wrQu516lq7T0wQyjvzM1JDOEU0OfVW9TPRWQUCUTPtPHk2EDtgPvJEHXx7DCs2qEfANWxEPDHPOQRRDTy6OUpVMAv3Zv42FjKteOM+U2GJc0Q8LBAePlhFZ0q0OBthzErYNLU2S3c1Plt0Dm5iS50+rEqaPE9pCzHcM14+JDjKVhY6sUrnRN04O1QAbPQ3gzqkWmRfsDfjPhla1T+ecPwwnT7JWeg+HFzrNaM4XTYROdt1QUr/Q/01IjWZRww9OXvaPNEyh1bgQzg0jzeaVARAoT7oNJQ1dlGTTHY6ajM+b/I9fk9tYsBKZWk/QR1AaA9XPBA04EcuM2AyAjdJOggEnDmBUlUBeVBjOS07RTI8dDozxzkmQGVCd2FeBpo59kCDMwQ8TkfnQjgPHFHvR45pPzibRupe0DeZctIyXzX6GCEElUerPypLT0ZTN6o77T2GAcE7jzJTQQ44OzlAOShbvDJvTSdRinsTWYI50T6LWmNAflegNa4z2kJ3WTptPzZfQQs7aj7JNuJW1Uc/QFM8m2OzbHUymTybSB4Fw3hyQ9FD5zS5QOs61zUQPapQxTsweIczuTv9QHQK32vMfbk6iTVOOR0E7DWjTdZull8uPFA44DuUOZIx2jHdMg1PNTNMVhNcEkkDTIk6OjZmEDg+HDguB6k3ozTgN4s0GT+jAtQJEESZQT82zEfBPQ5AgAMFTtFPb0X0NUYzkTHAa6M//DJqM+ZG2zy1YLU1KFGbN7s0i0dpM2IzzkFLA0ldLwjcOS03kABNMyAH3zTlN0NGZz8PAcYEvzm6PCI7qDjrPvUCqTudR59bbj7ORLhtC0mVNiJeoT+pR8djHgYHMpxjyEncUXo/1FSqQyo0kC+fae9BDzfJNs5ZyzZuXopd1BAcON4y7TdWcto44E7xV89D7V4SAjA52E6KPBFT3z/RVe9FaROSfA15JDOkSnAFkje9Aah0rzZRN0Y1U0jmPLY+YjptN9xZVkEcSL804jSvNNQzOzvuVWN9UD+3ASh14TKpUfdkTU01c6dtsl0US9I3t0uIYOJBwjbBAUo+zAfgNyJhZ1P8XY00qzO3UDctxDfGT6oa6TYgAVhUjBEHPYE4+DU9Bz4ORUBcMgMIJTVeFSlIjWTVNvM+EGZ3Blk1OE6qN6dHwFf3Pr080TxxY5sx4jPhRPBGO0fOZVcPI0zWOCxl5AESXRQ5NUbSBZw0MTPfT1BMW1nqaT1drjKRNOMH0VBBOiU0BVvKRRpZBQBLNjdFJjTITzQvtTXINoZ7ikwQNJBZdHz/NZtiwDNvD+RHCkvGN5czaTbdQ+0SYjNhSYg2cFsHYm5I9G3TNmQyq0VPNYFDFjQgYAM6THM2ZHE6/z0rc7xoGkDDN9oGlkefQR1T4TmvfKsF8nbyNRI1IEoSMxZWcUZMUXAGrUZuO85STjgYNhAG9EBdQns9mT4zaZQ/TjorNkpZPFe/V9ZHvRDlNfYFnVERb9g4+jVIPsc5Ulb1NsU0kVohNrNQxTcMWmwz3jGrOKcx7jy2NiRyJjo9NWk6/zz/Nwp85xD3MvgHEXrzNFFFY1u5EXM4JzMAAkYyrTlHO9c5oAF2QWM21j3iM6MFJ38OMwoElUPgVuI0yTT+NR1I0zU5OUc4VGgMNK9osQJVVQo1iFU+OZ82DQmIRlRubFOmN65Nx3OnWZpxizOjQlk84kcfTcU4UT2YV5JuSXe6O2BD9DcJNyNFpklTM7hlzULBTKdAVgcpSUA9DjmNMJ0zKTdlSe06WzZgP25ArDwnPNE8m23FN9BQ5zMqRfNK/TNWOwcQ9zZ1OVs7zj9VT1lGSzr8Ox1wtTHyQk47n0EQU9sBsnR+PNozkUm8MxZVg0yIOL88jW2QXBI13ji/SsAHPjyFAp8y1z18VnFREX3oFpAyJAhoN9hH3kvxM6lT2XZWMfUGfj1lQiNCtDQMNDEy/DYATdNNUzNDO9c93TfkMeYzXH83R847k0ZiMik/rQanO6o7/jrsPLMu7j09Ya5UWFjFN4N+Q3dGXns9RzV8YTc1d0NpN7hI9Ta0Oh1OYk2GO0I950ncRo9T6TKyR0o7tDVgOQ43PUHPD45YMFnoUlhhOzfcMx46oXjHBwxCrEJdPH1NIDNxROxHG0BUAVk1wEKHbtV3r0+MNSw7dWbSECtnAT6RNgBNVmbfQJAy7lgKL5YFHG3wNjE8+jfrMlM1WDbDQfYGJg8jXjdodAGsTS5BmDnGRUAzPzM/Z142IUgRN+tAQjZUWkQ2GkbuR6c7wD//P6s7TUzWNAU1OlBpARtHPAdJTTw4DwNFNRM2ZhYXM8N8xjThBm057DXtPV02RUe9OVIDczXzNPIzyV5WSIw6YlbgZKs9mlfVNVkzZktZOGc2iz6eOPU9hjccQG5Q506yB81qxxUMPS1J1UwMYuU3VDVrYL8x1zSNYV9D1DWSOZQ/+zJgOXI4KmudNhVSlWVSVk90YjX6NN05rQ/kc3k6TEGYMgFkEG7fQWg4cgBaOwE9PF9ebLN+vRGLAEc/fTM6NlQQ9XtON2c1LQakOvRHpAGzP942xl6hO0k19TY7TB1FqAeFMxBj8DngO6lLOEavQLs0Hj4aM25SbD5LcOIG30U6NNw5KUB2S8tm2zVLOSY1WjMbPgwu7jUNSVcFN1eDTt5Kq0KlNw8/5zPIO+cyTjtzOl9EgGJ+Ms5WJ0X3RfE1RlUWOP9Ab22eP6RMzkglVa4P00aaO/g4kj+eAic94DoQMBE62TkINaU1IgPIPm06VloONJZAoTe0X5cyUTi+PS0y5zfpbPo4+kqBPBFC7EyfFSkG3ze4QpsPYUurSBFDYjdvNPIzYQLtYmRCgTV9M243dTeQS5U7CDJVSdxEpDoxSixGVjUjWw9Xv0LBcwsyNzTBOmZE2AFYOZRbe1dYQsI4bgcRNkBFs2h0P+Y12UscNTw8QRBHCt8yCTriBZQ4DDrkVE01wDuNMkABG3nXMiQ0vDYmQsE1+j0tVOA3uDY7PjUR7QW9Nn4x+jSmQuw6eVUEMwA1KTzZPbVPFkTsfvc+YjltXClGbz3zVkA1FlLAP44yvzlbUVk+rWepWkQ8/DHyS5Y24j8fc9RB/0dpNVhCFjWbEEdF8hPADKk23XeKP3xDC3LAU8dLiTJXPHhQQkhDNV83W0/0Bq9PNRE5NW53MTxPDJ9zBQFaD+I2Aj7SRAZk1TPUGv01MjJPYV8Enj5tR+pK/z31NLk6ADePVglSTzrWCltVuQFbVTBCIjI9M0wwNUG4Me1+TDunOQc9KTcRQlk8EDVRTcY6gUfBSOY6wTPsDwYzzjUBPfg+vQcBPMM2yWAiUHl4J2XWN7g13jbzMetHvUBTO9YG9EpYPYJs4k2fbFs4ewBpM20z1UZuZNV+XjdUQE00NDfjVT5nZkecNsEHUT+rB0xJAzx5PLA3xTc9TIhSZlF6VicBEzXGOvQ4qQTsO6pKRi5OPJBI9EUFNtZJrjgpPBQ8uj3LXCpk501WMb5VAUGUDkNLiYFkXf5S6gYHP6M7RV8DPDkC4EJ/PIw2hkijaqk62jLmNMh1xzZBNIc16HnXOUlEwkSBEPUP4wR+QgNnaWFRQysHCH4qWoZJ1WGJPNZBl08hNNFLQT8PAS55CjldOQQzoUccNfZIsTOoQF871zcmOSwvljp/EOY1mEauM243LDVeRuM+RDdHQUxVVzmSbkZ/gQ/iSy44C1v7RH81kkrnREM7jD2hPIM5WzJ0Teky1lZ+OVpu5E93MlgyxAFpPYN/DjdzYkc8/zaNBn4FN38cMmo4CC7uSEYyoAE1NRwCjlfbA7p59kjIN4M2qC5OVpNtPzQMNhcHEoA2TyRGKzI5MzBEmTIQNXwyEGHuNdE0R0HqMos+yWZlRzJgIjrFP4I0uDRTUfs3rkX0PslBOwaITgU46GkFAkoU/lU+PXhFTwhocjBro0OiR9Y0l3knRJ00yzUUNnQyZFr5Nn5yhjtIPuo0+jNDVT436QHBNrkATWPwOhU4vDLpMmsBWze9R2xPKElPMepFcoKOA35hlj4dODFkqzWdPJM4tzZ9PrBLpDIXR8UAShDDPd1D2BAPNicy6zWwQalVPkFMDAtBgFE+Om8/bT4KOAkGflPfQcpA/lJmW2xuwU7wC/gyAW/dNmxUdDIbSdo2DTp/OCxsx0jIOQM1XzU8RV47vz+FQn8xyFFZFy4G3kyXMkY0ogJpY2g1VV3+aHc4VVT3PWxRk175M2M43zpVgQI1VVs+R2o3dT9kGHFDO0JZQAwzpAS5Nf0+6nEdQaha62dDSacAdUKlOZwz5A+GM/g7R0HTO79LZE5kNWAGnjr0glk6Nju8WBpJEj09OY9Lq0scQJ0FCwGuTb9kk3rNMW48FUbbDCo1Nl1La51jgDthM/k2EzktNrwtxDOkYcwzTC9/OA9B8UioMeY15Fr5NsNBPzwbNJs0/kg3PBU8UDwQOkQ3cTkRRihHoRVROChE7D+/Ahtz3Dk+OoxR+1SCAbI1cAVDP3085TWjRVkCMzkGNp0PtjV2BxIzWlZ9VYM5SUKjWnZxywWUTm1RvjgQEDVEyz36UnFW9QBDd59VuTI9RIk77j6uSwo6bVp8OEEUYjg3VDk6pja6NuY2MwNLe9phnjs6c3k+M0glEa82rkx1ORFhX2J+BpQ1jTLlGj1WhUqDSGhgukDWODc7AzXPSKNCOASyRhBK7j6FBZMCmTPGMwgG3zoDR8IzCkfeSLlt0zlPSbw8+zY6O7U1YUEcPLwIJzPfOy9ObU1qOwo4BUWeX0RBqD1XAXIEiT3gVVc4yD0uOvNGJzKkPFAAT1ToUlw0ljvug1Ft8Eq3d3w3OmzsOcs3zjhaNng60zlqQkFCFk05Ews0TEvSTFsBWkqDfj831j8bbIAyqVQvZNo5R0a/TMIAWDy1MhIQCTOMN+NkRjodMm5zpTZ9OPU6/WJlM99jPzJKNk9EmUrAN2dMhDfyPuUBfUukRZ5N13WQBylkJVBSE2kyzUDDPvU0MQ+2QwI4KFeiA7pTg0BdQpBd5QYHNZE5KGMeO3tna0Q7RP88g3VtModLdTYLNmt3mEOTOX87EgSyU5w/pjrZNVEBQUtkUmkCjlDwBUNFJQECSkk3CW9TOfZWZDd1S21zp3JcPnc4SDK5Mjk4p03nMc5ZjUSYRlQ1E03zMo840jICTzdHSg5VFP417FMXa/U22k/YO3Q/YjLNL7o1MwEzUMU7ynwdMig2mzqoYSU1pDgPQZ0BwDqnMyA6zQXVPYYzNzPaMwpqqTVrOHCAmD/JXwM9Sl75OKdFgDYoTKcQIzlbUI1Chze6QXwv0zUMNeSChC+bMjtPdV9UgLlRGk6ISLZOz3ynAo5GFTgoAWkBrk/QOaA19T9qPypRETHXZAgy2UDtOVJBzgP9BwEG3AIbQCIyizZeBR1DATTfQu05kjdVOkg0kg07NUo7emBSNXc2yTctMdUIJw/WUgV8CgB6O9g6+V6hPuVZrjzPETE0QzXxNsIzWjjAYi9QJ0t/bno/txDlAss2vAglYDJV8UT/OKcPYUsUhDEzvzKLWD07vEC7SfkHSTziXwNHvRDZTmI+UwWSMT84wgW/NUlhcQ/SOP9GGVMXYjY1tXesPdZEnTxlBYQx/DIBSrhokDr8BKYzuz1pTLVVPgZ3NIpMxjU9MkINcxNXOjFkkwbJMrA3dXPncR1RvjW3O91JVzlJONsyEDPFPZlR/jbmAE1NqURmREA2K0aOD+I9fFSMNs4G/F1LAeo3FUrhWMU9K0alAcE1tDJcQ+03aj2+OC49qjJGTrJAjDThM8czHjXbZ9gC4FTHR0o7mgEtT2o+nDrlTUk08TWPO008awdRSrpjW2yCECgzq23TQwctxDfJSAtk2lL2VLUz5lr2OqERKD5+Uyc/1kLbNhM/ljYAQMBGbjtgAw9IPVlIQzg1AWlWNuY013NONQBK5UUMS9JjX0J7PeJKSzwbYL86V0KhXwJ0YTipM51DDwWcNLE+kEP8Oa9EJjdhRGoQvlA3OI5uikAtT64+kDoPNt05agBjO0BbBzc7PcoGN3KSO882TF5GRCRDsTd/VTk4rmmUNww1jkxhTOZKmj7MADk0yDKHMo5tJ4V/NttYkzSJNugVsE6NNA02LgazVmY5UzP5OCk5YTJJT8hUBDpUPpNADDvrMgIBCjdmNkMyRURDZqsFkjgtNJsDXFDlMtI7XD+SPMkQw0HGM91DojO4Owlt0j9uOmdDaUC1MigANwRbPbU59RA1BUEzBXA6VYNCcTj2d4o2QEApXqY1XD7zfAs5vVDzVedUhDb3S7QyO4W/NkBLXFqbU99IsUUaNdk3fmSSO1FGR2Glb/JUn0ChMzpUFkZMOkgtGEzCYRA6Dk/ZRAZ5aDMNTyw3ZzhoAGZbMBbMADMHdQSbNvFolDv1TWdBUzTyO8445WDaRm82TD8/OUcCJy+fakA+JVf5U8NV7zfqM8c51EmPMl862jeVNfBlbFMnN3VIHjP2BZxO1mM9NbA9KW/jRx87CTcZAQ9CnDwVR+qAmEBBOR44V1MXN2pQn0wKc7Z5EQQ5RPE+dDZATZk5H3LSMvVAflJKM1c41ANXM9qEOjvBhMI0xRbMMO5HvlA3gg8+GTk0RTg8bGT4NcF7Em3SeApGjgLiOfZEVjJkNrBWCUl3goUiGQmIOncMqj86Dxw8JD2DW9lSTmVSQOtQnz31NDZ2LETtPaFWP0jmOTpK9EHjPCw+o0W7Qzw4yDH5Wrc34UQLRJ4Emjb0Osc2yDzabsFqkzYmPP1JPTfeV6I0k0D5QLlFrzS1RGxEdlZxUBtjZW6iNB8zKhghQNo6V0jcPhRTYzWxMw0CLzlqUQw8B0IDR44AWTIFOQM2QTWSB+BY0jXIO0Yy4z8tQm0CJErnSZEyBkzNQNY5YEm8VMVIaj1pM3M+TDOrEOZHwzc5L38z4QgnfzdNxT09OgNiXzSHCfwzSUDDWas7o1IsOAExsjZRMotN1zJNQtQyuUSYTOc6iYRrNz5pjDbfPBU38j7yO0ZRdjbJcBo8TjzPNJg62Tt2Ols3ND8qNB46ekrAXgRFWDHWN6I61GOAUBI23y+fN341gzWSNT830TpWNWcQh0FMNylKcDM1Vl1ZoTXGZFdLfwBDdHhN+E2OYgQ+hWfLf15U9z2RMhtJ2DmeNT8zMgULBp4zoTYZORI5hDbLN0NhiRDDOI8cLUUFQFhCTEx2QqSDaDvQVmlgsTQWMw4/qzLga6M8AQE8NgA15RUMP6k3izUAc9w0NjT2PHZ3TGJKXqtis0oeZVpNxhBsOQg2+jYTECM8ozURPtY2rDM4OQlHw056YA87qnhuNds/Azi8NA461EOxSBF3gQa9N2I0GTjANChAqzLQVIQ35HkReIhflzrrQxZacD25TJBU6AJKOWM8SVm8ZhM4VTv+bINAw0r8OTY3oDl6Ni4XokHjAhs67UFjdDxTFwE0PCQ7A2DWSh4+uzSmM/c6x1DwM0lPbzepcLhPGUmcTVY8BmVsM95CY06BRW5A0Tl2Oz8yCUhDSCc1OTh/PtxAsTuIOXI2IAScNsYNhjI+VtxSWz7rM/xTY0OiTAtGBlTkRfA1STUBPiE6/4QXOvMMKTV+OY81U1JMMtUyGzMjNmg8cUgHPYI3DzXcPJo1PzNkNfVh3lgYdK85U0EJNdlGiziXBSdnU0RzQUQ2NDRCVN8DdQA0Mk08P1F2TVE2qDh1XpM09lQaN483zmeFNIc4CEurDZBIPTJGP61YcDevAS41lDqnOF4/iQBLBcM4JABnTNY4MjVpYYlLJzMcQUxboTONUuQ71lL2QBMvg3WGZm9afHbZPapFmAMPdzUx+AIHQyg0kU8ZNLZDtgN+NlcBWTJghn47wVI+QlgzAz7JYjZpD3NHNMg1Y0aYOCgyDVYWEPc7v2qSNUY4cjHxAgdVzDLDdJE61zXcXiE6c0KlOqRiRD/qBe1aDzcIVLthZzm6StUJiAitW6JvIEzUgHg+d1o5UI1JVUc2Bt8170NlL7U87F4SRf8/gVbgEe02+lv7T4g91Db7TTU9fFm2Z2kzawI7QshSh0Fod7o/34LBQl0BHAEVP4sCPlMnOaoAaU+GRf8OVTZYSzlYkwt5Mkw1KFnKQfFE2kBNCZJpaABpVkhT4TV0Nfw5Rz05NMUBrAXRhJsxxGhNEXg6pDk7NTMP8HajT+hF7GJ+QR07CQ9hVFA04EeXWo1ah3dvRktIqA/jiIwC4DYYNwo7dlDzBsw80WESPiRjaDxaAE1Tg27BT1Fg7TejNE897jVcQEIIaAN0Ucta/DYWNJle+TciMcFIB3YnQnc5BDHDP/s9GDaDbXt0rzKvNusROVERPvVjHjVseoA71zVeOmo5JjfnP4433DQCNRJPOTs/NI5A9UChPPp38zKPXyFFUUwQV8uAmEAtADQz6gXtNdo+jlZAYYlycjuqOStHd3FjQVY12VogL383YUyEBJUz2XZwEg1KcjJDNo84w0FTPSs3+DkrOOFByjVKXzEx7jOxQfk7UjJMVVc05VJrDAsDTlYWQKc2xzl7W7pAj0X9X4QDBQLrSoM2bT8qV9thcUlVQqADcw/SYP1StzObNIlVYzePBvQ59THjPks3NV7QBp45n0WJXhJCqEHpZOMHcYXINlszyT7RZYoQ5UgnN3xH1Da5QttK4zgyQ7lGLk9ZNAIBqD0gfr1JKEC2O18OVjpfXCk8QmhNYaBW3DctOsFFDF2HRI1tYVySR2k5nj3gcu4YIjgBd284+jgsRdVGbjhsEL5MxDLaQ783PTgLN400Dgb4M82IiTtSEChM0TYXbeA8c1DFg5o8Z0r0NyNm1zH4SBJE327BM/0+yTmsNOV0tlPmXEVdujtsNwAzND4xdK82tzP9Y0sFyUfHPAA7ZS+bSqsyPU+DVpIDDzJdNiFBxDM4M7IyW05tMpFF9Dw6Bck5Z1UYRz84Rk/DRjVVnDaTNm4zODIdPNlO1kh5UlE4ZDqJSWlDVlPZNOFPFjnqUatYAkrRO+06wURuYl89iUYzPko5UkFSMj9CmzXAVMEvn0NiNnBCNjNKMfhEagAzRjVHTnPrOzo8bzcMQXw1G1PbOthKnUBfNtY4WkREM/BWETkuQqVHlTH1RWNHaUx3QkFHqQreM0lE8TUVegY5Kz5NOJc2C1COQ58yZgSVNOFVV3AWQvKJAjWRZKABwTgLAHo+yQlxNwo4vDisNUoIaE+FYdVAqzMGNsMRezU6MuA2lEdhOjRg7UrLQLI/ZEBSOWIyw3lkPslIEjK8OTU8Mz8kN7syTja6RPGISjufRO9EBjx8P0ka6T+WAZw/OjIJTopMEEUNV9Y5ZTmKUfs1t4aKbco36gyEZCkAQ0zQOdgzVk80ELNQjlTHSx007USZNXA6jE9qQqI4fjbtPEw0DoHYOxI07TeZQ7ExvkPKcHlBfDbTM1Y1UkSdPZw8IkWeMi9gMji+PBU23UJ6RN89lD3NPE+KujwkXWk12DinRpJCrC3gAWkzuDLUOStduQNPOhkHaYJfCQdF9QXVQtszYzeXO6lIJUK6ar46AnxGS3893jPORKs/xQvohvN8aDUyMs844T+QByk2eUCcPrszODnHOSwKv0FLRCpPxjgHBwg2FTbGWPpb0DwASBIARjexQsI3r3N4PyNjaECgQ74+40kfYAM2GwBNQxlCpEkfQZQ5uznjQEkBrEQ4QIw3kzJBRKM8EgGsQ5087jYKQFxLqz6sNDE2W0Lycw4543wqPyQ5VzYoQZdfCTMKTek5Sl2RNPNk538QA/06NQWdN24Du0B0Pfk6bjqEXAhhiVxzPTlmnDljMts95AN4OS5eRj4oGXtUGzp0QbA92j2jCt4yDVsHNXs5WwN4NyYyATPgVNg6yjSOQE08Sj0uT2ozMwJbTF4zo0c5aXBhXj4QREM/szkiPFMxs09xZhc2Ezh7P9YzwzoSS7FDxGkHMhE5fAERTLc9hknOfKA2IGh0RVE9nkFKXT007EdKPCc2YQF5M/5ngzorW2FV2l3BBj821GTjOSw+uzcFQLs5xjjgB8VAmDn0Sy5ARDmUM14Qwz40WvlLYREiMzcHZzygMjJBVj3fPCRHNjc0TWc2mDpDS1IzBEO8Zm9MQTv7Qf4zCGQHO2VbpTO0Eeo/1EQmN8VWoD3UNiM5LUU0M6I8FXwkTto26DYcMd8CWwwLUb02W2QQRo42BHSvCVtDAWalUO0zlDbhRM03RDWCO5AxzUQmO8x5vmvLAkZLOD1lYDIBrAhoL9NIvDNMM+Y15TJeDwYEGz3NNngy6ShCRLJNDl/SPyo9UjfjOZ0oeTmTNzs/fVTBBZQyOTqaaT9LpEnVRfVt4DksRSk30THKNrs2LTIZRzZBUUWHUbdG0lmHQ6IG/Do5M/2LFEZeOzozJDq8UBw3cQrfOZpLtzlHOpYBxjwpTbY6xYUiQn8BOTjrPDk5qmNoNJg5B1TcTNQ30jk6NVFNwD/5PvM+hWI2AuxPPku/ADg9kUGQMzw6iTWPasoz3TZ1NgMG3zSZAENZLDuQOCgHEjcMRuo1KzVdOOY/52ByWWwTwAETOAcyYEgfPYk3IzVAMoeItRPANkxWdTa6XCkXLjHaNq45Eg2GUqQPV0Q9S5Y7dFJmT7w+ajzmMl9Lv0J6bypOqkCEMfk9PAJZP35LpDVuO/w/HwayVvU4DlbBVsdxujsmRm491TbFNLUR6j1YYV4yXzHuPBUzwl8uNTZG5DKTPkMPYD3aN9c2UTvdOAuAFjbbOuxQMzruEXM9vFsTD/QzU0nxTz4MqkLbNZaEhQlxW2liNj2VBpo4rjMbNO5SZnMOfr0zoWoDSEI+SjIZObJXWEDmD1ZfXjG/D9JM1lulN487hjcNRQyHRktyOo4vm1RVM5N3SjhaQL1ZBToURgkBvlWDP/xULkScNrw/FTWRWWs8TzYuQCJVMzelXkZUpDg7UIBA0Tc9O1E02UNBNqg7WgGgN7Fl1jCTOI8+3Dq3OIE6RDdHAbI5fjleO6oHggHAPZ5TJ0dpOHhkXzs2MBVMWmvMRyUP1jXoM6tRmzvzYTNBUmXWPfg8gjoSAQNdFDY7SdhpL3ajPNY8tkl6Owc1UD/rNAY2oVilSO1QQUdxUP9GTHZdPAdZXjbtQi0HNUBJShJJJ3NONJtR+z9kBLk7EDy2NRc9T0b/UI1Aj0tyNmtN6Tz9NMk/gTS4QG5CXQWcTJA53jzPOu44jy0YTDxPgzNYVWNW2T/eNOJMDEE4dIV3gVH+MrMx2mA9Q51QnzfjQlE4ijg6DKpHxQvEPGE5qDxOAHZKcHWrOlZZRHajNNwBcTywFwpeoWQnTM097jZoOZQ7QzV4OrZCIiIYbmJGqznSbOJAmEhCAYRSSUfDNxM4uQEJD+M/pDVsWrs4wjskBFs26DvBMoc9kUGrOpE5AzTgO+5Q5UT5PhlUBDx1YAI8QUrRBLk+PEYQU+s8gj3igsFO8Dp/Agc1pz1YD/VCjDqaQ0A140EWM3hFkjZgMtUyRjuZBus4ky3gjCk2ozfYPcg7N4M2NgE1mAJYM+tMt4WXO59mTDoGAcFuwYpJOhU50jnsNWk+GQ8/Bp55ZGuhOf5YETldQ1Y5WzbtN1oF83J2ENkyR4DDRdRDIjqRQ8I9+T8/MeFI9YgAVLtMhDtiOvxBfHi0U2Q2sDaUPHZUMUmINJs9tWujB045Zzi2M6k8o0NANYYxyjPwRf425jPiPvlP3hNNQlkFijdVQPYzPTfWNIc2IjhGMpxhjTMWOMZIUwdMMb5FXkHXSzhLUjYQS7E2zmz0SNMD2jMbQcQ0kzx6ScM3RwbhXyEzKke9M1cEsjwTPlJHnDQuP0w85T/5NgwANEBoPvQ2806KOppLOTvYNDs/JEGATFpP9EEdNIc+ozU8Mu8xvjUWjV11ETq8RUYzIzwOSRdBUz/3NuEQbEkoOP06FUn0QNROZlagfuYBrlxzWJNBSDSrPaE2xlPpMtJFUT9qNkFhwkIWCXFDEznROIo2omHQd69atzSJTDhLiEI4RtY+LC5OZKtBhEFTRgZmb3NOLcQ3C0OPMw1LaDNuN603qTnaTHY4lwSrOj49yUefBJ43oDlHQmADxEdpa4c2mXlXUxdBOAIlQVo1C0mgC+o2sjSOR0pB10skNhdcIFXaN+MP7zf5MmAPBja/Nx9dPTj1bT8FnYucOiVFOjY0NJxGrjgZPzFBfDkzTalGFxcKTNE1HDnYebE24kqDOiABW0lIWkdET125TB2BxjHBQi09vE0BBoU0FjsSPcg+9DkrR84zETiSOYF2cDx9Ab172j9Va501lGNPUeM1KzpRS0pPC1T1MzgtxEkJNJxv1jinB4I3EUZAMv0DEDG+WkR2yUgREdRBlTOdVQQzCgRbATQ6xDa3U2NeVlP0O4xFOktERAY+rHQaONs3cwMFNadVY1W2RPdHxzQ5P4FPH0ncTyhUvDTqUnEvnzksQrxoWgFLOWw9QILcP584LgazQttAXDt9Nd4Ev0zCPAY6GEcGP9GBLTVYVhaJAj9XRyVEzTV3MkZANj2jSPQ07TmSOCo7kjp0S1lAsTp2A0s80T1lOKs361HPPUcx22GgCNw8sDgBM1qBjDvJBH48HTZGN3ZYwBHqUikzPgwrNZhwjhF4ObhG5DSxNlQ1q1n5MtUE6kZUapkyb0clATWD6kTaUUmJTmM9AlkxsjhUEAg0FEpJhyk4VET/VmMzUwF5N5k0NlZuPz1OKkxBMyc/kEG4ODtpjEZMREM8MzUVMvUyPYsURzYDeUYuQFxeEk9OdLs/D0BSHLI/KQBRW28/ljzrNTw5EUhoS5o4BzhUNi4Dc1eXNmxmgjgHO6k3LUKtQIM2yT8kNiw09Q/kT8NEpGf3ZJWL9zTZAmxQMkvvNdk61WXNQ7mMPjK/Mm8HATcRAjB51GOhS1w/Qnt6UpU0FgBjOlwP/AatQRIGswWEaIUyBkOYN4A7qQXgZSkxwBAijFNpd1LPQKwx8machx1MhDgMWkQ06kEcNz06GXlbNXk/czk2B81lXDQxURtCLUYpNQ1mlz7oToFJYl6wMgI4B4sHMeFRDkWWbrFC9IELQl1jPUCkL5Zc62GJSNM/8TlAOb06D0fANhNWCU2/AQhf1EKtAX45mA/8PAUM3DOwOnZH6k9DQ9Q3PDwkNm0EmzObBFtAoDxlEAY8AHk6iNRdCDV4Bos4MjMZNhk2CD60NIpeVDOiixQzETWlNtYzyTwAMxlVOT36OAhx1QEQVFg06T4ENis6FTfGT1dMFzwTPC09HYGBO9wx9QGLNIdU9zNAVqtFpmdpYdU30TduOMNA+TtsOWE1kj8kPnozJDauP+dNt0DWC7o2QzKrM+03q2IKTdY0RxDZPoU0O2XIdeo3rkECPJ5C9FP+O6E4jTYEMcg8zzx5R71CvF0fMm8GljpRW6ITkmueN447mlBBQqtsz2ziOtc6GzW1XHeP6j16MklJekK0NR0BolG3dPk/c1WDQ6hXGmm2PIw1wzn+QnNCpEOIdGJEQ0eyD/w3HzHmOMs/P0x2RG88EF8mRTh5kjKHMos+xAIbbN00AmH5BxF7CzIzWPk08EO2ObqNC0ThAa8ATWv1eKR2D1e/bPQ2aY7jNxszC0UMO4ZObTXtSp0/QkOpemxL0o1yNWAC1D6hUcI8dU3CNplk2kL8QB1CpTLrOYVADmQnNVNGmDj2NV9K0nZwO01wNDwNNVI2GDNJSoNs4knxPR19S0e9RO4a6TSlOhRBnFGbPfg/blR0PeBBY2KqQehdujnLOso4nkQdNlg7nzPmNOBydjHxedQ67mx1NXQVUUBEEEc4ATNIP45IPVLPNyhCvDE/NJ5IyFGfOhEyBEtPbriNczxhEu5Ag33lNQFLWQqycu5M7D6eMl0z91czOM9nRkEjOI06BmeDNJ5eEjp6Nz4CyjKQWAJGMznUWg5DFjmgVk1NvzwsPvVDYlczS4kP5DPOMb9SThNNR6tB2jYmPhpKSUEUSt0zSzTiP0JhZjKHMlg8a26WW2kHSQJLQVZUvEBuXcE9lTPhPw820X00PvgH3zVgczYQh0yEAFZfwUpJUGlT31svTxZYPWx1NrtbpUEKM+M6GWCeDlSOyUJZMjM6+gmIOjc7GEEJOjmES1H+Ol9BhDeAEtw7yj8VN0s1DTMYe5w62AcDRyVRWTYAcoI69ERzVpM5VThIipA2QzQPPxVkjFA3VrQ7vHMgTstWfUc/MzYUnABJPC590jUzN85PyErRNO83CTnXNEJGfEKKM8hCjAdHAahG+F8hOqhAwEfOVzd5Wz+9SY80mT+WYWg7qELCUDU5jjhIBus+GVsHSJAyxEX0M+YzPDvyWBpQjjNlS09Y+k7ag2Q/ygW/Ak1LOTYKPz89TzmyOucAM0LzQ0BIdzlqOixWqT81TSc1YQJ1GBGRb1AITyQHw0T3RUBGLk5tTVw1Oj7JMO5IrgbrOxA95AjeQAUBLQKcRSlK5Ut1RMs35VBSC/dDsjU2gfo1k4ZEMJ09vEfCUAg4XQ/WT2Q8KEUFAso1dGXpbmIAVT2qQTgAckRYOGg6yjc5BpJQUjkrMmuQzFHvWBqDqjpISCUBrjZRRKNb0DPiNvo4mjO0QzxCLWBSPsVBHDY3NoOPS0GASsN5wTxrEMNTFzriR8c3mkpwN9hNiQG3L4M3ujVOci4vYDTRTCwz6lrsM/cBhVKyTQFoODgQTF5ATVAGbXlbHl8DN/kHEj6RNCBLxjevSZE+EGUpBclBDlBBN6dnxzVWWIYP5DcKM1JLqzKPOso4zEpwPhBKgzuoPMg8jjlnVn03Vj28Mz82QzotEAc1dY0HPkpZvDH8T68AU0BNOdtflU1WTNRbrj/4THY7oT3dWm5NxmPZURA3Z1RYVYBLO1xxQn894UBSOAUBOTRHAGRc0GHCVVc9WROfPBFW7lZmP4FTpjRgUgV0BQfNNno5+jj2TIhW2V7bNTQ8dlGQV9Z5u09kVuI1NFEZTMZAhV5BEDUCzAFhYaFE7Tgnj1k0P0H/NOtHpgGzAWkFHFX3Pv9tJUwKOdhQL1tvOLc0QjipRv1PZD1pMBVSmD85U4NQMjh1AbA3FTvdT+diqjz6Ne42ukHpNeyCE14jUP9koVTYPiw0uDP8RtKMUzfWbJBA2jwsN+VFspLhOXgBclDlMJ9g3jJRPs9QQTJxDYY0qwaLQYQxvzSWBcM1rkxHOMiS9UBSPAg1mZLJN9c070SrNWEEA3evQw9C+AFHQCNUnzW+MeKTMkELBdVDQW0nku40MZLwbVxC+HDMZNVDEZL2Mm09mULsN0QCdZNMQqw7CkrbPx8BNTrFSCdJkDWAapMDTzNxk0U3jVA3EXiDMGVSRvlE7EHOO6k+Y0K8OSw780wKBncF7YHYU0E0P0bkYTtX7TNWMmg0FjRFBndE8UlKNeU9jxA1LRhSMGtASLmFfDR6RLhF/jRqSYI3Tj2oTg813VD/QZ035DdxWlg2fVq7Ue+TfQE4PO8EngSbMtWTjGADBJtau5OQNJRfwEsyNoRaM1YSZowDfj+uCew4qU6fSfk+Cz1gBQw0jDWdO+A02lDCQfeJQDLgMfBvKgEINeg97T0tAQlqYUZeRKtcEj34kudm30OyhDo6S2b+kghBD0HXQQtTiDG8ZmU2FlZxPIJxppLnA0pKS0PMQh1EnD3aOvQ1gEudQVNMNwUcdxA9kVydk9NaDgIwRYBJV3i0NBlBRGQpS9JiTDYBOS41TEgNQH40wl4/NvZPITLyggZv8kUaMv8C1ESjOJ9AmHXqO6g33BDjNnhKLTHiM0QC0g/TPnk3HTzJVs00FVUNNA004jyjN6k071BpaT9CezYrgM5XWEq3Qu5VSE3FOgxgXTTAMftOxz9ikzg7qkDAVuJFkjfTlCE/fZQjQdpZ7kmPNnQP80Etfqw140ekNsw8o0mVST1B/EtHPp5Rr2OzTz870EeVNMc7v5RAbSyUNT9qPuqUJjyjXyGUPEdFMkWUP0CEP2qUSQArlEUQBZRTNDGUVTTHOdIBNTM/b49JkDUOROw7zzJyBANSTkFTlEtcc1VIWjk/ZDvJREBBSz+uSnCT0TyCVJ8+0wN5M2s0lziSAEpGLgUdP/hs/ARbPvVGog/0OJwMKjUcNOAANjP2NLAy9z1UPMQzJjXNPmo1nTVrS/Q+JEIYNJUBrjtideFfXjm4a8xKnTmgdjVm10MMQFQ4qRFzBqQ0DTf2QWhAZTtiRzwKv0qaQFIzqIJ4fuNSPzfyV2VCCT2jMxs5R0clTvA+1kaPQvg1xzjSPtw4aEChNak5RzLnODt40zQ7PBFMp5Q7OXZ3ZJS7bFt7gz4KRSVCOZSzO2JPdRcuPlFRMDOzBR06ejU/ATU24z59OMs3RAI1W8lKIpTXXVl3bzXRTKeUTjl2EL5CeoHYRo9Ej02pUNROijW+lL2UyjW/lOw7v5RaR+o1M0FENO44KpT0lBNNv3DMlPg6xTu/gVIGNzINRUBKVBHtPfiU05SpM1hO4WJJjeQGlIqVgWRQjjKoATlBCzotPOZr9YFkOOVCpDsvUVEI3ETfWecyFV9eQWk+rT5gT3007goCNMk3jzksNMRK0ZCnNO2ICjLhTdM6BlUtOuc9E17bOv85ejIVAtJ6UDlVQN1gTDfwPAABaQvETrkxvQXtR6sCjjlHNRFMHRDjg2IF7TWjNzxwFpU0lS2VEpUaVfeVFQGcTDxHljHbShJI/EOxPjc3ok60MhAUhZVJdxAxvoFYPBM0h5M1lUJFaY0qUmkC4BC+EGxJiJUmTtiVVTTvO9xO3ZVZMT+VE5VcE8BnfUT5M1Q32FNoNaU1PT7RAX6VL5UpD2GVfTU1lX9YbZVblTo92mrylYZWcTVWlYmGqZWMlZNyO5WVlV6VF0/0lYE8FJUrlR6VYDhGNTNPqgFalWVI9Tx7lWiVSFRfckpK6DG/d/NPvELsNJkDrJVElXQ201o0P6450zT6lbVnn5W4TootIo0qXdRrBjMGAHdXfEtYP45A3TQ0D+OVTjSMOnMG2zeVPvSVLzXERdEyEEfhlZE6/07hO1lQygcMShJNqpUfdeqNYkqdFy4YEYQ6leCKyDXelRZnw0/0lew0wJXjlac4DHXqegBPxVQ3bIo8WV9UBOs5ZzG+lYRErl9eNcSTXTHrleRHlpX3OsWV+UPJEB409jSsOI877k/QavJUlT2QX1QyGZX/lZaVhTMaVnEOQ4k5PhwH2ZYDUMAyh5YQQqyVNZUuMFwHapXtCCeWATVSNvk1YFDFNxCWHzldOMRQwD6tleOKspWSMriWBJUyOIqWJZUtMgxC+DqSRkCV6ZXXliiV4TCffCuVX1ZxBe2WDjTvlj2V3UdOWvCWQjVbAa+WRZXyOWdF0WC/laIxwZXyPBSV9JZKM+KTVjWLCVuV+pYNlf0/0ZXulgFUlZY0lgWWSZXllmKWC5X7lk2WJJYSRPmWFJX8NKyWF5ZplZeWG5Yvlh6F35ZsliOWT5Ymld+WKVX3lnuWGpYulh2WMZaAldmWNoaQliY2G0VDMnNAXkJRPvFVr30ESKmQczX2PTk/rjlgMvQF7TJEOWI+GpPblnaWM0JuODuBUUDrOv9EjV/wX8A1gFJyPd90YjaicxBAcT3aZWx3EDt0lW1Jyj+OeoVLk40qR9QyQTdwVC88ZUIlb+VK6jUAA6yWqhNNlic15TnXSttCejlKQG5bqlD/OK46uDgLPpBD2EeVSp8zTFSCPos4CY0qO+8AWlGvlt5fVUtiggGS5EbqM1YQbDguTNZC2zKHRQQ2iZRWNqwCypbhlvCWvJbzlr+W6JbCNTQ1Iz7NQog+FE7YMkQ8FZakN7GWpl9elqhDQU7dlsxAdpReSsBhXj5hNzxh0EFTapKWtltvlUpC7jRPlrU07pcXlrmBhwECTyZARD3iMyk071pHhRUyAF9VlsuV3pcnls89kzlrgWRbqk79PP9BaDTQE8BnFTKZPcFLXzTsTw4IZpYCSVNNSZcKNTWXDDa2RPGXDzURTAwQ41BpOv9JyoFnZco94pa6Mb6W8Za9l06RuAZZNvs5npczT6pBFpUylyZly5bJlwpP0Jc9lneXA5c7OWWW0jTdN6s4ZpdZlzU+N0mgST9BU5bQly9AbmNoPfcy/lwyP2qW9YIBNVUzzj3BVEkBD17QNYY0GYVIfygyI5RWMmA8z5dVl1EDXDlaPq04UpdVL5ZAWW2ZMfc9pFYnP5JLZJUvN42WqZRKl2JPWnvsNOxP65dnQdQDXEFET6qXlXOnT/qXnkIdlqWXPpeZQ0FPjZcMWEiV+DXvN4BFNDt0TOeXhT6tNDmRuDHBiH84RkLbW29tLIJnMhlnrTiulh03qjlaXNBBU5e3l4xkKT1Pl1BPFpe+lreKoHjHOucvYA/WM5NeRkefOYU6S2qSSc6X0pcelW2Xi5eGlvqXxEpGWjQ6/EfBaH6WM5ethDo145ecX16X7DnYlwZJ+T2wNuFz+zufNnoCNnMQl96XwE7PeMeXvZf8OtmX/nlLA0U8yTa7OckIZjsQUNMCThNNPxyW0ZWiRzY7mpefl6s2L5ZBl/dLYpfbO8BcKT91VIKXeJbnMkGW8Jfil40MqZePN8Nm+DyzTB0xvpenBe2XqU/Wl++QB5eal0KWrJexlgo174XBNG9Et0T/NIBOWU5VTl5OXZg8mD9OXJg7mEJOU05PTk5OTU4DmEaYSZhIYfSYPZhAmENOVJhBmFGYUJhKmE2YUphVmD6YVJhMmFmYRZhbmE+YXU5XmEeYYZhLmGOYVphamGWYXE5bmFOYYE5amGKYbZhkmG+YZphsmE6YRJhqmFiYX5h2mF6YdZhumHSYa5h5mGiYeJh8mFeYeph+mIKYZ5hxmGmYhphzmIOYgJh7mHCYfZh3mI6Ycph/mIiYgZhkNRcH309XMglGKjNIVgmTeVcHVHF120q8NmR4XDkHAQdFpmRFMxxWH3bjBe1bHWQpT2880TIZNw1O4VODOtk7EjciQQs1yTtFXaBLT0VRe0lLlXQlAnVOPU5ITjmYxE5DTkJOIU4omMWYyE4yTjaYy2e4mMeY0JjJTjOY0ZjKmNWY1JjTmM6Y15jamNlO1ni0T4M8RzHzOQM0zXS8OvpT3ztCM1M9LhDmVhI/3lJOPeFAw18hO41fIUN9Uas6S2PCNZE63EFMOJyK5gb4QZgU/mRfijAz6TRYSNxN9WRNPPtDmF92mIeYkJiEVvVjHjksRYM+JH16Su4QKzZ0NLlMUUiMEtxI91aMM51E4kZYND9cEk5tSVNCwQd/NvFDwTgyNNRImj3nOQ5czDtaOINHlH/nO/s5InNFOgAzY0MzYY02FWgaNJk28jx2OtU4ijMxC8RPcVH+S5ZDvlBSSxw20zTyOm95ZDl7PrBNhjlaRGo8Tkn5NAc1LJPrSYg1D3BaOhk3XDVjT65c2jOeUj5AfFP8W9A4+mhmNi5MCUj0TmJLiTG/AGhObQb0Nzw65TJeN8c4Oj91NV+TpEigT7xGi0BcXhEAT0H2MlMG6zxDOnQ94GYzNwmY61GQf7JBFJGBM601LjI2NXZB5DUsO7dZSFIDOuc540daRPl+3zLEPnc6GDdgVQBpjDc1WDAzVwF5QRIx6TLEAnk/fDlnSac57EerPBJJp0zCOVRLC0W7B2k4GDiqWHA6tkk5T1BOpz7xUnFyJggnP6M8sD5TPvVBfDPfPVQ4yjMpOOY3rlIDX9REQ2EoRSZPHzkuQmw/NRAFPaQGr1RJBclLtz28k2ZJMUB8P1VApEkXVHE8P0USMqA2KD8VS9JIeglITOw0jTP5PjoL9zNwRMoybjlfQx1Id008O3QPI1fbOVs2PgF5OS1TwXCVPeF4iEtcTcY46zIIRmc/fEoMMpqPLQdMRRpgXToxBm1PrjsdPMRBOTZ/NgE7bIt6OAhPQ0T+eUpLnXRmPSA7e01nj8hUvE+CTOx8l0FaRR4/bllCAQk/LTV1NeVxejHeNJBFWjNAN7pUO08uPcg38nSvQ583CD2iW4gz8TQyFGI1+luiPao+CznoNcY73Gl3PIMyr2eDRz88mjYcQqIyL0rVSYhcElPMZcVPvDJgNI5hZ05tRrI8kziHRBRUqmgRVYBApWGlRSROak/DBgYTwEBWERRSPnnOTVEHDzKHDy9JnTJ0U5I1Cz2CQqI1VQHfNehCBgFbD+oBKUyvNUA0CEuJQQcz/jtSO5qJPj/4RSRGbnAWNvJ0YjPZPIMaPT77BIls03i0OJNRAEXVj9lOD1iGNrAzbj/QPbU63z2YWhM1SDwHNaQ0Ql7gQH5p0jNjETE1gVAKBYoFCkKtWqQBaW0uObsEnkmQA09f7EHkRDtA9jvXin9a+T/WRWAzmw07Nbc4iDp3OcZRT2jUQtNK3BBHSPU1dDZUMteK+DbAM/hN6TkpTFUWkAWdQNdPdU+8M1JLsjx1RiZFHgHKRDwyMzdFOnlDmDfnSvRBFE11OlEvg2x7Qvw7wzTNRWkys4phETkvxk11OagPL2mnd6FGW0WANb85qltZZdBq0TJAOnNIyEMsM2E1w0k9Mec2YhEoPkxF6DxHNXdNLkIEQpw73TQMXT08ggaWNb4y4YehPZxUjDqLOtRGZzQOOAc26EuJR+Q4CWCeMruYsWdpOI1BDkaPOAYF0Tc+N66P2Qu6P/VmZTTaNmg1mza2NZ098zkmQqQ5HTU4Qoc0CJp0XqY2f0WLTDw1YAZ+OvxLbUFGQkE1/hJPQLs5YzJLaadMBny5P6YDuwjrB1E1XUDRNcCZjgMPPpE8VUa1Nf4BQT2BNOsGpzivV9WQOlXaOf8HUkfHWEgEuQEHXHxWSDM6Bcg0nFDlD/w9gz81O91NPJccCGg1vkurMfA87BrpRnw6E3HUOGdeq1iFPYEzVDQyNO2ZZzPwOdhWaYHYOWxF9DgFkDVepjSUAd8z2oX6PPtEWF26OkQ+zEPgMl1CfzzlO9Q72IY6AHE5oztSOdc5skyDQ0ABfjS5QKRPPhGLV+0CyzSdMb1z3DW0Nz8yDDcZS20BYEiaQJg8TjjPQEg8FjufacAHUj9ONQ5ELTh/OJc/q2TnB4JnAZUlQ6E9wWvMNe9HwzI5NYA97j8WRAZWME7xcjQHglB0NY85h1GbZdZDHV/9Qws69HWjNnpaRAe/OZg+LDHBPFA6/VU1R6l3zFjuPY402ZjDmMxNzzHhB042RgJRPOszxDcVTKcLxEkaCZIBBUG4PU8y2TXuR948/WarRTcHgjjMhloLujrYMz1GiGhmR94Riw5FeJE18z+kNjNpdzoVQKte0waITEY8ozdpmQlrYD2hYa43bgKpAVmb7E5GTjeY0DuVN7dBaT02Bw9aIY+mM8M/t4Q6ZlFW3F4iORE5izLuPEEyUkNlIhiHt0KjSQ05bFlCPeE40kFVRaY02zG9cqQ87k6nNshHBj1XRxECSk9qRuQ3SzL+hBUzsUW+MshhXQESFhc0RDodR5U7dkuJNRQ2FjnROwg7/TsYO9s2EDISOJAIJzhVVuIBhTX7PEJIyVG9UDMRB0IDNiNFiUT/MthH5FVIO0JJQA5EN4N1bT2CQtsxvjINaJQ5skLCNAZT2TfzRlQ2lnplTIc0izIRR1E8+xAMN+k1+gB2MtcznZImB6lYkUG5OHNiXzVBajtNtTJCOOU3mQBQPbkyJDKxfdE1HTWrMzhHxUXUNypUxzVUPyRo4jOhOFQ5mlMXbZlKBDktAuA2C0zQS5YzsUsyM85Bxj3gSudPvEJBNJQ2QjfqQUtK5TxEV5M3BTYVUj48BUrAVMELuj1KP3VnmTltD7w0CmjiRyUysjvnNBY07jM4YFd+rEqrM9Q7lE80Oy8+pgEKTyyFmjVSPhlADDS4N9pKYALUAaI3BRDZOnduk0pJMew1izXAMx062FctYx470DbWUglU9zvPOFBM8A5DmLYHlDl+N2k6A0F/M8I93VWDTpNVVzYxSKAyEFF6NxQyyECkQHEPIzUzRB1FCkYuMjGZ+1xFfr06+WgcQeMCLzanOIY37EBlRatjHkeXVXE8hQI0kNE3EUH3QQpK0WaSP4FV4D+gPWA4WjVUTMFBxoHBeLRAvVxFNLI5IU1JMgFn8mx1WjQ1nWHXZ4M65wYVRtNIowSmSLVAwzkOP8k7wD2BQVOZvTG8OXMCTjeLSJ43FTxGAXNQxZO3V3xnQz6kPYM6SAfZV5M6Sn6mAsx1bT9mUByNVIodVkgC5VC8R3dQHEVZNAJJ9GLaPAlWzW2ZWvY2xAMFcRJ8pzMLN3BEtzf4Oq1ArD2VDCoCNT60NdBmnTVhUP81WkjXPBFWQHN5QiVBRjetOJ88dVENMrNTADvXXr1H6jynPGcPtj0YMtFD506qPVI1P05qAk1CtFuRQWM+ajWZluOBTQO7MldCXQJGOT8CJQEIPZRPKDTXQCkzXETLPykBxkehTNZWj0EkPHozjTpESmc0FUcKTFVmTD5KAUo603C+M8dDxUhBMjE0rztGV+g6uG87MiM69DLpTXUw6EKlM05SA1GTPuow21JPQPYEA0avmLaIhka3NdlIyUZbAE5mnAEKEBw9kzWPbWEDTj5iOdkHaUM4NWBNdVzqAQZHlQESP/lUTgZBPEk8ATXiL9U7uVX3RwpRwklTZGA2jx+pPPw+3zQBZts4MjLyUkkyzWAoRB1faAO5Rck3JgHqPy0FvjRRECY5qkxbODc/6zrBNqg1TTyRWWgiGFA3P384kVaoNZM3HwInSkttJ0LUaPQ65zwUNzg/QgBENRxY+QXDSK6Q0zIVPiRVRzufA1dBB0tfOY+LsT25D/yCwUbqOwhB2QaIDlRa+Ue9NfNV7zLSZuA61VDAMuBuYlFAAtMy2QU3VUhKLTyzOV5EgVxzN5g+YkUKQaA3hleTCYg9AzriRmdaNBVRRo43t0tfkYFBLVP0T8g5SjTriPwFvwc+T1k4cjO4P944SDbAc71bynIkOBcybzL8OANC8gwLkVgBHTWIOQVApzjyEdRe028qW7U5rDWdSQ0/2RT+RNw1qUYzPqY6sWyQB9lR/m7BA7tdsjXoO1da4m6iXatIej8EP1U6/06nOP1WMIx9OY8BfTxvEMo981GUOz83+YZEWBEHMjc9NI0/m5utN9I7WTZiTNQ1iHZwOHCSDAHBObJE7lMXOQc6XDLcMtc8eUsbD7wWyjKLdtVeVz/iROE0I2FfYLtHmAbJTHUHKUmnbSg++TWwV0wz/mgcOIM7A0CSX1syGTbCQ82a5W2eO8ByPDKaM7cGyUEXNQxLUEoSSQ1HLmvFR8FdFDY3WBFdsjvPNrCZHjMFOzoHTEIGAQWbjTmaN9cyaz2vaA0/kgN1cEY07wEpM7tBHQkQYGUzuj2CP1VQYzWWUDM/JhBHMiEz5G+OSfk1kjaQOS80yDz7NRMyRj+gMhRPbTnjQodLFD/xUT46NxeiNos9qmTEPD809UKli1RP9A9gOrFPvBVRVedE0EwLbuRRijNpPpNLOFpBNmU03TbCOehuNjJRAEY1I0NiAG1YPTUuRuRYETqwOsF6tju8QalLlTeKNoY04hBoVe8yA1KVPfyDZgcyNAUz2TTrNow8xEIqMJ05WzquUk9NdTfWRdE23AWcOppbohcKNjc/yUKcMclfxTHPMBFAqp9zM6E9ozYyO84G346bPAY+0RMLUGONwEyDdeFDrQRbMhc/Jk8uOWZCpGSrD7ZFXlVXR8UzCzJkPx9pPziOmqlT1TYgQSRO1jfjAjY82lj6CVsHakB+khFhJUuYAFhTIDSaN480rxC5YqpFNHOcNhN10HSvncpAuzSMRTg4zwEJT2FMOGXQV2o+rDKHMupF0VfVTJ88BzLnUZM3HzbLO2A8Lj6jOdEUYp+2ZCeKYRaQAXFMPDglWvYGN2mpN61SRjjDO1E+/zSymgMBMpmMPmox5jmUQfZMwUPNdl08IkeXO888e1VxNyc4O0MeO6w92k9tQmA6DDe0V2o6FTXHOHQP4iZgRr80NF2ymSZrC0D5NXAy7Vg4aalIkkMWZIlcKUFGOT9VPgEbRsFPqkbSBQs24WGlNbRE3WixOSdxIENDiMQ0yT09P5aRIkPNUYpFHp2xMuUTUj+SVfcyWDkud6BVtjXtdBg4zAcUUk84WjPaPeFj6zPDWnxBwoN/ECM0jlczOwcK35sjTmo40lgwNe6FrUq3AFUyHDSrUMU354lqgzA7CjzlM1pRkFwpVKpAIDYNM9lL2zKZB+VV9gc+m5syUz/WODA8v0HXiyk/dTTAREM5T1ksOPZm30WYbdM+328uCls0AW4tNeRAmDpuQOs04DelQEkRB24MMj81kQVDWIZLiDngOdg75xcudD4ymjRROnNJPYLrOlVQaY2KCYhlzEC9Qdc03zmSNVAzGpNhQcSZajoMWcsyrDM2QhsC4DiDOU6Q0T/3bC5ByHxMSc6YkZiFNV0/7ofpMvFJ9EVUWkdQt0j1ONI05QKpNAs7Ej1+MbU1vzljOrwI0j+OnZFCijaZQ7wzJknUOVVd1DbLQUozP0BUM+Az8DpUNPY5SgU3VnEG3DvdMcB5KgWUa0aJ92c8Nt2YzZvrmNKYzUDRSdU1wDj/Y5tLtzLUPX6K3jZaBOpAEw7AVLU2hkX1ddA5ozqSQKRREWEjC3k13Gp5S0SgTj4PON5V3DL6bdOS5DKsMec25kyQN9F0fjWLZVxQJziJfKNCbjIEh/CLFz6wOTND/Dk+NkJNLhCnOpk4hwc+ETFXIUQdQV0+EJubazcx9QTuhHdN5zI+ODg0hj2cR70NhkfOR96dCzfUNTYyA0dcTQ5Wkm5iRLlO4FeTM08zTIDoN9hLYwEoP/k9gkZeOTV5vhHqMuoy6mTVOEY7nUGiMcU2LWc/RNGZ4J+MOPI4RjUpTVA/fGBvAbddspLzNQ6cxEt/U2RWHzb6e9pR+wo6kPpLsA8jA34z3kA2NqsTCzIBQAxFkjVgQYZIb0jJO44+NTZhkklMdjgLAa45J00VOso0yEGoSkYBwEekY5tGKHXQNkQ1OGcBN647zksyM+E2WDuPM2QGBhNNNM1qnV/UO2UJWzZBOiJW7k01MvVSlWbrMyE0zi9gZcg9gkn0XbI4ipLfBohGOwlVbFtGKTXsRzwymlbgQ8FCwV6wLSJPOTjeSZpbe0CDOLw6R0AEAatl1lZxkNE1wDwbNNCDmhJPBEgzHmnANqJJZkZYPk0/Wz0tN+RjHDf9YcBp0jGrU+ZRwDbmiaRFJjaLNUE7WTQJg5o6el/yMy1DZXeKNAU52o9OSKc3AES+OkdPJDWRUDc3Py9ggsZMtzJxM7QGBkOoQhY231JJRBR16jJaNTxkRjdwOso0MlA1Q4hG5EKMNRsy1TqOOS1PLEJsOWFVIRcuN9Y1HDwddGI3PgEEQZdNXEudNsA/hWAyof5CS1YfNTRLO6FBOJ8/fBDDOxtIN0juPgw8mj5tcpIBDzV4Oj1T4zPZNsQCd10ransBCEWyXwJEBDo9NTMF3okCNn08Z0LCNc5SRD71YqFplDL8EmIRQzSKPxY5P3ZjWHc0TWuhPINKy0zCNakz7jXDEAVHdz36A6xPrjgHbGtLlDkrNImbnjWYMzJXbTsmOmFM8DbAO6Ez/GAXbeA5BTdFVic1GzrXPcpFNwdRgBE5jzXJMvEQR0vuAVxBPzOpSYw1Ojk6QKxA9QayimIRQjZUT0xk44gWVJ8G9AGvEg1VdUBWOU45OjZgccNDaoVrOSsK3z2YMxs3uy+aOuxMXlQWdIUFepDKNvo2FgLgOsEGmj6jMrg4ZjNoVdRPOUw+XtMBE0oMMeFIsYErBjc2ak8kWjluQUM6cdENhkoMRv01XkclBzI0CAHqRr9QQQbrQcM84jZgQKxRwEjIS/Q2EDP8QdNI5kTKPG1nAUKjOIoyB0IjA15FyVr2OSdYMEbjAV1EbjzbPZxW2TwiNltDPATrR71aDjQVQqKTVgGvRqBU2FAzM4wy5TxfNqtLUQ9ikqxIEpgaTbZKszoTUrdk01OSOgI87mqXojJIyZQrNw89bDU4VElCozeLTFVaUEglRxE1STv7PhRIrkKhQc9Bu1CARG8EfjPRhG2h/JjZoOCY1kAeCplauzeZP4EzzEzsMq05QEDKoIw02jzlMvo8kGFxM2CUezT/bFszQzXaUJ9m0oreNJpKTjtcNhNJjDxPSSd5SjTwT9mgTl+uEa85Mz86OTsBomarDJ9ExUeKeAZqqThDQFg1kgoCTkecIJjGmMl1zAt5YgpOQKEAXMFOJj6AmM+Y1qMXTkGg4U48o11OJVXcXMFV3JiNmIWYj5iMmJU5GVYwTBwd5TX6PG0cLwNPTcY0DGuKR1w3kDodTtY2FktZBkE0HkPYcNAx3zfaPuk2yzr9beZUMTxGMghzCkr0QakzIExhdUFDQwOsN64DV1cqliOUiAQDNi87qUclV880/kwzPY4CW0oMo2CY2KDfTZUzFoTTSEJSPjdLeLRY+kW7aYw3bAwLMz9JpyZglXRa4ji3kl87/jlSObqLLDz8PvNDfw+8AQdA6zUMN7g5CDSPNngzWDjSFVFBlz7TD+JBUUGdQzRWjzcdT+hfPUQKRxw4ITZCM/gy+FnoE5JNZz7SSLY1HVfJRUBV9kgSWCOdlTSZNBkz4wGdikw/vTcWWiB3ujKtlSI/6kWeUnI7A0oSEOU/50EHRS4PhkUabPQ5b1WDL586/WGSSXEzBjh4MxpPH0JMOs8zaDeiUEF0RQSVAk489TbDQQpAIENCYkVB5DdiNi9jaY9nPPs77mGNVLU7iAfhPHlAb07eNAU5jxcuRN97tDZ9Nok/gz3iRbMyNQ5FAYBDyxArQG82KDZtUowC4n2hocA1zjzkgcI02TjHX7FOkzfiPWVTZBJiNelsFj+edBU5qjvzQcOUhzlAQ5MP40zGOgg+EjJxWRY12VFHNAwBd0RPTLWEWDqBOFcBKQmIOtM5xzrnQbtE7GNlO902LWElYsAFejXYBz4+JTv9UkkBXF6rSVNLlpxFQeN+DDmKT+c6rUMWXRQy2DYuAVhWTzvQNX0yXVTYNs5B/3BaQLs2CDngWatoyku3Nyg8WXy5YXE1+13WRCpLJDPHXqs2fTIIgzAz/E6qOzk1XXXhPFMTCwGuB8NXokBYT94xwkVhNgk10gY/Wg5qxnNBNKsEm1AkRfh6tDlHTmI+YWf0WDo7Q0GEVdw6dzadStIz331dAaNADjm4Of9RvVwyNSWILwEHURkyblxzOSs3q4XQQoxee17blYc2GzUlMfsNhkJgZv5JcUFdW1k4OzHWMcRzToC+PG81bEVpUvYybjX7Ya45owyEOPZE5gJkAa4yTVjlSv+keTazO19IJ5G/NV4CLzvON2AIpYphegY4uUXrSuU++ZAXVFhoZj2vTHZgsUt9iC85VDN0YcxPzG80Mz47jjTjNcQ5JVaSQrQBWGjeP5JbEznoOghE4XNpP0KUiG8uOklPhUC7O3N1bU0BReUz3oBmQAEy9zY4Rv1RDDKKXyE1mzslPzE0P3BcRCEQTTNXO906kTY0M14BBj4ZQEg7oTw/M+YBWzbfAYV4+DtPCNxeq4o6mzN46QdnSQk0yjx2AR01tTmobPxNFXLaNfE37UOTNis3JjtgBq1AXALSnwk5ETQjO/0210tEPbVCcwdSAls3yUbGPoBaRBDUXBJ9BExeby47JlI+OrA/+zSrN/lMLJs8Rauj735dNz6LGTtlN6s6dDJuNsBZbDquR0wyFTUdTcVGblT1UVJ72jiKWRk9zTLPm+5BODcoOlefwz1YNt0zaDbBSbxhcUwMhqY59jgxNyJjZVulSK42SJsFMfKDMDpmOoOQdlG4Myc0FkYzQDg1hjxCQQky5j5ENdptgjOiP/gD9WPwFsoPP0vsV+g3NT8WOw4+fT1YT2RXyXlfOiE14JKiRVlk1UttNbkP5DhySAVVPlUhNz49CE0iVtk2wDM/Tb86ETdzMdc0LmejQIxO/VEMPIJQrzljXhIyGTkuiEpQyjbJS7JCoRbKNnQzcTIuN58zClAcEQc8eUHZCF4UYjwRMvcJB2g4Ok178lQkcn1AIAFdOeozo1eiZ407+DbKEe01XT86MjZF+DtZAcFNiTH/P/k2nUuUM/1oTUH2OHU4+T63YiU6LTmvPWUFknoKAWBK/0HjhNxddFg6QpNYajr0ONQz9jbCP59LdGObBj01TD09AWGlkkMNXtM9qDWbeRE6djmLAThiwEE5VtmmBzXxN4A8WVXaUy0y2TWOWzE3WkHEk6o4+jQjdBoEujYEOEgOVW5qRQlDjAO7NwxEyklSM+dDiDltSQ4/2kOdAp8QCDeuM86jTZwio1tOJzfHFhdOk4RZQsE5Vzh4aZ04gzPnBvhCvC+We3FafFDzOFU69F+VU2Q13EfqUGORT0BYBEhANjM+Fsx6MWaWNcM0hjobP31bDzaLQERMxo3kVhI1NT2oOhOD90u0UDk2WAEJKEJDNDgHSp05njb7mp1Xz5GBmJOYiphqmQ1MRzIPPLdatzV9Ntd3kGBqSs406jWjUREyakzwNjk7QgArV5NB0zrsU5w2CVxsPANaCzNTO5xWkjXKj9lcNkBnQmVMLEIWQMM4ijWuOjZOnT4ZMvKAkQ9jNWlkq1zQhZYGzEuJOnY1sVUYAz4+TZlqfA8EQVHIRzlJKAEEWIYxvWQnbdNNJXoKRy4MKgYHBxEP00mdOD5K3RAJYdA1dohNRIEzk1NjYY1LQVXvMilOpzUrNu1Rm2CxOSg5/we/N0s1VJZCQKFBqANOUpVUdD/7AQ9FT3JTVXE8RlZABO04Gz3tisJDiEWqMq0zNzLSOTNLYjkSUoczPWLqTAtwID38OddNSTl7OeBCjDpFTtafsjNPO5ZTITHcNKEzt4YfMrEGyTl3NT5+vUxHQ+5GhTKHQfkBrg8vBc8y408VXwQ7wAO8VMc9lDg+ggY2yVAGAXJCd4GDEAw0rAIkZb8Bc0GXhdVZ6D+pVIwz8ENBB8UP70/GQoE1B0h5guxbezVURzlC8FRGgrdYhjL4ARxQxTYHLSIzpFJOdzUxzjfxZts5Yz2LW7U//Ab0OHIx3zT4NY0+Q0eWUbc3DjKMaLE4ITTvT207RgS/NLw1jV43MfKW40BcO2p8+QdpP4IBM4WVVIFCpKcwPVM8cQO8NtE1eDXZOCFm0mNlPgRRt2ruOV1BYjhSWKV0YjXZS0Rs4zYhXZdBF2DcS1w62S/GYDI6IIJWhtg3wzi3BAOMUwGilqw1jVVxnvo1XjObN/gz2T3dOUJ5vjScMj5PWjyaQagQ5my3M+w+8YBTYY12XU6yZpxKqzSSVgs2QTS1Mw9HwTK7AQIz5DHJNa80AUKtT4NLYUTLOVc3ijuoWjQ4ylAkNUifUmaxNis/MRVRBJ4040C6ECg+YF8hMgkFz2hmRlRBZUCrNsZrozj9PxsGdwF9BO1X1WqmTmoVUTlycxA7jECSAVwEmzwbBzIyb0YrWEtKcD8tWD0BAzUiPvMDV081OBhZQg1zSFMz9k0BPHE8bDiPOD1XHITQMs9IqQoCOAg1RjJkBgc281KWP3V/CDdaPlI6LT8DaIU02zmOUik9SjxIXtMDVkQfOKo9l1GiNEICNZubOlE3CUynNX43mTbcYz1ANk8hBUEzVFiyOseITTZPZ6wzQTodBtsyjIqeeypiGDqmNKM/Kjc8VFRI1Dp/l450YjTlP7VHxQ8cOUFHaQN4beA5dGesMm4y9QFYNpBTkjJJNaY2JzPmVQBKSQO6XDg8Pz2Agf+HBA9gPINKNhhxRhBabkNiN7hK2zJsAXIx7EnKUxdV7xcuQptDHQ/8OY06ITJTN8dVJ4CRQRI0OgMPPBFGb3ImOWE0izhoYsg5hUrlqDdeyTk7PAA+jjgxARNmTDP4OWZCQTi/PTxhSBC+eMNx3kA2ORNBRGk9O7ligz4fM1dEuUCdOqw5/UsuoQU9HT/QZ4M2Ozc0OVJbLQZBP7UzQW3SNx9AfBAJMzY7uTg0POM5BUg+P9Yy2TW1P+ZMwTWTPDk4zzsbTB00jzUNFQw4qlKVd1aPpkWoOzdB/mc8Nhc6rQt5EQdDDEzQYsBFYFJrNTA8wwd/U8Mywzd+NCc9UpbnR0421jS1AiQ6zzhIkfo66wKZSENXajYCN0M6RD3kVHRHdEl/RQxWCTsvYjYCJTnaQzlkDTlyNYYGJkF/N484r2E7M/E6NDJOP3uMrjNgWrcQBjoSMBU4i4B1RN01kTZ4EFk+JTJxM6JScj5bPwNGfEwrPZmUiGTVScYQ9QG9DYZERD0kYQs7qlRuS7c0jjzmNS55EQa9W4k1EziQnGkHlDLaTmQ59jcAZE01bzbbSfkDxEgUNo0oeTVRAQU/fzjhUDNWC0SeRVVAVzoSSalHwUCdNKZk4wEINLI0kBHqXHMCJzwOUPNET1AzN71WwFz7VYCckAdpQSOXylOSVzNHbDe9QCJNGWKJNTqeF0x1O6VfWU84Nsk5fzKHi/pJlTfcP/hjzQWKTFVJV0i8C3A1b20nNrI8FkEkPCIQNTkHXI404DJkOrFBRoQ5c3lD7gYmOCpiNjiXfzw6ykS4QNYyAkREM/cGszvnRv08P2+3N6c0LksLoqs4KDr0PWBAOjNvTelFWQZZPoCc5EY1WnxvKkuYRlgycTQ2iOw2sjXkBJtUADw/BFsyO2CxUmtMt4kCQ9gaPYg9TJBYagJZP6Z4pDzuW1kz2UQ+fQ01hTo5aDg8BToTaqlhiVKmM5hOinqzPqY//ESNVKQ6sDfGDAujjTxQhUhUn0clmraegXI1BO04LjIxRtOdmjV7XRRTNjlnaFpyJj+COM8BTDptMd4VUTTdB4I4nTMqN040DEnGOVpD2G8dGBE7kS3ENhd5vnYsNoRhZ1X2Okk91ziGAauhKDJPNm4Ev0RWS7Ix+knaMo5jmxJPcLVXjGjiMcOcqT0dPzE8TgZZRi5MQT1TeeUyVzSKPNE2h0jUQqgPlHMFPjE18xOSdeFFJkjTPU5Bxo27O2I1cDNtCt9cbEouMvE3EUjTPQE0DDYWNx82g3cQUhk1m0F0PI5Pg3CEnfk0NHpsM3EBKTvANvsJiDNDO+4Gd0GrO9xgvzKvPmAxxTI1Twg+9Ta7OMc+nHf1SPQ61EH+R75PGTTbOQZBUj9xRAF0GKXoUrtQvDJBCoVnhjeliQeEV1DAYQuqhT+WXxBPlDNgOBk+yTc9Z9hUdDT/OI0xvkUkRYMBG4gVeLR6DzxGZowy/klKS30BYFAvARsHqTTLOh4IrTXUau4z+UlpV9iOuToMUDNAfmESNkQBVTHYhz9ShDzDQsFFvgXtNI1hXjmaPP076TkOPz9KuDQBX8UVKXEbV21AX1F2NmyiDULtaFo5ujaMYSQ/bTOyPyQ9g0BuX6E1Az18OOFVIXFWYQ47kjJVNXtSAwFLVx48ujYxP8U/gjMqQKU5QEpNMtJGXmFjPfhMNzWvPw0FvzQNNTw4rzHeR5hlbDTrMew1LBEoR3RD5zS6Md0CS22CNsuHNTKrQUQ0KDZDMjI6TTdbPfIEuUttS7I/rge/Mb5Iqj1AW6IEAzOtNXUP75FFQQcyXUG7Of0y8DM4B9kGfjs2NB8ysX0nEA83rTdbNlhizZAxNmtKgzzbVRgCS1vQCGgOVj4cMnFbtT1HPdRBFl9sPigy0EbbO5RJ+ANPPutLbUU3OspFODu/D442ojW/QrxeETinT5U3o0H+QLo8XkzNBchCxHMJDy9CBj7fRoUyjjvuOI2dhDauUP82iU/ZPls7Vl2VQuNB4jIRNcg6SQWENIc6qFsHP384mwEFYCIQwzkJMykx7TKtNa5ARjw5UVkGlkOoBtJDfTJkQ9Q4jT2ANudNDj6vSVM0J0juQO1DAgfhOAgBeDjHTz9BlU1QOWY84jv9BEhcMl+Vd29uahFzMfBR7TW9NFhHhaNOmNIyPDQ0N1oRc59UOnE650vGP4RYalSMQak28kQoSNxFgDSxm5s31DdxObAyNUUUQRybm36hAjM3u1xXQ+5P3T9XPiVGjj5qN5gBCZkCND+kkjyMATU1VGbbpmGjWqOgo19OIKOjNFMH2URuV+0Bc1ulQlE+3z74OOA7ljynQxNF/T+EL9hX1jSQMgBAbjI2S1JZCUUkO4+Md5nTNAVCwTHhPnNK2DriPEQ3DEp8Nj1Rr28dZ2k2HDqRDxwMqkcuQC2Ue0Y7OWs73EL4ODE26DVhNdl/8k7ejfJB6AXIPE5AXVEObdMzYVh3PslfoQXeP2Q+DEPwN64yFzWzBcdHwRHtO1YyQEKBmwE0Py3gO01GNTZsCK2hzTq4XlYI6zbiYD08mjVsRnxCXXHbSss04z59M8dEpAepN24ybYsUL7o2aAe/Btts4j8INMVX2zyzhP5ZxEUpNRs4LTNHR2EBszH3SOYL6jpzQ/w+dGnSTb840jq8NVECGzIyaFZd1DUdQsQBeEE5QVI+YkxGoe0Gi1JKQpxJlRgRU9U79TWNOgtWFGGJQLZh1YF4Oh9nFTKtPDoIaAF+X9g1fDVbNQ4+WjpfXGwBr1JHbdJKuGNPZdY2LzIEbSc9NjqtQyqDBjrYkjMF1QmINu09updXN5c6yg8vOIlGMadzUZNGTFdqluM8DmrfN2ljSzPmZhI8VaBWMmZANjk+Njamhkk9SYI+YjxvBUF9y2DtM+E+UUL4Nvo0tD80WJFLYTeBOddD/TNzBrJCIm6xdKgHzTW/P64zNjSyN6NmZVUNSi5hdqEUTEc7iAEFjCVH3jqaMm8ydDfmOOI6MQvEOo5cRTcgONVHaTn2N+UCykcuP7E91Y1zTFtPPzicomU79Td8NyhLZGLZB8U3kAEpMdUzdJ7pQZA0MUBuPtOo/UNDUDI99TbcMg42ljjoYLE3+UVeNSsyUpfXRsg2azpfN9xLlHjDOa0GJlsdNt8ykHmUh2NC7TkdMjsvm0ZTWrdT3ziNTZ9wFgETNVVkiTI7Ozo3DBH+nsh82lSqMvpDnUmuAQQ00UN5SAc4GUbBTVBAbwQ5PVxhcY86PKM0tlENOZRAOJMuY2VObUKIOw4CUT5RA0lWcV+rOP9I7jz2lBM8Z0TCb3lQJzZ0ObI4jkwQcRg61kVWO5I03T1TMw1KDJY6M7FVhVs6NdhE7TnLMeqHKE/INzyszRJiSJo98EMzNLqeOkT5Mecz/nLSbYw4RkHTO/4CjkeyOSs2qzzRB2c7qDuUNZVdQ0KBNsBAXzgIOeyO6aEWrHJwg1IFMtc7QmD5Ohk1jUaASRI0iTfiAShGSzo1M9s1IDgFPEY4GTbGaQWGDDazOT8/5E7aWKVabjkFRVg3yVRNNNthiT7/NDtw1AEPMw84HUc5F6JUqjSeRZKKfzP8N0s12aIeSpmB8wFLObJHpksySKgDSTl7Nqo3DzydOQucjTO0PD81DkKoSYCTBK0qNbY7/kVYObo5bTU9EQc4f0VjPYBADG4FSEA2bRUppAE0njIxRR4SDRDRNhk4hzbGoXKtpTa5QKtYRTczfaE1IEO3M7qsfzulN35IrmqSOltCekUaP/xD3UApghdB2X7VQ/xKwGKqV9ZGMYF9BO1EdjczECg0uTSZQhugajW5QP497UFTT3U31BVRZkxq7jlHYKpWZjrTSaQCPmSTMw04Uga9WyBB6To6OCU2O2K/PJA5i0/IOKE4JEblWwc8eWGlAV2nukHGNY8/iT3MO/w5fwSIARpYk5+yXjes3IDCobxNn0t/NrBLUUyQRMU2IjQEjFM1EjmNQCI2T0D1OBABfRVAbdJDyTYnNLRAUjgpEChNNToPPF8zCT14gaQz/wZ3UU9J1EATO/gzMEEPNNRDuTYMQflAdjSTEQdgpEmVNK9p0kJ3SMM1/jCTNSM++TazAXFDQTZbTEdLYwJRYBOiHzW9LeACG02LmImYj0skgstbWTzEDCpFiUlKRvgJ7Jjoqcc1cDNhNcmcl0mpUJ83Tj7PRkA7CDmoB0cEmqdROQk8dDaPPMhHzhCHOQhDsUw8TK8+7TcQXVw4kqNKSkZt8E3rN/JStjgMWPkyWKNenCGr15jco6GrqKZjq9mmYqvYrr6Y26MYrsajUK7BrsWuwK7ER407ZUP6N407JZX3NTVwvnVBOyGAuzcJOsoyawavQbtBSD6FS2JVdTSyQntIN3ynO8ExxDcUOJM40kIqM642sEBdEOVd/jkmSJo1fUE5S0RZ6EaOM8IzCjGyQMsya0EUq9JCpG3cq9auyKOfrs6ux6NcrsKuyqNPrwuuva7Lrs+vBK8JrwavDk4qA1xG/jHdR7I8fVZ9P8lKYEtigtsNhjjSNAg/LEyXAelJoFXag3SrvmGNM8c6eToyMfFSZjSmS1g2TjZoCew87E2fSNc3H3mSMeZQN2ElN+kFxHMQOH9QxjXJX1VHpEUaO3OF1QQDMjWVujTqW4g4bDU9Psk+/zIZNU5CFqvTZt88vK8FrsmvEq8MrsNHiUEmMr89fjlVMms+pDM2M3FZq0eUNDEBST9qRBRRRzr4BO0JW1RGOWAvxjzRNfA1NEKkBzN16jghAncPBjxuODJX7UlpQoF3HkTtDXOk9KeeQl1KRg8jODBAdzTnN46jOwY9N7gBNTXHB0k63kzQQFk+agSmAi+P2T7TSKM0GV9+PvFARDkfOyg64j2cNkI1QYqeOrNU9zq4M0435JH9T68x8QGibZ48izjeNoZYJBWiNxxEmUotPeAzxVXaS5VVg2PiSbw0AjOkNYtl8wJKQ0iAIRExU2MBo1ODMh02ZYhdEXmITkOpAplGbjT/OFABXERvAYA3l0TRdokBowbMW3s2XDkJQzxufEYfPk01XgGsQHFHbD+JOOyD00PCPvEzjUWeM5FSWHhxOzo7hjaQPd1R+zjhN1A6JD3KpU1CkznHNY9RETaiEg0/hTQVOF06mkaSNalZvFNkNaY7XzH5XtBjCFloNMVAcTUTT94/3jfMYmSIxDlsNkwBqDNcTNFIpwHfScpLLjZsPm0FHVDnOJNl3kOpORFCKkPKT65I7QLSNwxBm0JMV7w7bFq2ZOdAdj2vNtyj5jboNiJGv0sLWpt54Uy3Xx865FtZMhUCMDcUBwwEploSRq4G9Dm7Of5ByjPwVQ13imaMAhsz0zl0Q1itUXsTOhM18TUpFNY62TmyNg0zKDazQUQ3JjS1SuMyEkFTnRCkLTZEacBA7QEcOAg9eDodUvarPEuWNQ0F3jW3Q0NPZDQMSyRAIkicZmpCHI5DNMY2bTImBvg7ezmLB9FYhjvQfmpddDYAju9BM4ZEPicCKDWRWMVokDIVQ5oyUQNPO8w/djcQRgY4yAcIakQ/91AWOTNJ9EwKOdw8Djt7O8NUBD1gPT5kvktiTy47AQW+Qm1Wkn2LNA1cHD4leSRMQTaoFOepHTe9QtQ6hWVcNhpA+VboP04/kDWjNUA/QkSBlI4BG4hKeIhKmW1YVMFD2G+1VtwTVzWDBfOuqTeeYmQ9ooW/Pn06rmZMUoyQV6RhOMhw0jwiN+c1OIyFRW5AVlEOPRN3H0KRMJ1FWjjoc049i0OsVhE1KDaxqx9DWEVYee1DKlfPXjc+CjSiBJtJpzahMcREpDW1Q+0BfVTBMiRDyRNXSdU35GtGO0IGbUGAQ0gCyzm6rr+vV7ERr1ZOQUWePOZkHDoUO489LDjNOhhEnnvgOQYyMz3VeKY7R0SAPlF+0jHwRDds/DP+AbBeN5DvZdB0rwINQ51OgGTaOjpP+jqZTogzx19oMxlWqzpJiEpLODr8Mx2uuQFZEQevWa8Krw2xRJjaMuFOtmHtec49UksmWWhKmk3GYHJF7Ac1EAU7/xHtNOM7AGarS5Z/Tj2ZndtSjDTiirFHp1p8lpo1fjfaPfo/+z35OOE00U+uPjUE2mmUR1o3gDwBZBA67kjIO/tAWa3oOgM3D0lPhNRUyAe/ZcihoDZ+QVp0DDQLTrlvtXZdkjaYsTKoCKVJ4UKsRQQ4h1XoMwM2khF5QThafAcPg6NdYUpAN2czm2cKYwh3pXGlOjVVAEBnOIJAp0WzTcVJvERPNSM9gjhnZE4HTDx2gZxUx0sKQE87AXhyN6dBokuYIQoydpAXApw7hkRvNts0pECnNehhohAPPO44lzdpqJk2kDljNFM14kPUklM/qwfRfSoP/DVKMkZOpzTDZm8+UjH6M0BAjDHpTNCT6EpJOIEyc0GYOSxkUoR1ObA2kzx5Bb00iQW9fTE+Mz8VP4o6wUKbM805Y0Q7S3KrDgcyP8d6BlJmZrFMpz3BUICA1EH3R0w2+UUKNsc7Sj+9Sc4x3D8mPEoUNza5AqmFSDi3MlEBWWObX14GljWIPw8+f11ia5c3I0LmPJANcz7NM6OdZlK7RQo4FwG9Mek0mWJQii9IPEBcAS878zSiWCRNZwglVG5HjgFJNW4BS1XaaHRb1G7kMnFp9TbHMrwyi0gRPOxhC0JMRNE5cjHKqURdwTuIOU53ukh5QfZmqzYgTR09fEEcO/gNhksUMjkBxkC2Mh1VYlL/MAJl6AaaR5g1wVu1Nvc+FD/uNrs30a6NRSVMPFAzrIhj8HsuSFM5JjJbgsk6PVU+RNg5KTV0OSsTaU8/PvU4GUsLO8A1fpHGXtNLcjdpQLVYEUbTbpY18zeCPBNM1mTalE0RHEecOVU4x0RYAjVatwKpB4U5Ty+aNRJPxj1KOJN/cDOOOQY2g0LBOrw6hgULBJozuUQEAQdBWlBjPDOaOaJjRJg/bTOhAmQ4b4tePEMyj6NTU66xR7ESrxFOMZI9WhtQEkPwNrozr0GdTBcG3zksOGxLClWDMkVCKktiYqpBBmCxPqw+hVHPVpI3rjPHO1xGjlPMN2wLbDM/QF8D9UQGOBQ0ZVS8PAY0ZUDregqjZ5kKo2iYPTMANDI9BlIQXtNRQBUMc052LJ4BOgg35DbPqbw1Z0MqQFgFnQfDNNo1XDeOPSw7WFXcU/Q6pFagmtBBC19+k9hH4TupP55jHgKfRfI/tUOpNR1RuEaLS31BRDgOAatHXEXUQ/w4MgEaNf9WC0EkBgaLCUpOsk1qnRHqQHZHmBDDOiEzZVgRSp0+4zdmV6JdsjVQBJo19jc6PGFv6zjoNo0EnjSlXGxApAcpbZwNOzTqPH1S9jyzPEo1bzr/AVsRKDYhZSYBSamnT3U5JQeUM19d0jYQTIg5O0RDD2JDyVP1AX45vUEzbVdCOEvGVDtBFjU8XmozZ1AkAjAHaTKPT7w3CZuAOBg17jYWkRE+6gzcMBU7wUT/NeI16D3hUUc1sFJPYW6Zai3gSp83UDxHEMpCJTgyN9Y3r0MdX16yNAGFPIAzPBArECM3fDwGAnlVAFX3O2pAkjuqRO0yqEyXOkg6Mm0sM999rEpNPpA5KXtSMiE5+m3wNfxMLDp2a/U4wE6/D9Zl9G8uec5D4Dl8RAZFHkJtS5gzzZXZd4qF4TM4jio2x0iaMwOk8K4bZ/Y4x0BdORFXM0ynQGVMkDXvUyc8/TSMRJlD7jVYN2FAXW8GRkAy3EFWBn4PYk5iO00Q5hRiMtkElUKjR6YCVUItRewC0z+pMj8zsFGkiVxplFAGM2kzGjBcZjpVnDXONIewDmHMTbY0sDJze3QBhUkfOA5qwFWwqKg3ijM8QLtsi1P8SHc2AkBUPYFCcUBdMs9SjASrQ+A5u0TmJmA8RJfJaHNpjDoSOEY/5jbbPwM2GjX7NcQ7fTlzQglTnAayh7ovlz5NYhg0pUm8PhxDd0D2RW42V62iV2o78kiMBn43ujJzPa80jTXaj9lKLTNOQKRng0T/nRZBFEPnNCMBPDmvmmBK1o/7TyxHmEyEp8ljZU3TdqMDfpTvoFQxyEipOz81fBghNcA1Lj70qhk2bV5CMrA2ZkuYjKM8s1eiqTIPtkHEQ4I81kQEN/M8WWeDMdWvuDP8ENk4dT7YRDsy12dGYhFV9z70QzFHTkVgTb8/dWJEPqRAoEhoTISbL1FSQ49BgDVRVSAQCVvXNbgzbzSUCCdeNzuyUZA5EZf2T1BBIzVwkNEDXF8KAck/p0hTZchzDjIfMdc2pDHhPIszSlYSN+t6FDuMQAUGzEDANhwPjjPuh1pAcWRlVn4xqz7XP2RRDTfJOIpgv5R7aomzYDpJMcuaqT9dfD1TNAqZObA1nUn5RNE2oU8WMqyqdV5WRDxSjIo1AplcIDuUjd46/WHCMyQ1NTWBN8Y0GVT1EIdFkmRKOcc4bUjTRMo8kU01Py06V2DYNcpT2E8kSO5AkkMTS5VTNEwdWpsysT/miBJHSjpLMhlRvTq4M/Ayizn+lE4z3zrTNCdQsDH7OpEBqESNM1dZND24M/hIsTwWS7eRvzhIPHUz1AI0NJURB0OPes01rq1gRkxHwTTZSp+jAT41biRCcz7oYYk3rWKzSfQyCjicVXBYGg/jXVho1DfzNU1HYTq2Xp0vuhUMblmyl1FSN343LlbZOq2coU3CSudfLnKAFQw0Lzj1rIJKFzoMODJhO0vxNrlFzUNDPtENczU5QER1nz1dQRcx3DaYN0QBczIzODGPnETAOBlWuDgGV4U8FDLSsHA4pHpsUEEBoj6mNekzqzZqM98ysTgnTM0XCkM4Ek9ATUOYojoBKDYtfglqA1j5O2A7wTobsME6wTdzZD4Hv1aPTWqwujU8TzcyQD1dNxJEnWpPPvQzkzg6UcIBeD4yOLlLlDWLBBs6t0JjM1NFgDyOOlQIXlA3QB80njLQA0ox+DyTdgctGDvcAplSjDQOBEFDQjLvO2wxzzl7PNoycBCnOd0BsD7NPSw6mT1gRvhYMEM0Mj0+1zGzONE6czV7Mgo85DrHXeVBwzrFNyw5K18CPdQ8joMwPhBCbTV4WuJ9UEenOCxLClPMeLU3rQ5FS2QBQUtRSbkHR2uhSi03BmbgY4A84jxQkIcTVwyfjV9jEDWPS3JSTwN5QvxHMl+hQOszw0K6Yn5JpzlhZNUEuUIjaXc7yDpHTNYSYjuoVgldS4DbVL5R+03WP/xHPFH7TLdLC2xKD+QFnDqDNAw8eEw3OgxD7TZeOAhB2n+nN2pCoxAWNoZTYziDQbAyqDaiTRVLWDnsQLp0rzTUNhESDU3CSp9zTlYfQagz3TYCRRo4VGxhP2pTY0UMNK9CkDeAO6wzcTX/O8A4zEgUQKsPI4GkX4yuzLEQTj8HCFFHFGI0ojerOvo98zxBOtQ1+jXIPIZMEDIpZvc5x0daAEhggBF7NMY0wTULO2U24TNXUgMC0zihNPoCynxJifc2ADJNQM5jIqNKqjW2Xq8PrwiuzU4McJk+JzU8hLU6E2E7VDu0Yj25P+46hDCTAXcYcTUtM04z2miFN0lTLUZLO7kCeVgaNFFs9DMDNcRjm0G4NuY2m1CjOFk3ZpEXOk1BuTkHptYzyQavot9NPFwgNbE6tjaNVt81EgTrWBFyJj48MxY0mTPbTdM46zAuSIwyuTTgNy0TTTbQP8diHTWwNAxLf1GQOP88KzL0NfpToTb0gYE2QgaSR3FHpoOaSzhSSgPEa9I7egBkPAg57JAWPfg5L1YLE8A/rkYzp8w4gkVRO6mWwQTrUruiCQFhiRA2QzydNxFYSDsQSYg174yuPGZ0iDQeQRRNZ3Hnj9lE/zrWaNQ5VTPpVGlfoTPMWj021zynOGg5+j2UOgNBYzM0Pvg010FKEXhK02vMM0cP8DoYNmZcHDmoXBIDvFS7Zvg0MECxS8ZDfUWHRq4+rAaaT1lS00AjVXA6mTi8RlgzCjbtQFZnFW2HV9U2+TtCM/AQR3SvP21amD8EOHhR70SrOJ82NEaON7hLf2ZvMos5P1t0OPI64jVbPN0y9DXQM0swnVCNNNc8w0FRO+c04jg0M0pHdFgYSMg7WT/fi2Y3NGNPMmSn+1ZzWy42/0tpDClpwFbNMrsEmj7bAWlAUlSBBj8/DzakEnRHRWNbMsg6Nra+PBQ67jMPMk5nzgF5BzJIU0H8L5oBWzbPAbA2DUBaQVFL0kHiPcGUVjWTQsEBA1qmRpgzGz8jN+ZSIk/nRjNbpUYrQrw7ljUrZ84yRDr/M2VEjTVXjZhDPEyDmucyIzc5UkaHczYNNJxJen+MNugS7jfvEXtsWxArRgaer3jDO1Y9qDYJB0w5Cz56VS040TU9NpRP6D//MBVLkkK8V1g9KUVabwQ5EUGdPy0DSjDhR046EjbPMdc+J0CsNv82bXb0a6o4C1DlS6M4oQZ3NXtCaDwbSKA1Ej5bcMxW3GHQYE42kTtgbjMBeTkoVtxTrjHhhadGkjyLPfxkGjuPWTRrBjhIltU3ADirAelso0B3SKc1gERzAjAyVTI1TygBwDg1Nv80MqivNlU9qFAKAXMHAzw2MxxCIkcuMv5AukVROUdvLjMWSENS6DmUN2mzEwecT95LnUOSPO5bL50lVicMqjKQPfg8CEzUQJ5IejIRPmBTwzsdPiQzxV57FQxLiwdnOqdJ2gXeSU864kZIQFRSt0lTrRFXsAFcEAwEQTHmSHc4D2Y6V2YxvWWOUAo3qEBXOOG0nDdpTCxCq3Cih2ZOnwZtN6MBrwEzpOVamxAMPy01jlBBQwxLCwpboVliwUZUBZJnFQZ+TJA+z0IWMc40KAYGEDUQykuJMzJDokFdYRI7/zOtNox+HFTBQ8s0IFJVNSuuXDgZNkUIaLhND447zmQQBt9ROzbfN1xKg0HDW4hVnQkHVhRG5RDZMjVEwHsqNBU1SwJFOgY8hjXZOmdV6A8GO1ZTATcpOSc4MTZGY80y1gbMXhI7RT3UO6peVl0pOOc9ZUJMBm1E4QJFNnk2FxEUPeQHPhDKSxwYIUO7NQ5GNUB0EwtB1z/uYOg6OQXzMnIHf0JsTBA9AzzZAaNE/zyzmpJDsjNPPvU/D1+eNlwBLT/FOzc3r0b/Xy4ysTHnVrs2upH6N7s7JECxOuKGDAb4rVA3EDSJQyo9XFKZWPZUOWEzhL41dHARPNl510hxdeE/JGxMRkxJPUbTicW09Tv/OZp3tQyqOgJEykGYNY0G0jzCmQhBHUAdO59c0AdMsuKYi5kKlWgBJwazARIBt0vqQINzZDYQd7p6CjZ1M6IyPTMLM989njIGONgx2wJGM8U0QpHdBwgFklSMNSJZ+UIlR0ylf1/AO0qcGUVghOqy32mMMtymn7j2mJSZCzSCMhA0UT0GIQo1UzJxYa5COEQUN65Auza5j4Zdsj6sSHc0nTWWROY7iHE8WGqbm0mQMbVApzkWPmJFWnSFS7JUjD67TrlBmDG8NMo2wj4dT29aNIxoWwdLJzjDNLakaA+2NLA8jQI0OPhfq0bSOZk1NjxfR3QCL3fKcihLaEzsTIMzxT+1Ufc6/3MZYHI54A+8NfWTVDmFOnRCwj/iNig13jJeaJStiTYXDsBADDo+npM8jTQ7PFU18UBJM2Osdzf4Na8zzDktM+5HOovQPcqejjnorjM+xIr/NPC3J0zweRGL2EAMODs3HV3BYcwP9VhqO6gQ0UUeMqyOqmoDsheLBwc1NNE4BkRDW7lSSjyMASkyb6HOT0ODDTsJMc82OQb8O78zOknUPh08tT8jOIY5ijciqldSSneCNupMwV73M2U+6k/YPII7QkGwM6k0BDcdNuJtwA/vQCZBDzuMARBSnzlfq+QCeVCjPxY97RAcYXU0hzfwqJQ1KRbMN6o0BTz5Tno7bDiPOvk9kztWQVFUBE7ebhxAVEGiXoY8DQNXhfgyhzPfOL824Th4jqe2JwIltcVWqHFiP2Jd+ETvPBJDFpI2XGxYbTunuGo03WDNNsMymoz1PiUBvV//Pt9ANk5tXbBVAH7NASJfwDo5QFk60z4apTcaPTbySm5MFzS6Mh1tbT5qZaQ63zZKO/6BUU0uUEE+uzOtWHw7QDehEShj8EHkQ48CB2msOXoBOT8leZKyOYjBMycSYjpmSrdB5EaIQiNCPURYC+o7ODtHOOtHLqxdMedAZWEOhO082zSJQ59LCgdSMm5GK0RxSNc7pBDDAaK2JgfEM+JAsxNNMfo82mD3QE0HM0QhCVuHQ1YwQJBArEjtPG0TTTXtNaZFslGvQ2o2MwMFQwdARJR2A3Ol7zwYUbxgogbrkMpdXDz7RzZHJUAMNDoQwwXtM2OI1EFoB2o4A67hSzg5rUn5X8CVbj6vT8wz04AYV6JLMjgOM8g52jIzOAhLuzbEB7o4zEtSQ58yiqXPR8EE2TevAcACTTywNbidej71Opo+pkfhMt06A5oCSdVIdzBTOeRYbwY/N4uQ0T7vM9k6mTXKOeAwnTz8b71M0XhPAQcMhEJtLcQ3uI+AOss13DjAMppAX598UQc7lD81PPpPTDjbAQJy/U1iT8azNzHIaJCfzgdHaMk8EDQxuVcy8VCNNEI+zzLWQGWd3z75iC82EZyQR74GBoZXCXE3PzfrOIk/sVMnBBsFlD+JPClBWkuxM2k4f2nANwtQ/wEmNaV5kjNtNSVczLWqOsWdSa0LSk0JEG8GAjBABD5TESRGFUs6QCk5jTQoQLs1MAS5RmdRDDk7PN8EnTnjBYQL9zUQQ5dFVjfkOREGdTXPPIxNPJK3O7c3PD8DM9WhULTWNJg1eXQ8OsoysDW5Orw51F75TIg/dUFMM1QYITtsN/I3TjfSP94/FXkRRI1rBmTntZs/gkinAo5jCEJuaHRPPlKZbvkyRkZTNfE08nqFMu1EmK1rOrWPgVH7PvE+TT8jQIky8ldrZTM9R6wKOuUyOXtdl9w9iVP1P4k8TjvHgtxUy0X9T2I+pjevPU83sFK3TJc1uzP9QQY0OmxgXtAHZ0FLQ5Y/KjX1QVpJDUcGNx024JErNhc1KTTuNfxyJjTEOFIyXmebOFcz8UPJQx2nczMcNc985wUnYV9FT0kqN+xDojMFB3UzjDdqWrd8BzynMnOHxjM4Ock3YLuJOKsz90CsAqk91i+aOsdEakzBOCsJ7DMPOvRa9kqrURm3V0c8MwYyiT5EfnoQ2QWTNWc12EPRAUsQbDMAPOYEpoGRWWhsTEL+NZKv61ZIacAvxj09d4o6ELPNNOU+8UVRYtqqLXcxmZwyzVo0Qww7wTSvuCReplsdPjM0x5GjRMKYGm3wOkMF+wYVNcRNOTbINsRzqTFLR748gzHGbac3jYhuNvFCI0BCUAZxIARIWXI8fQdqMz5SjDQfNspB6Q5FP206u1thNQ0yyD6vNToyTz3uO7U2VGHMNlx6hTNTNexB5DlnQSRS/T35O8k0jzr6kXc7/4FDRbNgsUjJhFcPBjMDARuU3j1+OqZHNlZxQn84PkDDU8xIo2mnBJ5Y5S+bOiE0yFpDUresoEr/MxNUvj/KPw9BU0SYawtRiqiebYKbSzX9Szg/1D/FDlU+vTqBOfSUlzuiWrthJTsBS2g50ZSIOf88Z0N5fSc3fljFtk1DGU+DMxhHn2tRONKD3A/8TZ88M2eDNb0BLXToNcY1WzrnVLxb9TrWAVtW4lv7M145oDtZkPoBLpcIQxBO2jwdoMBCUTo+Mtk7SzdpM1eWYW7ysuS8mLLjMfo0PTp2BexFVlqbNZ0GPzg4YWwNhjjbtxNY5WANOAg6dEYoT+gy1zNNNvA4roQ5P9A7v6bFXChOn0QBuJ4BPDukQHymmwLlIhhYbaCsvMGYhJiRBwgFejbPA0k19j8xMwNJaT4QUxCaAD98Wg8GfjfDFhcS7jdxRjE5BEdcMc5DEzZXAi9DuzYiQjg9HFJGA3VNkjLvQR82xT6vPyo3LjeoA6wEQUM4POxTqThaVvVt0jwnNdpPyDaoPy40Qj4oMspK0TglSfY0U7i7TWRSt3ogSWlgpEJYTuANcwUWU4M5QjfkNAI3g1U1Bc9NdjI9RMuspTIlN42dL0/okVJGQE3XQ2Uyjz53GHFPgzhiEAh+gDPNlNIPYTeeENk0iQjeMd1Kn2SJoO2i4WIFNDSM+EUKRG45ejTZR0o1sDjoUXKJyw9glQ45GnYwrZ8BsjexPMJzpxBHNdw50TW6UoE3IlJPQG9TqTn/Pwg1u0HkPEk/lVXtAYWR+lv7iQJjaDauVYE1JWRWMs09i3DzWWh45Tqfrl5NxQbMO1xGi7z2PhlcsrmmRGoCnzcJTvA7QK6aBvQ1a0Y4RV5ScjnbA3M0Pb03uk1FQDIVVXE8UFUzAo4zKQJKNJmBopToOvhCwjHtO5ZbLVl0V+hTLTSGieQCWXwLNV865ELwMypcskSeR/Ey1W10Vm0RBz2TBrM2BKLCs32hgzu1M7M5aktPVIKUzEAEWo26NEcKO7JJmrEqENQyQLz/b34xyUBcP/VG5Zvjd58+o1IDRlhIbASdNDs0UQFKQPxFXkK3Nvs5CzP9EXM8IDbhOOhO4DJKS50UnVOpsrWxE7K3TZA4ZE1nPs6ScjW7NmBM5zSkNRM5rA/TAYBShz80VC9DNE6Fd69CUEJ6E8B3EDryNX83KTWAOWZgIkkoPY4BLmHxtmS2Oa8Qtma91L36vdW9/b38vf+2Or3+vgG+AL35vgO+Br4Fvgi2Zb4Hvgq+Cb34vgy+D74OvhG9974Trwe+Er4VvhSvE74ZvdO+Ar4Nvhi+G74EvhC+HrFGviOvWr4aviSxRb4lvh++C74Wvia+Kb4nr1i+L7K2viC+LL4qvh2+F743vi2+KL46vjC+Lr49vju+Mr4rviK+Pr48vj+9+75Bvji+Nb4hvki+Mb5Gvja+Ob5EvlC+QL5Ovkm+NL5Mvhy+Sr5PvlK+WL5UvkK+Ra8RTalCKgGWBwYPjxj5LJsDQQYTLD8okjGtCAQFCy9hFvYBKyvVA4snkRbCvmu2AwYEKsciNzF9GwUNkg5hC38xgyzuMYUBdF/FNhAx7iytKsQghSWULLgq4Sv3K0cSZTecE9K+jzFXMTgomyvIK7O+iDFDKuAbSTFOKp4SWi2/CX8AMQ5kCAm+oCwCJysTmwXGKCQJaQy3vn0gcCsdAcArQgSNKM8rlr6nH1crrCjqLBIqxiyeKp8Y5ggJADK+oQl/vr2+pBcmvqa+wCqyDl6+qhaovqwj3r6uJ7YfPgZ7vsQslB9YvrYp2L64FnortzF8DLMMuzFuDmS+2TXNJ3K+gCvGMTksSiXmvpcqfCimJqwgMCD6MXoxTymuBRAL177bMBkL2CziBjy+8AhLA70FlATBFe8siA2KvscU6wSMvvAwKEFEKr4XVQMEF3kqqxFsiMoLyiuqIp8xyzobDYAxNysivre+mCgyE5pBSwNfvrm+eQyzMBsDkwFVMS4JdL8aA0i/HL7eLEgxWRosKE0xPDGKMV6/H0JRAUEDbQAzMZG+ar8oMWu/HxIZBDkPZTF2MUse3TFNvuoqnjMtEaUFEL8fMBYOZC+lC/oW9hlOKxEnzxSPN2AALjY6UwAK30XoPk004ztFCoYYAr9Kv0w7RTuGa/UB6T5LCoUDMTGcAnkxngAiAyEANAAuVpJIowIHO0UKhUa/BgYDTgEYDHYANr9LZqtNFU23N2BTAJwAC/ID0ETQAeExqQhoMasBUw2MDLu/H781GdICdg/jASQAPFGvAGcAIKx7DAswiQGnBFsAcA/yMT9INwAuNzMALry6A1cBYUQ7v4gCcC+wgqG/jQckByS/VUXrv1e/T79av1IFxgAxv3C/Tb9Yv1C/WwA0Al4APgA8AiUEpjixAkwQpL+NACO/mb+ZAnACJQLsAHO/jQA1AC5ZBTG1Astykm7kQJgGiwLVv6G/qb9Wv06/Wb9RDXMALL/Bv8MJW2oDOCoP1kXoOfoAIAA4AC4/pjV1AWFUgjDvAsy/bL/cO0ZF6L9mUTsvl0rdagMAIAAzA01K3VkFN2AGB0cyYTsFxwAsADIALjY5agMFx2wKAstDQTgqADYCXgAvv7G/szLXGkkRwr+4v7oBYb+8SfEGVL+Nv28DTz4xZqs2Or/xQkxdXL/Sv8I7Yr/Vv8a/2L/Jv9u/3VMAArq/4V72ZqsANQAsv+UK3kMMTRW/6UcyBgYANQAgv9PAGr/Fv9e/yDn6ACy/or+rv6W/0AAyv+2/72OWv/I+S3KSN2ACzb/cv97AIrFaAsvAJcACv7GUWABnAD4Q2wEKEtwMYRCOEcIc/hHFGPEXeQLYKDS+cQEAK3cZ9jFHJqkYf0zNI+UxKwyzBtAcQzFhDmTAZxrawGm+kiiavoM7SDKvIrosmiu0vuUxRRbrKBO+nBN6DyEHai4eDZJrBjBVMHcEugd6wH0ofL7ySPQa2QJtEnYBEQacAnELZTUaBnsEv0Q0AlwKWwLiLRtDfQXTDTYCXBDlEPQFQQSwATkCegEaBd4HgQXhBSo8ay+mA7wPThToCHkCjg33Lo8GwggTG4cPrgIsM7gwjQd8A74GtwK3BNHAkhBHAlwuTQJ3B1UCnAIiD+oGkhlOCXYGjwJHEmoFz8CQMFAGxwXTBrQFML+JEL8AIBAJBKeDfQadLt4kwb8KFUpQLw5VDlcOTzS6IogxCALcBiYGuwIPDMoHsCQQAtAPGy9wLSO+xb77vnUCAw4FKx0X+SsgKccuJQ5OLgoKPgAtDTsFNTBdEQvA6ArOwOrA7hE/ADo2OSzkvqnA8Q7GKx0sqSyNHiUNgRZ8NRsjQMEBGSXBBg1sFn3A7TG1wQgMtb78DLnA8g2QvwLA9QIRwPcbgyz0vtK+hyycHrQs9MBcLGcr4zGSDmo7IRJ3CekWIL65BJ0QJr8OMX0VFcB/CzkMCAI2Ly8Keg7oE2wu9S5mLq8laSwrC9gutCpXLvwnZS85K0UDMRaRMN4EeS47HaUv3xHHCR8PG1L1FqIrVibYKYoghyMVFn0PHQEHEX4POA8lD6ENZsEsKKkbwzEyImIq5wMZG0cL0sExE1HAYQEBC+wWFit8Eg7BdRb7F6Els8F5wXIoXR58K+oOBC9hDn4F1RrZBZS/wg3qDmQxHRTsBqRCuAwqEFcxFzFCLoQxHBNuCVPBjVRiASsxIgENMUIxJjESMSkqYCNvMVAFEDEwDZLBpBzJMTIDBTtvARMxNr8jK8cxOi7CvycxkzFeMUAxQsB2JZ09pAIRMUkxd785A4W+mymtKsgVFr59DmTBwsBuKnMAIsBwvoXAc8EoLBO+iioTLNe+jRCcvpEY48HSvn/Brb7hvoa+lsEpIk++5it4MZkejix0Bau+nhOrvqMWiL6iKTosA76mweS++sEJvzEGHRFcJUK+y78GIou+s8DbKr3BXCc+J9G+ub6dLqC+v76+E6u+xL7yvsO+qMEcwPHB7yjmwfEsgSTDvrK+zyB5HMjBJyFFwSq+1SZ8CUq+7b7/vtoNkr7cL4fB1SnmLKzBysHZwczB3CeeJ4jBvisGwHsC3L7uwhi+8MHnJyu/CMDIEU8ByQ/evvkpPSBtwR0GHQzJv0HBDMBYGNfB8ggOwiq+tL8MMhoJSsIPLPAnPyzyvxRE7AHcwhPBwQa+vxsBQcHDwky/IMJOwcUrWCq3MVu/MMGyvzLCUL8rA0e/giYAMWnB7QgEvzMRPcJdwbq/OBxJvzrAecG/vz3CSwZBA0fCOBaIv0MHXb9FJjnCD8A4v6S/z7+uHNHCdr/Ov62/Ur9dWby/XwNkMZ8BDL9jv2W/cr9ov3W/a8AmMaIG5L9wv2a/c79pv3Ytub95MagE2r98MawMxr+AwlDCXRwvNXATur+HRNC/ijh1v4wCXg/uv5AP80g3MBO/lb+XMO+/mkTQv5wJkmO0AHi/nwAgv8u/qsJ3wn0Khb+owrfCfL+mCoW/sL+yAQPABr+2AQTACcAKwAy/vr/AwBm/xL/Wv8e/2b/Kwru/zb+swr4B68AxwszAHMA1ADbAH8BGv+DASL/jwCbAKL/nwCtdXMAtv+y/7gNOwD8K38BBv/UCzb/4v/pAmFE7agO//r/GwAEAIsADwsG/tMAHv7cwisAKADDCyMAOAl7AEEWrNjoEOV9QA/UEOQLVwtbAG8A0ws/C28Ahwt2/4sAlwCcB6MApv+jC5L/rwC/DCsAzws6/ycA3v8y/o8K9wDvAPcLov/HC6r/0wEPDE8LcQHzC3sBKwvbATL+IwE8Z0sBRAlsBrcBUEKTAVhPhwjoRyMBawSssusBdKZ4d8cBgKaAkpxVMwGO+eBjiwHwvrRrpwG0WiMBrw0vCFyw9wdbBx0rCwckjiL5mvonCISeKvowkKcBmwIUiKhBRwIAQZQXFMHjAhMNKDZzAh8DEwIoGvcCMCv3AygFVBprAkQcpwL0J0wbRwJckWsCaBNIFhAv4AjkPVxBHL6HAowMFwKUDwcCnSSelTgS4DdrArQdkL1DAsAZDwLIBHcC0BMhbMwTAwLkFxAI5wLwNN8C/w3wBrcDDwIkwwcDHCEvDbsDMDZkDxMDPCGjA0QTNAVrA1EH8Lf8vmsDYHKzB9QfBDlSJqMDgASYPrwyzwOUFxL8AEDrBAhIcwOvBGAH/wO7B68IEwmADxcELLOsgfsD2I9Mqt8D6Bm7A/AJRjjoGiRNKwRQagBdOwOwN78EXw8IF8A5fwlgGHcPGLKjDOgMHwPfBD8JJDLPBEsPSwm/BFcEHw78GBcEawO/B7MPcDY7A88PHHkvDySooFaweuMH3GFvDV78Swz0abyviEkTCNQgEKEDBMxNzwTU9LgI2wTi/GcE6FojDYQagD7kwt8FWEmQNYS1WGP/BQy6uLCkvMjF0wUkt1MFLKIIe3y65LwASTQf6wVEvSC8PCTkf3i70AzEIa8FaIBslSL8RKOwoNA+bwWIOUsFkDzsLMcFoKogZFcFrI57BbRnvE7rBcMF2w0O/fi9+xEEsv8F0xETBeimlxEcM3MF2wX8xCsGCMQ0L7gXVDL3BiDERB8HBlRLMMBVBRAXTwZHBiS3oL0cB4cGLD9rEWsO7wZoAIsGcBZrEVy4OMSoruDEsL2C/HQSQwaYeScGoMTTBqxIvw1IdzcGvL0ASJMQBfqwTTDFBxF6+mMHNESPDQjF1MUoxTMG9vzvBv78YBRAxVRt/EFHEjr8iwhwxhr8lLwbCYb51MWwCuDXNMWMxZQRqvy8MxMR9xJkxYTGXxJ0Dhb82xIce3TF5wmkpLcSMB+4u678eGL/CGzFYwlUxiMJXwTAxjDGWMY8GfsSfxHzEmMS4QUTEpMS7wiQxm8KABKLCgwolwowD9AMxwYYQjr97NVzCmMPwA0fDcABpMbExswHqMbYxgb5wEEMxugENMbwxvjHAMcIxxDHGbEUzebzaS1ExwTt0D/RHvTHWMdgx2jHcMd4x4DHiMeQz2jH+Meox7DHuOyQx8THzMecx9jH4Mfox/DWOMegyADICMgQyBjIIMgqNYDIOMhAyEj0kMhU5ezIYMhoyHDIeMiAyIjJlMicyKTIrMwQyLjIwMjIyNDI2MjgyOjI8Mj4yQDJCMkRGoVhqMkoyTDJOMlAyUjJUMlYyWDSxMu8yXDJeMmDFD3TTMmMyZTJnMmkyazJtMm8z0TKAMoTFQDKFxUEygsVDxUbFQpRlMp0yiTKLMo0yjzKRMpM9QTKWMpgzcju0Mp4yosVXM3wypTOVM4AyrTKvMrEyszNyMrYylDK6Mrwxyz05M48ywjLEFaIykDORMskEGzNJSO4yzjLQWngy1GcpMtky2zLdeD0y4DLiMuQy5jLoMuoy7DLuMvAy8k3GMvVIqTL4NWcy+zL9Mv8zATxzMwQzBjU8MwkzC0iQQZaO5TMTMxUzFzMZMxszHTMfMyFBSDMkOXgzJzMpMyszLU1cQ+0zMTMzMzUzNzM5MzszPTM/M0FTcDNFMiEzSDNKM0wzTjNQAsszUzNVvJVBRjNbM10zXzNhM2MzZTNnM2lRDTQrM28zcTKbM3QxwTN2xVczeDHMxVkypzN/MqvFXTODxWAytTOHxWMyqDOLM43FaDORNtozlDKoM5YH3zOZV3wznDOeDkU7SDOiM6Q33kipSsszqTYNM6wzrjOwM7IztFT1MuUzuDO6M7zFgzO/AQIzwTPDMkczxjPIM8o5BTPNM88+dDPSM9Qz1kdKMkUz2jPcM94z4DPiWVB9+DM4M+oz7DPuM1oz8a6JM/Q7mTP3M/kz+zP9M/8FhDQCMzakIDQIcM80DTQPWGpwOjQTcSc70AI1NBo8fTG9m+40IDL+NCM0JTQBNCjFxTNrTPA0LDNxNC8ykDQyMo80NTQ3NyA5er3Bo2U0RTRTNEjGSbzDxk7GTcZQo2mjZrkhxlSui8ZVmJbGV5iSTl5L0zSJNIs0jTSPNJE0kzSVNJc0mYNoNJ4BBTvONKI0pDSmEAUHxK0aNKs0rVQHNLE0s12OM9+bozSsjk81qU6gNMJM8zTHT7k0zDTOQEg00TcKPP001Ut/NNg02jTcNN404DTiNOQ05jToNOo07DTuNPAB6TTzZF809kgJNPk0+zMyPqQ0/zUBZ0M1BERDP4E1CDiuM901DDUONRA1EjUUNRY1GAEJBppYdThiW6U1ITUjNXQ1JjRPNSg1KqsCNS81MTUzNTU1N0+Tt3I1PjVANUI+JXlpNUc9ODVMNU5AfHk3N1FTkTVahhs1XzVhNYs1ZHUYNWduDWADNWw/9TVvNXEHSUmCNXVWojV6NXx3mjWANYI1hDWGPUU1iTWLNY01jzZChvc1lTWXeUM1m2UVPIVB0jSlVKpl8zWlNadMgzWqNaw1rntHAkU1tDW2Nbg1ujW8XQ41wT6jNcR2UKtwNctMkDXONdCkpTXUMzkLxEFdNdk12zXdNd814TXjNeU4mjXoNeo2FTXtNe818TkRNfQ19mGHMyM2qzX7eMU2ALYlNgU2BzYJNgs2DVP8NkQ4ljYTSG82FjYYNho2HDYeNiA2ImbUNiY2KHMjNis2LTYvScY2MjY0Mjc2NzY5NjtbLzY+OVE2QqGGNkc2STZLNk1m7TZRkeA2VDZWNlg0BjU8Nlw0BTZfO0RFoDZmPvk2aVonNm4ymjZxOk2ivDZ2h1o2eTZ7ODg2fjaAjSs2gzaFNoc4qjaKNow2jjaQNpI2lDaWMiM2mXpMNpw2nkh5NNs2op+XNY4zTDaoNqplyjaupZ82sja0NmY2tzbtNro2vDa+NsA2wjbENsY2yDbKNsw2kDbPNTA20jbUMjpjxzbZqVM23jbgfao2yKU6Nuga6TbrjpBHbAQ5NvFJFQMPkcJuijb6Nvw2/jcAQQ43AzPkNwY0TK7bNwxPfzcQNxI3FDcWXsQ3GUlpYMQ3HzchNyM3JTcnb803LDcuOmI7dlR8ZVg3Njc4Nzo3PDc+N0A3QjdEN0Y3SDdKN0w94DdPN1F4w7McN1ZPlQcRM7A3WzddxqE3YDdiNm4yyFboN2c5sjdqOPY3bTdvTiE3dgImScY3tzjGPhQ3fTd/N4Fa6DeFN4c3iTeLMw83jmFwN5I28z8VN5aeZTebAyBC5TegN6I3pDemPbY3q0JRstA3sQavqSMzXzSlnnI0JKKVS6I3v5nQMh1uWTfEN8Y3yDfKN/w3zTfPrkM30zfVN9c32TfbN9033waaRKt9MTfmN+g36jfsN+438DlVN/NblDf2pgk3+gaINoM6VQLiOP9JTzgCOAQ4BoJzNAQ4DDpKOA84EVUKN9o6t0OKOBkx9zgcOB47JDNDOCI4JDgmOCg4KlcoOC04L6ioMfk4NYJUODk4O2KQOD4MnzYbOEJAyThFOEc4ST/kQ/x5vk3CVPe707TtOFM4VTQ/OFg4WgHAOFw4XjgqOAY0UThjOGU4ZzhpAYQ4bDriOG84cThzOHVAdDv4OHmLP1P0NX84fz9tOII4hLzsOIg4ijiMOI44kDiSOJQ//DYSOFk3LDibOJ04n0gFOKI4dDilRb44qDiqOKw2uTivBZM4sgZ+xxA4tji4OLo1wzi9OL84wTjDOMWrlkCJOMs4zVq7ONCgSTjUONY6VDjZWkwQpzrsON9XClZxOOU45zjpOjU47DYRTIM2qTMJTYk48wZBOPZ5aTj5OPs4/UgROQAEnjhsYbI5B4egOQtU+TkOObs2AUoZORQ1PFmdxlE5GjlagE45HzgPOrM5IwEEiSo5KVCNOSw5LjkwUxM5Mzk1OTc5OVJ9OT05PzlBOUNAVEJsYY05SJ54OUy6hTlQVBY5VDlWOVgyDzlbuU45XzlhOWNQjjlmOWg3aTlrVNs5b0HUQ7E5czl1OXc5eTl7OX05fzrnOYJHnDmFO8w5iEr/OYs/CFzZMUk5kj7JOZWWVDmYhSpJBYdmOaFJOTmkeHIBNQIuOak5qzmttHY5sTmzMcQ4FTZuQnE5ubBJOb0yKgFcM6k5wj3JNRY9r7ZLOcmo4C5OlIhBUznQOdJbeznVOHVH/DnbR/40MTngTNR8/DnlRbKI1DnpOes57Tm7QrwE6zWOgEY59Dn2AncHnFq7OftFNDn+OgAEpjoCOgQ5MzoHOglC+zoNOg86EToTOhUysKTuOho6HDoeQk06IxrpOiY6PkmdTLdFVjosOi4+M0H8OjI5hzo0OjY6ODo6Q0ox+To+OOsyF1P1Nm06RDpHUQA6SDpKOkw6Tl5GP7U6UhDdOlU6Vw+8Nc9AaJ7POl46YMfSOmQ4MTpnRI1eKziDMlE6bjpwR5g7Lzp0PVw6dzmsOnoHvwY/OW9D80HyNDs6hDqGXyQ6iTM7OSU6jTqPAGg6kTqTRJkBYTqWOfQyjjqaOpwyRTIBOqA6ojb0OqU6pzqpObI0izfmOq4zpJ6fOrM7bzq2OrhCokXNOrx2o0N9OIZWSDrCRzqWCjrHOsk6yzrXOs460FCNP5461DrWOtg62jaUOt030TrgZjtNUZlunUk66TsKe/c67mE7NjdFTzrzOvVgcjKTOvk6+zr9WrM7AQ2QOwSI1DqFOwh8tDsMNuI7DzsROxNRlD6mUUCcnzsZNAw7HHvgOyA7IkOiOyU7JzOOPGVANjbMMl47LjswAUpFgDinTHVTzDs3PNlAhDs7Rktnm0CSO0CI1DtDNmKHMTtJO0sBeTtOELkz5DtSQLp21bAyhqQ7WkixO10/gjtgO2IHnFCAO2ZmsztpO2s7bVDlO3A6IEDrjHg7dkCzO3k7e1ZNO35tnlwpBxI5B8oWO4U7hzuJeho7jDuOdIM7kzuVO5c8gjuaVGw7nTcUO6A7ojukO6Y7qDuqT9k7rW5xO7A7iDuzT0gyBzu4O7o7qDu9k7VCzFfrO8U0vDvIO8pMHTvNVP2znDvTO9U71zvZOTY73DveOHg74T7cS2h0PDl7NrE76DvqO+yD9zvwCZI78jv0O/YCmTv5WUI7/Dv+PAA8Ajfavas8BzwJemw/SUBJPA5C9DwRZAI8FlDIPBo8HDweRBQ8ITwjPCVHLjwoPCoQ3TwtPC88STHJPf48NEBfPDddwTw6PDwyzxHqPEA8Qjd1PEU8RzxJPEs8TTxPPFE1XTxUPFY8WDxaNzVbWULCQg88YDxiO28+1jxmPGhXazxrPG1CbDxwPHI8dDx2BxE8eTx7gAI8fzyBPIND3UuoPIiG0zyLPI08jzyRRHY8lEO5rLY8mDHcPJtuWTyeNrYBIkK4Vdw8pEtSQLo8qGgCPKsTkkScaZ08sGJfvKg9njy2PLhbaTy7PL1A4zYNO49CjDzDPMVPwzP4PMlEpI33PM087jzQPNI13DMhVAk8ejJGPNo83GFkPOA7CjzjPOU85zqZAwQ86zztPO+JAgNFH6mDlzz1PPc1Yzz6PPw8/j0AO3Zlh651efI9CDUVPjcEvzwQSfQ9DwGzbjYyPj0UBXpnAWwrQZx3n0gLMdc9HjN2PSE2Wzp5PSVcHIysPSo9LD0uMz4yTDW6OWA2QAXPN/M9NzVKPTo28j09PT+X0D1DPz89Rj1IOvg9SzMpOCw9Tzx8PUA9UzcPTuA0C0QBPVk3HVROPV0GADeZPWEB6kCPXbI9ZkjXVX1W3DMhPW1NZDU6t/s9cktjX5I3jQdMW3VB2jksNU09fT1/m309hDlsPYdg3D2KPYwyCU3rPFk9kj2UPZZNarFdPZs9nT2fL389oj2kU2RGtz2obfA9qzbyN9w33D2wtlM9s3oKPbZgmD25O1aecDHXN48+pkALRfgx94hNPpg42DjlPck9y6yQXhE9yzqoPdI9Qj3VPdc1XIHYPdt6ij3fPeE94z3lOBs96EOFPesEmz3uWjM98QdMPfQ99gIkPfk9+z39Pf80iAlwNqIxxT4FNxQy6Tj0Pgo+DDTlPNueLANzRgk9XD4VOYsCRbvDPhs+HUruPiA+IkaEPiY+KDmNRsGyvpD6Pi8DTj4yPjQ+Nj44XRQHfzNlPj0HaVwyR2w+Qj5EQCA01FTFP9BmOJsCeMM/lVgCPlI+VBGLRjE+pD5YP6s+WwEUPl1UwT0gPmE+Y3PaPmY1LTT6VwA/bkBTPm5VPklzH6k+Uj50R2ESTz54Ne0+e1hwRNQ+gTSxXT01fj6GTrY+iUXVP5I+jT6PPpEzNz6UPpYBGgfRTGWBeD6dPp9bbj6iPqRA2j6nD/A9Zj6rPq0+rz6xZcg+tD62NBYGrzhyQgY+vD6+Nzo3YseUPsM+xWb+Psg+ykSBPs0+z1ERPtI+1AlbPtc3FTpbQLqUwD7ePuAzq0UpPuQ/m1YMPug+6j7siT4BET7wPvKV15TIPvg++mg4M/gyDkY7PwA49jpbPwM/BUzNOhps4j43Q+cPIz8OPxA8yEQBRzlY5WYePxhUxVGvPxw5ywSrPyBT6QxTPyRE5j8nUoQ/KjScQ+A/LjbKcMw/Mj0TPzU24jNpUhk5ST87ShY/Pj9ANbw/QwQbP6BBWku/MBE/SnXQXVhLLj9POTQ0OzrFREA1Bz9WP1gyUjjmRDs8TjrUmmlObT9hP2M/ZU79TPA/aIHYqYk/bD9uV2020TKHP3I/dD92LkG7Cj96M3A/fUO7P4A/gmNLP4Vz3z+IP4o/jEpgP48/kTQ0N7ddXIqNOCU06kznP8U/nDUWP58/oVgaP6QCyz+nRCY/qj+sP64IaDo6P7JLf1QxP7Y/uDPRP7tSZj++P8Cr3D/DrT62rT/JP8s9yzkIGBE06D/SOlY/1T/XO6w/2jM/X5CApEBZBLI/4kWrP+U/53zFcDMzPAFJP+8/8T/7edR9zWd9QzuqLT/9QehAAEACbuRABXjDNshACUKhPcFADUAPS21EJGJHQBQwnTuIQBc8z0AZadI6vD7rPYJAH0AhQCNfdmodQCc73EAqBEg6s0AuO6w49jcpQ0A6IgFKR5I0iEA5AX1ISkpwtjRAPzvdPN1AQ0BFOTN6aEBKOKhLtEBOQFAyVUBTQFVAV0BZQFuu8FxjQGE4VWTTP/tAZkBoOC0BcXXqRHZkq0BvEOVAcj3wQHVAdzdVNWM0IFFPQH11VTxxT1lAhECGQHxFJkCKSh5AjTXlQJA+5AUcQ8k8EkHiNKVAmTpqTJ+6zU0dVMVAoTnRBuFApUCnB2p14UZgNv9J+TketNNozkC0PVxJS0C5QLs1XkC+VHRAwVtIP/dIQz4LNn04Q0DKrwWg40u3QzlM1AdnQNc6wUDaAgcw7lWwQN85CFBShBdA5DLbQOc3gK8yPhlA7EDufLkzDjSIWApmT0D1QPc00ED6P4RA/UD/TM09XFXXQQSWF0EHPdpBCk59QQ1BD0RWbFtBE0EVQRc4BTvWN8408EEdQR9LywFhOZ5BJED5QScBKWJfSu4Fw5Lpd3w46zJHQKA1vEE0NkJIegcpQTk9Rje9NPozv5yQQUAQ5jSIQ+BBRAFbQUdBSUFLQU0BOTPqtWaOXkFVQVc1k1DlQVs750FePEJJQEdYQWMzzE01MnE1iEFpR0w+yTlyAiRQ4WqSjklBc0F1PZ6xXUf9QXtBfTz2QYA4y1I4pLVBhlGUTCtSh8nDQYw1saxIQZBE7UYrNqFBlTMPQZhFpUGbQZ0y3TNpNXw8i0GjNfVD7ki2B8VBqbF2QiNGCXyAQbA7b13UOI1BkDvQm5sz3kG5M5tBvEQ1N6Bi5kHBQcNBxUHHO283J0HLOSZAXUHPR84wXEHTQdWFv0HYPXl1T0HdV20CNV/AVjBB40HlOjJ8XEHqMb1FjEHuSp8yDEHyOIYzTjjoYNtB+W3wOFpB/UH/NUZsW2VsQgQ0r0IHPchCChAHaP1CDkIQWg+N5kIUM19CF0IZCKVCHEIeUD9CIUIjUnFCJktZqERCKnKNQi1OuTP2WhN2t1lZQjVCN0I5PblK5am8Qj5vKryiMz9nRj3zQkBCR1DzN48+HALUQk1CTz3eQlJV7zIBRG8zkTSHkZJCW0C6Ql44dUJhsiMzqz41kFdCaDxVATM+H0JtQm8Q3UJyQnRflzaUQngFnEJ7Bc83lTT/QoBCgkmnRls9QkKHQolCi0KNNAg31kKRAuBClDVeSVBCmEE5QPVCnC+1DkQ9eJOnQqNCpVksQqg09ljlRK9Cr1WIQrI6x0K1Ph8y6UK5QrtCvUK/PH1CwkNKQsUx2ELHB8NGWEWLOSU7wYZEDKoQ5Uy3PrtAWDM+QtVD/ELYNShC23dviapC3zwdVuI2u0LkNdSrOELoOVs3kELrQu1tLELwNdpC80L1N6UBYUL5cA9C/EL+BxFIsUMCQm4QpxEoMdlDCEHpBe1DDEMOY5uTK0MSQxRDwkMXs8BawUMcQx5UtT3hNLEvmxgRMcZDJmJuQylDK0MtMxRjm0MLQzJDNEmuO0eis09tP/lDPTp0RDVDQUNDMfFJgkCSMutDSUNLMnQ8mwZ0Q082RTsHWhM4kjtWZdZDV0NZbT9dYTtccHBDXzJxNQdDYw8cQ2ZIyDgounZDbEhAT8NPskNxUFI2LjZmM/Q+M0N4Q3pI5kdMQ34Rr2STOORAnQ9hMwVLc0OHQ4lZ+UmMO/u5n0OPNnA8KEOThDpDlqxhAXNHmEF/M2lDnkOgQLZDozkePjM46DU9Q6lFXj/wQ60yCjKLy8pDsjSdwP1DtgakapNDukO8QdQ0pUPAZnlDxFJKVIw8cUAtsCif8EPPC+pD0UCKQ9S/X0PXQ9mu20PcQ95FOEPhMcI/95w/Q+ZD6HWqQ+s2YFlJexJD8jp/Mq028kwKEAYGQUP5Q/tD/UyEQooxzkQCc6dEBUQHQZsG30BPRAxHPDdmQq02llQtRBNEFW6KV6I+NFIvRBtJnUQeRCBEIkWqRCVEJ0QpRCsz5jnYRC853jWkRDIHAxBHRDY3E0Q5UBVEPRaQbps8Ij38REQ3gz/kAlVRlEmpNi0/VTW1MfdETkRQUXYHzTIZQ6xnAURXRFkOVBCnU+sBBEv0NrBKgzNPinNEZD0uVTOn1UnxVrtEa0RtRG8GPURyRHRBLUR3ObtCfz0kNQZEfTk0MjpEgYlnRIQ0QUSHS7E3xztlQttDWESORJA3kERsStU5HTPNPZ43Yl80RJtEnUSfQzkBvnsqRKQyHQdthb83ur2VRKs4cjvdR59CrTL8MuBEsz4fRLU680S4RLo8T0W+NIZEv0TBRMMzC0TGPX44qTyDRMtQHD6mOJttJ0TRPec7HT5/U+ZfrDL0RNlE22STRN5E4ETiNUgRi0AiROd3813SEAY/OkTtRO9CFkTyOKlF/j/5YqodCzmaRPoCWTsvhE5TCEUBO8BFBEUGplFW+zCeNKE+kw8vNCg7xISURRQ04zb9j0lxHUu3RRtGfDohRR8FiUHGnLFFJKpIRShFKjMYBtwzGZ0ARTBjCKiMjR9bb0HURThZ1kaIxiFFPlfbRUFPhkVEZoBFR0d3vz1FS4QLOC6ttUgHRVJ4pEvSNwhFV0VZRVs6316rRV+ko0VjSYg5nztGRWhFakRAO7l6bEVvB389iUVzTvA1701kPJNB6UCrOW80nTpbQLY4hje6RYFVPkWEOF0zBkWIRYpFjD8tN85XNEWRRZMxS0WVRZdFmW42uJlFnUWfeqJFomMiSYwORUWnRalFq1ERM1RKS2h0MepJ8UWzNc081UW3RKszDlpuRbw6b0W/emw3ETq8bSdeRjrBzHA+mUXJE8BFyxD3Rc4/ljYrPpxF08x7PoxF2BS7Rds4GDrYNqQ8az+JV8k7qgRISLyHcEXnRelCiEXsP4U1NbZQRfFF80X1OXM23EX5V9tEzUX9Rf8y/DIoN9Q7Ta2WRgY+8z8cRgpgpAWSVe8ORTWARhE2VzbERlM5/0YXOL5NTUYbZgk8gELsRiBDEwIwMiNaREBJYkZGKUYrNko2IUYvMrFGMkY0RjZBf0Y5Nw9GPD4nU5IDukZBBtI19EGUSgpGRzNLTOY6TaymNqI6uzlTOFc3LDYyf1dGVpzpqrBGW3amRl5l1kCsDJ9GYzm7sClGZzuPVYAJB0ZrPUdO/UZvQ1gxyjolPrOIAkZ2Z4MFyT/WhBdXokZ9P048eUaBNsI2Qj4kRoY2J0aJATVGjDlaRo9K7kaRRpMzo0EJYDI9o0aZQJhSlXdKMh9E5hbMNysyRzJGA3VFYKZURqcIJ1ERA1Zwkj3tQXNGrzM7AVw5XTARNMM8z0a2Oc89IDYoM61ZaEoJRr5GwEbCRARAXzOORsdGyTq3NgtT6zt7URlHWDdbRtJG1D9uO780CT+kOKsz50bcSotG3wTsNx10LkblMmg+bTv9EAVG6zqhOjo+nj4lAhs/vTTQAVtG9ATqV6dG+D5NUnEybW3SRv5HAEdVO0NK20OTRupHB0cJRwtHDS+aO/0/6kcSSy44JWMIrW1HGFfHRxtHHTDhRyA9AzuIP6M5YUcmNhs5agJYuchHLDM8Ry9HCDIlRzM1j2ujRzdCUUc6RW5HPQYGR0AHqTI1Ea8zTkdGMhdMpwdOR0tHTUdPW7lG3EdTNEJHVkThR1lHW0ddOtNMgwYGR2ILbETsN3FIijwnOiFHaUdrR2045jKvPI1HcgEbR3UyKkd4ogRHezMArQ1Hf4ifR4JTpaunvgRHjjgpPI2ZPUeTR5U4DEeYQwFHmobmPBVX20egR6Ix8UelR6c/t0eqR6wL90yIPqY1W0TKR7M2ejZAPOfJhke5Bvg1dmjiR74GB0fBR8MBR0fGR8gG4UfKnJA4XjxXR89uiEfSQ0BH1Ta9ATySokEeODSb/UfdR985QUfiNXVK9HTTNeI9izVgSVdH6xDRNy04ckfvP8hH8V6KR/Q0RwMPZFZH+T+COdc0Mc6FR/9M1EgBWnZFNxScSAU5LUgIARBvO0gMPp63EEgQSBI4J0gVRS1IGDYuPvI/7jZbRjVIHzcuNiZw0EgkSCZIKDSbSCtK4y+6Ou5FHkPYc6dHMkuWPG0GADOTSDh87Ug7WAJIPgJFSEFIQwEmO1k1/UQfE1I3JUhLNbpCkUhPRmdCWDUUSFRWkktkN+cy3WCAZfJIXC+WN7tmwEhhBFs20aE6SGY/FUhpPMIvlkYrV9uMR0hwNJNWYTceVpI3ZjBcSHi4E0h8R3FRPpQcSIGhVEiEWw9D+kIiPdQHUkiLSI07/zznSJE63DICP4U1IISiSJhQUwlxSJ04VwvqSKA6OW4uAb0JEEP6cGszXwN4PLZLq0iuUAg2G0iyVMc8jTYjSLc0ski6Pf5IvUhDB2kzC0BdRDtMFwb0BJU0LzuhSMkCPkK4NAtGQDQVUgWOnEjSSNQCqTiaSNhBSzeoOWNI3WXySOCcn0KMSkY3cDnqSOc5ejZsTQZI7EjueSQ/JDo2OCVI80j1OkNI+E8sN6SRfEj9QXRW4EmVNjZSh0kEOZw/GzM/ZrFJCkCxM0FJDkZibCtJEjiDWDA29Gu7MzI3VUkbNq5Eym0IODBKWD3LTSDTd0kmSSi52EkrUdpJLglVAbdJMl8DN/Bt4M84SThJOkYqOuVJPjJESUFBOTO5NDszTkk5W6JQgDhSSUtTADLlQ/sEuTYQPX5JVElWSVhHLmNlTbY4awJbM+NWEXFeSWIQZDkIUfs/0E7MSWmGR0ehUNMyEENqctpmkklySXQU1lgYSXhX20l7YO07/jf4MnJAckmCNkaBOkmGRWQzZD3BNgpJjUUeSZBJkkPrSdpJljTquiu9sEmcSZ5W2UmhM7FyZUmlhUE3TEmqfotJrUmvTIQ17zHFWQUzCUm1Yi9JuELCNoc+zUm9UQBXWEAEU7hJwz1ONjBFaUTuM+5JyzNIRo9Jz3h/SdJHJUnVS0E6IEnZSdtJ3Tkseb41tUniRf9aOVG3Mm1J6DNhSetgPknuVGFMkEnyAVlJ9T+rSOZZuHFPSfw/yEwLYz1BI0I2N687GzdBcfRKBzQLOMShDUoMBj1Uqjt2Mm1NxUoTh0VKFmEFShlUqjaxOjEFw0ofq+BKIkH5NC5pPzwRPYMyZD0oQSiBHEovUkqDqkozNgg/3jupRLnR7ko6NgYz7WxMSj9GyEGVV9s5KTZiPctKRgGgQ8FKSkpMSk44KDPqQG5BaDbRNKJKy37VSlh00zUUZDQ0T3WXSmBPqjmvSC1KZYjUWg47AwkQimE77kzUO+5CQUFjSnE3AgQ5WvmLkkp3lHtB5DPDM7NKfU8MSoA07j+1SoRAHgFZe1FKiUYEPAVC2jOeQ905UlloU9vPMkqUbqIzQzObOjZKmgfhM+xKnkqgi5BKozcuSsVKpzyISqpKrDkHOeJKsEF0Q9E04D+jnjpjJEq5SrtKvTliV/93NTYQD9JYOkgSR3GLB0nGSsk5skrMOPyhVErQStIHKQcSStZfwErZNpRK3ErePRNhzMgNSuNK5T0TSug85l9eO6kx3wfgSu9b/0ryMjlK9TdHVmY7b0VeRSQ8vJszSv5LAGMeNS5AATwbS4kyMTWDY4FLCksMMcsy8Vy7SxFEBjbhSxU5O6eBSxm2KUsdM9pFgFAGQKE/7jyTSyVCrEsouZ9LK1/CSy683ksxSzMGPzVdT9g4Zks5PsdLPFhjSz9KcEtCOlxLRX1yS0hO/UtLWxxLTktQS1JbnUKBl/RLV0tZNdJPqktdNMtLYEtiS2Q3kEtmYHJLaUsES2xLbkJ3gyKyf0t0S3YypF25PIY24TxsWbxLfkuAA71Lgz+JU79Lh0uJAw9sz0uNOKs31zMgNnA3gALKS5VLl0uZWOUBMjT2S541wFVIXCRLo0ulNSA+LDTpZ51LqzQIQuNK5DhVNIlwkUDRS7VFGRD3PZw/8EYoN4YP9TgkS8AM3DIZS8M1k2EzS8c4XUOyMvJLzDerNqgBAkvQP65L04PKS9amgEvZpZ9L3BcKNYxDajYcVKQzVA0xScY1N0iQzsY0l1JOM6lNwjw/NsQ57EbkOjdL8hOSS/VMKxTnS/kBVTklAVs1yU8IVyg/HDyGMb/U7kwFTAc2wgN+TAtMDTmBP/xMEUU3kLpMFTJsTBg32kN5Nr07lEweUlU+o2uZTCNFKZP1FNYzzkXsOGZL9kwtOy1j8UwxBp4/8DghD/wzTkw4YY08hUMLTD1Xf0xATEI2llP0NdlMRzivPB0GvUrdVXtMTkMqU+YGWWVQTFRMVgGgMOExvUxbcHBMXrYmROw7x0xj0ahMZsyHMrEGp0cIeC9MbjTlPTk4/xF7O+kzOUx2THhBXWc8OOE+f0ulTH89fjSVQ9hMhEKrUGltYUyJOfozSQfRSklYMIM8BrNETzcGU+9MlkyYjwxMmzQLRdV1RlgzTKIPHDSUOU9YyFL2TAx0haRFTK0FyEywPTY+78qgOvJMtky4OxhTjHh3TL1IuUKKN6BwSEzEZAoFekBaRQpJQEsxTM0zyT5STNFLUJGNdUFM15uoTNpD/DM+A3lGVDTEjTxM4kUUW4gzPEzmTOg2+TduTOtM7XPsM2w5foqNTPQ5KTM4N44xxDgqRkc3oThuOVVCnDpLXy5NArG6O9CsPE0INy53EBNNnMxNDjMIO6ejIU0TNyNNFjj/OBlNGkqdETFNHgedTSEFnE3pM1MQ2UgUTSg4G00qD+8BwTj7TS8FvgKZOYo5Uk1RTTY13DOhTTpQBk09MusP9AWSXjc08DLmQP4NkLWFTUhNSkuJPfxS/k1PTVGB2DwdPAgGs01XB2o5pE1bTV1SazuZM9m0xE1jTWU73E1oQIBNay/GNjs8yDZIPqM74DXZYsA2rF9fTXjE8E17M0leEUS+vV9NgTV6TKevrE2GPStflU2KZ7KSM75WtmZNmVAzPcs1jWgaS0RNoDdxTaJCk0qaSK6MzD99bkxr9TicQRdKLUq3NCg6tTYgxpRNtE22TbhUqkyfM/VNvT2OTb9NwU3tVn5kUk3ITdaY0E3gNHhOCU5ATdFEmE3UNFNN2U3YTddN203FQfc0PU3i195yVdfgTfE9i4R4Tp1N6k3918pN705HTfKEck31N6BflVOphHY0bme6mNxOAdffxlJTSk4vTgi+Vb5DvlrX/L5evjO+Xb5Rvk2+W9emvke+WdgE1//YA75XvhZOSrLj2A+499gRuSO8mdgSpqAzkTeuVdpOY05lUNNTJE5pT2CJ/U5vOV1OmE/4TnVDLG8qBdWENE57P2pOfn6sU8NOglAqT4hOhz6tO5ROok6NO6hb+zXeVPWLGk6UNbNIEdgi2C9OhE6cTp7Ge06KT+ROpDgkP+ROpzJOTmJOqzcJNzwP1lBPTzNOtHAWPLBE2DU6Trp41lFKEAky/QE8OtlPFkUMrGdPB088PHtOy0Ua2FZBC08lTtKKT07VTtdl8DYATttQEjU1T6NOlU7jRWdQKU7nOso13jVOTuwPYV57NitO8Us42EZO9T7SPNHYdjllT5ZO/XLuA09kPgxiTwNPPj6eTxpOx08dNzc4gdiFTuVPDy0YNV9RQI1zQF1kKU8XPa/YkU9JTx5PIE8iT19Osk8mixRPKbBw1Bw/2U8v2KW04U6yTzRPNk84TzpQOk7JRbdPP7l+T0JPRGOb2KVPSE8JT0tPTaqGT1BeAVD/T1RPajX/T5xPWU59T1wG3Es42LBgUU9iNJpPZdiS2LczSU9VkQhPbTXzT3BPcjVAPpxPdjSOPZRPiU97UNBCHE7fT4BQaTZtT4RPhkRqT55BU0+M2HIzbU+kMzgDrFAh2EZPqn7TT5o5d1kAT4hshE+gUAzYc0/n2PQ8z0+nT5bY+GJCT62vq0+xQ3BPtDLp1m1PuIzHPZNBSE+9SD1NqWbb2KdPw0FVCVtPx0/JT/pPzEe2T881elAqT9I6eV9VOI1O5g3qT9hP2jLyOHpP3mBeTJBO+E+UT5ZP5k/oPZlh39iHT+00J1EKT/FWq0XRT/XZNtknToNP+QXtUAgxvk/92SLYQVABQnMBIjMITTtOfdlFUApPoVANZc09PX7Y2HFz/FAVM2U06z5YaqmzNlAcMkIx3TTuO33YaFAjUCUQh1Ao2ShQKwGLOGQ/6lAwRetQMzgXUDZQOF9VTwlQPALiUD41GzTsUEI0zUXUNLlLQQEvTJ9QSUHCCXHYP1BOUNhEBlBTgWpQVjllNVtQWZU4UFw04k/Zhb+Y8lBiUGQ92lBPUGhQajYXUOxLsjTsSzhQ8DzJUb2YCFB1mgNQeDIZUHrZl1DYUH40zVCBNdrZqTTJUIY5fEIGAuVyN1CMUI47jlGvlFY1OlXnXNAymjqxcMxQp1CaMb89PjbUNZJQoDzEUKMC0zkuMw5QyFCpUMtqrFCtPE5QN1C+ULIC6zi3ULU2z0bBk8dQujS8UL1QsZY1NhU5LlV1NTZQxpcoDKnZzoR/AXlQzTXYNjkxP7XdUNNTwzWRPdrRJEwMT/pQ202pUN07wFDgQW8+lTgoOXpQ5lDoRlYC62/2UO007FDvUPFtJ1D0PGFlXAaaM1hS6jqtApxkYVD+UQA5PzruNWzR8VEGW7hRCUKlQFhRDVEPUk9REjnSUSJRZzTHURlRM1EcakpRH1FF2iNRVFEmUUBRKFFrUStRRVGIUaZRMlFyUX5RdVE5UVJRZ1GEUVcBPNoxUVtRRlF7UXFRNFFNUX/aOlGCUT1Rhdo/UYvaM1EuUV9RcDL92jfaRto5UYHaPFFWUUBRWNpNUVzaT1Gm2kRRc1FkUYBReEY42kPaUgIn2jhRZdo72i3aWEi4UYfaXWRf2luKhVGOB9FRkTpqahNRlrrNUZk0/lGbN6E69DUSYqo2zKc0UaMQ49plUTM2+TMdLcRRrNo62blRsTpH2lKpOVG2Ubg7iFG6WDBBlVG+M0wBSjptUcM/oER+Ucd9z1HKN+IRMVfbQARR0NBMUdMzFg/wCCcHaj6hOl+q9VHcXEUtGF1uUeFbLpckUeU/pBUMQipaRzv8Nwk7YGVFUe8y4EknMiYyTmRxUfaAxlH5PX1R/DVdUf9afDX+B1JSBFIGNOJAd3ImOvw+bThyQ7ZRmwaaS1xKujpCUhR8nlIXOHJSGU3XUhw3VDT+L91SIVIjNLJ/4FInV+hSKmSJO5Gb4lIvOeNyVVIyMhEMKYbzOW02EFO2UjpGNlI9Uj9TnDfaRZ493VJVPclSR0p8Uko2J2uhSh5STzccRJ4DddhcUlU4BkcKM91mrjKtQjI9DlJeT+c7qXoGRLdEsl7QMjpSZzT2UmpSbD3zQjhx4b19UnNW9QWENAsIJ0ZHNe0Bi0JgSxZSfjYbMjs1SgmIPqRShQfRUog9rlKLUo1UVFKQQvw+k1NpO9ZSljPabYJSmkSBNe1DmGnAAUEvn2AiWPlEPFKlUqcBeTYVM/tSrEF/BYpTQFKxQZ1BEkrune1COTLXO6lAIlK8P2Q9+XESj+xSwkH+OvJGRzauS38DS48+UstT9Da6UkZS0D/KWrdERAInUtVi8lLYSaARKFLbU98RFDTsZKtIJzQgcUFepjSHRdWikzPfUug1b1LrObBBnTanS2Q8fC4IUvPXWlL2NbVHSjL8Zow2UQa9O9sJB0BdUwFUtTT+PO432EIPN046Hz5YO/w7CWgZUw4+SmOhOSlBnDMgOYsFkjglUxgz4Uk9EdQ0yzVsQNk5lEQmjSpTIzVUPgo/o1MouylTKzLVUy5hoTNDZVNTM1M1QEg5oAIvNrpDymbgWEhGrgX7RahHPzltQzhYPTgFQVE3oDiQNT1g21NLEDUP9FdtA7tk07ZNSdhNqUtoZmoHCFPcU1k8RFIDNv8+EEgUMc9Wj1qvU2NTZaotU2hTajQBMjdajT3VBytTcTXIkRdTdYkgU3g3KmXPpGRTfWl3QRZTgKcNr8hThTJyMj4/FtZyU4tTjT7rSRI1VjM+U5KXBlOVQKc0hmGJOkigYFOcR4xTn27xU6I0RGRTU6dN+G5zTjdTrG5xU69flxAIU7JfjAJ1X4A/58gCU7o8BkEOYHIu7jkmAUt161PDQZVBHNvpU8hJVw07U8tTzWC4U9A56AFhU9ODMFPWTCJT2ZR9U9yAiVPfPOxT4nm6U+VT53uFNSxT7AQDP79pllPxR5+K2lP2N2pegVP6M2RT/TTQZF9UATmUVANUBXIjVAg81kyJVAySLlQPS/FUEUCYVBNRz1AnfxZUGDfwP+Ru1FQdUbduMFQhuTFUJEeXA6xJV3YsR5dW51QsMgY8jlQwVDI0zjskNCQ5UlQ4Sqs4VVQ8RDWmwlRAUAY8tgGyS19qk1RHRAZUSlSZVE1UTx+pQQqQPlRUVFZJ6lRZP+Y97gJYAsqdplRgVGIGFUSdB2cTC1lyVGlqqTuRNA041VRvjh5UcgLgVHVKmkLyNmQ0C0fANzFUfVYtVIBUgnYIRic3TFbcOAE/D1WLVIwH4Tv7QQ8+dD7OB2pau1TBUFVUl1GrfxxUm0BaOSVacFSgQcqGqlSlPLZi6juhOOZUq02/TbRUrzfHVLFZ41S0VLY8vE3XVLpUvAVDVL8G21TCM2RGBlTGVMiLY1TLAQZwDFTPOOVkSVTThuFU1kemVNk+9A/kkGtU3lTgAWBiwEoeTVBVSDIbOghU6QEaTaBU7QERNOEyOjI6NRU1b0EOVPZU+DQLgORU/DvQBYp3LzqOhjVVBG3TNLU/hMaVVQo0ojgPVQ53rlURPLx5EUnOTLU99T/ZVRkJ7DicO9xCp2J+NlQ8V1UiNvkBSWmURpgyLUHDNks1kzMqUUdVLgE1VTEyrlU0Q+BqTzXRPdVVOmBpVT1VPz2cENkzEzn+AYsBGj0YSBJVSa8VVUxCBgXR1MVVUYQXTWc3CWTaNpZVWHwOVVtFm1VeVHxVYTtRVWQzCkG7NLUHulVqONhDEwtsOltpp1VxS5RGWDRHVXZBLVV4TTw6OTgXQV09aT9CQRdVgDLXN+lVhJJIVYc5CI5JVYtGZzcQN3MyATg1Yz081mk9VZUzPECFRKM3djgHOjpVnTVRVTlzeW7kVaKUwlWlNttAwF6rOeg26zelMus8+3dRVbA2H0t/NJxEwjHAVbcz5FW6RMqV91W+AX2l/zV0r19VxFU5WG09+jetM/w0q0SebWg9XE6MVdA6Yku3N2Zu5DoZPp4MUztfWhNV21XdMvFZaF78VeLK5lXlPp5V6Dj2an9V7EATVIRV8HqwVfNeVFX2Vfg5VTV+TJBvK1X+OQZ3FVYCNeo5bD3JOCFMd0NYVgpWDD3kNZRADE9tmOxWFDp2Vhc3xjfmOL8BHYu7Vh5WIAmINosGr0WrQ6tT5TsoVio/mlYtbmo3yrDpVjNcc0sKbYI6dETKOdJCTm2eNU43kDsIVkA4zUBvNPpznlZGVkg2fTaUQIkBeVZOVlBjvlZTCN49HZUOVlgy63kkbBuHVV7TNFlWYQE1VmM5ThAIVmc4nlZqAo46SkSYNGdx8zduVnJOClZ1NJfGQzR2VnkzID0Dh19WfzJGOXdl71aE1+FWhxmNi9FWizSIt8RWjz6VPYJhiwFKP1VAgzgMN0UmYVaa0c5WnXhGVqBFY0VoVqQ9fUVWSVVWqT7JVqxMRrGTD45AaFODkeVDnw07PeQ9RT9iSI1y11a7MvxMEFfPPIJQN7CwVsN3SkF/UGON/1bJEA9Wj4FlPHEUnDLwOUBPKDcFS/E03URxBKY4t1baR2xW3T3zQH5W4VbjO50CNT+FaaYyaz4ZAlE1FQFVVu41WkW5VvI/HwyEVvZHbEd3NuNn81b8Vqg0xDeYPmo5rUH2ROZEuTkrVwZqGFcJOOIBNVcMgwo8/UscMFJXEj91Yz04bjHYMutNxThkNi9L9VzQhTdXHzbxN1VATWykVyUCykELVylEqzLgpZhXLrTEVzEzzVc0Q/xE0QEPZpxPHzehMz42F1+VAcldUldBQE1BxDG9NP81pz2wnZRXSgEGdZ9XTn9lV1Ex/53KV1Wqy1dYYl9EatidV11J2jKcM2fV6FdjPPk7YkBPYcw9hml3V2sD9VduFJxN03dvPNk2ulm8Zvhaz1d4lSJXe1d9Pp48cTp7V4I2CDXKFNY85AInWPlah0OSP6s9izHyN68/OjSUMeYzS1eUDlY2wDuUGCHaflebWjk+HzlnQLsynENAV6M4qVLqB38zSzXuN9hXqjUDNCNgMjHodxtXsTScM403VkA2NQMzmFpuBOo0AVe7OX9JVVQ7OUdKUlfCV20yq0NYa8wHSTYXV8o321fNAlhX0EcfMatrylfVV9c037PVV9s3uEZ8MuQBXNKTevBX43QyV+ZQ51fpSss7wzOTV+4FN1xsmOdX80UFNOq7/Vf4OY9K0kA2Ngi2nVf/T9hT5lgDYDI3SUBSO0g2MUDyWEtIUFgOa5VYEUi8M4cQFlgWRwhYGVgbMxk9LlAKOt9ND1giMm5YJTo3EwsOVknVATg1vjQMAYVVCjguWDFBFzV5ROZIB2jiMdmRMFg6EAZF9Fg+Q7ZMFzSONso92FhFOC1YR1hJAelYTDYMPYuJXFhRNQxC9EQUSdU1WROjWFlhDlf3WF06NrILXwM9hj4sMnFs9DZmmrNYaDWIWGtLiVhuBxFYcYnZWHQ1HbvVWHgyDVbcNiQ/QjkGcLpYgEY4PwMw1jXSOhVYh0HEO6FFHglHWQUfqTiLPfpD/ViSWJQoQmrkWJhC7T81SHdRkyZgSI9YoDZrOZg2HDbcWKbH4VipZ3xPOTahNJtQn0PgOiuh91izBnRH9AaeRH9YuTZpXos5ulmvWL87/z53BJsCNmRfWMY4C0ynNlhHnM9RWM06MUnqOYsz4XjxWNTTP1jXAql2V1jbde5Y3oPwWOFEwgmSRVZY5jU0R7tY6jbRenRY7jxJAa9FOETxRO9MHTfRM5013Fj4WPpY/IRtWP8ORYsBWQNJs0XsRG6GKFkKPaNHaXjVNDEHMgeUNC6bmVkUMs21BTINMrh1UlkbgklZHkFdbAZZIkZUPwxZJlsuRLI6/ROSWStZLVSEObtZMDwNPYA4Plk1O1JQ57i+WTpGKGmUOf4w4TOoWIZDwllDQGVKXDn2O/tZSVNEWUxPg465WVBGRVlTO/tZVTj7WQU/KTlPERQ1PDxvO9xKEjn9VpU3aRDDNzM2MjbgNoRGuzqFP4VZa14tWW5QNTQMRkBZc4IbWXYv2TSiS0lZe9PHWX4KhT99RPkSDdbIWYUx9zfYUoxPNElpQF84EAwpNVE6OjorMuJZk2kBWZZny70wYgRZnBA4WZ4IJVmaX0NZo3CZWaY3c4xsfyFZrDyHWa+gjFT1jsJZtG2eN/lXXFm5NvMxnA/vNvlzRFnBQRJZw1/USWLSolnIOD49+DJLadI4nDVZWdpZ0TiphrdZ1UU6SNdN1kglOyaaAFndMmsyHzMqMtxUslnkiE2ITT4zWek4oVroWe1mYlnwOs+pGln0QF08cYuxWflCxHPuWf0y2klzSt0BHD5qYDI0wQNeWgYKmVoIModaCjz8NXUx4VoPx0NaEloURWkDdVPfVAAz1At5YYkIZmh4Wh9aIZD6WiQysEEmsB9aKVwgNxZDHTl61jNaMDckQX+eb1o2iBbfVFo7NJ5aPm9kWkE2WEYqWkVHl1pICew3ajPwONs8T1pOuNFBlX5AWlRLlVpWrOM0lGz8D2MCdVSMNTpaXosUiQI5rDdWWmQ1HTQgQmxaRFVIQdpRWQ+OSdpab1pxP4dadEIPWncQ9UOhWntafc+AWoA9+AFKP5s8/TbbWocPHDPdWop5VTCdWo4+erT1WpI9Bk/GNyA1xjaLUQxkk2MIWpxHPDiCBymwXFqiNrtapWLqTp9PNDUdQuMyKUgLTEZjoTz8Ye0/BFAnWrNeoaZEWrdnaVVjOaBavDbtOdJA1jZckXRawztcM0sBBD+rAQ9ayTUTkrw/0DPu3tBa0MclWtNQL0T/TzFa2DN2VFNa3F+XWHBE/zeiB51a4zkLOno3LDvUC+hIvEc/SUo4UDc8VL5KmkL4QOtkFVr0Phla9zjGWvo6YlG90rla/6flWwI5+p46Ps9mCVsIPCI1ozx2QeSZJVsPZONJcwXeSdg/STNOYZNbGDrPTqpJnTIhWx45jsziWyJGVjg1s5FbJw5XkR5bK1VjWy5bMA5WOKwFQ8t0P/81NGGJSnZbOkYoQRc8SYf2W0A/bltCOzdD3Tj7MfFjoUDDRMAyjjVKNmgHaQ2GBus0DDkeTpNbVErROi0BsDQoW1pTZEEtOmJIQDU8QGdbYj1cN85OijYAWBVbaURDW2tlXDtWW29Kmj9VNupe01OcsGxbd1BDNo9PdVt8dDw0GT7xNpmhvFuDBH4CL0TYPD9biQPISycG4W1tW48Rr1uRiNZblEWJVhBbmLTSW5s3w1ueVYAy/lZxW6MGiFumOI9JgjSrN6sQ5mIhW647dVuxPDk5A2ZlW7Y9PTXwW7o3N39iW740rzfnOVJUSFvEXy4EuUUaO853r1vLq3RbzkAFW9E8+jZqNfVBqUdpBt87TVvaacBD7V3lVTPJslvhN3V5JDoGAuA6hFvoTg98OlvsS4tb73tHW/JEuTHnO6c5xzpVPBc2ZkixW/w1vlMXSvFcATqRZmU2fjYZNKM+MzmfU5xJczg4VhE1rVY/OWw202sGXBNd5YxbXBc1+zawOrAmYFwd4eFcIDWvQA4BKTe9N6s2LWJHyn1cK03GQDhAzV9DXDFcM0BXhXVcNzQoM8MUYjMmr7VcPhAFVhFbuXJ2YddBnFxGBdE2TDYJRo8z4DaxU2REHzv7NU5DZlxTOT6WVVxXDxxPzDU/P20LukE4Tx82BgJKOA88NVxkMzZcZktBAUxUBDoAh4lYArfDXHCyIYtHXHVvKkm8RxxMK3RTXHwGvToySKNEbjcQMcW971yFM9NhcRmN0NaOwlyMNJw7jkHPM/k8dlyTXsNcll8lXJk1eEsOXJ0FQzP8XKA1jzIUrog1uDH7L2Bcp2IKXKo0eFytMo5crzWNXLEWFzJBGHFuyly3rrlfk0L4XLs8ZQJLi+tcwDWNTg9cwzO3P/c4dDetVLU8gFzKWhM1d1+kXM9c0Tw5OOwFCz7HUAZfPVzZatpc3GHCur1c4AUDQBNiR1udbno2UUYGN62RgTvuNho+eg+PNfEHaVzwNhMQkUB8X6F0rFz3B79UhNm8XPxIbwB5XP9t4MUCXQNbHTmTXQc/rlgaNhlSzzVOMkA1vzyLOao9ThghBOtdFT3aXRcyz4aqXRtB/xQ8M1Q42zfzqrJdIwJRPOZSpjxXXSg7QplqXSxGW5LnXTBAmF0ySPRBqDUQi0ddODfGu+FdPF0+AcZDwawpS1I7e0HaROwyBzVZOUBm3zkJXUw+30maD44MhEZWPn85xwNLNz8GljINXVk3FWFnXV0DrJ+qXWFdY3Zx109dZzfkOJpDSEt/OXxIk11vM5u18F1zXXU9gZz8XXk9fAO7ZmxdfokCNbwEOUl6UGlHCgepXYbLZl2JNjdabrOXXY5r8V2RN0sQCEJRXZU2YTMPMb84gjvuQjgQKFPbZttBCjYnMlE0DGB0XaU52jQkPp5FmJfOXaxggDxGcX5dsV2zPk3Zy123FSldukoMheddvkzQOx1dwjnkPYYzrTOfODsCnD2hAQlPZEzNNTM8IEudp/84kV3TXdVEuD/kOUNd2hOSUqQ9y2cKOsoxR13iNJedvDMFXeeM813qPT5igzrkRGyHtl3xbZ4x2wTrXfVIqbowXfljZF38CUhd/lv7YmlPUlU+NQ0231pQTooR7UK+MwNCvI0uXg1JxtK7XhFeEzYrWPs3YT2cA3VCwTVeNigxxjcqkK1eINxNXiOW4zqnNAsXLj6TXik1KTpqR04/qUCPOexvO26sXjM2RTfOXjZeOEh5oqlePAYHXj5JQEP9M/dPyjIUOjo7lV5HkSFeSmOhN3938wcDRMo5JzjbNdoyLV5UBgZeV0M0oGVeWzzPXl10wV5guBVeY0KjTmo01DoiBqcFvUHEnM9ebU6yPVxu8F5yk1RedTlKNy02WV56XnxLSjW6VQBQjVKEShJbsV6FXCnPZF6Jbl9ejElXSdg762sPXpJK1QEHNqpel0ZWZtJXG16cpUNen0n0XqI6mzHKM8dep3g5XqperEMTx8VesDYCOZJiYF61ou5euD+OgvVevEHOTo1KmrqfPkRHzjHYBKs5hEHjP4s4g1NpP+aCEl7NMBVggF7RNWde1DS6Nl6ISmZvM+45hF7cMk6Y6l7gNAK5oF7ka+te51agNf1lyJl6XFBe7lGKNvBe8VuhXvRauwLLBZJHjl76UCde/Dv9D7ZCkESZNKJfAzqmZp5fBzKXN2F7Fl8MQ+42bI0mQ0h2rV8UgetO4D59fG1fGjgGUb1AoUcKPlt0r18iL8Y0ywbePvk9aQd/QCOflF8sSrxfLwheOL4+0ndv2Nw4kUqaNuc2XDU8OsSgTr+ZXz/jh19CZmtfRTK7S7GRhF9KMg4yNzWLNC4/61kFOOEzxTn6qxvGiV9YUcKKxF9cOy9fX0NWcI5GyDY4C+przF9mNQRwvV9qQeJEjTZhBb9fcDU7X3M36Dr9X3dTFzfeR1O5INfkX34z/0YyX4I9mV+ENDGcHD9rX4k+1mRWvfZfjkkSPjVNUF+TSktfll+YREM4dJN8X35WeV+fP55foj6YX6UyAp8vX6k0sV+sQ0oDDl+wONjjl1+0EOYGyUYrMj85O1z3X7xMWjeCQHxfwUHpYYk2mF/GV3RfyQ/jUARfzTGzTp01Z82gX9Nf1QNeOiJNn03ABZ2Il1/dWBpiNpKcX+I4GEs7kt87ljZLUZtNHVUhOj01VTqmPo4zKjTlAj5AdwTqOggxxUMTQGfMmF/6OZhSBTVTlTVgAD6QOXtgBFdt0i9gCFKZXwJe0F4SM/yyYmAQOMKTc2AUmWoDXGAYhkc7lmCeOqRF1b2BYCASYmAjR3E9fDxlN+yIjmAqhkdKTc/uYC+Qa2AyOWNgNDHrPjNHwUAeN1U8PzYtNTJgPjJtQ4g1fqKeYEQD9UgL3stgSUW4YEw+KEIGPz82CkSrMzhLFOPUYFavbGBZPX5mZTguP31gX0UEYGKHbGBlOFBbDzepN3Y9yU/INy0zFDY6Ak08V0TuYHM/qzupEAY2KztZYHk1l2B8AuWd7WCAOo4znQ5ENi404D61Niw8NlxVPdVF7GCMS6Ro1DwHS9I0nVG3RzpDZmCWaFo9uGCaNW85DjnZYJ9EuFn5YKNgpUuLYKhdPQedRihW4mvMdPlgsGCyVj87+1+0YLc4VzNoNasP9DVs5Ptgv3ESVHRgw2IoYMZYbUYoBQBgy0DDf5ZgzzQUOP0QNWDTSxRg2WDXBohh7mDbYN1kk7YVYOFDzGBeRo40xzNoNR08FDYaYOoz3WDsYO40pDMeTFo7nT5DuGlg9k1kPypGbzV739Bg/TjgqfthATg6RjVDllA0YQc9IF3UPYlhDAFxYQ8GLGESAUE5sjgIOXODxmEZMnO2zWEdTLUy9UdqNh05i8rGYSWJAqw4YSk2GjVW1FlhLjHjMlO4wmEzNsg5NDJNPndZrDcSNNphPDPmO9sz7Uq4D7Zig9/JYUU4RkScB+URdT43NyxRDDhZYsg6CDc8VKqd6mFURN02Bj3Lp6VhWmGWYV1hXziKVYA/Da54SxthZmFoUCdMFw/1AbA1ZzlnV9YP42FyMdVCrjcfOp8/TmF4UMA0DzrrAUc23zm9Vdw+KDwOOiUx3T+LcBNhhzv7YYlIdGGMYY4EiTXpNpk/LTylYZUEvzLXS38GFT5qVCthnTc/ONJiGGGiTFtNiWGmQdc5f2GqMrIGr2GtYa8EnD4UOQUyFEDaYbVTJ28uQFMPBlmhS0FIjTjfMgJkEEDjNPNhw8AWYcYQBUfqMwNDfUrgA/VBCbFsOwpLq3B0YdVcQ2HYAaw05TOMXRRJyk/qimFh4Tc8MfUxvzM2ex1h6Dp/VDEH30KuYe43BzRDvfY1aZiPYfY0PGH5UinnlWH9o/NiADUENVVG5VmbYgalAHkhYgtA0TadNXYDXjz2ODiOKmIUZK5iF2IZbINiHGHMDlaix2IhNkxO4DnqVXg1FjPIS5gORDI6M0s2ojXs3itiMDfJO8mlaGI1YjczsjLkRVo/rlulNAKTVWJAOnNiQlT3YkVGJ2JIATl4pF6wW2EGpD/1ObpDqE913NtbLT31M8Nqkj3hM8VPJAaLUDMxxUCSMzhiYOZgYmNiZWmpJmBiaE6fps1ibF1YQyhGJzrsNYgzzkefAQ8GvTkzeMMzrjPfOR1HCDogOnlif0OxXViaRk85SQNB/3RLYok+NAyEYow0jLy0YpA1Fl1YiT4BGqfjYpdNXA07Ypo/yTcAMjxinjXbUQzMrmKj4EdipkPt5mdiqpymRgxirmC/k0Jisja3i+1MWjfk3qNiuT2oWDpWETWmQakG4bhMYsNPqhF0YsdiycV9YsxizuHkVtwCnz6mM0FWZWLWMmg6amLaNf1NUJ7+Yt81elq3bdJIeQ8cRQo1z0ioYSU17GLrMxs+QbIMYvA3t0GdODg1qjvnRNBT/DIfNfVUMWL7Vqs02QLSSc47WkekYwJOpzS4PU5ERmMIYwozsz7cSXc529ThYxFWH0AZM3A8EWMVYxg+JF1LijA6XzMsYx82YFPbYyOD+oK/YydMtzo0YypkP2MtOyG112MxyX1jNFBjZdZ1QVXaoE1jOwE1Yz5KcGl3NQBJkGRfNss8AEEmx+5jSVqGY0w6FDfJY1BmC2NTl7djVlarY1izKmNbMhA1uzr8imhjYTtFNIy64UO/P+5jadRZY2xC+DMqY289JD7iY3M2FVtZAigYEdCuY3o4q2N8B3Hj82OANmARKFDnAYQ3gD5RXQVjiQ/iR8F752OOMg02QTY9Nc9jk0EdQJhjllIZY5iHWm3ZOEZDamOeNXQ6t2OiOj42bXd3Y6dhpXUWY6s0EmOuW19jsUCJOFJjtT3BnR82Bj9kRiBjvDghQ2KFFWPBVmmV12PFNrFjxziXBiY6u25ZAlljaI0MOag3o01QY9Iz6T4QUT5Ce1gkTtRj2j1dOOZs9E6dUa84azq2Txm2PGPlY2gyY0SrM0lJiGbSN8c0AmPuNq5j8DpMqGtj9KOXY/cKW0C2Prs/ZAGoY/05MzKtZAA+FJZeTzQ6b2Cxe/1kCGdGTMZ7uWQNAw9kD2QRRICsymQVOm41UoZEO/tamw+hZB01FDTJcCA/pDSIfLQQI4Xshw6UZWQqNoY5HkIPxV9kMBrpYaRkNDeqQjVkOEbuZDs+H2qHUkl5LGdpUj5A4xDZUrZkRze7OU5foYdeN3NBnTQ/hHXX2jOjOit/W2RUvZeHWGRZcdRkXBAIfuM20mRibm5kZaCMOls2hFBiZGtWt2RuOPpi6rIAZHM9ImR2NYUBnXikQ7Yz8TXuSuSR7mSADAuQv0PnSAlkhmqTZIhkilo0O0VRPjLtbfABxeckZJNHLmSWNAk1N0DrQtc9NjorFVFmOjUENIg2Slb1M/hAIzp2Nyxkp71jZKpkrHRhZK8tJ2SyT4VKulQ3PZhFOlptZLo23FgKWEtkvhNSRfGiRWTDZMVG0VczOa1V0WTLT23RYWTPM61BEjHKZNRk1jelMbMyDWTbA1c1pEYrAZ1+F2TiZOQ2mTkvZOjeCWTrQDiQn2TvOPo8jU0ZMt2XzmT2PzRduZO7ZPt6jWT+VtVlAR1eZQQQvk8mZQg1jlVjo4dlDYasMtlQ5QEIBt5pKjZCZRU1QDaWSaBH3jqGBJ5Q/zkzUAo+JDnaZSE0Lp9VO1gzIQcSQ8k1VTosQahnPIRtZS43Dq2dZTJr7mU1RfJN1jsKDClh3WU83vJlP5UtXtMxv1FPTF4ROUFMBsxMwV92PA2sEGVNTNZAoFFhZVKDpmVVRFhJcTc0PHM7ljhkZV05J5pfQ7Izt0HKOAVIYWVmPSR6G2Vqg/NlbUfAMjI7QjQiR0o3HzdhMwhuWTxQQ0FY5XXhMmqmmWV+NB44AzTOC/cGWGWFOIE9A0JzO6pbbmWMSdVJSpGwZZE5hDXKVIw4vz+QNeRlmEpoZZsz+lwcR95ChmjyZaIF3j8EWBplpjSSPtI5rE3pBw9GZz3fOqhZOWWxSk4u7jJASppOGmW4PY5lujOjTcU4zZOn5SBlwTabAne7FmXGN5plyZUvZCdlzjQuZdE2TD4KiiNl1gE0E9Bl2lJPNEdl3VEcZeBvKj3WMcFl5DdJRJhgpDNEOvg4pzo+QvQ7zzaWS4lCGzolNiM1ozV2Uf49kWgNQPxhojWdSU8R1EfUNO0BgGzaReupz2YENgh3fEuYNr1mCuQkZg26c2YQS/I/dTngOSlmFTIbgXJmGbXsZhx6TD31kY5mITQEPINrnTX8qLRmKEsy1T5mLKxuZi84LTQJPcnfTmY1OK9Mtz5KTmJmO2DCO/tBn2ZAPsc5VTHaW9BX6ETQN2A1Djr5N9J2LGZNZrE2xgHGYc5mUzxCQpw14EhCPh1HoTYXSB4P4k9vR6dC/dVIZmIzm2ZkZmZG6jW0RHFmawMFAUtmbmZwMs5H6jXJaZRmdQJqZnhDYmB7NMdBTDlAOdQ55ESB1aVmgzKxBR1KSUfhM008FTcjTTxmjQdpT3U7Q3MOZpNYbT2qTJ8yRzj1PT05cWactI1mn+LVZqI2hjOtELlGfDa/ZqiD8zKcZqwznmavP6ZmsjiJVkDHGziNPzpDsVuGZrs8XzUrjJLTo2bCb/I8WUBIOSIzsQI0FwpXWEATOYRTnD0TOX444kpLZtIJSDVJPe46W2bYNsU59J4RZt1MHWbgQ2o85EYoZuQy61KVPiRm6E8+1tNm7HJqZu+KYUIWZVJTZWb1SklEHWb5Q5M33DVYPRNm/z0WVh+1TmcFRvgzDTHOOk1nCz/REPc+ajX7ObIHCDeKOdlhJWcWMlaIxFLYZxs52jyIZx82+q34ZyNcHGclRRQ8m0GwMtcFw0ynATU7/zHmNWkBHT4QVOiITWByPDN+CTHGNqFU3zbEO/NnPVYnemdnQQJFZ0RU2GdHSlgyVTI5Q6IzzsYpZ08Hv1YLaE1O8UmPQudnV3pqZ1ozQwWSO6M8TFL2h4JMnwEJeIgy0VUCZ2cBoGdqSJo6JUREWyZncDORZ3I5/jdshtxnd58vpF1ne2d9Ro45U2EzS389bGeENx5KSzd2Z4g21mb4jitnjUVgdGVnkUX0B4tnlT+EWoY05UikZ5sE60AERVlPvAitNSMCZIjEQLEz7UBdP4sFnUrgZ6upvWeuWY0zNeXcYZBntDdxeSRnt5jWddJN/We8NHVnvk4oZ8FawWfETZJnxju/B98EslV4Uik5bWfNOVU2j03pOZ1y2jSbBUNcc8xMZ9hqB2fbNT1AZ1JpPSw9LAEiMj47ErRsZ+Z1MGfpXrBCQZm5Z+5DPNKuZ/JFCTU9OY0221KPPGU1XFXaRMpCODndP6t72j3JeMM8LF4RDCrrfWgHSZk03zuoOZQ7OmgOOUcP9DVRNYg/hTTQ0zdoFzbHAaNoG2gdYQsRBzHxM1g/ydbCaCUPYz+kaCiCLWgrt9M+hUBWRb55JAI+RjU2jYkoaDaQ0Wg5OdSu3Wg9OkSjl2hBB6k6HzLaSc65cGhIOz+NhWhMaE40IjYLPJFoUzuhba9oV1P8D4hoWzYbqK9oXzj6MrlSVWNOaGVoZ157MrA1EDO4QfZESWhvQhw5+jLyMpFodUM5M5M4/TxCP6tE+TV9NcRofzirQfFogjt1aIVG4zrfW4g/bjAVXtM6VEE5iYRokFAKO2Vok2iVPGVol3ajQbkJWzKTBQoCLwHKRlswEWihPvS7dThiNtoyHziXPIxEKEtcOa8zUmSJVqg2yzmcaLIQD+eRaLZO6zk4B6njMVLRaL0E2jNpMfIy9ISrNltdSzNEgz02ojvyZvg+yQQ5aMw8tUzxaNACaT6sNjdo1QflaNdH6gdOjEdbpT0rBQNEKjpVM280J2jjaJA1wmjnEe1o6V0VaOw/c2juPpEF1QNeaPJHWjogAa46I2j4POI3cTcOMt1U5Wj/ZE1pAjqBNmo0QgFVamZpCTbJM2WPL2kONA54iBUpcqNpFBJPaRY13mkYTEYz43oKWO1pHjMRA3lUxTl6NKVpJAJYNP8P4za8AbeBiGksRV50r0jTMjc8MWkzTWeMR0DDD2A4MjIXM11aymk9QGVpQDflNjk4BQypNas1mexMaUkHdWn0aU2aqWlQ5jdpUy/ZUf5NiGlYM9lmapiZaV0MhDuVNsMIxGljNkTmuWlnPsk+LDQLRwZY5Tm4ZJWNsmlxEXVpdGHMOmZpeEOyPrppfDzP4WlpgGjiM3YwAjP4B4IFemmHNnk0r2mKPhRpjT0kBrI3yWmRRFZUdGmVFpA/sWFeARtBdAYGObpYRGmfXqYzOmTjaG5ppVboaahpqgvqXqY4qs3HabDWlkJjNOBp7mm2MdY8EjjK6b4FyT6Vab094Wm/acEzPgayD4ZAu2IYO5AGB23gS3V7pmnNNq40iDdUOJtp0zkeSRKbbmnYS21fxV7bd0pDd0qfP4FGo2niRkcBOTX0S2I8eTx0Ozcx+zYdB2kH5Tu/tk3tmz6ROZ2GQmn1MvVT9HTXafrXP2n9kryKMDjYQPlO8GoEv187RTjCPlsy0QoCN2kPPw5VMos85EQLhBZqEzLvT0NIC0kfMh1atzNOPc04gTk7Nhc87HSvM6tdPTpvTbdVnD61NfQ3G1wcBjdfl0FGROG47mowT4VCOLFWajU4cj8/ZwpMdmo6srtqPaIVakABtznsMwRYPTS5MnJqRzb3DkRHYW0/SfRGxjZPjDNqUQG9McN+KmpWUAY6lmP7altAU1h6al83x1JyBw82IzQMSi4CLkItN0M5K3L+amw8UAlbeb5qcHKyanM9Pmp1VgtxVmp5QelqfEgran9SZm35aoNCoTP3ZD1qiE3FAw9qi2uXQSNByjLINg1F62qTUPM3RLP7aphqmnCmap03D3SCaqFDiLljaqV8Q2qoaqqa2mqtM+2UaGqxNLJAEz1GSxQz6ja3VmZ1cmq7S3816G4PasCv82rDNChqxUGcO4Y6f0BTPLV+l2rNQUtq0FNBWy86oTUMNLk7QEGWatlbImrcNZc1pm8qeHKciWrjsVNq5jotz3tq6qj+au1q7zXpth1q85s8avYJR0tiERTuvmr8Rq/nsmsAVsNHw0Ptpc5rBmxmawkSYmsMPs81AEDROMYz2u8FkotrFTM7M/1WCmsaNx49uUfOUbtrIFk0N0NKvDOxUbc1hlulUI1rKWeEaywvtTzlay82CzwoWAI9wTjePP1ffms3bmpdYufsdDNuclOoVn2sA2tB6nQ0fGtEkqLvw0rOa0o4p2tMM5FudrCLa1GpxmtUiU5rV0UeMl1gZmtcSxRDMTpcc6dHvkJjNhDs0mtmMrE23T+pYx6ZYmttM61xHYnXa3ICJWTTRjtifktEATVreY1zPrTC6Gt+MgM5BzcpSLx/S2uFB0en+2uJQf489jgbNvtqQVGreb5rkbxCa5Q03TG9a5g8FDquOKE+UWueMgxBFGuia6Q+u2umPQY05YQXxpQ7jAaWOp8CWDCTMnQy1jiGa7NfrDXPN/BqqUC5OwHv2Wu8MnQBhEJYP2QBvghmM/fg0WvGPIaEp2vKPQ5rzUmka9A2vHk3a9Q1SS+Wa9dMdWWVa9tBHH3TTcZr3z0OAXFr4kBcU9s05zfeeHI6VpJTa+tG/UO8SdRxz2vxQDZr8zcba/btf3ajWPnRkGv8WmM0lnSvMc9GKTRHYhgQ9TvYMxA3J7o9O0ZqAzbibAxLREQ8RaiY9mx1S2M0rzrsBgYx8Dj/PH1BErL+bBxAZUFGbB9eUC9gWQABQUw8M5tSPjM3Vtw7WjQKPRgHK2wuROE7lWwxOEg1YXn7bDY45AfRNAE8tUNIPHg7enZwbEAv2G87Mqwx259/bEeD8zlzSEMyRTZ/RhBZy2xQBswBEg+TVbkyuUL9Nf1Dy2xZMtRsXEyIM7g4a2xgNX46PTVRQPdsZjQnPv807GxqN+QzU0gqz0NscEMdMfVLYy+DbHY5Pkb/lfdse2WLRUBGW7EwbIFsgzT+255sh0aPQF8IJ3DRbI2dPWyQS6SPRE7BbJUxtSh5MvxF+DJkPx1snUzQVgk+DEDRawZaUD4nNitvEmyoMi8/4mxbbKw1lEZeEGSF3GyyVh9GbzeXMdrRumy5b2dsvEDWNdI08KiMbMI3gzvcVLs3PUAdbMmM0WzMcyBszkuMbNFB/HwqbNU8ozgVO0NmAEbTNe01WDP5yd9iVGzi4mZs5Tducp1s6TjGbOszq0BSNXQ2wQFdMgA2iTUHbPVGMTS5OOtD7mz6EShs/UNpW2E5uFSCS5ROaj+WPP0FvjS6SR9Fh0Ts4rttDTHEOk1BBjb5OpI8eDpEvevgPW0Yl4FtGz7OdCltHzpVNd5DWInwPcueM20nUbgXoklAio1tLTJd1lN5JDJoMfA1/zihPWA4NUWWB+BInES35cNtPUZnbUA8hUOxSkdtRTeGM6+vYG1KOy8Emg8cUJ9tTzsYT1k+CzUoVbYB3jLlOccBhTaTOxtbbzLPtf9tX2HnRisRFGZEbWZqqW1ptvdtbE4FbW9Ec125Y65tdDKx3qtteDeIYcI23KjkbX44XkHoP21tg05kfGRthzMdPn9tijbyPoAP+22PSEM1wEhvRaZbLz2jYDIQylENbZrHRG2dbZ9WqDfFzpc4vjbqQdptpkj0Zq451G2qMeIJcePKOkl8e22xA3RaD1TYRkth+TbXuBltujSyM+I3BhAoMrxtwVWcbcM9YDljQc9I3DHNZm85jmHVc04yaD+jbc9t01xfbdNtwDoQB81LOYqBbdpK7mbbQ303rjVBbeGISmKJOp9i2TyNNImyu23qRic2dD4aPHqY+X4J1Nht9DibVEY14m34PnpohTehWoY3RZDRNhBABTYHDCq7R24FQRYz0W4MWIhuC24NVZw21tUPbhJEnTWBTApuFj/1RgxvKW4bRW9uHl3lPqQ7rIxTO4g4IVpQNI5dOG4pPFU5fkAIB6lIozSS5sxuMmuho3huNgZ3XyVuOgEoUc831jegM045km5Bd3gxwFhLMu5iXzaweVUCPkXJUwBuTDwUbk47CjY9MulCTrvDblVLskH+FQxuWjVRPIw/fzIUQZxLUUWebmNcLm5mND9uaFOobmvcKVOlksZucWtHbnTcKm53Vn0BxQKOTFpNNTfWlXZugF5oP70zuzXjOhk99UD2PMlBWm6LPAE36ECcbpBFHm6SBEF2XbKEbph9FjybREA6rkBuO4gznjYBN3Vuoz1ORm81EwY3RfiCeG6rQKoP4065QaJEgDz8RNg2ujwGMgNCY4HYU+k0lTxhZq4+hUXoO0hO3gJbbsI30ThSs8xuxzoVNb9ncG7MObpPLjI1QlE8dDI5SBpu1TgXbtc8p3lAbtsGnjbAPQRu4HaZbuNu5Tp2qj1u6UBEAeoyHUj0M/9u8G5zOVQ4rseQbvY59k80hG5u+49cbv42OQ5DXqagaz9kQxZvB1GRbwpLsTgpNUw7kgbJCQdvET53NxkyDQLLOn85NUaTbxo6ITJubx608W8hB04C003WRAtz3zbBMvxOd1ERRFYHEm8vNxEvmxEUOZxQMjvPBJ1ZTG85OBBvPA/wXftvQDziOldPbTW1b0XQGW9IPDZFzG9MTHVvTjNdNQxBlz/12rxvVUFMTUk3okSZAig2aGXlM7kxyN1Lb2Ey5VYWNTpTFzZL7JhvaTH/NykGB0BPN1Y+N0/eNphbnW0nPTw0Lmr/UGNBRD70OP8Cy1bomj5vf0toN4ME2pDRRKNhichQb4g1gRHqTIgBrEeXP05Kg0QBO6lvkoTqMotIJRyySvQ3Ojw6O5KQ/G+dNkRnFUCxNJNKVm+kOG5PITQGM5E1ATkoVmE9mDnUb65WkzxtPZk+1gJGNp1vtuz3b7lapNnitZxvvkekS7c/yDMyOy9DODSjQvg1ATeuo3dvy0+DNyrN/W/QVLw1MjjbQIM1nVo0UU9A1kk9BJtMPEMZC3Bv3zfwCVtv4gdRPPvnsW/nOd5BcwHqDy85LWGWb+8wn1V4b/M2bD1ChMFv+DwV2/9v/DdBARBv/3GlcAIiGDqWZwoxyDIkSbw1SzNlaaeI/HAONfts03ASS5XE8nAWPt82t1wcNTYyFUgtcB5x5XAh1XNwJNzScCcCS3cQNJdCKjvOUQxnCj7ucDE12kFTZBC1ZXA3MktwOTIoV6IDTkmQQSyL2V3lNKI4kz7yPlNNSTeLWkQ8ETRMPhxwSzvgM0RD63BPQpxg7TFGcFS5AnBXStE9LHBbNsdQL0IlMuFwYDaGRVk3qtKacGYVUQcPV+intnBsS7E6OXYsBeBArCllcHRd1D+RcHixhXB7MJNGOw7ScIA/NV8hOhlBuDt6Oh9iI3CJCgI9KEvGT29wj0pcRqs9ZUQmNAZVCkzQRo5N53CbSqsaPWx1OKtwoAU3BswPYrJwcKZWCT7vOMY3uzXecKxL03CvUms/yEL8OMc+c1czPsQ4NTsmNyzhVHC8OrY09mOAPP88GzvdM20/aohYcMc2NFCiU9uRLWXWTB00CznoXDJAOEx2Of9ccXDXM0xUnzVVCt84jTMEQrQz5DfUQRxs7XDkd0pLC0FePtKNkHDr4L5w7jinOd41UDP6byox7Df4OVVw95ixa1Fw+0wdNgcxy3D/PWkFiTxhBjdyD3EGFsw5NUsKOBVhzEDAOdk1NHdvN9gzFHETN1QBKHEWT8wQyjYhNJx3uj0kcR53J3EhP9FJPUVZNbQ5/zQWaTJxKjMpcSxNsHEvN3BOgTX7bIIyAEX9UKM4QXIhcTpAdjRCNw5e2zadRdFxQgypcUQ4SIYIcUg680PRb2hxTQ3qSftxUU/IDYY+tG3AOdlBgJo5cVoBoIPucV5xX3FhcQNxZAeZcWe0BnFqNbBIJ0NKNZg/+0vEcXJFWjWmYYdStzNwctqZ0HF7BgYzTDJJscpxgTbhyN1xhTmYcYcCeTObENRNXLFicY5Ft8U9cZJNdjegQ/5J0HGYSrcy/DlmWlBOywitVXViGAY9U2lCWQKpNgQ06zqtBJpxqVQkDxw4Ckb9Me3QxXGxObIVKTXNOagDsoThcbk18Z6kcb0403HAR+E8dTxOQ2JEgTmoP6k5KwE4MyCtDXHNXns08FT0N3EyOXHTRENg1V+ccdi2OHHbOpI6BhEoNlRQxUScNJY2rludcWNx5z1KcekCeXHryx1x7k1JMi05LuMXcfQ1fFsdR1xIcXH6QzNIqEBcRkClfHIBc9xAg1IDQQmr7jp0EN3FrnILPmtyDkncUe86b0PYO0pmOjevSEA5x0WSVZwCn3Ibb8hyHjVhNYI/Fal8O8RAZU2pcidLJDz/Pig3u3IsOs8Wylb1Ak45jzciBH41lnI2NyAz/jiSPnNPHXI9SPVjHjlXUBByQzc7ckUCG3JHMj6XcHJLR2E5bUItTcWgE3JSNRXa6nJWBt6biDmKZIk3W0sUTelyXloycmE9r0tBVmxyZgKccmg+NU9tQG9IbzRjcm40eXJw42Nyc0d2cnY7/Z0CbSxyejPHM/czEDkiNuM3BTHKiJlyhNDjcodGMzmoNXoGdEehNsY3EjHPYO1ykXKTOfQ3czuQNCg94kx4cptGizj6OPlyoEfqO8poqnKlNeehBXKpwzRyrEyQT5U7+2Y6edpYYXaCcrU44unGcrk4qtLmcr1aE01QAa45ONsIS8Y0InLF28JyyFA3tYRyzBF4MxAyczV4PSBy025qbFs4zWOTctly2z5Eh4Zy300rcuKZn3LlN7FAbzxnNLpIEjbMcuwymnLvBtw2GTWCMfVYkzVLOj6OUXL5NjNEt3L8QMNOyzXuMuS88XMDMduAsHMHkqI+62FfNLRvLgdOcw9qklfNcxNolBA4NK9bokBTEAlJp1JVcxyIShBsfZ05lHMiBSd3SjrKO49zJzIFNgSDHnMsgNNzLzz8czFHdIF4c4RzNkW+RGlzOjc7PEE1/WR9c0BKWHNCdZ1zRZK8PLACeT/qR8E3gjTzPeRzTxA1S9KkzHNUPaIyXzmLQhw9+jzEd4oEqzlOPwMPYHNgAtRzYjoZNdiLKs0lAck1HZ1Kc2s1N0ISfKc3Ij/mEAk38zciWjRPvDTCCKVzeUGVtONzfTlbmbZzgTYvpdhzhTPqubRziTcO05tzjQ5XOQdGY3OSPPs6wTo3U/REnVfVPy1NLi+XNUhQxTX6AmlXKE3pc6JaA3OlNadzqFPMRz80BjMANpM6VzXqS5Q9vDUSQQpHw8kbc7fUV98ENI0xzVnLc75UwRBsyQFzwzhec8VWSDNaTxlT/HPKMl06IDhQZwHwvDRPn1I5KDQgWctz1j+kMppD0ekpc9xAXIphNuJMiD+OXjf2hHPlQMA/ajNTSXdW4Ezuc+2LPnPwc06f13P0UmZz9nDwc/k9pohNfOdSC3P/BO5u5HQCdAw1vDvAdAdWYXQJRql0DGga8R50EDjfRapRDT81NiTkU3QYbyoyCT4zUCRNtkcGek50IUvGOs8x3TJdnrZ0KFM0w3p0LJWLdC8CjhLuePt0NDv1ZxU4z0tBWy+a9HQ8OVV0Pp/OdEFCBmS8dEVWSES3SvRMLE/MNwg0m3RNnJBGiDTa42N0UzQZPslJMTIcTEZ0WT8NAUpDzT4cSiV0YDpIdGM/NTqnPpw0AVq3RR5AqzulL9M9ZRRiZi90cT+ETXp0dQNJRyU1zbB4dHs1Sqa2dH9LZDNUDwY7kVLqdIahznSJ5Q50jD6RdI5u5DHnzzh0kzCdRRQ1hqRidJmifXScPUY2qz3dD2A+vTT1NLqvqHSmPj50qUdaNcFDwjjgY090sDl8dLJV3EdqQvJcHD9idLgLbDj7j6FLJEIPpAt0wRgiBt9AWDHyQamah3TJOkxT9HTMNhx0zjW0PaM1N0c6dNTyHXTXTFtBFj9JEdQJiGQsdN9F7DXoTNbmuXTlPIZjZTYtNWlIkFAKRYc2LDWRYsR08TSvHLJcjjxKFaJTYzOyVsh0+2d9uox0/wXJdQE8WQkldQWkMXUIU151C3GjdQ5iRECSP66pKnUUMod1FjxfNSU6CztHQqVBI0vYdR+eAASJAkU3726KMwh1JpOmdSkzrkLBTbZflTcTQcJUTTJHTHYC00PKNAkNO3U3TIh1OTc3N84GzDohLcSm4XVBQOB1RORUdUcWF33edUtCwTZwOe11UKeldVM82TVFdVZinnVZT6pHLkBENSgQ9z0OOaA1loC/dWQ8sAcBPYNB91hMQro1PDn1dW5a9gY+ePp1c2XWZpzsdjoOVIV1ejhIPWBEKnLGdYBvIvVZ1+R/AnWGN0t1iDuqS6Q1Y3WMOqc2KFXudZEy7zH6VTkzEAQbOPYFvUe9O611nDJ0R8Cq6nWhSLYyP3bkdaZPGTTrPCk/xV8CA6w6K3WuM8NJ5zq3Nl9FBVBjXqFzcTPDAZ0GfjTHMJ9ffXW+BZOtX3XCQr4yUXXFM/lJqfJudcpW9TKPNTlJpz02ddGyjLZNk4F5K3XYThp129r/dd49KzeCdeJn2NeLNDRGp3XoNzl16y+Wbgh171ZmmiJ18zPOdfVBMzmjQqhCKjltST1VtkCFdf5m3zi3NexhC0znWnZSVUZTNRVUhEhKQKAx6jQPENk4hzVTPls9IFdldhQBEXYWPU6JeHYaNw82wAJ5PIs9yTnjODVKnzP2MgDLgGBeRMtvtTaiMrg3Z3YtQ0g7XFPmVYgyjpXpdjVUxTv7TuBaEwS5Qyo3aeKQdj8oQgEvb+h2RDj/ZdAyRGAiPYFQ807ldk0GlEMTNcYQOExbRQoxPzHwMmwOVk0nAjNGU0DrPvV5+HZfuX92YjION3M4qjyGaLE2UURz2cx2bFbDQPx39XZxXvk5NQRaB+E2m0dFRplKenZ7nkt2fkHGa8xEjVMBXXR6thgRdoa16HaJd3x3ShA1OhE2z3J2M/TqUnaTPEYHnECrBKsxtTVhW3s6S0gLNfpI1AW9dqBA5kefdqSIQXanAb7yVT4ECGh2rAfEM0w6MQq/OZ5CujqGTKcy2HnMdrg6kTn6N4o2kvIc8GR2wFPmPMNCOHbEP052xjCfTzgHPtlidsw+Hz0sZts9fu+9dtMHN3bWTJA7WPdwdttcRUt/DKpFOlS7WSxApjiXMiGFv5ICduhQEnXqP8VY+llycv128GSrUs9Hd3jMdvZIETabAXZ2+jgpO/sI3EFoOUd3ADVYS5Wp43cFNsM/fDgyWEs3hkHadwxCJT5bTHZ3ETlXYct3FQbSM+xFQDSZQHc4jj8IYJ4+W1wyD2MwAnciAlp3JUYWSepBnTnBSIN3LAmSZdBVADO7dzIzRAF2dzY8InqAQFw7NzNaUBt3Pkokd0FAGX+Cd0U6ljYfc053SXdLPAA67kBfNfSA41S8d1NEwgaKQVJuwTbWOtk040FTffV3XoYld2E23zxld2QyS3dmIhg3Lj/xNMI27QX1RL453ndvQag0yXdzOrl3dmOmd3nJZECdd31S0neAd4JGM1hHd4Z4TXeJd4s/sVogUOV3j0hTtdh3kzl/kOh3l0FMbSdkF7tCd51EVqAzd6I/rURzNRA0kH0Gd6lBU3esXjc17newNP6q2oajMmx3tlT1eQx3uk1RSbN3vlKHMtCKRHfDREN3xV0YWrt3yIURQsIyczlXO1mIxDqnXWI3WzYZNP47UT6FN/N31zVgdnp326Vjd94x11thqFh34wN4On81qmqpd+iedgF2YY08LD0Dd+4RMTa3DwYx1Xf0ih1390MzRy7vHoLUd/5MK3GsP8VdYUUFS7EHPkC9d4FfklAGQ51ObTWTYn589HgQZ9iJnXgUN0k31iIYNUN4GkWzNgIDu2KqPaFU6J0weCNB/E0ZD2BEQD3iNno6p0Y1MhE9pHguMd0BGlUceDPTQ3g2OmE6bjiQNAh4Oy+DAX0zUng/4lmAonhDNJgGBkdpSt2ZkHhKcKJ4TTYVeE8z4YGWeFNEFD1gNDs0pQ/1N6FZPXhcMkpzQHhgBeA2EKM1eGVC41snAss1wzXwQxNZ03huu6Z4cXhzgb4Fwz7OdN14eTQWOaA/2U7BMhl4f1RVQkwH4EaIS7fo+HiHeIk1FAHJsF94jki0ob94kjPOTYZHQXiXWDpkXz60OhV4nEglk6Z4oDbLTwgBwHilNfpEdjbUSSc82VKzFNY9PNQieLAJEIBCeLQQL3i3DJ94uTdETJ821zuSSO0zUqXWeMJ4xDX+Pz+NTAY3TBBZNnjN9Gd40DYNRm9401pQbMZ410zNUCczzgJOeNxPPjW+BxEBWDb/Ov9/rzKrPuNDEzl0PypMpwGyVoN47UM4OFUxxEZ8SfE61T28MsMyP3j3aZQ6ej2cdDN4/QaXeQBCGIAUeQQaPW92eQhN93kLUilB93kOR701lHkSXot5FVZdeRhYGnkaMkB6ST2QeR+jYnwFTJd5JRAjZ7w0xTUVNEV113ktBZNWjzJTTVA9Tn2NeTU8YjVSMk1StpR7S2g17lulL5+MUweUgBJ5QzAVOPU94HlHMg428oc1eUxIQUGdNIowXHlRNStJcXlUeVY3qUGbPPs2hjJTN0dIoxDDAepB6THZeWI4aHllUpU2VDazNUU4oT/VeW00NtHZeXE0jk8reXUBLXl3S1nfyHl7MgI1wnl/UZZ5gjoTVPdEb/nueYhYS1wSOgh5jEehfXV5kALreZM20Tao1GY+vZIJeZo0C1KMODpIijv/CYhFsk1JtuF5pWCkZYtDiFRYOqiPmnmtNV3WnGP1ebJIJQNLOm82x0icqxV5unM2eb15vwaaPE449U11NdoG3kJgOQU66zMOTz8z/UseR6F5z1YwbPRYCpnuPxY+sHnYSLx52j2hfKfM6DZBO9h54LASeeOC3M7leedOp0TuO8EHf3nsRUV57zk+ZrFiUHn0WWg8OQE8OMF5+kd0OdpBf0+qU9k6xTS5RNhCrjThOPV6BzbHPCl6C5ramDZ6DzmEehE9KHGiehVQ8Ev1Auugb+rLeh004DJJQjJLfTlnSK6LknomYtk37TJoASZstHotv8R6MPmKejM9PWGhBO2B/Xo5RMoE7TM3qb16P7NFekI5O2Y6WHJ6RzqhTEcFk0RPek07xzdpRRoP5OzgelSKe3pXR6Rnm2JEPZOpJ0CYQhY+ekruemFB01TFXhLE7HpnQEgQDEJjTAZ6baA+enBuyHpzOINbYQOyWiD58Xp6FSllbDfrR+o2azTUM2m3O3qEeoZ1M3qJPd1BlTu3QnubJ3qQCGY1UDeeUwA2jHQ8S0s2AHqZMbVNHTauEk8yXHgHeqE9bEE/VQAE7NrZeqg7vzq7ZdA30jKSMdtGrnqwyMR6sz5iDNxEwNsAURELuoWrerw/BAFagGB6wT3fOXw2CzcKgRV6yAEuN5dT2XrMWg95JHrPMkYyTE2fXwOMR0DWQttG0pQLetozyIClet5FQ3rgPfg/+TfUOMo0oXrmgXhF9TZi+n967EZUeu4FejfWfzp68z/rOMIBtzXdNxYIaG42L396/AUWev4L6l+sj0R7AzT2ONxHXEhoNjsIJ3sKVuI3PDKxew43aUL8NiI8B1SEzgV7FgaIpEF7Gk22QmM5K0ATYaKg47cLOq1P50DjdiwyjzTfMl48a3srPPl7LZTwezBV2kCkQS10rzwIM7p7z3s5PQ4xyXs8RbJMtXs/NQFA1lM0gv97RQIwbTZ7SZbVe0xJPHtPPaIBojM4OgymL3tWNb57WEEXOUk/7jPCcH97X1SkSdTiL3tkZfR7Z0aANr97ajaWe2w1RT98NMhItkx2EMNcoXt1Og8z+TmS47R7e0U0+Vd7fw+8iJd7g/dFe4ZCmzZROKs9ZWcVjOF7jjfkOMhnO3uTkG57ljwTWg9v+ja6+3x7nYowe58BxjSbe6JWMD02UKM/cwTsNqZ7qkH2TAw3EDjyNsszOUf0e7M53Tpzd3xRzzhwDepecHu8YmQHKTQHkkd7wjZGVlDcIQFJsjJ7yU7aT1A74DYiN8Y31157dRt70z9Ye9Y4wj+tBxF72zqDMfI2sT4se+BMRjO37Bx75YCmP2428tGbAd9alnvtbUN78DHhFVHzHHv1dVs1ATO3M7c3DktBeut7/nwFXMB8AjPze/98BjK5X0N8CkThMkByXnwP9eI3vTyFEXlV3HmEfBfei00gfBo0xTotSD58HwhmLu58Im5idZ98JgGApR0x4nwqTwZ8LT35Px8ybJqnMwRGyDpDD2FrF3w4kol8OzeDh5l8P2TjBJ40UzUOQOPGynxHNPVC+AL0fEwy2zMqQ4/dZXxSNqIx6kYxXy5KcEkoPTYxxzw5QehbD0rLMrNYGjnkSjR8ZD8NPs1FxnxpOOE4JzQ7fG1BSEQqSVPfjDVhM1Jfkj9qfHc9IFRUD/V8e1boEXtDPDH5Qa98gjMPOGt5W0bBMxFjm3yJM2cBBNW/fI4BSURXOIMMhDXNS7GRr0x1NcSP2RC+UDU48kEjU4NGGnygN1QzLKDofKVula8tfKo2IWbXjyR8rw9Xhed8s4l8fLaudHy5PHg6UUXUOhN8vgKufMFHaYQvfMU1xIG0QH5YAkhvWnBAnUoefM4zaGb4OvNOnz/UPrOHe3zXQcMwn542M3B83UGoN6k3DAJFSGg3YWjUS/U38F9VXvV86jknOhIybUaOQehuCXzyPnNJMTarQc87ej1KR75KqzSvfPzqjHz/N2Y/2T6V6iR9BTNKOeM3qTdhQXlWnn0NQXR9DwX2NZU31/H7OX8/ujcTPrU1WXcxQNZzIH0cqBZ9H1fVM2V9IgbcO0dOuTI+Qf9yJrScfStG00rARfQ3u30wN+Q4GeIB3UbKjH03S6RBHTYafTs31AGzQGdFOgaLRLlMXnI1P+5I9zgsP2p9Se2CfUw0lTr/Wlh9UT8m8Vh9VTyCOAU73Dl/QO19W0cROuc9DH1gOwN5LX1kPahItjuUNMW7FH1rAelA2jmqfW9TlX1yOKo/8DXJX5V0PHImPYt9euomfX0y0lVIOFczUllCURlznn2GBeBcbDNpL9hDE2B/PD9S9H2QNTwIZjbo6319lj5YATk8e1SEfZvaIjIUNJbjJgXISx59o3QsBLJDMamJjWF9qvAOMy0BOAN1snt9sQepOdpvO6IVfbdkq4cVfbtPN0FTP/B5QTn1NZZ0r0tPO5I9PX3GPec8hmXzfcs1xD/1PnQ8RjjiZJJ90za2UwFZgZ33fdk0h33bYD28cH3fAV1OgVhbfeTluH3nPxY1pVvQiNF97TbOPlJ98EgLMo/3iX31BJtYJNKAffo2un38OGs9PjM3OUk8Rz3WMgpNIN6Nb+x+CH4KNTw3DjjCRjtmUH4RQLkGP/yZfhY/gTLhPGWNc2rZfh34Yn4gRFdD/b1wfiU4l34nOQtXfDoYPTY0kUzw7qs6bkSBOnYyS34zOk1+NVNpP9RFQzQGB8VDmD0YawN+P5T6kcV+Q0H/OrxyNUq8Mjnu1hYXRzb1WX5OfcJ+UTWxflM9HbSEflc1NOC+Ab8HaX5ckeB+XzzEM07y6/MffmVIkvKFfmk/QgN0fmwyoEPrAbfnAhDKQDR+dO56fndDNAflfno7JjHhMyFKYX6ASa4zQ/uHfoVYT126QTg3NTj6BKtqmbOIfo8+3/wyfpM38zbwyPl+mEy1fppXf36dOsQL6v4dfqJJcX6kQrozNjMwfqgG3EJPlDZ+rlKkPbw4oX6yPEZ+tFeiNeA6xTWSMkFnQzvENId+vjdmWqh+wjfkPz9MDzWYNBk0yH7JBb05bIm+fs43P0BJP6bxJX7U5vF+18Tqbad+2xYXNNkz5FaoWmZ+4pkAOrtHTH7mRpJ5DFtIfut2on7uOFVHqTYhfvJSz370kbJ+9zy2NUV/dTWANKB+/jgZyn9/AjICNkruW38HOZJ0wTolOUd/DDQNNegTwAcyA09A1n8T49R/FjoSMmxFWTtFfxtQJ0fDD45/HzMb9Gd/IzTuRG+MB38oNKJat19VfyxfAj8IPQkH3zZcRq4TkjjSR1h/+H84NT4vgzbgx6J/PjH8SfE16H9CB5xFWdYuf0c/+06qhed/TDs6f041W0ZWPu8BfVwIf1U37UUF3Cl/WlOlhvP1NTJAutF/YUaLMcQ6S39lM0t/ZxOSNkUyrX9rpfl/bjnbeMNfLgcp68p/dYjEQWgOVzSMVuh/e0BENmFW3EN9MgIFnUIJOWN/hDx2WCA56DoVf4k7dAFhhlB/jm+1A0VhDja6kUBCpzXDNIha8TSvFNV/m//of541rjoAOL4S7jtH04tET2WVf6gFQzcqUl0XCluhf68/Fn+xBZQ7dlK3NqEyBkOTNdT6h2c8VzM0CDbjs8l/wDLYi29/xDUlNUF+w3/JQ/Rbe9dgMmQyTzfGOpoHTjSRXdI1tzgJiN1/2J3tO6OMU0Cqf90yUUdxUibjR3/jMfIzZwXJf+c6xXAWocN/7DNAMwaK7X/x3wx/9EHxQ7YzYzKtM91/+lgk4yJ//rWDgAE00DXjXUWABkLsU5I/1ETQP06ADEjFPE4G9IAQNUA8QXe8gBVE+UBXNI40B1dtEPc4LjHXNuc3Dmb8gCJQMgWJpiaAJ2afgCoz0UMzQCM3gjxMgDBTY+KygDQ4O5IzPp6AOKC7QIk2HT28S8Y1/kyGgEFATzUbWy9d1DPpOzpdWFqks61FCkwKEIc5HTXNEXk1uEe+rQGAVULBaLEMC1XRgFuXqjTFO181bjpJOCc8bV8QecKAZrUNgGmykYBsZgmd7U01XdRFCoByN9Y+TTfvbYJQNV4SyTyAewSVQeORXoCANoQ2vPeqgIUGmjwQQZesGICLOJ9EFNBNNd0z2oCSUCQ9+lYfgJZd/oCZVR+AnD0sgJ771IChNiYzWj/fN9wReAvEgKhPbVG90xY5sDziMeJ97YCxP2RK3V75NqFJgmIYgLjXYG3agLwz1VuIOkg19EPogMNT1UQUBskwnYSWgMo5nTVTP/xCnEjcRQpSA1pwQoY3rjwXPdU0oz6mn3ec4lJGPfWA3Tt/gOAzyYDid1FApUCYgOZfoIDpPBaeOjetVYiA7wJGQOY4XW3Stk0/kAFpetmA+UCxNwlbaTuWRf2A/zTugQFGyYEEQmxVuUODgQlQ51Obs++BDgLigRB32oETqMKBFkBRgRk8a0+FNAaBHUrbQcI5R4EhrMFFDHoGSa5E2ESPQ8pMW0HEyI6BLTkDMqB9VYEygXqBNTSZOd003Tb/P79EqYE9M0qMUzpNBZOGxoFEP/fj24FIZ0aBSk/eOkgQxIFPM/g8egcpPJAJ7IFVeKqBWDK4gVo4LYFcVL6UTYFgNa8/BECsgWRWzVYLl4aBaU8dgWxBojqG+HkyS10UNyMBsF6rAQNRUkBoPpyBej7phvOGDKc8NY2BgKRbgYPcnIGGMcGBiISxgYs9oz1lATRMMgecXBI8bwN0NWE+xzktAX9QNzXiMvhE7wmIOcZplDaLbwZVYz+tTJAzA/yugacYcTz/OY3LYIGtVC9Zq61ZWyaBszuaPP8yNjjmMw0+01lIM7pBxvypgb8/xT+maT2BxAW+l4c4YoHIVS1J4Tmpgc004C5OMyoSTzINN9gyJjMIOQkP9YHZNAoBOTXAAcCB3jdzgxCB4nlPA3POV4HnOBs3CZRTgew8OzVsBtI53Tu5M+k6lkB8Nchb7IH4PT5rozT1Ot+BJYH/lsBEmE3pggQ6jjhSRB1DzHjNggtFBTthPy1aIYIRSMhrBYIVNI9r9YGDghr8kVftQ7I5NjtvR9QzITyzB4IHaVuEgic9k9T5VklBFzoYgi0x1jTGM8g87ALrNlhE7oSVgjdBhDaZNqJFBThQNPUyBzgX96yCQot7gkUJWzgOcLmCSllyQzg0R6u+glBiX4JS3eWCVTMn0LT4gIJaORL2wYJeNoZFYER2WrdVg7i6CYhPWVsHRgkP9TXogmtG/0mPXStwoYJxSRc4CROSNf2Cdj3tPlEP5DyjPu+o3K/Cgn+zJ4KCVzyChZIzgocR6nOnONuozYKNbfDnuTl0fDUyqExBPeA2YlXaNP9AXA/jQFw4VG/Igp4yXje9gqFOD0EmNFqCpkGpNMpByjyCVnpnaTtzStMztzTZgrE0kDlfVzNN1j3hOrE85YK5NYGwS4K9ODVD+kWHgsJH3j5ROqGH+oLIOoEVKUWwgs1t8ILPBL+C0TyMNTZLLlLPNMIynOVKgto9ooLdQoYQOAJ3McYCaZ/lguVVPkESXdI2CRMLOJI6JbOfgu9mCUwK8IEzuGb4O6kBB4L3CluC+V/AQbsztDHFkoaDAD2LSHdVw4MFA1dMWjr4F6I1pVRJRDUzzDi+DKo344y8gxMzk4MVMiSUaoMZAas3CTgY6C01VrJHRV47LYGogyRAATN2X8E230IlQw02E0wKSUqDLhDmgzE2mDbDAk4+MfklgzhWzYVINmxoxjvEgz84f6uKg0NKTWd6g0cEIYNKV2paD4NNagNGNYhNNgZSPjujBt9qA+KEg1hMXk7rYh2DXTwXMdtjIkAIWBhHnDtizluDZzScW8pIQDQ6UQw4LTb9aalg3Es4PdE1gDTcIQow1lDAXFSDemz0bwiDfpeZg4FK5DmcNI02NkCgZD44XoCjg4t9BIOObws4exRiMoeDkxezg5YfqUtEMuuDmwaWYcJYtkgHRP8x1zg1Qq7VF4OmSquDqECYp12DrIBoNxA0tmA2g7I2CDe7Q8mOf4O4Ndpqk03WOqGSj1AkOow1q4PBGulQMzjRPHVBTDDuO5E0sXpKg8w7lD/7Yz07L0wMnpCD1Eylg9dRO09Ig9szGDb0X5dtYfcug+IyAe/dg+YBv0QBg+k9aToTNjky5jrWNwIytzTFQi2D9D0Og/agMl1LMgpQMtsVg/0BKTH/Q+08mz4bhAQyRkDAMe42FTrEEKdCXTNaUP+EDkk5dxCEEUD2eniEFTkshBg44C0YMhw9ORo9hB4BMkaShCE1/QdJNVWEJZKONk5LFEw4WeiBToQtVeU4BlH+OYrd9DenhDQ6VIQ2XLJEVk/ZOdiEPGPwtkSEQEHNhEN7kYRGQRcQp+kHAekP9FIZ+I6ET0AEXEU0/0FMhFRLiUu/MyY/ST/ePjc4EEQ1NaOIDIRgD+Qx8AJFUeuEZjN2TeoyUkT/VPdSJpTShG9N6oRyN2fg7ungoSZAzIR6RSVWaTW7Tz7HH4SBuRmEhDpMBus5BDfIhIpApvMoNwqbX4SQVDE8jzkFLgWElkHGM2M8yVYBhJw3KGY6NUY8OkPYNe8JVTw2au44DDHFXy4zJnN+hKxJd2Q+MrM6gxE5PNnPmgecPEh3ewFp12CEuT6thLs/ToS9OPs5/4TAZm+UaITE17N46ITIQTsy2D61NCCde4TPcvCE0jeCUpkDVgO8Mfg2YERv/aKE3DMPBKYyNzvuNtgyBDbKSY9A/k6uhOg4RoTqAXmxZYTuB52E8E3R596E9eHFcFaE+QKOhPtJ2j3hWZ+FADwFhQJ8NYUFipaCpYUJNJhDv2eDOnk3PjHNTDw2959IhRRX7Tb3Ns4BcpR7TReFHDcsAYVKvDKxhSF6z4UkPVNB9kVag9aFKv0OhS12qYUwT21DzDzZQPw6NEncRdQ8AWHtRjhgZYU9NXAyZos2hUI8IDI1NRw1PEWHhUlVM4VLPbxx5oVPZ4uFUm/qhVU/FYVXPSw3DIVaP4HxJYVeN4+FYDMIMb40FDMOEYs0kU8fQdo98FdYBykzDWCePh9QjlVIPseKHTflGHE3QVEZOQg8EjquYcwxxDmeYNw4ZuXzhYE34juRPco8QT4MREQRB0skNtszk/wbhY5LnVEAAVk9fEmPPxU6X0zWNs9GhYWZNjk5jjl2EXtEQEkSCGiFoXcQ0y2FpTYrNqtBF3P2AjM/jqotNC5FQKazO/mFsjW7gU2FtjqNtsE0pkSceuaFvT7zhcBibzvDM/g36WGhOSI0nTlgAQhjPUfUQh6Fz9UAOFRVOTXUQKqF1gGcOHA+6kRDhds2FUrkASaWIDgOheFd1C+aNa6j8oXnQTldPTnkORI4WkCFgsGQyYXxojWF9ESZNlg9mDz/bfA5Zj2AELk8GAJpQ5Y+IQXDAS47AEdOP784Z0B23q2GCpDRhg00FjnHL5vP3YYTSmB1l4YXEeoDdQG/NV07GEThhh5c+oYhBkE2mzwgPks82fc+hilCYEs5RDgHR1W4DsBEBF+hAlVoODnRNQs5UoY3D1c1Iz5qAROGPEsyT2Q2s4ZAM1ZBnEMxhkVFWIZIPUo3sAXg14eGTja/VNCGUjvcRHFlTYZXSkucn4ZaOY+GXFZAPt8ybT6VeWRkKb1OhmU1yjb5gtw/rTbLVedHHwXDQw07zl/rQqRaPWDdhnU2xTr6NXQ83YZ6NxQ8jQcIXyE4a0SEnhyGg0CPOMI6CIaHAb5KcDHXPeiGjaeJhpBLY0FTuYOGlTNuOn/7gEBS472GnF25hp48B4agQ52Goop9hqU7CFIiP3OfjDtHAuKGrAfFg5pO1jNWOOUCS0PKBQpWzQdnOjlDGQ+PgJE8s2iQMyg4oUATjfuGwjetpsyGxkwLPdREq4bKQSZ3tVnoNuSG0E7gSCGG1DrHPI1J3Db7Mas8Bmh0htx4p4bfNNqG4TQeOWA4awlxR5w0iTeZB2ctIkzWM/c65TsbRVpEajYLdWQ6jm7BNaY1k0wXsuY9nEfANzNH3ophMjY6TDK/bPRV2v1KhwY2zjzChwkynIcLQUGHDk2pN6G5SIcTXPCHFliRNl47kWrPNpmISkT/O5GHH1zmhyLjsEWefAeHJwNzMkCHYkFGaBwDDzwWSNM+TTtHTDjz9kH2OFKHN4pXhzpg+Ic9TDgQ3Tbfh0FASZr9h0UPhlaLh0kzjTcUVN8y9zXBNLI4v0jXQBNnsIdVNVyHVzRWDClG5YdbvdLL0F+Nh2Bu7odiNsif44dmN7sPiDPdO1pGLjkfQlk7HT/8PNk3S02GYRA4kzdQMyCJaYd5NJyHezTLPVM7mTvKQUpPzDjNxreHhU57h4hcbEKHeW6HjcoRBq94pIeRNreHkzuWh5VBFzkJeyp5JoebBn5CgQWdWbwzSvR/Ofb9vDUUiuJL8jYCximHqkQ1PslBhEdKMjc4SKyRh7NmrjIoRc1tJ2orh7qlRIe96BCHwEkDOLHrXvsxh8ZCYIfIVe1BvofMPYMyBDd+N41njFpjNSU9QjLQyimH2DeVM25BlTbUVs2Ed4fgMzo7Jofjkp+H5gG3ctL4SIfrhV2H7kAB7xOH8kG4QzRDBzbGMtybLof6P9A2gzkOQjKH/zhXN+c6KzOpW7VNUIgGe/eICUdOMzZZjYgOQ/wzHGuhiBIxw0ABNtM3LUAdiBk1YAdxQZhBpIgfOvo7lU+8SfkYcTXOOKd2LE7xiCkxxVXvASJLRGbXiDA5hUHkNDYQ5TMGStWINz/kiDni+FX3Nrrnx4g/Uuo3oFreiEQ420RxM2Soh4hKdiw3xYhONZNLUjXgOrVFXm3gVnGIVlaMOvOGv4hbSAkCdUHGTbaIYEUpNMFHTEZA29RCMkaFPt2IalVjhZGIbl8hiHAz6Tc5UmY4ZAitNA6Id3Im7beIe/SYiH5zEIiBQwEGBkF0bWid6D+uPuiZXVaSoIiIjV/5iJBWP3bgiJREk4iXOUrzGoibiKdX2zZPhhWIoTVOOuc11KIqiKdKTUsKXdRnIIitOV6Ir0RzQxZJqTf5iLQ5yweFB8OIuDLjM+Bh0D8PBWSIvwU3O+46UVHGRyWxmIjIO8oCeTgubyo3+D34iM8zRz0OY747BTaVq/2I2Dn+BOo4xgIkPT0BOYjfOwcPPznoec+I5WJERik1RQEQUQ2PpIjtXHM5Bj4zL8Y0sjbqNsmCQge/O1IFA4j5Ni9DYk+4iP49y0Y7U4yJAj08+Tl0dYkHCGYBWpG/txhJ3DfiiQ8zQTvcQh00U543iRbJ30YnNkQBcTqMPn5rITtCmpmJIQ/WN4GB7okmaDSJKeTpiSxdPUrjsz2JMTJsMpG7m4k2SJpBHTcQXrA2CYk8Q7+JP7EbiUJbN4lFU/U4LUeURo+JSl8DjGOJTmgHiVFAw4lTNwKJVVIDfb1Grz3LXhI6FFbgQfyPPw5D0cuJYjkpOKzuvolnUQD0mIlrVo9D/DJDiW88EFXciXIBIga9NRYyP0UkPX4DsgPaUUA2J0LwiX49RUEcbMqJgz3JSplCNjWPTDKJijj2RWlRGV6RiZA0nYmSRN0ybFtuiZbJ3wQ5fr006gLrS7Fg7bvkiaDJcImjOhgzShDmU/QOV3La4kmJrGIYia44OkjcNmw1Y4mzM2RA0VFJibi5ZexRibw1rmJhicA66wE8O2qJxDxONz4/sXJ2N7o3K0gqM56JzUnOOOEFv4pPidNJA2GHZoqJ2AESNfo6AjOiO7k45mZTieFE7k+8RsYGdDn6ShI7/jMITem3BInt3E2J8FQ5ifOTJIn2T9k0FqvgifuWxjKQQ2p5EUUJOnY83VNAigWRB4oIOvOL+YoMUKCKD0SeihE6FDq7N1YzCUXRQrhBMzawOKlF9Gw+ih4zm0zWO7w361WDNP841TrUTtZYJKDAiitBSz9VPEo4O4oxQjQ7p0nKOmE6dgvoPtdKgzZ/TWpuD4o+QpCI1GTaau4FnD+gS0v/84pIBb84nzeYEu55ZES3PHNBFDYyaFCKVEKQ+IeKWJ6Ails7ZXWfUvSKYIpiStVJjDHVNLhdFG0Yimo3ojofZYs3DzO7OvJyTIpzgtw2DE2pinc75z3hNRxWqop9NEw6H7PzioJxEja2SZA9PRDUStUBojP3Q52LPYqOQYuKkTvBNKGKlJVeN3VCBDLxMdeKmjiGRAY/koqfNDGKoXSFA36KpDNDlj6KqGXIPag/rUYJPh2Krge/M/mVLIq0Ojc070fClUo9tZrDiry084q/NVAHvzZAb/mKxTpqNKxV9zc8UUCaw8iUNlFZuYrQ7DuK0zqRT2o3HUl3RBWK2jaGitw2Kw8uiuAK3+oDiuShiURWNoaK6GJyiutA41I1iu9LMjZFNLBNJ1d3ivYw4T56ObBOaIr8A08OVza7AUk4XlFSOHBYRYsGiwhT0IsLPyRtP/0LMv4yqaceixOLFUH/PLdVcDZYPZxDuwEpqaWLH/dniyJe0EBaQWI2JYsofkE1dwwrODU35DQkizBKXICIizQzEzlJQlmGzznkE8AHMos8P5Y/vzh7BRZi6jJVXhE0BItFNPoPjk9MTSqLS2QQSyQ1NTZcWohLQT7yi1OLWYtWMwiLVItaFSk7Bz67MgJnRYth8p+LZDZERww17otoR6QCZK/KOh81Z0EzU7oyoD7cR3EtxGcr6d2LdztKfxeLezJOi30JEE8/Mh8+9DMqSHpBFIuFP3VBdouJWQU4NWIYbJDLC4uQAluLMIuURUAz9DZ4OW00IzmeNsY0pjcJSWk/JjTORxOLozwNBykBvj05QXw8IALgi6sYcQEii64zSzayko2LszipOBA4ezjiQUtEIV10O1ZPeYu+OEaLwEFdOeBJKI6qi8Y1wQFLDkQ1YTZoMkFDnalkRdVDKjSKwFKL1Egci9dCYEeXDXNMR0LHAQR0BU2YPqw+poviQRc+KFTei+dGhT0Oi+qBjYvtwm2L8ElPj5KL9DlfAYVKnTayMzg3E09bSEM5/T4ki/80R4wBMd+ebzMLNrIPV+xQjAk2JzKsOxsyoKYajBA1/TW4RCpI7lA1NDRzpzy6ixRddD7z9M8I3jtKQFwyQ0pGM1JG/0BCNBQ2/TU8TvEPV1GtjCxLUUX+Wm57KjaUjDI+gDYJSCpEskKKp3WMOkMq8LmPzIxAVnyMQwG/jEU6koxI/KeMSwbSPLWMTkHTQqU/+ztCjFQx6DxvSrczS5tCjFs5VDz2VAQ2BIxgNm5k2i9/R8WMZTpqTm2MaQUdhav7B4xu842McTWSXdyMdUJYjHdJwox6tvCMfT6sQj+MgUttN688LjUbQ7uMhzgqB6lNSUKBQekzETQNjI818YyRBylAQlVnjJZF+DoRDkM7wUdhf3GMnj3wMco8czpLNCiRR4ymM7BE+YypRAQ1zj0obWE1pUnYjLA4EGvMMuYyIQOsUOs/ggNJQIySosgejL1m0knCjMEJSECANrs14tZujMgy6wE4BrKMzDZAQFQ3ZzIzOdw2Mk9/OexYZ3eKU+Z4gIzaOFkKWzVOyY2M4JInjOM8jozlTNFQ1YzpNsEvukRmjO431DaUCt4yFwNWY/A/4jdpUo8HaUEmbHXnC4z9YwyNAEb/R5Vqe28utleNBwWPjQoBHDuhPs0wAkDtPYtJ5zwiOAc+0ToVTYCNGEFRNmw6E9MZjR5FNEu0NuI1PEjTjSRT9V8QPx9G0lBpPLo2AmuXc3lWzU6qPLVLfUuyPsmNNEoSjTY+4zsk2BiNOz91PzFMDNI4jUFNhj0t5pONRkCQOOJLY0pwRQJW7jj6QT801BDRBR1U9ThSjVVPEI1YQwxBmElVSE2NXi+6Mgw+yU6BP7pn2E/ZnnmNaIkCqc2NbAvookONcFCiPdqNdF8CjXZ9cTiqQGqNezJqOVo8dFYSP9C4Lo2DY+GNhvh/jYk1wEcyd4oyvFixjZA6hXJ2Bb1gS42WrLKNmUqZOUJBU42eWMVbL1SfXZqNpA3qOS9s9EfDOXuNqja/W2k5uzIxEEc4oVYWPDtvFo21R2pGKjd/Tzk+bTjID4Y1gzOAa/VHH3sBjcNF/T9uUl0PV43IOMA/8YcxaFo2HzZUNDE7ozgGNs+N0zmY+cKN1wW/jdlFWTfcbz+N3k1nSFMzKUO2j0mN5TIINAlI7TiLcjVml43trE8CVTaRfC6N8zHyZGwHEUmwjfmGwI38QmAy91bIjgFFHqv/jgVl1mUxPVxBYgpbc048AVpLjg85uj2hb3COFDgMSRmOGEDaOWYz/VPBjh5BhFksN3U/5pGGjiUtIg/0Mwg/q0GiNc6GDANLAauOL2pqjjJAX440O/UzZDlUa6E6R06nNE8xvTpEQFZdWI5AQYA0145EqqWOR1WJjkpiX0HoNWtQQjxM68SOUjnoOo4v00jUTFuOWDkSbVg5hDJJhBM4YkUU+GSOYjoVNXCUbDbKTwM6RG/mQKZAuWAyShI1kU+uNJlJ1Tc3NKxOjU0OOiE0ujIXTp9hYI58VDFQao6AhIOOgzu/joV8F46IeFM8O44Ljo0yNUK0Nu0yAENCTqqaLo6WQTlWMG4MMk1CgTVrV7+OnwIoOK42xo6jN6mOpYQXEA8HPjW6RCaLsI6tOXY+x3/njrIBE0hDVVd3r0aYM0A4KTVnP8pulj6sCGg0po7AP/Fci47EM806Eku/UNmOykKMQyuOzulRNQ83fETASxxQgI7VCUjaC47ZAi4zYz6RWoYG+I7fT1s5xzgIM+BEHTLZODqrKDhkrOGO6wECQr4znVTFMymO8THoMl84gY71NbBXbTiJBuFaNI77j9k2/zdOZNrtGQ/0Mpk8zwEuOoVRvI8Hu8E/ZIGOjwyAMY8PMnRyqY8TnJ+soUj3TZKPGTW+X348wwFIjx45eo8gS2h8p6TijyU25zoTWDBjaExVaFrGcDhUP/BAbnnOAlg6NDOjNokOwOiwjzgyOTVKQ506YY89YSaPQDTIPqaPQ0qrbZWPR5Qgj0pAUk+GZUyPTwtsgY2PU0YuUhk0kjZFYhiPWRAFM5hCNvgIL7pYaruAj2J7LUyEPS+PZ5FEj2pKnTTZMvpFvghmOBePcU35j3QfqUpY6Ik5BUOTOZ6PezwuDCp8AY+ASGjwn4Kbj4U7kXyn8iaPiml0YX9Nl4+OAUo8fEIdM+Y+Cn/Cj5YBCjYmQAxVgEdqSAs2JY+fUruPoT7bQcoPYTUXj6f8G5K8QEmPgY+tO6w4VTfYUdE0mjQvOhWPtTPeOS45f2WLRTh07Y+9Na4ROUgFUo+Pwkqdj8R21TUrRuSPyFAOj8tGJ4/NkDGP0BAPRkc82TOe3+TbQ4/Yj9qSvILnj943HT4nOso2pGg/j+WzgTIUMe41MkZiXGzE+o/u4fkx/AWTNyI/yfDmj/YyU4/4jXNddBEHQPUyEAInj//Gp5ACMpxMzUHakAaTX5AJS1870DfGusaZRTTUY5s7WUhdkBQ9ZT+eNktHHERPOz9aDzSjNsox4zapOm0/txE5XGKQJVXnO+A2xUEJNpFJ+TTHMJMiGDhGMeMHAURqOpo+ajgLlHuQN5aeBqGQOzuMNzRS6mhRkEGMGZBEB5zHQJBIM864bpBMNLKQTjn2R2o1dkFEO281DugQSoOQcDO5iEJZXZBcRkCEa5BgMpEysjh1RzZh7T9/Myc5uDM5RwpcAJBtWOU1eQZ+NQwz/k2JO5BnpZB3azixkDdxQi0FvTaSPUqnIDsSBq+Qg9xrRCQ6SWObQ5Jk09MjkIyPF22eD/xygpCSDy+QlD+OWh6QmDUlTy5W7jnLSbyQnmG1N3EIJfDrkKRAcUIDkKdDy0DwTm1ajTPZOiJ1QTJFcR6QskZnQOZcMkZiOZpHdD2BO7w2awGAPvmQvkFTkMFNwgIlNViQxXNFkMgyAlt7T8hScUL0ARyQzz/QkNI13jVTkNVHvjaSM+CQ2UIyPBU1PY2dMumF1ThIMtxFVJDk5biQ50hTV+g9aUuYODpsx6CIkPA1FFGKOAlFGgF4UKNPqjUjvEBvAvQM3nOQ/jgMTOdB9zPxOHRt05EFNz7nH5EJPrU2lmZlQqJ5C5EQRxE++DHoUOc7bzOhOZ4zO//skRsEujjSVRhro15IkSJPGpElU/U+3DHF5raRK0fHcMw5NWKqkTCKnvLEQ0NkipE2T1A/65E5AbAFkpE8VdaRP3C1kUI9/nCOT9g5qjZRM0M8F/0xkUy6yJFPM+RlzVloUuo9IDONOWxxxJFZd7o+ahNNRr9rnQUdvCORYjmjadJMzW3TSJzb3pFqTp003T31jayRcD4dNc6PL5F1bPxHl0hjkXpo4jfJNWE3NJF/OaqRgjn2PBU2kDwYOrM5ckl34qaRjEzUQB6DjpGROC7WApGVMkdPvOoTkZrsUpGdL9M5M0TtrFORozgwR8ORpkE4NrM4I07rW6KRrEv1OkpsMpGxdgyRtDtFkbZixkLuRwZT6Tl6NpY1iASckcDecjb3bo+RxT+ene0C6zcIOMSe9ZHNQncC5TTNRNiZNpHUAQ+R1r3okdlLkw5WOhNZb5HfNNRbuT6R08iR5TWV/KeR6U+/QxNV91tpPOU4LTtikfE6SIHYmw+R9tthkfmR++dOkf5D6T1GkgE2eVRhBp4Q9TY7kgdDZTvBAUiSC6G2Ai5CwjmTkhFxZpIUM+ZWYUmVNm036DknSsA0q1q7+buSIDTsM6GHgkefQBWSJziXteuSKxMLNmU1ODiQ6zhE8TWTkjQ90ZI3PHU8szfHAiiSPFfbYdBScZJAOOHNBzNnMmicnzVTPbA45EJZSQk2UU0BPn9U1lL2MxySUUJtZVxw42siFNbNDUY1PBtCbDvMO4wyOUVPQG81OktBNiBjm4MvtjaSZzy6sGBSIkaPuJlLf0hTMuACRVTJknM3iJJ1dDxvLZJ5OrfdmJJ9NtU6iXjDQQ85ETHfO7+ShYm+koiYppKLvVqSjjwkOwBqAz3kO5Y4cj/ZRCCSmDZrM9/mcJKdOXdNVkj3NeWSojOYTfeSpkfhEBySqVSokqx/WpKvbgQ2bgfRQAg0w7Ihc7ySuGpPkruSvTYoUwA1MpLBOXQxxAu6TduSx0zWOdjHbZLMVIxgpDgHUgM07ZLyktRk1ZLWSdg7zzJSj9kx6nUOQ5gBbpLgNXBuNjpbkuRC2j5zPd4TTUEtisiS7JNCTyGTRDr5OBdRkEjJk0oDSTp0M/ptgpL6OPY8bwI+OiIzRDHsN63TcZMEW4hDE0hvW9mTCVbHOwdUuJMOQk+TEQlIAR03oAZ+NvtBkUyQQfw9+HbHkx1BgDU0Mm5DnamykyQTTW79kyham5NJkyxfxT7qMyg52JMxMj9IBznXAtKT8VrwkzmTWJM8WwcyP5M/PeSTXJNDBww6+ZNGlDqTSZL1QOcyP5NSk09gP5NNk1MCdavSk1eTO5NaURqTXTr5Mj84BzsHvKGTYz5Nk2WdfJNoRlg+jlqGEGQFHDRMN4FncNNAk3M3RDdiPrv7xAbXk3pfmwTqk35Mg7smddXIVnXQNFqThaulNECTiGLIR4aTm5OOYguTkTLwS5bl5QYALRh9fJOZM406D5OcXvWTn2z0NiA0o0gFPYHrxpOnSF+Tqnmlk63QWjM5O8g2ygv3UTla9ju/OM2Ttz4mEtOTuzLEMucz3VJyk8ABr1Hak8QSDWoD6buTyZw2N+psgpYj3BOT4pPRlLOT1D3ek9ZnfDkuesGT20mVLcRDNKc63BOT4t6klLM5u1D/ARtAiTfoU/RfIT+jNMST7lthk/DJG5PzYYmS9G8dNTOT+JR7NMkfqVy/k/5G+K6AlAI1Wz6eOeps/Dd8nbmUCmzGAo5LZpQP3TqUEpNHlBU9E5QqlBlDd0KclByBhgypD9OE2pQiPBSUJFnulDkBR0BEP3WUGJQsS1+ULjwUlCSUMToORDuS6ZQ2lEuUOZUElE+UPpRYlEGUWzdnlFhMYTzElENP0JQ4k0eU65Q9lFGUWDywhE+UQ5RWN2eUWJRBlFszKUqaRPE5kkqDlGFFXjuSRCgyYHKSd6o1ekeklGpJ5JRtPpVu8JRxMzuR4E9UlHYGPjZYRxy86jTuO/U7CZlSlIGFYjISNVRaRGv1T8yUiUtBPT43D5SNcbSUkFwcEeo98JH6Nc5EcTwVQPw7+zm4MydNG5SeN86UoFR/lKM9Tk+DaQZZvDfyPgRLSkOWeE2UrjoLlNhkX5SyPIKU1UvDlLfSuZS67YmUvT3+WIY3KWg4lNuUxLrklMcCjpUDlMtJPZS6UUU2VZTklNJT7zyClNVB5EmPO78z/ZTalMOU3V6raplm3zhsM2eU0JTlSY+U5zdxlQOU65kBlO5xY5TxToCVAZT2lQT035TtlPtiCJT+PZRhOzpMlQKU90k9lQZHlQcplQk1M0UaNKKVDVZXPLOVENi9lZ6VFIF4llqV8DHBlaSVHJYHOAwx222Z2jqVJDvOYR9K6pUplRyVLJcrZcuVjpUzlX6VNvV0lTkGlDiOW2GvRJU/lXC2JpVyPLo775WwO1JLiJVrlUyIDJVPbbCVUlgYlVRAw5V8lViXK5WelRSBeJZalaiVYtUyBZwyPpWulUaVaUuIlWs20pU+lW+VQbYmlXJ9BPOrlXY+yTvOYR+VekDDlXyVWJcrlZ6VFJWDlZdW4JWZiE00mZWcY78yuJWOlTOVfpcrlZ6VFJWDlZdW4JWZiE00mZWcY7+VgZWgllqV8DHBlaSVHJYHOAyVYZWqO9wFnDI+la6VRpVplbIzVpW0iC+VwwholcWVuzMylb1qOpXANzyIL5XDCGiVxZVElcgDvDTqlcyeCJXPNskCJVj5ldM4ZEu0UbiTx5Y0ldqWg5WSleyTRJZflm+V55ZUleoxP5ZXle6VoZXwllyWhpZelm6WCJZwlmSWDJZMlmeWGJZqljOWO3mTlgeV9pZwlmSWDJZMX1SWEJRolhNPWpZNlnqWAJZ8loqWMEBElo2WIjj8loOVkpZXlohJ+ZZ9lotARJaNljWWSJUslytly5Y7D2GWg5Y/llI+sJZUleoxP5Xsk0SWX5gQlnOWg5Y/llI+sJZUleoxP5ZXle6VoZXwllyWhpZelm6WCJZwlmSWDJZMlmeWWJYZlz6WO5ZIlgeV9pZwlmSWDJZMX1SWdDV6lhNPWpZNlnqWK5Z8loqWMEBElo2WIjj8loOVkpZXlohJ+ZZ9lotARJaNbWGWj5UsOv+WkmmMZtcBIpaWNPCgajlJlppNiZacM7A1d021EB6Wopdll/OWa5cJlypJGjrV7KiXD5axXdQ2ITt0lxUFHJcdl4mXSzWRlvmXeTbnND9F/pb9lsWXADzeSVM0yJdBlquWzZ3tTySXLpehN6uW1ZbrltiW7pbbna6W5TlVmB+W4pbkUTuW5pbAlumW1pbsltmW7z/Zl0yW+Zd5mCA/2Zb4lr6XeTbnND9F/pb9lsWXAJu9lzmXBJc8lweXP5aplwuWrJdElq+XEJdIlxMyh5cVBRyXHZe7lxqXFZcclriXuzg3lyBDVpcihdVOn2Y6lPI15U/UlyqWzZ3tTySXLpehN6uXMk9kl1qXNj99lqGXOpcFmC+XCZcqSRqXRJavlxCXSJcTl0uW8pa+l4iXz5dSlvmXiJa6AXHfRpdrl1sPYZddMriXXzSml2GXB70xPuuXZYqOlzCXaWCxT2SXWpc2l26XA07Ply6XZ5d0AiSXdlAcT0iYHztAO6Ey21BpMi4BSDl7Ols0802pl8uX45eIl8+Xy5fjl4iWupeQOSnzaJeUPBhnadnwmDCXrpdhlwc0NJgtl2aXMDkLNd6YKJemMq2YLJgSl6qX85Zrl/GYMkkamDQ1i5ezBjc14peEl8yXupcZmACXv12Ml8IyFLqDNcpQxZfHOm5IQJghl7iXzZeJl9CYAZfTmASX1je6o5mX2pf6l92XvzrZl+CXipe4MmCXeZflZglP2EJYBciBapgwl640MZfzlmuX8TQxl/OYFZf2iE2X+JgZl92Xv5gCP06X/5f7l7+YAj9Ol9SYBTsnmAgR7ZeXDFNYxU8kCCeXcpZLmBE53Jeql/OYFZf2iE00nZf5tO0HxDpvSY9QHE9ImB+Xypgil82YJT2Ll6SYKTpMMq2YLJgSl6qX85Zrl/GYMkkamDQ1i5g2BjeYOD7j2BTYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BOYZ5iYMk43/GziPq83ETZINLmYoC+amKIzEAWUM+CYpj5YS9Q4LjZLWS5FGuI1mK8FyDTJmLMxP5i1O8CYuDKHmLpWSDYnmL04q/enYgszEwgl2AnYAtf+2ALX/tgC1/7YAtf+TjWY3vYzmOE4MZjjM61oDWLqZXCY6V7fmOxDyj5SlVWY8UtyB3U+IcmxmPdMwW3wyKmY/Ab8Ph1T/5kBNGWZBDyamQY1b0x32BTYE5hQmQ3i/ZkQOR9O1pkTVgs35TZFBlmZGG+1UUc0iJkcMkWZHj+ChOqfyXAWONVOYjQiPO84C1+SA/VI01ERNXeZLRHqPq02F5kxRDc36BGLkdKZNzMqNkFhiVaoOdIyOwdqUs+ZQE+DPDluEGTaQ2I2QFQA99WZSmGNeVVBVTx7RPl5pZlSW35GCbMamVfqGZlaBxJMC5ldgfSZYDWnTK85RzPkA36ZZqr/mWmZa8p2mW49HWECmXJBwz2BmXVBzzYlmXmZezJvWqSDITfXRuQOVpmCPD+ZhAWUmYZLcgGdD+Q/0VsMmY1oZlNbmZEylziu8PI6C6CgmZhfITBcAaJ7KlbZNYHOOJmhPfBQEkYzPfwBrv+LmalbDwu6SJpiyAkHR6tO3jxvNyQ3REPwYwOZt0qnmbpfFZ1Vmb9ZITcQM1Y2LkS52s6Zx2l2NK8QCT/qOUWZzgX1NhdRDDMWL9mdepnWRBQ8dQlwsvKZ3ALSQZ2Z3zoUOUd001W+meU2ZsKxUOdzDj2ibxyZ7XnUWw893TznAo5C6Zn1h3mZ+DQGmfowAjMDQS+Z/0PwP0ITTTe3ULyaBUehP32aCAEUNCQ3LTqoM2g6nzZ/QvA5Y5oSOkg+sJoVPhw+nJoYOT/udTkfm864gJofO32NxZojPeQ4PjG9/S8yTTmeRQxflVYRN7s52jfXOjI5HfbHmjS1/Zo3QNE5xjPiVqA6OTtFQBO8D5pBMutGr0bjNmtig5SIPjQMC0szmkw2MlJlQ8xPd5pSOzBBC0TAVWNUA5pZVTNFUTPRPZlWzTfOsTGaYp3ZmmVA/kELmmk3DlHhmm04ZPwImnE44Yf6mnUCJDUPaJQ4jVsdN0NtYTtWW6JLClIDMbNs/GGJB9k2tjJRMdhJU2g4moo2hpqMRO9KvD4lk5k2DWruM6s0DzK8U+Y4azj7NutJmnhyPYqanjPDWSxCozTRQqdEbMaumqdOikKhMl2aqzhoNro0njVVmrBDlZqzOh+atVTfMcM4rDbUP4szsJq8OtM2dTMLMz6awTAuNSSaxQWUPnqayD7ROFdQCEgeO787CuLoNps2xFqNQnpuQY4Cmtc3UEi2PSOa3E3pqeaa4DLwNEw0KJrkTXVLXHXQnxSa6ggnU5wIJ/csmvA/tW7JmvTtLpr3PPs1UkjJSema/WIYOTo1LTNDr+GbBDobO4xEBGsGN2xR/j3nVEZG6kYJNgo4NZsRM2Q5JZsUBLniqZsYNOvzhVvQ/QabHj8IPtcBA0urPndFBE5iS6szyDVtmypF8jMRPMkEnBgRUDWZ9pszST1olDo2Bq+bODzutUWldZs+ARI7AIA+m0P4XJtGNeRB41r5VxCbTAQbP+Z5vjgMaGabUkLEl05U3wZxm1g5e0fhPEZNZ0uWm142m0PBRDtCbAS6BUU79Zram2hWjwJ3OOVjZTlBQQp1TwEVYYdMCk9tRAtSZjoxSp0CJY+VM8w4uToVm329NJuAZWybgjQxm4Q7xECYO8g2UW+HQS03mgE5RV45ZpuPUBIx/AX7YjY2GjmUMcJAnWNlB9k+apubAkYGrzQuP8gHaj4latWbpE8/SalKq0Ozm6oz21JmNgM1TkLEPq9GrlYRCoUQ9z02Ct82kz+6QUg6SkHCWnA52DvgBj8/lQW/NX1jWzvOm8U2qD+rUOdnSpvLRZg6MTZsRl4zPTWWm9IBPJvUOzY5rD+mWIY1U5vaPtYyP5vdPxwC5Wlpm+IzBm3g3VwQIzlXm+g3bpvq2Amb7TQe2X+b8TX6m/OILwLiSoMt4DSfm/plD5v9twycABgRRAtesFuXEGQ6xdI7nAkzYDQiNxtXopwOp12cEUOYpOGcFZNHnBg0ZTKtOcY9jpwevfPX/b5NnCQ1kTksnCfq8Dzad9ucLDhSNCecLxrpnDEz1KlNnDUFegY9k0I/+y3EQAR3uJw+AjM8+2uWnENWrJxGO9BEAZxJFwo53D/1NKVKXzxlRjgORTLIA1ecVMTnEIdOilcpnFo4VU6KU/mcX0pOMwhLbTMZlqCcZlGbOGtHwzTQPn1jaC/ZZt9JjDLqPuM1Vj4ESvScdTWYOMM4nTLdp6WcfFhINKZhFJyBPwTNcZyFPLUx1pyINJ03AD31nIzIO5yPnJE3OV6mnJTaBpyXbd+cmjq4P1c7ykClnKBEwjI6MsScpDl4dQecqLIPnKs/NDK4PST4K5yxBTdBmWgcXyKct0NYRzyQSZy8iH2cvxrpA8S4bZzEUklF/0rdBIk0nVXxnMxFJDZEOY8yQjM/nNJNHWmBnNZPWzq2UfsFnUEPBO2c3VoZnOCQ+pzjSPmc5l8+nOk1iz8VqWSc7oMDnPEEQZzzPMJLn5z3b2APBpQ1nPxyJpz+cTidAUlTMT+dBExVqHWdCDHwgmOdDOrQnQ8yPEOdNIw77UC2PQY8yTHei5CdGkHOMAKdHa2WnSBBq8eInSQ2xlRo6OOdKTqJXChIJUEHqDCdMDuVOt80iEtQnTUx//OpnTl4sEa/B2o+tKNknUCGRETIa6M+oTNNLSdM7G3PnUo40TsbN+Y2I51PMuM85jsSnVM0OWTjnVYt4LP5nVpDHTqJMyZXKzdhSc5AWIfNnWQGs17byGSdwZ1qTv2dbDIGnW4CTTwJMdhFmAOsQR4HaTU0nxBnwp16mdY24judNPo21DSy5K2dhDqSBykXogSb3kidizhzU4NMdzccLeA5W4k+EmII3jZ/OWpApUiKMb81JUEJYc9olEKBPlgNkJXLMo9AXz6LOldLiDLDS1Clq+c+nawz+vmpBnQ2yjbGM5NXWJXRnbZFKTVMM0Sy2p28pVGdvzMpAsw6+T6RQlk9pKLjNao8LD8fPzU1lj/wNqHGmFqNUkqd0XqZndRCtDfiAjRISlI+NtFEFAXJnd17Kl7TPHk6RwEUneOqdZ3mOFJOsTnPneo1XkkDne4QpxAMinOd86G7nfZcEmQnMmAx7jvunfx7Fp3/NAQ8m1hzngRtYkQ4U98/jtRingvaHJ4ObDmeEQFcMuu3wp4WOnqWUQn8DJ9J2gQ5NXABE1buAjaeIWNLYCJzlJ4mNU6OHDrzOybVqJ4tQ2KCi54xPbBPGVZTODJ820gHPR2eOZ47QYQQDzQu7fIC608ISBKeQ6+ZnkZIjDjMnkkPjkTvM+q2JkjuO2pBS1V4PHVR+0RzOkh51zaW/WqeWjyQRhY8Oz50OY68qJ5iOTNm755mg+sQNUY4PtEQKz25XcE4qwjcPbxgfze4OU9KwJLgnncy40OdD++eezz9/q2ef3AWNN02822ZnoRAZZ6GSNMP9ev4notMRp6NPd92xp6RNuA1TDS1NptJMQFaQw07c1rYOUE6t2V9np849TUcM5g2ZAFaUbdSIjn2nqgGBjVnnqvNB56uOthNYp6yBNo9udianrc5Sj5LOX81qjo9Truev4QENrCRv1wcSflHqzNMQMOeyEmansqCNJ7NBJoyslWBntI4N57Uu86e10Rxntk4nF10OvMP9J7eNxSLpZ7iUbie5DpHR8Ge5z1pOuvploc1QxM+6zu1TXWe8TsSnvNcxJ72MesBSezUnvs8tzwAnv5PHzYDBvQ14HsqNekyQJ8GPXhPbTh1ATlFXp8MaDufD8rOnxI3i58UOucvxj6uhTs/+aelnxxyNJ8fQ0I5ckzsOGc/Tp8lyP+fKDpMPLoEmzlSMcs6/TSwZxU1QQEyMeaJ8Z825N+fObWgnzxbB58+OPxYEX7Un0OGx59GUEE+UzsBn+Bx20b/OiJASGPwMBEx2J9TBxGfVj34NYRFR59bRMCfXUGdTEcGizqnQtcBQZ9kOWA27VdtO8+faVPZOSVO8UM0CCc8c3N+n3JNqTOhle44VDdsX5dBaEYqCUdIlp9+Rq9TX5+CR2FNqZ+FPaRJjDWlMmpCgZ+LBxI3HjM+Rx+fkDXSZ3yfkwypt+SflzIMn/Wfm2TEyT+fnzyLWjQ62UKhn6RyklUwMzgyN61xn6uZPp+uONKfsF7bn7MOQzwsMfA3rTVhZ3Q4l0IJPFk7Nj81n7877a0gn8M5Lp/FOKlPQ69oWoZM8wO8tC6fz091OH/7HZ/UOdczN3TyX283oTUNAUE2jDKuOBg8TkyfN6I1F0nYNldBqTb9/Qo48pTWp1qf7DZ/XhI1yjpLXQaL2Z/0D7bchJ/4Aqmf+jVBU+l5zjtRWrdDHVIiOdk1tEv0O91OfaAIPO+gCjU3OIsyTKXX1ZQ7jFUwWmM29zO5GBEF1TjlXhJEbkPRPw09uTrPUrtpdzQ6XVxLxqAjTvU/2TV3Dy9Dd6ApPho6LTbGoC1MYUHjNsU8/zU2Tm3WBaA2COsjIoXsoDs7fWbSoD45f1yeN447OknaegZK0Ux3PnegSLN7oEs0LqBNoE82IzvyUUc1UaBUNUZBxjPGuo+gWjzkUupCYDoVoF84CzN0Mzvdo6BlOUI2DaBoMT+uFEEeRUAzD/vhoHBmq/ZroHTGI6B3M247lVrxoHx0rwNLUb06CELCXJ6ghDLEggY2mIMxoIpdYlPDPSs3jjiSoJBEQDXAoJNkJ6CVkfqUX6CZNRA1naCcPxsGBjJLoKBShHksoKRB/0DASgwS7qCpL2AzKuD6yPU0aqCuSR+0jAaeRERcJ91lU+s6DDjhMOE1tW2eofegvUjboMAHR6DCf402mDYGQuxbLVZ9M+Ps+6DMgO6gz3I1S5yg0zerBzyg1zRsaH5LtGILq2kvl9gFvkOg4z3KTHGg5zaQapMPPwJFoOyEdqDvOHCfVTbCkYKg9TkSUDdorzK/Mq4x+aD8zCVU06EAMbVRzzlOoQRapD+CM+k3Zu47W2yhDEP9S7ehDz3BNAyhEky3QFNC+KxxoRhL9DbLNiw+HzbfN1WhH/OvoSLXq6EkNb0zSaEnimEx1VouoSxcElPmfv1GAqEyOg8x47EIoTdHzmxbRtsGADiOB6mhPhArOSlHPEHKS082XjfrO1o9fkAOsVChSxA1NuM9PrWzS7E6FKFSM4c/JFYfUBJBUQJNoVlRkEjJoVw4x6FeU+yhYVHCPhQEpqFlOlA5eAEtOyqhazOhTXZfrEw8+u05HZLzoXQEsjS2QlmheEj3NMG9p6F9eoURizecoYIy1TG16TWhhzrYTYlUNzoIixmhjl5VoZGJTqGUN7jKQ6GYM5s+YjSINxI9YKGeiguhoUzUMm88R1YfN+Whp1woATVRADUlQX8+9UNqO+d1K6GyVbk10jNKQohlbESkQww+9D5iB5RcnaG/op2hwj3nRATSAaHHQVY/0KHKOOJEO6HNN+U6X6HQZPM3HThsQqsBSqHWmZg8RlgYAls0Hz5BokWh313UU8w2XaHkrl9dWALLQgk+rNRYoey+baHvSxQCB0YoSks03aEdofdb0DJqMu+h+8f4of5DEzzPqceiA70cogZUSUNlbYqiCzJCOI06Dk9ZN6UGr01cBvg0AUPR3UiiGF3lohriEaIdRzyuhqIhOSU8zzIxUMUBHTQkW7aiKmhNQ6yiLZtqojC/X6IzYTM2Q2Tj/D2iOWTTD++Mq6I+Pq1/fE2GY2ULxKjJOnpRGUerMg6iSZLzosuiTROSPqY3KjSsOQk7Wk8bolY+9TfkolkzNp/VQFY5n0rjQfk+0TV1Ag3oqKJl8gqiaI/XomtFsy+fO3tKTjVAonE4r0Q0onUQwzTtQ8JB005qOb2P2TUjOZMFFnRFOQkBBUNCtqczP5XpoogBLbqFoowFAzxOoo8HKaKRy9WilDWIOEFD2EYp1Vm9H6KcocGin0CdWnxWfa9soqVu5KKnn+Ctm6m3oq064qKvTyFhzLn/QzlPbaK1rPSiuEScNng38jZ0Rik36TQHNdyUezhobPw6SAFKosY1TVSkNf53fNDsos06AzPNQKRWC0AZd7U+2zPGS1g2TzupMAJHpw+OYYlFt9+vouAPlEMMR8E+pkKjspg0HzcrounF8KLsdeE8vDKLNk+VaGXKB8Si9HkLOC1BWjgwNTkz7J3ki+yS86L/O9RAp0VZOgNE8TSJWnw0H1BpRahJCW/low1bbjLVO9s5fL3goxSU0sf42ApN/qMaNghPxrGmox9SWqMi43xTw6Mlj5WjKETKV1hXRaMtNQy7UKMxAkWjMzh1NaqKZKM4NVk8TqM7NTPmAj3BR0xPzD4sNcpMLDQLYkRh7b30QL2jSavTOHNBRtgJvkKjUjd1srROFaNW45ROE6NZvlPYBr5TThijYterYfe5JNf4xk/X+DRJo2s7lKNtR5dRtwFIo3GzyaN0M4077lCgo3kHK6N8RFg56KN/QVpBlWGHX29JIkKuTyg3LXw2XlZTE6OMRo4zcTbwTyFG/USro5M53j2CnXyjmF5GbyKcHEFMOySvA9gFo1ujozeCo6VEtzTaRZg6xD3VUCc4hzM+CK0/P2LAMzKjskgYQ+A1a1DwVgsMK6O5EPWDswS6PtszWueio8E1tjDuObs19jWtVXFmXKPKZdBEQDoTU5z+V3dKQE+j0ghoAUw9hkGoPnek76PaWHWj3TinNLRGfDJuo+I3mEtcOnQCNRLuo+gBxVvKN41gnjlHo+5JkDvPkbKj83KHo/Zbx6P5PpDC8aP9Py2j/zuhOIkBHD38Mf8/CD8qn0ekCQEIuWBCTEEJOYFXk+HsjOKkE0SkOS2kFpqMpBlDBzJsA3RDqDg0TEE0BgXeUyc2wDndpCU6GGNLpCg01zksQ91RUnhDpC8MKbYkpDNGjqQ1M0s01000htSkO4pBdG2kPzhQP9Ex8KRDNiSkRT0dSFN41DKMgpmkTDbxRgmkTzhIpFE1W0MsM2g5YEM9Od01/QEpBxE8eGGlbc+kX0tt2sGkYzUpNh069I3VpGmcxaRsNTA4jzbXPT2kcTcOpHNk1TX7D5N2taR5LRhDfQcBd5qkf2OqpIJWuz2AMgH7hXiEpIlbtXJxpI1EuKSPNMEEm0s7bopWCUSdNAYK3kCEpJlUgXNOQrhQL16wOJxDAQ+UX61FYqSlOwFjT0GcpKlsjaSsg8WVIqSwP8U1PaSzS7Tg8aS3T21ieaS7U+Fb+012QIw1S0Xrm/SkxEMlMl0z4g07Mf0Em0PCM/jW8BDZOD43qgcIA7xB/z8tZ0NEJDmaPSw44jU4SrpbiKTdRIBBmz+hpOI03URYB9FXA6ToQLEzmDMAyAdZ6DoYTWcz7FSfOHU7ZTxCO0I/KVfJr6+k+mx1bgw2S6T+QE1JdztiRwClBKj3pQdJc1AypQq9pqUNjx6lEO3BPvWgB40iROFmOjLPBhWlGTqaOX+FjaUeMuYyxD1+N0OlI1P8pSWbm0X4MwtAsUtSQpMzwna4PPrHaTgYO1KGsDQeOmI24lRUFQw2UUJzNuY4ij4xBt6yMqVA4KkQuaVDWnA2f6VGTKelSDl0AcEzN0pN9/6lT2iypVIykF4UpVYyakEt/d2lWziXRuilXwyqOVI8MzaQ5KulZkLyYcxHjkPKOUmlbEjcA09nCj2oQLs2OEFKSmBBHqV2SZCleER4RIqlfDNoRmdWqDYEpYFfdkJ6RouxAKWHN5VamztaPYKljF6rNB6ljzmKMzICjqWTREQ28a2+pZh8p5xeNSlNSTVWN7E2sAUdoCY/hAI+Mxw8yD4MM/elqKYXpvGlrdvfpbCKYXS8OZ1LCjYxPPY0Hhm9pbo+KJPgpb4+fkq4NYY2iwHqpcQ5U1E7NWE7RzHJMjUyAzXDS8tb2UGAOoVAfqXSRAQ0wkdsoA5Imj2jAzl6TDctMfI57D2jUDel4TLjPBRQ8Eh3p0Kl6FYJVgttJzr/MpdbL6XvBZ3/CaXzc/Kl9jM6SMlFpjWwrhsCTjMQpf5UYTW9OsijFE1qOIpm3zwnOWs/sT3CpgtNxd+Lpg82UTVVMOE1MFCjRMU1vaYXVXimGW3gMJKmHTxIX8A2Ozg7piJKwJbjGY1eNzj6pigx/zTtVXWmLA+2jEmmMAKOMeEH30BfXqtvO1YVpjgBWVGrAXg3jjlrpj6WTKZBRmIzzEBcDlamRkEUfDaLmaZLScY7SjYHMnRHHIErPrA73WAHplY2u0kXMbMzWT8Eplw3haZfyd/YCU4kpmVIQlYRpmg1Mjvfpmw5Aze6Qi1IQzl//bw0J17upnZD4DH7OHRCiEiMQKumfVYfD9I+HPtPOOHXxDirOWcxzkrbOYF1XKaLVfemjVBBO2ETklDGQ8uvQgkHHWOmlzIOMb1CqDRNZchAUrki2BZOA6aiW/s3XKo4pqc8m0hTpqqhSjzPOUo2tjJxMb8K3kIcprQ8azeORMVFYz8EN9qmuzcobIYzZpyfXqY1kabCPjWmxDVONVIP4zkvX5JW6qbM3NmmzzpuOoyAPTynjfGm1jTuAUym2UTQO/+m3Djgpt5PTETFO5Y5UkVp2fWsAqbnRkA5KAcS1Jqm7TjSCls/0UA4ZCdkcqb14dim+AWUQdIJ7EIjNbU4xzUoOnunAgMFPrCnBTWAPYZCon9Ipws9yDUVpw5RkGBXpxICTTZApxVhm6cYB4I1UpI8px1gA0c/NO5CYKciQipOuTzkTuBC2zpHpyk6xV9vTWo/66cuOZw8BjTupzJTYwEUomWnN0qZTm2nO4hupz5D1DJgp0E/aLIPp0XTHT9op0k9mcoPBOunTQ8vPBEBB6dRZD4y9DwkL5dQoj4kVruiO6dbONg2M0hAOiWnYAFdOLE8gzzPOrGnZjX6MyY4vzWVRhBB40S3Mc1U9zlVp3FXjKd0yn+ndzPdB7+nejsOOAynfU8+WfSngUCsN2Az5gNWOWUzzTofM9pLfTpN/wxbTaePNyA6X6eSNyU8BqeVVglb+7d2p5pLtzXPc9w0Onvaec5IaN3jMjFLiD2CNAXkzEB2POIzD6erMdY3oTKaB79F+D5/Myens0nop7be9ae5QfHkgLYFp75qkkMByQynwzn+ZWxOfafHZm86GTxrp8t/zDIKcPqoXafRNONcczQgZ3Wn10hoPjXVQafcAo41pJlBp+EzXTsbaAqn5kJ3QeRCOEPUPBs04npWp+87R3rdp/NCoTh7M9qNnaf5P98vljqwaaduN6gAAXg2yjlVqAQBv52ZM81ApTWSO6o1jjM3+RmoD0OTN2lJaQRBN61bHT6sMkU1JTTtPH1LSj59Tb9ADnLSW6eoIlzQqCQzpqgnPBc/9XuRqCwxnFRJOZKoMFbwqDNL9QheOo02RDiPM9EBHAQDM+o0rE1qqD+IxFSkQ+tk0z3JFGIH4DXzapJFqnz/qEzL7jW6S1FDOV9vTemoU0wdQu07Ek7xRyWD6ahbYVCoXkXsbsRIoECYPJAwkwEVdqMB3xAiQaIPY/cEx1uobqDoqHEy4qh0OgNINzhaEAw0KKh6WPtLGzfWqH5DnAFIN1RbuTkR56KohtYLqIk6IkaLAnlbyjY4AndWCzYn3aOolDItqJapYqiZBttOimFfOrY17EbTPA00kTIFNkSopHdMqKc4MuuOqKszUmAiA3NHTjokNc32x3DMN6Cu91iGBwGouN3pqLs08DoiP8wG4VW2WqSowjVROpL52qjHS8ZaPTtKC3lBIzIQa5Oo0EEXYtoCL6jUbgk7t1xFSKM5VTU7qNxYAjACMlc5ywczqtOo5EFSqOY2MzHXP/k0r1NjENFO1lSBBgZMgzUSuaGo9Gn1qPc5XUrjPAldSz/rqP04Mjc+PU5lj6kDPQbkEKkHQ9KpCoZHOmqiYecxqRBAjDaWUk/2rKkWQOY3P0ObqRs/FTTQPaNfEK4cVsM1pakjPd5hcTlnB2k/QjfvqSpGXaktSxQxvTQ/UcIFv3xxqTU6wTP3PiU2kLd4qTw0IFcoB05A9QEcgBipRFS+UvypSDJ0PCRHw6lMPEFuDDIpphGZB6lTVIRJDTcbN7E0NjMLP782Gza/otGpXzcIqWG7halkYs0BFTbrWuI1sDdDOhn7NmAXQhmpcUF/nivUz2x1Nvs4J0FSlvCpekS4YjZBnTZERQo9KYZElNwy/kO/ngmnQqmI1S9MRgG/NTw1VGNoqY87qjSPbJACdamUOZhGM0fBN9+pmjrWO46pneDAqaBP2amiNkJLtECMTAtSA+gUZhWpq1fbNAlI9T3fM2tM1DSrNT2ptEB+S1JGVqm4eFWpu2esqb4wLh/vBnc5sjcZQFpSj1fbRuQPlDlaqco3DjPZOIo26wecAeo/1EmgT95yEqnWZlxZvDOum9ep3DnBNLk4cxaQqeE/9/z4qeVBFJqDqek7JDb9OVep7XaBqfAy/GCeMj1Gjqn1Odo3JKxaSwo03an7PB0+xD5MMiU1JaoBATmbtjY3POZSmVYfXGiqCju5AattP0nGWeCqET7zORuqFZZVqhg0rwZBOXdDWEPwNcCAYKohsY+qJDdjqidccKoqzYWqLUnUVzOqMMThqjM4CTbcBfaqOHlMqjvSF6o+VtxF+DVKOvhDvjkfXduqRy+bScSqS/3VONJHlDzZNXbXuqpTNssUPDt2qlcFxz8pQKo/OKpdOJ81r7amZCeKnapkDy9jvzuOe4GqalRJTDcwAjQfX8A3iEKuPVhF1Z3kqnY+izX6OsGqejvzQzNj4qp/qtCqgq4cODEBaaqGOFSqiEa/Skuqi0+LMyaqjjgxAWlUqqkfqpM9vI1hqpdqc6qahkQ2/W1hN7GrTzejNB9Ky6qjWhM28wcSTDdLYgV6UZM5stvNMjo2HV9vOTgQCDkiNN+qtDgoC/d3igKpM9lC8EOpEN2qvTodD/BFGgfEY/A3XAG3vEqqxzTXPBBAww+2N9N3uqrOVOiNGqrSOKo1Eog/qtdGPKraiE0433EdMgwy/0BJMdg52arjNTbo26rnQopfLqrqNjIyQEerTAsBrz3eM5vs0qr0TvGvPKr4SNda4lZINgl/Yar/P6ZEWDUtBYk37WObO+41aUGpOH+ADjzPQP5ppzY3MetScXfRqxNrzDLYzzirGEQ8M1+rG9nSqx41WzIDT9irIlVmqyUQCUS3OsFVCasrNAZB/6suSNQ9/rI0qzNTJ0WzSoM1zzTiBzM//EBEd2/is6s/CQcoQlpKCVXdr6tGUCerSEAQq0s1cAZtPOdox6tRRJgyMjioU+tPeatYQg+rWl8uUXY+66teQ0A5JzQoJmBCIjg7QF+rZjtlN9drfqtrM9WrbUthMos1yTQjPfg1vjJM2byrdwLiNmwzPT/UUDVbLWerq4BEJFQvUa8BrAF9PfUyjDUtOK9JEjiGMimXCKuPPkM2nTkGO6U13TjGOMhFgztoq5pE4TU5Pj+rnzw5NDKEYqukNGXS/74Lq6o5czHABckHEauvM1Y8ATZUQpBE2DxtNovUBau5RWNeH6u9VVdFJV09M2T8zpw/q8VqnDdtWy86rl9vYZqrzS9gNGWr0aNKrwLYCbZkq9s0xT7XMowz/jM4NYV+kKvkpuGr5zZcQ801mTeaRWk8VYBTq/AB6TkLq/MyOzsHq/Zlxqv5YdXU7Kv9QAU9tb1BrAI16FwCrAY8JqwJNiI4aDSvohusDzvuNzs1DTT/rBRCuKwWVVc6TDIyQmM+YuAHrB44Yjt2NSw4xFtvOQhObqwnM2Y1jzPfOK5PhTNDrC43f3grrDI3GTn2rDUDyKU1rDnnzaw8M+IMKzv/OWo6gTwGrjasRT0TNPo542b4TR0/v1CjOhtF+qxQAlmsUvikrFWzjqxYOAY/1mGNQFNMRzcJlMmsYTIoOTSdDaxmWHWsaTQiekxQUjtSPAAFC6xwoResc0nGM0TSZ6x4NPJWqDh1OM1zIDHpUms4CXB+rINNn6yFNaY2ADxEOBeuCayMRilAkkGdPc00KEthtIuslTgdA1esmFV1BkOsnDtWrJ42MkiuO1ZeN/T1NLZHCDsHRexXkzoPbyqsqzu1OpE/dayvQcasse6/rLQxzqy2NQE3QTbGOXwDc6y8Boo69JIzTDc1KF+VQXxEOzH6EPc5VN8gNco6Dzz8rMwDflOMVKWs0ZLrrNQ5fDqfrNc+gDh1Rl40FKzcOAFrvazgAb1fAjpRPOJSuwXIZHOs6TfmN+XNR6zuNAY+HTMYRJ2h16z1NV5uilvCrPqhKaz9Ouus/0pRrQJYEa0EkW2tB0EmXy42V2ziccutDjsmN7qtEUX+NAc8OQHBs/CtGEBFrRs20a0dNJhcRTjPNUiCYq0kQoFASTYXM91JkcUhrSwv2RhxrS86560xmmCtNAKfWg5FHpnMrToLeTW1N6k/xTz6Zeahdq1DOBc8SmX4Z3xP0EYWVuutTEdVENlAaFTYVvqtU0WWOhU+9K1XS5Q1G1Tog5oQyq1dOwCW061hPH08E9TsPERb0K1nkaCtahBkA3OtbXImA36tcDzaNo81HTlAWYGtdzwRRtzXq618Ne1CwmB7PBFp0jr/Ols0OpHmrYc6008oPA01YK6VVdyscaEYOhmtkUtSOrCGUzp0RgWtmHevARsBE0cuQiNEnDYjEDU14Da3B5yS8xJPRW6oeq2pO/g51GByNhp1MK2wXf4+9q20RU+RCa24DwY2dGYJO5w5n1p7rcBHPD36R9RbmgaaAV1E3T8mQOY2qVF6NyytzIqeWQoBYCZga/ut0zWPrdUyOq3XYHJH1GMiZ/St3V3BOaA0NmcVXhGt4wEbRBQ4ia3nUDI4Oo1QrexmbzkdkvMST63xOQ48AK30i9g2Awak7EM4FXKS6e6t/TywTnKuAROSQglr9a4FYbhKfFvZAa81pzWXhgyuDTKQNhoBvT/7RG5A5pcUrhY1yjKHrhlCQUKTPHpRra4fPU5CnDcMriNCho1TMs1SjI5MVbZDqTNlQwIG4a4uNgBB6D5DMhsyG3qFrEOuN0Hxrjk6WzVKZdauPQayAS6uQDaPOI830ZJb0ExDq1+orkkwUq5MOiIoQjQBfr0U1jevj9lM7Fm8PqwEia5YOY9oZlIFSYhATTObRUWuYeeyrmQ1xq5mOJBiAK5qARqNT65uMtY3EXVSrnM8RzNhM8M9mVWSVN9D6/R5rn06Njfm0kmugjh1QH5A9q6GXKOuibkimHyujTI9ro8BLXXbNvNH6j36PH0Re66XASZPyDARFpCunArfNmU1aTu8QFgHvzaVM8gLbK6mNA05ODUWMd9A4K6tOSs6hok+rrE89lAvq9OutU2Orrg9jj2YN5W+XL5L1/3YCdgC1/7YAtf+2AJN/tEIrtI/Qg5WrtU8jzT2rthkt2GlNwpW6a7eOmFV3FQAOL+I8q7lTOxVgDm0ruqCwq7tZ0Pv5q7xRNoDsjHwaJBsDa74AVVW4D2DQ4/OBgWESlyjSq8C2AnYAtf+2ALX/tgC1/7YAtf+TjWvFXS8rxc5c1PpMpAC05bgrx5/NK8hQ+CvIziQMv03zjTcryhFKUruNeVEgTwzawthZz7EQrxaSa80MfBUghT+VuI26johOf81rwZBrz6Pt2epr0I5Tjr/aLE0yEO/2IVHpED2P9bKTq9ONMmvUaNKr1TX/tgC1/5Nz69cMfVffrRnr2E71011P4I52K9nn8lp/a9rOGY/MTnBNIw1rQ8vQ4g4GUcKBzJPNedTr3lCbK97U+ZEauqX3YmvgTxCr4NVcQWJPnpf8q+Jq447yp5yr441Y2XWN9GvkgIkTEcGFQF9B+Fcf6+aVn5U6DxTV+gzjq+gM0FD8Fg6Pfk1vEKGDkN0h6+qQNc+61g9PO84uV1LONs3NEML066vtkx3gpavujQVTxmvvUtQO44ReDWjr8JE8Tgnr8U3NDkINDtC8jw7AnWvzEQBr845uzZ5imE19jSXNpY2QksLQq45fK/ZUVI4F1KmN3U+RE01r+BF6DJYBxE7j2VcUT446wULr+k1FxDZP+YznTPdr+9qx6/y+Yuv9aiwr/j3/lHvQ31vK6/+SQ06ejfsUpU65WsGMd865RBHN5AQHFJmPc1KkLAOQFxMxjf4Pypm37AUPfw0DzIteZJJcTjsNA9h3bAeBH49kwW+QKU4gjdtOrBf/7AoOmFEKi+Xk66wLt9yRks1B7AyNTM9ojUtAjWwNzY4YTuITUaucZpQjT5bsD9AXBAFtDuwRMjXTS5W7kZksEozQz1pOyRL8mp7RQrSKLBTbWpUhLBWMjYJcVKMNC5aoLBdNd5d5VVnsGJEBjKHsGVPrrBn1o+wamNPPBRBDnVJPDk4MlD/Ek9IsUPMBd5KXKwysHkx7lr2ixQ0LjqDNfps1VHvMv9U/bCGRmI5SlTFsIprULCNNzqZapm4sJJRGrCVheZA9TkeVNjUSQVBToozZbCeBq1EgGoDOhg9R0aYNc45n2J+NoOwqd65sKw4j0fCQxOwsDkeQwKCk7C1FNawtzhoXwJDWDSRPQ43jzW4AbfrkrDCS1yEV0dzsMcQR7oQfyawzDOwMvwPL9IAsNIy0ILbsNZEbD7HAUdKLT/nsNw3IEA4sN816E8INRuw40BXTYZAaKTBR86w6T6hOJ8DSTXlP0KbXrDxNVuw88/BOhhJcXPisPkDdZJksP1pp4XzsQEEsl6hMv0y/AY3NDZWkkL4sQpC8EL9sfGxD75T2Aa+U7EVAus85LEYQ+BG5TXaR6sz7d3QsR9WaWNbNfqxIzx0OoOUTV9vOPRHzhirsSw8grEuTopB1GO/uBY+CpZLMhtQCzTBUXZHTrE6NSNScTd8SzlHalNkPY6xQsvP1/3YCdgCTf6xSbqujzCxTUKssU9cLLFSVQoTTWADPta9prFZCVtX+EXUMplEFLFfSMg537FjVmaxZTfSjFGxaTTQRmWxbTM+NLncUrFyNiQGfmC0sXdQMrF5NiNDrzZedvAHaeD6TIQ4/XQDsYRMd/FcNdl3ujTJPYSxjOISsY+QeknOQnGRp7GVAbdCrrGYRsixmmo4sZ01ELGfNd42koLBg9KxpT+Bg/Mzrqelsaux5LGuCYixsFYRj9lIFD5hMxFHqTmFNnkydLG6UUdEbjhrO5lFTzZGNXBHYTfSQ8I1VD7fPBCxyLaZscs/3mVcsc4H2VNksdEyl7e0sdUBGkc/f+2x2j/RVG5AibHeOJJMF+L9seM3c7HlMvg3sUerT3H5zUuWQUQ/FrluRFdCFgLL+NKx9DY3sfZSYbH5PIBB4j2cSIxHgm87VSOyAjU/Nhdi/7IHXVg3t9URsgw2kzxQVMcWym8GPO4uTmADQGVgf0mdiT4+8wJLshv4H7IeXtuyIK1EsiNIQ1PbQ6iyJ1gCsinwCrIsOmmyL174sjI8/GLNXwNKTYCoNTO4rgbMOf43xbBgsj9iwED8PecyrzWjRtdERE3pQ8FMrzHtv2qyTTeeUocBJzwAGBFsG7JVARr5lAe/4UBhifQkSss/v+NWsmBYxrJj6ECEe7JnOu48RLJqRo+ybDbzMjo6gbJwgSayc14STzSCpUt1R5Vw5rJ7Pp4/uTjMNLDctDiXQCM7pFAzB1EHNVcojGKyigWK+OeyjjQYspE5rAd1spQ2HDuhhkmyme0EOTpIOrKeuneyocX5sqQ3844esqiavTX9sqth+UvxMftaSIR7N3Wysjd1srTYBr5ToOGyuZAVRKSNc2A9Piw7qhDRTRm9obLEZqs3gFRoNP88FUMMQUw2/VZhO6Fbe2cestI3KwqFAihBFGyJstkzXDq3stwDddicND+y4Oy+xlrGWMZWEAgBM1W2MJNVQVVxMOF5vgIwODI8m7LwO4xJF0G5svQ3UDnXRx8L6EHkWy04nzQ24PGy/wqFYlHRJrMEOS6zBlKMPS4RPLMLNvlDCza3MtQzSwG+Nbhm+FZxUy0P8LVXBQo1D3pMN1Q6Ezt+R3Uz+bMhNso3pQcpRkw6IlaTi/ezKjl2PGc0wjHqRO01DUNDDXMPL7M0OcZBnT2GPDYv2UfFhb+zPE85QQ4y8HHbuDmzQzXaZOM2ZGsmL9hSA7NKM69WMEY7NLlepjzitXOzU1ToRIE0tTUATUM2zj/UNxRHDLdys1883VBjSfFL9Fbui52zZ0fbs2pHEbNselyzb0WHNyZDmElKR2FBm5zwPN1BlTgDOn9YMFvQgymzf695s4LonLOFPUU7EO3ts4ruhLONR2Ex3DfHDlY1uBAMVMVCgVCOkpqzmQdST8MORTM4s54GfjNKdzVHwkEGOYpByjL9s6dBZ1GrNpVzTjLmRVFFUTZ/NrY2dW1hs7NssTXuQaKzt5n8s7qmJDbbs70/3kAF88OzwjXuYCIwkzpXXClZSDQMO/U1vWqSPrBBfEhcs9E1gj2oZm8B33PcPv84hzPZNJgI3jj2NgA+PDYBOC0+QRDjs+NklTiOAgczkzrYRv85EWXFs+0+EDTyOa3Ru1xFSIOz9TQ0s/c4MrP5O9C4uje7SCdYCghePpE4CFmrMia39bQGOq08M1idtAtIQLQN1z60EEPnS8tOql7TSYxDj68YtBlI9YZENJS0HTdh5x+0IUTYziW0JTWxNre0KHNOQTNFq0L0MlNzurQwMm0z7GGhTAwx+Dm6ck20EbQ6NxSIg0gSOey0P9tAtEI6GbREa/i0RwY3tEk3g7RZtE1TkgNcNXy/8DSwAQM5ErRVMg4+9TQotFlW9QW/tFxBl19UDlf76bZvtGRHMrRmr2C0aTo0ZAm0bUx3OVd9o7RyOuQ5nAEEOa9Uv7R5LkoFyDH1uIK0f+LOgFG0gz5iEPc5NjkmA0o2zzqStIvG27SOBO57FjIlPIM1WAJZSydLUrQPtJlFXlRUen20njXObFG0oj+1Ws20pqj1toC0qvdGtK04CTQfeWQyR5QgPN20tDpLQqG0tzYTtLlHTDcdO909g0CdPBhohaJXTHaZurTFOmG0x1czTzf8CE/eRV48QUJzPuP31LTSQLF33kxntNdVIWhaNiK022HtMzwGiLTfPwS04UX9D2AzOm0nl6W06HNwtOsxzzTJtO/lcrTyPZyszj1OaFpz3DcttPkRQbT8RinTCBC5W/q1AjIzWRa1Bg8FtQkz3zIxWg+1DTTctQ9Y+nYitRM15zghtRZapEoWtRqSM0rVRKMyCMKetSE/ZD2AO2FbpWCkOZOja7UqBJu1LHmSRYk5djUQRMK1Mk0AtTUHKe+atTkBwbU7RDg05bpVtUCGqbVDljG1RjcTNkSDMrVLtQO1TkgLtVA/+0iNtVMU1rVVNlGzGEeyUVliqkgL/oe1Xkdsd6y1Yl1YPUpqnLVnQQZk07VqOf4/STlteLSSCbVxuWdZp7V1NhV3EAEoQ1i1ejICNQcz7ea1tYA3ukhAd5W1hbVOTbYQw0RvM6FiGDSQXHM1OGQnOtNXkzxzOPW1lHJ2QKwxyUAZNRW1mhbKjP21njzJNPVGxjZuOXo/9zHjM9G1p1tXtapDSjvggCK1r09kdxS1s+81tbYE2jKsMvD1C7W8O5p1q7XAYQtSA0QERE8FijWKOna1yDJAMwg73MN9WQC1zwbrS1JCwrXTOl9IdzO6Mh86NzxtQmBjm7XciUro17XgQQ6hXLXkupu150OsPI9afDhdZhu17u5CtfFfb0KHOlu1qLX3Uka1+eittfxbiDXPT2114UhDtgKEsLYFRwgzZkZuNb1k4zOOPq1n6jb0WBRJ2oAxthP9fLYWBgc5LT/8OR2R4LYdBus4AzMdBqc8SAXVtMW2JkGAsnxLGztHRhm2LZ3ltjBwkTbaNZhAPrY2MwO2ONgCmMO2PD5TQ8zbXrZBOtc+GleiNRCCwTI3PcHFDEDXtky2Tgfh2DO2UjjyOAZ4SLZXNk5lPbZbT9m2XU2WtmCr07Zi2AXX/U2VtmhfOrZrWPk2WzKuOIK2cDf4NdY3TGTnTzUJSAYVNTAmYDyASEo8tw3/tn9WfvCNtoM3LDxCPPsx60C9OOBjoTmetowybDW1QOu2kDACPUa2kwHqau5NOWZNA/WxyrabNyBKgwGAOzY426srtqM3jmqZOGRUSTb9PFJAVmHMtqw/xz/1QRZbFzOeMxg226IFQqGRlQaaAii2uUIbQkxnmzVIbZ5HFxbKtsIEWz+etsU1eIs6tsm7PzziPpXQJ7bPMeoBNDoittMzQbbVEXs53jWONydoWp5w3UUzGUiiD+M1WDVYRf224zI6m5tiiV4Ttumn+LbsCGhC/L/JtvGJvLb0PqGlc7b4Bym2+gXIWGpcHDQPNyoQpzw2VGE3p2NLMpC3BgW/bQm3CgWjtw1ERLcPPOi3EkUK2Wy3FkYziQwWyj2qacACTjkdTzdd0lEMtyE+fmnSDkM+x0fDNcNqvLcqOhGluDXDRmdHsLcxARE2CkFoTMZHXGaxRf6Ii7c7QG4yB0BxPbBFslwSQL1HDLdEPG03JtOsN3O3STISNzm3TI0ut0/Mr7dSOGQ3JDs6XpW3WMnftsECNDVIbZ63XnyDt2E5VbdjpEe3ZkFFt2k4qzX2Wy05R7H7t3BLxLdzMAJi6rd2Vj8BvT8tO8w21LUlt351QVUtWZxAZ0s4PT1AjJH6Mz63iEh5q+x6bDnZR1w+RDwAt5A7n0uVuG1JKGqTFzm3mDOTR5g62LecVtxFYregBSc9TzvUQEg1PjARS0o47Liq4Ya3rEUeXSs/ZLewN2kPvEfOTqc/+Tq8+I23uUCtt7w7Ure+Wvk76RJPt8JYGDoUSK63xjrBUhkGQTh4iLu3zUyDNLprobfRt5231DtROHk8k0DtAtNam7fbPXg79VZxRuq34DHWVOJf8rfl7hy36Fr2WSwQ0Ystt+40xUdOt/E3VDPfdtS39vf3t/kzxxcuhee3/jI2NUg+zLgCRpJm+LgFVDFG0zHtVk9EHfYZQs64Dpq8uBFNHbgTdeE9KG7kZR+4GQEFuJxUZbgeMjw1XDtlNdIzS7gkN9I6xQKpuCgMKjbGdixHRembuC9AT7gxSUq4M0rlNrBWETg7uDg1bzARBsy4PDeBAQNBUkApNJh+tjIRQ0BS6kE/PvL807hKdew15bhruE84ikGcRmcQkUKHOGZMd1E/uFkQ5UdOSCo2YTTyW1lDLPGLRJlvuLhlPtuVeFTtuGpBnbhsN+qxZ7hwMmQ9BlUouHVhhTRCM7RkRLh7AXE1BDJDDyNM7Iw9uIM9j2HuuIczPjxtPjK4jGNouI41LNRZuJI7qGAcAoJ7iriYQZxIP7icOlsvYDdqSB41glilXBJWcTHmCQd2fbipNDc6HTHnYaJp9biwNtpbL0X0N4I30Vboau64uJXXuLs9i7i911q4wF3+P7E2DUcGXMO4x0QmOtc0mlj7baq4zqLpVKRaUDL3WrfgcDfya8U3Zzj7uNk6YbjbAso0k7jeMpc2f7jhS6Qy/TxOuOU35TunZNNfwTO5Q+tGBLjuUT5Md7jxPYK48zIZWDrGWcZTTl64+UuIOpuZkbj+OZg12LkBRKun4bkFqVm5CEOPjyS5DAd1acG5EA9+uRM1I1XJPAc9uVaouRkx8DRlOsTYnDQ/suDsvsZaxljGVphcuSZVtkC5cMyZxrksGj2SrbkwOv07kbkzOv84XTTjPyNPhTQkNEK5Ozi8Oh9G/TW4EDi5QUHPOoV0DLlGTWoIJ1V40lU6EVj6RRi5UDXQP206Ubg4O0r5xblYU+a5WjTgBKa5XUQmOHU1hkLCuWJHWFarcHO5Zy7uuWkQCblrU+Y/7kKrAnW5cDUuM2BSRjIDRgk++DZCTyi5eTIuXRREmMbJPt8iGDy8RSU28dVUuYVBnId5uYk9ykMquYw937mOMhu5kDa7uZI1w7mU3r1B/9ZtuZlHnzVpAbICNU1q6oG5oUQmuaNJnbmlAahogrmpPzFAZXSFNZOhNT4LNee5h0PtNblTZA8jOdFHSjmoRdRHDEPgNAxPWT9iN4u5wHfzucJOuQWSucVuNj9kQ7k2IE01ngC5zTgkNNRfuRC+WpvTFrnVRW45xrnYXrW520TCNx+53lYvSCUBJjlgQFk6/YLcXQc1FndKT66sobnsR8NISkHEufD52mmpPvVKvDz/ufZEq6t2ufoQD7n8Mh1nlD7xlPQ0CDwFugNVGHSFVE41IlpEIQpfkroLQk66DVp2P+K6EDSUQiq6E0GUhdcya7oXXA4GiktyBhVIEjvOYs0VDLogAw9CQbojTJCykE0ZTVA/BLopMx3HYjdHPhk/3zzZVAQ/QroyRE82YUEjD+894jI8Xqa6OkU0ROa6PTJyuj9rCrpCRr9AZTp0Ow4CdbpIP/c82bpLOEEzPUxHuk+f7LpSN7tO6za5OOKfsjVpTWRRuLKDul0GPj+SD7bN97pjMAI9iU1kumduWTWAWm55wDNDOrAzxTk682S6ckcMSi48B8dGunjOz7p7NPp3gbp+QZW6gDXxW3u6g0w4OU43Yj/RN0sFHAF2B79QgDeQBIlcKVQAupFZuLqUOXq6luJZupk/Jl+hNw48tUdOS5g6VEYouqIHMrqk9se6p0GAuqkGALqrUKy6rnEdPby6scyMurRFVjqkE026uAEaCXG6uwcRur1t/rrASdVm32YTusUFkpufWAJBagRbOtNtaECdNZk76brQQlk3PFmLutU0BLrXOhFJkVRhNuEQh0DDut5K7j2GuuFEowfFuuRm+LrmATQ3NLrpRwxAdKBOO9Az1F7TuvBCxFGvNoxgt7r2qRi6+W3wRKs87DwoPpMy1zNcNaM/N7sENwx+P7sIAQgyYGuXTHU1d7sONY8R7bsRN4IUnFBjPMm8nbsYOf+7Guo0ux1QNzjEWuIBTDiTQQs1MAepMmj8dz3UONK7K6iDuy4y2D3tRuNWzbszBfs6sTb/S7G7OEJdffO7PMcDuz9M1EQhD9I4vzkzV5i7R0OyRMJB9jj9TCs4eLAEu1AWyrtSPMhFClBBA3k2VUbRU9k4SLtbMcqrzLtfQf9fqxBku2NIaLtlhzC7aEruNy9MkEzWu202IrtvSwoCKLtyYwkwnT4Lyqa7eAcBu3qyF2I2A3Q0OkOoNkaJPLuDTRVobjc+Q1ZfAzmEUow9EzoVRclHpAFySVVaOUrnu5N41buWQu67mT2jPPoBSUc8edO7oDY0MotfVbukMzqsIW7BCYg91jmoNpE9yjIGRRxFyTXKNJE5O7uztXq7tjqZN60EshBkaHQ3Zj4oQcLe87vBAiXiFbvFtA+aNbvJt467zF7TMos8OTcoSTq701GUBjc7j5pMUxc2f7vah0qq+7veDsA2FjXcATQ+sLvkYqo7zjS2P/u76Xsqu+s1HHXQRhm78FUASlyHErv1T1EHxLv4m5K7+zMQN4tsdTakU8y8ATTmvATy8Tq4Dy+8CFpwQXw6wX7PYaJDWPEXvBE8NjoYM7FxHTvIXChWFlXatk08XzTbNko1yUsuLSIzTH8xvCQ68qd0vCgHAzvbvCszEzbDOb1Hl7wweOJGKDDWPvMzJrw2Bm1jm16rvDpHdUmRN6EysDf5V+S8QjnGMto6FXU9vEhGKrxKSK68TAWEeHI2YRcuMoe8UkNCPI/oFzIkdzRFALxaVL5m1zJWSkY3djwVvGE2dTI3SeE2rDnNvGg1pkJtQf+8bDnbMmMyHD4cM9FOalAcvHQzGLx2DXMzLTgG/aW8fEewvH88vDunvIJgIj5/S5gHcXnUO2BhhTfoSVO8jDIDWvlDYryQYcJ0rwcpvJQzWJX3ePzYFNgTvJo39lZ+PlMF9byfQXSDMEJBsLAGlAdqX6tFCss4Nrqj5bysQqhaRDifPwR2cDQPD48CDTVOvLY0x4CRNDwByTxHaZQ0TTexQPU4scZP1/jGT6NpvMU1zTpvvSK8yjHEXCmUzP//dwe80b1qvNQyakFjRbJAHr0dvNsx8jmObOm84Le4Ue9HZY9zvOYBi1t7kwK86ziGeO687zdzvPEx2EKoecS89hAIOQO8+aBZMg87QlJ+tpm9AEFL4y5E7UgLNf08F7xBvQlX1T3BOfqvwr0PvVe9Ejau0sIyNTV0OoO9GFlovRpAE70cMc4GyQV6P+a8yL0jLu44SL0mT2pFY0HGUQw1lL12vS4PlOD3vTKbfr01ObI3ZzHiRBQBXb07EXM5C70+U+a9QFGvAkVEA71FTak3Ff1xNck6TUJZTfi9TgTuTCwMhETROjZAE71VvRC9WL0TvVvp6b1eMxFvKr1hPuO9YzObvWUwLk7gOu5EGbzTS1EBqL1tNwhBqAYHOePtiTkdNBY2J2SJQOtCWb3BNMo3Z718mbi9f2HVSZw3jTMyY4BPNz+tvYdNGTmjMlU9+T9CNMi9jkenSktGxr2SROG9lAIw+5W9mDMnSZG9mzHfvZ0yV08kRb44bDhovaNAzIowrEC9qFlIrLY8BUDtNmG9rkPCNeQ9DUUJNEA4gUtEvbZFYEMZAXYzBr27QmBfqzQBYOAH0TQ9vcNK+b3GNqlkiT0kPmpLFD4mM6EyajWjNR0C4L3S2Aa+U5jQvddJkLJfh1o3G06nM7A1VTkHBH5l/73jPHqYrr3nSY893r3qk8+97TThve9J4VKhvfM3br312AXX/dgJ2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAr5gAFq+YgEFvmQDWyXnLRUqacJfxNECDTEMDgQd575wwz4d5BVZwl/E0S/Tvne/F8NIxK4Zn758vnvDUcSTvoLDVMByw1bAdSaTwHfB3iDSwdARUsHSEJTB1CWAK8UdyytZwdgEGMB1JpPAdwSCwiTB4BUWweYNksHmvsEatcHpwgPD2sR9vsnB8AwqvszB88Hqwg2+0SwRvtPD/L7WJ6jB4cH8wf/B/ifAwgAig8ICwRvD2sR9vsnB8AwqvszB88IMKrzCDiwRvtPD/MISKdsVFsIZvu8wLgRZvt3CUxsmwa6+4sB0vuQmk8B3AovCI8SKwiUUXMIVMC4pWgEkwignKhcmwi2+9QFIvvcV6cPZBh3Efb7+MC4m5Cu/LJe+sCuVvvMwLiZAJNoKBg1/DKvD+b7jwdojEb8TGLG/FcP4LFvDPyxlw0EugycEKLUW6sNGvxfDSALcw04E4sNQEFHDTgTiw1DEsr6TwcjAcsNWwHUmk8B3wd4g0iJ6w0nAfsQMwTwvqsNlwH4nKhcmwIgIQ8Oew2wJv8CPw3AAIMOXwJTDdQj3w3cODcCcw3vAn8N+wKIwRQlwQU7DgwPBw4XAqi+pAiUTksOKBs8HVMCxagXDjwAgwLUujcC3CdM/xcC6w5bDcsOYwNfAwQBtw5wIQ8Oew2wE08Ohw3DAzcOkBMHDpjBgwNPA1cOswMDEERctK6vA3cOzCqTA4cO2BRDDuAZBw7oJK8DqBvHBBcPBwjMSgMR9wR8NnCfMw8jBI8PKG4LA+RZ8wPvA/cPQBvzD578BwOnDvcEEL3DD6sPZBh3EfcEfDZzD3xdWvwUo2ifDK6LBEAYaw+YB1MPTwOrD6sEFMbUB8cPZBh3EfcEfDZwnzMPIwSPDyhuCwPkBpsJDw/vEMCfvw/++dMPEwTG4KQwBwTTEMcFhHLEF6Qa9DyMwE8Q2vnDDPifwLLzEOxELxD0W/MQ/wX0JD8FzxEDEScRGxEDESSxsxEPETMF6xE4foTELwYML7grZL/zEVcGKxFgIJjNjBKbEXBNMMRjEgcGTAQDEYgoGBHUzYwt7MSEUuMRoMSfEJ8RrwaDCSsRuwlIWiMRyFmjEdMGqBb3Ed8STK1nB2BhFxJjBtMSBwbYnl8SFwmXEiAKlwiTCShjmxJENksSRwlMbJsS0vyYGMcShMYwxbsScMXLEniP5wS++fcSiMW7EwQAwMXO+8b83MXgTE8Ikwkq+eilvEFHE2cJTGybEtL8mBjHEocS/MY7EfzGQI/nBL759xKIxljFwMZDEwxEaxMW/YDGgv20C1zGlwY+/esKWxM/EQ8TRMa8Cn8TVMbTE2Bi/MbkANDG7lUvE4DHDMcVvXjKnMsExz8TnMdLE6jHVMdcx2VbhxPAy2MTyARAx5cT1Mesx7THvxPo4McT8McTE/jH7Mf3FAotexQUyBzIJMgsyDTIPMhEyE8UO0tPQkjIb8vAyH4y0RiMyJcUXMioPk8UaMi8zjsUdacDFH2sGxSEyPTI/MkEyQ8npMkjFKTJNMk/GHDJT3aUyVzJZxTIyXYZixTYykTJkMiXFOrzVSebFPrI5xUTFRMVExUTFRMVExUTFRD9qM5EyijKMAZzFTjKSMpQQkTQ2xVPFyjKkQUvFzjKhxdEzfcXixVwzgsVfM4XFYjOJMpDFZTK+xd4xysVqMsbFbTJNxW8yzMVyMtEy0zLVMtfFdzLcMt5AoEztMuPxlcV/MutGR8WCM77FhTL2xYgy+joIxYszAAlVMwLFjzMHxZIzDMWVMxIzFDdVxZkzGjMcMx43OsWeMyMzJcWiePAzLDMuxadSz8WpTVzFqzM6MzwzPjNAei3Fsm2fxbUzTTNPbmMzUjNUPKfFvDNaO+7FvzNgM2IzZFdgxjvFxzQtxcozdTN5M3nE5cVZxVvF1DOCxV8zhTJJM4gyucXbMc0zjDOOQ0ozkDOSxeEyqVZNxeTQ9zObX8XF6DOgxeszpcXuM6gzqsXyM6+JYcX2M7bF+TO7xYIzvjPABm3GADPFM8d7/TPLxgYHUcYIMwrGCk9Mxgwz2TPbDyPGEDPhM+Mz5TPnxhUz6zPtM+/GGjPzM/XGHjP6OF3GITXGxiM0A8YmNAk0C8YpNBDGLDOoxi40GMYxNBzGNDQhxjc8j8Y5NCnFxsY9xcg0LjQwxkLNMjQ2EJHGRjQ6vMI0RsZM1/jGT9f4xk/X+MZP1/jGT9f4xk/X+MZP1/jGTzRRxlxq4cZffizGYjSWNJg0mo7DNJ/GaTSjNKU0p8ZuNKpzyjSuPoLGdDS2xnY0usZ4NL3GejTAxnw0xcZ+jMfGgDTPxoM008aGNNdi/TTbNN0P9MaMNOMzVMaPP9DGkZU18B/GljT1NPdXgTT6AS/GnDT+NQA1AsahNQbGpDUKxqc1DzURNRM1FTUXxx41GsawNR/GszUkxrYBPDUpNkLGujqFxrw1NDU2NTiSDzU8xsJDRDVDxsZYPcbInifGy4q8gx7cGsbPNV3G0TVixtQ1ZjVoNWrG2TVuNXBFgMbdWNXG4DV7pH1AR8blNYU1h8bpNYw1jjWQxu41ljWYNZo1nDWexvU1ocb4NaY1qMb8NivG/jWxxwA1tTW3Nbk1u7x6NcA1wscJNcbHCz2Axw1FtccQNdXHEzXYNdo13DXeVXHHGTXkNebHHTXrxyA18DXyxyQ198cnNfo1/DX+xys2A8ctXEnHMDYOxzM2EjYUxzcFA8c5Nh1Dycc8NiM2JTYnNik1rMdDNjDHRjY1x0k2OjY8x002QMdPNkXHUTynx1M+xMdVNlJJDbfxNlc2WcdcNl3HXzZix2E2Z8dkT4I2b8doNnM2dTKTx2ySyzZ8x3BHpMdyNoRwzMd1NokBeMd4MBXHejaTXrPHfjaax4EvmseDNqE2ozalx4jI2zarNq02rzaxNrMFyceQNrjHkza9T23HlkYTx5mE48ecNs420MegNtXHozKyx6UEicenNuPHqTbmx6s26jbsNu7HsDbyNvTHszb3x7VUQzb9CezHuTcCNbTHvDcHx7+M08fCNxNersfGNxrHyTl99trHzTcoNyrH0Dcvx9M3Mjc0x9Y9HcfYicbH2//+N0U1scff0QA3TcfjNVXH5TdUx+c3WMfqN1xPNcft5LbH8Ddlx/M3aTdrx/dkR04Ux/o3eMf9N3vIADeAN4I3hBAIyAU2FbP5yAg3jzeRS/HIDDeVAbDIDwEEN5xZQjefN6GJBzelRovIFzesyBo3ssgdN7Y3uMghN7w3vjVWyCU3wsgoT2s3yVYwyCxAaMguN9HIMFYnyDJMGT2uNuPINjfhyDk35zfp/OTIPjfxyEE39TRFedpGrshGN/3ISTgAyExVY8hOOAnIUDgNyFOQxzgTyFdZ+chZOBsy/8hcOCDIXzglSBM4KTgryGXavDgyyGg4Njg4PpXIbDg9OD/IcJexOETl2kNqyHU4S8h4OE7Ie3bJj6/IfwZBOFk4W0tjyIQ4YMiHkT80CMiKjYI4azhtyI+SlOOZyJM4eDv9yJY4fT4dOIDIm03pyJ0zsMifPA7IoTiROJM6rsilOJfIp0TOyKo4oMitOKT+26tUyLI4rci1OLFLmMi4OLUzOci7ApzIvT0+yL9YcTjEaxA4yMjEOMw4zsjIONM4+sjLONg0zcjOON3I0TjiyNM45jObyNY46zjtyNo48MjdPgg49Tj3U+Y1vcjjOP7I5jkCyOmHl6Y3yO05D8jwORNabsjz4PrI9TsIyPc5Hcj5OSHI/DklOSfI/0FpyQI7t8kE0LPJBzJKyQky4ckLOUIwUzlFyRD2rTlLQFbJFEUlyRY5VTw/yRk5WjlcOV45YDliOWQBnDlnCV85ajlsOW45cMkoOXS8zTl4OPvJLQLUyS85gTpuyTI5hsk1OYo5jMk5OZE5k8k9OZc5mTmbOZ05n8lDOaMHUslGOafJSTuPyUs5r8lN7K05tclR7js5ujm8Ob7JVznBD7zJWjnFyV05yjnMyWE5zzbRyWQ51EfM01Q52clpjVNHpznhyW5GKMlw3bw56lDFyXQ578l3OfI2Xjn1OffJfXObOfzJgToBOgNWMMmGPU7JiDoLyYo6EDoSOhQ6FsmQrE04vsmTsyY3EcmWQ0DJmDopyZt8HDQIOi/JnzozOjU6N3BTOjvJpzo/yao6QsmtOkbJsDpLOk0/Ncm0OlE3Asm3c67Jujpayb1J6sm/OmML9snCOmjJxTpsychEq8nKOnM6dcnOOnk6e8nSOn46gDqCydc6hzWBOorJ3DqOPbnJ3zqSQhbJ4jh4OpfJ5jqbPHHJ6TqfQnHJ7LMAOqY6qF5WyfE6rMn0OrA6sjq0yfk6ucn8Or3J/zrAygI6xDrGOsg1zsoHOs00osoKOtLKDTrXgYPKEUHUyhM5U8oVOuQ65jroSp/KGjrtOu/KHjryOvRDM8oiOvg6+jHayiY6/8ooOwM0ksorOwc7CTsLMwDKMJyQyjI1Wco0OxbKN2udyjnZod3QyjwI7jskDlbKQDspykM7LMpGNMrKSDszyks7Njs4yk/Itjs9ylM7QcpWO0U7R8pZBynKWz3zyl07UTtTymE7VspjO1vKZjtfO2E7Y8prVtzKbS9gym8Dc8pxD+LKcztzO3U7d0JzOlvKeTt9AYXKfDuByn87hECqyoJB5MqEO41px1WTO5Q7lhHqyos7mzk1O57KkDoCypI5f8qUO6vKlzuvPw/KmneKypw7tzmdyp+DQDu+O8A7wkCzO8YzkTvJO8vKqjvQyqw2N8quO9g94DvayrJUgcq0nXY748q4O+bKu0eXyr077zVAysB87Dv1VUjKxDmvysY7/Tv/PAEyFMrLSSY8CD+SPAvK0TwPytQ8FMrWPpzK2O8jQLnK240SSJDK3jwnPClFlsriM87K5DwxyucCL8rpAS7K61VoPD3K77TNPEPK8zxI+Cg8TE23yvhAZcr6PAXK/I2Oyv48XMsBPF89ocsEPGTLB5sBPGo8bDxuyw024ssPPHfLEjx8PH5GS8sWPITLGZJ8PIpiP8seNiLLIDVwyyI8lzQHyyU8nMsoPKDLKzyjNqLLLjynMcPLMQF+yzM8rhAjPLHLODy1ePk8ucs9VW08v8tBPML2xjzGy0Y8ystJSfnLSzj6y0081MtQPNjLUzQoy1VI3MtXAi/LWTzoy1w1+stePPDLYTzzNYU/vctlPPk8+zz9R1XLaj0CPQSqznPchoo9CstyWzQ+ast2PRLLeT0Wy3w9Gst/PR0/8cuCW8rLhOkkPSbLiDkEy4o9L8uNPTLLkD01y5M9OVGby5Y9Pjtly5lFJMubPUc+H8ueRMLLoD1OPVDLpD1Uy6c9V8uqPVvLrT1fy7A9Y8uzMjXLtT1py7c9bErjy7o9cDodSZHLvj11y8Fq/z16y8U9fkUmy8gIpcvKMdjLzPT1PcnLzz2Py9GWhsvUPZg9mjZwy9iWNYJcy9w9pjHCy989qkIjy+I9rsvlPbJLt8vobec9uD26y+09vsvwWJY9w8v0PcbL9z3KPcw9zsv8PdE+BMv/PdY92MwDRkvMBT3gfz495FV1zAozV8wMQfnMDj3vzBE98xHtzBQ9+D36Mh3MGAF+zBo+AswdhrY+B8whPgs+DcwlVNM+EswpYQ7MKz4YPho5aswvPh+Y9EX0zDM+Jz4pzDc+LMw5MxrMOzgxzD0Kv8w/PjrMQjqSzEQ+QMxHPkXMSj5IzE2KUT5PzFE+U1grPlbMVj5ZzFlEpDCHPl/MXp6BPmVCocxiPmk+a8xmS3/MaD5xzGs+dcxuunE+ekuVzHI+f8x0PoPMdznXzHl3itGyRdeJQj6QPpLMgVHXRcc+msyGTGjJaz6gzIo+pcyNPqlofjqRzJE+sDryzJT/KD63zJg+usybMcbMnT7BA9o+xDMczKJMQcykPsxLPcyoPtNKRsyrPtjMrj7bPt095MyyPuLMtT7mMyQ+6c2PPu3MvDIGzL5qlz73jhI++8zEPv7Mxz8CPwQ0tMzMPwjMzj8LzNFDAszTPxLM1rHtNuD+rj8azNw/HszfPyLM4j8mWws/KT8r/F8/L8zrVk0/M8zuPzfM8T86bdLM9EIGzPY/QkkfzPk/Rsz8P0k2mMz/P03NAj9RzQU/VM0IBJrNCj9bzQ0/XgEUP2AyFM0SRQ0/ZzbJzRc/azcdzRo/cM0dMvI/cy9/P3Uz+c0hP3ky8j97zSU/fzorzSj3uc0rQjLNLQF9zS8wk80xP5PNND+XzTc/ms06P57anD+izT8/pj+ozUNeEs1FP7DNSD+0zUuyfc1OP71Ux81RP8JJPc1UP8fNVlJdzVg/zs1bQsU/1K9LOVY/2T8EzWI/3T/fzWUDfj/jzWk/6EIieng/7c1vP/LNcj/1zXQ/+c12M+DNeDXAzXpABEAGzX7h4EALzYI8w82EQBLNh0AW01Q+Q0AazY5AHc2RUrpAJM2VPP/NlwZ0zZlALT+JzZxAMc2fQDTNokA4OFDNpUA8zagQZM2qQEJu6jbfza5ASM2wQEzNs0JgzbVAVDupzbhAWkKozbtAYD7Ezb5AZM3BQGnNxEBszcdAcM3KQHRCoc3NQHnN0M3YQH74ec3UQINAhTOdzdhAiTYizdtFyc3dQJFAk83hQJbN5DxSQJvN6ECfzetAo83uQKjN8be6QK7N9UCxzfdLlc35QHZCXUC6QLzN/kDAbJJhuEDFzgSu/VOdrs3OCUDTzgxA1jnHzg9A284SQN5IB84VQOLOGEDma8zOG0Dqzh485c4gQPHOI0D0QPZDv84nA07OKT8/zitBAc4uzRU5es4xQQlPWs41QRDOODMPzjpBGM49QRvOQDfYzkJBIs5FQSYyJc5IQSrOS0Etzk1BMM5QQTN0skE2zlVBOs5YQT3OWzVFzl1BQ0FFzmI85c5kDtJBT85oMoc5jkFWjKZBWc5uQV1UN85xQWHOdEFlzndBaDksznpBbM59QW/Of0FyTS7OgkF3L3/Jac6GNKPOiEGBzotBhTbGzo5Bic6RMrzOk0GPQZHx0s6ZQZdBmVp2UrLOn0GgzqJVQ0GlzqZBqEGqQazOq0GvQbHOr0G0zrJBt861QbtFXs64Qb9rpjl/zryLSg/1zr9Byj+YQc3OxEHRzsctIs7JOVhB2s7M9q1B387QQeJB5DglztRB6M7WQew3OgRIztpB8TqBzt1B9c7gQfrO4zyCzuVCAc7oQgXO60IJQ0PO7kINPA7O8UISRGxPP871BnTO90IbQh1plM77PpXO/VdHQifPAUIrMC5CLs8GQjFCM40/QjY6vM8MQjvPDzlXzxFCQc8TQkTPFgS6zxhCSs8bOiHPHUJRTWTPIEJVzyNCWEJaUc/PJzhizyk3788rQmXPLkiuzzBCa88zWD3PNT28zzdCds86QnpCfM8+Qn9lbM9BQoTPRE5tQopI4jpEz0lCkEfOz0xuis9OQpcBD89RgQfPVEKfz1ebMs9aQqnPXUKtz19CsTWrz2I6ms9kQrg4i89nMyTPaUm5z2yJikFMNp3PcELKz3NCzc92QtDPeULTz3xC1zzpa4XPgULeMzzPhELiz4dC5jScUgPPizdJk1JC7jfiQvHPkkuJz5RC+E8wQvtC/Tmdz5pDAUMDz55DBs+hQwrPpLzuQxBG/V+Sz6lDFjziz6xDG4RD4FlDIM+yQyPPtTW4z7d2OzUcz7pDL8+9OU7Pv0M2z8JDO8/FQz/PyENEz8tDR8/OVITP0ENONYLP1ENSz9dDVc/a0CZDW8/eQ15DvM/hQ2JKEs/kXlpDaM/otvhDbs/ssjlDc8/wQ3bP81XTQ3zP90OAz/pDg8/9Q4Y4odAAOBfQAkONtBbQBkOSQ5RA9kOXQ5nQDUOc0BA8k9ASfGdDpdAWQ6hDqtAaZ3zQHEOw0B9DtDnjQ7fQJJ+y0CZDvtApQ8MyTtAsQ8fQL0PL0DE7STM+Q9I5o0PVNA4+ENA5Q9tbRFVI0D2amEPj0EFAGdBDQ+pD7NBHQ/E/5tBKQ/XQTUP4SIZJT9BSQ//QVTYl0m1EBjab0FpECtBdRA7QYEQRQQJEFDoZ0GVEGNBoXtPQajL90GwBENBuOpvQcDoG0HKbvdB1RDFxQdB5RDU1sdB8BdXQfohyRD9EQdCDREXQhkRI0IlES9CMZoxVnNCPRFLQkkRV0JWz00Rb0JlEXtCcRGHQnwXe0KFEZwETRGnQpkZv0KhEce4cS1nQrG8q0K5EetCxrauCV0SCP+I+WNC4QGjQukSK0L1EjUZu0MBEktDDRJXQxkSYRJpCuNDKVBZEodDORKXQ0USo0NRErNDXRK/Q2kSy6PX55D1+0N/e1ES70ONEvkBl0OaZLUTFO1pEx9DrRMpEzNDvRM/Q8kTT0PVE1tD4SsvQ+kTdECvQ/XFvROTRATjP0QNE6tEGRO5E8NEKRPTRDUT3AXFkjET70RNE/kUAjmhFA1nJRQdGO0UK0RxFDtEfRRHRIkUV0SVFGNEoDKlFHNErhexFIdEvRSVFJ2hm0TNFLNE2RS92akUyBEFFNNE8RTdFOUU70UE/P9FDNVLRRTcK0Uc6sNFJRUozdtFMRU5FUNFQRVTRUxei0VV2O0Vd0Vk1Taa40VxFZtFfBH7RYUVt0WRFcdFnRXXRakV40W1Fe9FwRX7Rczuk0XU2QdF3RYc229F6OHPRfEWPEQc9LNGAMt0EldGDd0rRhUWcMuHRiEWhNnjRi0Wl0Y4+FNGQRa3Rk0Ww0ZZFtNGZRbjRnEW7NdLRn0C60aFFwtGkRcXRp8yFPaQ8BdGsPpXRrnRm0bFF1j6NRdkIJzLp0bdF3tG6ReHRvUXk0cAHEUXoN0HRw0Xt0cZF8Dsv0clF9tHMM2LRzkX8Rf5GANHTRgPR1kYH0dkB6tHbRg3R3kYQVPXR4UYU0eRABNHmRhozodHpRh7R7EYi0e9GJdHyRipGLNH2QVXR+FNp0frWHEY4MtbR/jOy0gBGP9IDRkPSBkZGRkjSCkZLRk3SDkZQ0hFGU0ZVRldGWT7RRlw2eEZf0htGYgPE0h5GZkZo0iJpxUZs0iZGcNIpRnPSLEy30i5GedIxRnwvg9I0RoA2mNI3RoTSOkaIMJ/SPRHq0j9GkIW/0kNGldJGRpg5rdJJRpzSTEaf0k9GotJSRqWC3LlLRqnSWDsI0lpNLtJcRrHSX0a00mI6RNJkRrnSZ0a8NkNpwNJrNobSbUbF0nDrz0bL0nRGztJ3RtFG0wIl0ntG19J+RtrSgUbeXABG4dKGRubSiUbp0oxG7dKPRvDSkkbzAYTSlkb3RvnSmkb80p1LfdKfRwPSol5ERwgQBkcKN8nSp0cP0qpqk9KsRxXSr9/GRxo5nNKzRx9GK9K2RyPSuWd90rtHKdK+MurSwFJy0sJHMkGd0sWLskc40slHPDRR0syFSNLOR0PS0Tbm0tNHSdLWRbLS2EdRlLxHVNLdR1g0udLgNdDS4kdg0uVHZNLoR2fS60dqVts0o9LvR3DS8kd0R3bS9kd6OTPS+Ud+QbDS/DHr0v6vA74M0wFHkNMEAa/TBkeXR5kz8NMLR57TDjH/0xAQudMSR6mx6DiL0xZHr9MZR7I+kNMcR7bTHwFV0yFHvNMk+LnTJ2DiR8czNtMrO6nTLUfN0zBH0QV60zNSu9M1R9jTOEfbOhWDlfUKR+E5uNM/R+XTQkfo00U4y9NHR+5ASNNLkn1H8zlV009H99XoWy/TU8loQXrTV0yQDwbTWkgESAbTX0gK02JIDlsHNaRIEUgT02hIFzfY02tIG9NuSB5g4kgh03NgctN1SCrUP0gs03pIL9N9SDLTgEg104NE7dOFEAjThzcJ04lIQkhE041IR9OQSEqtG0hNQIA2mEhQ05eoHEhV05tIWNOeSFtBVtOhSF9FQ0cu06VIZEw3OJDTqUWo06tIbNOuSG8JW9OxSHPTtEh207dIe1EN07pIf2cxSIJJH0Aj08BIh9PDSIo6mtPGSI/TyUiT08xIlp0SSJlIm9PSSJ9IodPXSKXT2kip09xIrNPfSK/T4kvx0+RItdPnk4JIu9PrSL/T7kjC0/FIxdP0mvrT90jM0/pIz9P9WD3T/0jW1AJI2tQF+4lI30P91AlI49QMSOZWFtQPSOo5uDqD1BNI8NQWOf40NNQZcRFI+dQdSPw0rNQgSQDUI0kDPA7UJkkH1ClKndQrSQ0BKNQuSRFJE9QySRZJGNQ2DTvUOEkeSSDUPEkj1D88BtRBSSo1LNREQpzURkkxSXHUSUk11Ew5ogFL1E9JPTVu1FKfstRUSUTUV0lH1Fo8z9RcSU3UX0lR1GKGFYXQ1GVJWtRoSV3Ua0lgMv1B2tRvSWXUckloSWrUdklt1HlJcNR8Y/ZJdtSASXo5NNSDSX7UhkmBSYPUimga1IxJitSPMyPUkUmRPOfUlKmL16xJmEAESZtJnQaa1JxS8EmjNwx4tNShSak4SNSkS5jUpkmx1KlJtD2v1K1ASNSvSbvUskm/1LVJwkBf1LhJxtS6ScnUvUnN1MBJ0TkH1MNJ1tTG6wxAKdTJSd/UzFQ71M5J5dTROLfU0zYD1NU3P9TXkQJJ89TbSffU3kn7NdnU4Un/1ORKAtTnSgVUVDM31OtKCjNASg3U8EoQ1PNQJNT1N63U9zWn1PlKHNT8BorU/koe1QBKJdUDSijVBkorNAZKLjq41QpKMnxiSjXVD0o4NrkQy0o81RX1UEpB1RlKRNUcSkfVHz/R1SFKT9UkSlLVJ0pV1SpKWdUtSlzVL0pfSmHVM0pkQO3VNkpo1TlKa9U8Sm7VPzTd1UFKdNVENyTVRkp61UloDEp/Of/VTUqDPjfVUEqHOSJVY9VUSozVV0qP1VpKkjYDVqvVXkqX1WFKm9VkTCvVZkqiYhjVaUqmfyVKqWOh1W5KrgFLaT/Vckqz1XVKtqrJSrpbjzlv1XtKwNV9SsPVgErG1YM/+ToZ1YZVCtWISs83W9WLStTVjkrYkd1K2zul1ZNK4NWWSuRK5tWaSurVnUrt1aBK8ffWSvRVgkr31adK+tWqSv0/8NWtSwLVsEsF1bNLCEdpSws3vdW4Sw9EJj1G1bxeqEsW1cCCZEsb1cNLH9XGSyLVyVZh1cuWLUsqWBrVz0svU+ZmKemNSzXV1rE+1dlG6tXbOR1LQNXeS0RoONXhNQTV40tMVE7hsLXR1elLVVM07UBLWtXvECvV8Up81fNLZUfRS2g3OdX520FTw9X8S3FLc1V11gBLeNYDS3vWBgHA1ghLgjjG1gtLhg+21g5Li+DhS47WE0uR1hZLlEuWZgeGQEub1h1Su9YfS6EzqBJP1iNLp9YmS6pLrNYqS6/WLUuz1jDRKEu51jRLvNY3S78/5NY67KZLxNY+N9TWQEvK1kNLztZGMf/WSDSH1ko1E9ZMM7jWTkWY1lBL39ZTS+LWVkvl1lnG9Uvp1l1L7NZgS+/WY0vz1mZL9zSXTIPWakv81m1L/9ZwTALWczP91nVMCdZ4VEbWekwQNNDWfUwUASjWgEJx1oJMG9aFOXLWh0whNP8+JtaLTCbWjkwp1pE+o9aTTDBAQtaWTDTWmUw3TDnWnXzYTD44mnhsPKPWo0xF1qZMSdapTEw17EuI1q1MUdawWnzWskxY1rVMXGXITF80R0xhB8U94Na9zIZMaNbATGvWwzP81sVMcdbITHTWy03W1s1Me9bQTH5JDdbTTILW1kyG1tlUqEyL1t1MjtbgTJLW40yVSPfW5kyaZdDW6UyeTKA/ThGL1u5MpdbxTKnW9EysMeHW92JE1vlMszaYTLUyJNb+TLrXAYzPTL/XBUzDO2rXCEzI1wtMyzlXTM7XEEzS1xNM1jth1xYH0dcYTN3XG0zg3H1M49cgURlM50Vn1yQ/1Duy1ydM70zx1ys3g9ctTPfXMEz61zNM/dc2TQDXOU0E1ztNBwdM1z5NC9dBTQ/XRE0SQ0BNFNdITRjXS00c105NIIxT11FNJNdU+V1NKTlj11lNLddcTTHXX00012JNONdlTTw9K9doTUDXa01D125NRqvjcgNNS9d0TU5i3E1S13lNVdd8TVk3JfmOQKfXgU1g14Q05deGTWcP4teJ36RNbdeNTXDXkE1z15NNdwJV15ZV2teYTX7XmwXeTYLXnk2FTYfXol4pTYzXpdf9r1bXqE2b16tNnteurt1No9eyTabXtU2p17dNrNe6Ta/XvU2yN2EzOdfBeMPXw027NoTXzjdu18hOC9fp18zX105C19AyFNfSTdCE8tfV19lN+k3JTfrv0U3d1+DX9tfh3mlNktfsTfTX50eL1+mTik4v1+xN9Kw6TffX8U36NGbX9E4M1/bX4df4gqJOQ9f72ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7S6Lkk1/jGT9f4xk/X+MZP1/hOTU5g2Bk+vdgbTmcKv07P2B94U9ghTnFOmU50OJzYJk542CnauE59cuBOgNhA2SlOhtoiTqFPqNg2To/YOU6SVhHSYU6W2D9OmVAq2EI4XdhETvPYR06mTqjYTDr/2E5OrthRT2DYU0622GfYWE68UWHYW07A2F4yuNhgTsVPZk8dTspOzNhnTs9Oa448TtPuXU7WMpnYbk7aBlxQE9jy2HQ2lNiG2JjYeU7q2HxO7th/TvLYgk6VTvfYhk76T+1O/tiLTwGJT08E2JDYYtiTTwvYlth3DerYmU8S2JxPFTK42I9PGdhiTx08o9ikTzHY0NioTyg45NirTy3Yrk8x2NDYsr2FMT/YtU9nm6XYukBd2LxPRvPNO7XYwDi/2MJPT09RMt3YxlSf2MhPVzinT1rYzU9e2NBPYV1i2NMEW9jV6kbY109q2NlPbtjcQCDY3gyp2OBPeNjj2P+KstjnQ1bY6WOHT4VPnU+J2O8FnNjxT4/ZAk+S2PbZBk+YAUc1/Nj7T51PiTwVT3xmVtkBT6XZBDvD2PdPqzTQNUDZCjXk2QxB5NkOT7exiU+62RNHn9kVT8DZGE/E2RsvltkdT8tPzRDRlErZIwXtT9PZJk/W2DBP2fSdT9xBTE/f2TBh30/j2TNPkE/p2TdO+tk5T+8EXJK82T1P9FGK2UBP1k50s5ZP+9lG2SFPDzU+R8LZS1AE2U40NNlQUAtmVk7fUA7ZVVARUBNPFkQ72VpQGNldUBtQHdlhUCDZZNixUCQGmtln2JfZI1As2Wz0MVAx2XBwH358UDnZdUHC2Xc8tdl5UEFbeNl9UEbZgIn3UErZhFBN2a9MDNmISJrZis4xAZzZjTQxUFqZLlBd2ZJQYEUmUFVDNNmv2Zlat9mbBTfZnVBv2aBQctmjUT7ZpUQtOGI6Dtmv2ZlQf9mtUINQ0Eavx4dQiNm0UIsHAdm3UJDZulCT2b1QltnAUJlD0dnDUJ3Zxk7W2chQpNnLUKfZ55XhUKsCTQjc2dJQsFC/UMHZ6lC22dpQuTHW2d2aC1C/UMHZ4lDE2eXZzZXhUMwFA9nsUNDZ706A2fJQ11BQ2fYBotn4NOrZ+jjK2fxQ49n/ATzaAVDq2gQ0yNoGUHBuY1DzVVfaC1D32g5Q+toRUP3a2lEB2hZRBEQhLSLaGjQSUQvaHmIY2iAzXdoiURVRVNolURraZ1EdI2NRLNosUYOSOdov2kxRbNpOUaVRSdo22kVRdNpp2klRaNo+UULaMtpcUaVRYNpm2mDaR9pW2mvaS1FC2jLaXFGlUWDaZtpg2kfaVtpr2ktRQtoy2lxRpVFg2mbaYNpHoTFRedqFUX3aVNpp2klRaNo+2m5RpdpwUWxRRVGNOBvadDmO2nZRleZ2UZhRrZxn2n1RntqAUaFiCFGk2oVLlNqHUarailGuUbBAUlGy2o9RtQ9i2pI4XQSr2pWL1VG/2plRwkW32pxRxkRs2p9GiNqhUc3apFcz2qY0i9qoUdbaq1HZ2q7KJFHe2rJTktq0UeQ2RNq3UejaulHr2r1R7lHw2sFR89rETyzaxscpUfsQB9rKEQfazFIC2s83O9rRUgna1FIM2tdSD9raUhJBnAEI2t4CnNrgUho2JgfCUh7a5kg92uhyVNrrUin4odrvUi44itryN2fa9FI02vdSN9r6PEHa/OiMWbza/1JC2wJSRdsFUklSS9sJUk5SUNsNUlMzwlJW2xJSWdsVUlzbGFJg2xtSY9seUmazI1Jpc6fbI1Ju2yZScdsoUnXbK1J42y5Se9sxO5HbM1KB2zZShDs62zk/1Ns7VT+q61KPMcrbQFKT20O/s1KY20dSnNtKUp/bTVKi21AWF9tSUqnbVUa521dSr4EJUrLbXFK1219SudtiPEjbZFK/22cysttpUsXbbFLI2281k9txUs7bdFLS23dhhziv23oQ3dt8Rl5sW9t/Ut7bglLh24VS5NuIQZfbinY3Uuoyc9uOUu7bkVLxCls6V9uVUvfbmFL625tS/dueUwBTAtuiUwXbpVMI26hTC9urU/XbrVMR27BTFNuzUxf5VlMa27hTHdu7UyDbvgb228BTJtvDUyo7fdvG/rpTMNvKj6bbzFM3289TOtvSUz3b1VNA29hTQ9vbU0bb3lNJQxZCf9viU07b5VNR2+hTVNvrU1c0mkJBU1rb8FNd2/NTYNv24mpTZjWmNVbb+1Ns2/5TbzNDAmBTc1oWU3YHEewUU3oBS1N8ZvjcCztWPEHcDlOEpo9Th9wTU4pFWNwWU4/cGTVYU5PWelOW3B9TmdwiU50y1dwlU6FNkVOjWY1rTWs83CyYy9wuU650M9wxNbg3cVOz1AxTtjHJU7hWW1O73DtTvtw+U8E0L1PE3ENTx0CA3Ea1QVPM7lhTzzev3EzpA1PU3FBT2FPa3FRT3lPg3FhT5FYn3FtT6dxdWJ5T7txhMllT81P1QwzcZlP5M6TcaTlm3GtUAEX/3G5UqtxwVAc+z9xzVAs4Vdx2Ai7ceEe0VhFDsdx8VBYDdVTH3IBUG0tSkaFUH4rWVCI24lQl3IpUKNyNVCuQsFQu3JLs4FQ03JbqNlQ53Jo2DdycVD9AKdyfVEPcolRGRh/cpUEk3KdUToHCVFHcrFRVN0Pcrzlm3LFUXNy0lbJUYcGP3LhUZdy7VGhRq9y+VGzcwQGv3MN0YtzFByncx1R43MpUezVNUZTczlvyVINUhdzTVIjc1lSLVI3c2lSQ3N1Uk9zgVJZrqlSZN1st4NzmVJ7c6VSiO0fc7FSn3O/G91Ss3PNU9dz1Q6nc90W33PlUuD9iMmjc/VS+j6xUwTXO3QJWh1THPWDdBoTQVM01XEfD3QtU0jje3Q48mt0QS/TdElTcOVT0X2dG3RdU490aVObdHVlcVOuTmVTu3SNU8d0mVPTdKTkMVPownz7b3S5U/1UB3TIJ7N00VQfdN1UL3TpPyN08NgDdPlUU3UFVF91EVRvdR1Ue3UpVIT4l3U1VJd1QVSjdU1Ur3VY+dN1YOfTdWgF23VxVN91fD9bdYRLc3WNVQd1mVUTdaVVH3WxVSzZaVU7dcVsu3XNVVN12VVcGmt15WSzde6rnVWChgVVjNrDdgVVn3YRUVd2GVW3diVVwVXLdjVV1NVndkFV53ZNVfN2WVX9Vgd2btYdVhpy+VYlDqAmS3aJVjt2lVZHdqFWUUpXdq1WY3a5Vm92xVZ/dtPlmVaNtF1Wm3bpVqd29VazdwJaYVbHdxFW03ceGLt3KVbw6+UP7VcDd0FXDbILd01XH3dZVyt3ZVc3d3DUkVdLd4FXV3eNV2N3mX4TU+VXf3es9td3tVfJV59NPVep/4FXt3fV0eFXyfkpV9VX3YyLd/FX73f85rd4BVgEMn94EVgXeB1YI3goyWN4MVg/eD1YTVhXeE1YZ3hZWHDhuM0TeGlYi3h1WJd4gVilfAt4jNlTeJVYw3idsdd4pVjbeLFY53i9WPN4yVj9WQd42VkRe/1ZHVknePFZM3j97IFZSOh/eQ1ZWN24yjt5HVlt5FlZe3kxWYlZk3lF4pN5TvJtWbN5XVm/eWtvxVnSBUlZ33mBIb95iVnxWfj4f3mZWghA4Vm3eajkz3mxWiqP8Vo1Wy95yNVJWk951VpbeeFaZTStWnDNd3n5Wod6BeKTeg1an3oZWq06n3olWr96MVrL2x96QVrbek1a5i4Xel1a+3ppWwT9zVsTen1bHPHYyUd6jVsxWzt6nVtHeqlbU3q1W196wOdTesj2A3rSAW1biNXBW5N65VudW6d69VuzewFbv3sNXN1b03sdW+N7KVvtfld7NVv/e0FcC3tNXBUHP3tc4z97ZMcgBvd7cVw/e3zL33uFXFd7kVxje51cb3upXHlsu3u1XIt7w46VXJ970Vyve99w3VzDWFVczNl7e/Vc33wBXOt8DVz3fBldARf7fCVdE3wxXR98POPvfEVdNixhXUAG+3xZXVDx43xlXWd8c4Q5XXt8gV2Ev2FKM3yRXZt8nV2nfKldtTp/fLVdx3zBXdN8zV3c+Ct82Ek/fOFd/3zs1A989V4XfQFeI30NXi99GV47fSVeR30xB2leV309XmN9SM03fVFee31dXod9aV6XfXVeo32A2Qd9iV63fZVew3GxXs99qV7bfbVe533Bfkt9yV77fdVfBwH3feFfF33tXyN9+V8wzEN+BNsvfg1fTO9hX1luLV9kLbFfc34xX39+PV+Jd81flWqTflDzI35ZX7N+ZV/DfnEB2V/Tfn1f3NK/folf736VX/krA36hYAjTc36tYBt+uWAlYC9+y5JnftFgS37dYFUA437r+TKYeWB3fv1ggD5NPN9/DNZPfxVgo38hYK9/LWC7fzlp839BYNN/TWDff1lg739k3fN/bWEHf3lhEPADf4UQ73+PqPVhN3+dYUFoP3+pYVN/tWFc3gDvJ3/FYXDdU3/Q2Xt/2WGLf+Vhl3/w0pVhp3/9YbWt+WHA4wuAE67BYdjc7MjrgCVh74AxYfsnxWIHgEViE4BTexliJ4BhYjOAbWI/gHgSa4CBYlj5ENVTgJFib4CdYnjhsPHjgK1ij4C40KFinOBAGFeAyWKzgNViv4DhYsmHV4Ds5VeA9WLg7A+BAYbNYvRFzeKRYwOBGWMPgST/u4EtYyeBOWMz+uljP4FNY0jfTNbzgV6NrWNkzUzTn4Fw1bOBeMk/gYFjk4GNY6DV3eZLgZ1jtda9Y8OBsWPPgb1j24HI9mOB0Mkrgdltv4HhZAumQWQXgfFkIrc5ZC+CBWQ7ghFkR4Ic50eCJWRfgjFkaClvgjzQL4JFZIV/CWSQFCktaWSjgmes1WSxQzlkvd5JZMuCiPbtZN+CmNUbgqFk94KtZQOCuNtxZROCxWUfgtFlL/mBZTjpzM1jgukN34LxHw+C+WVjgwVlb4MRZXuDHP1XgyVlj4MxZZuDPWWo2JODTbpbg1Vlx4NhZdUmu4NtZeUlAS1jg3z0g4OFZgeDkWYQ6SODnWYjg6lmL4O1ZjuDwWZGmZVmUuSZiBlmc4PgE6uD6X7xZoOD+U2nhADyQ4QJZqeEE/odZrlZ94QhZstveWbXhDVm4OKfhEFm84RJZv12/WcI1iuEYWcZRADZl4RxZy+EfWc7hIjM54SRZ1EC54SdZ2OEqWds15AbM4S5Z4OExWeMzA+E0WefhN1nrP5A1v+E7RGzhPVnzaLHhQFn3s+VZ+uFFNDtZ/uFIWgHhS1oE4U5PN+FQZkzhUlqVWgzhVloQOnS0gkzW4VtaF+FeWhrhYVodQqs8P1ogO0XhZlgR4WhaJ0BUQKbhbFos4W9aL6njWjLhdDV84XZaOg5E4XlSRuF7N8nhfVpEMzjhgDng4YJaS+GFQryHZlpQ4YlaU1IF4YxFY+GOWlnhkVpc4ZR3E1pg4ZhaYze74ZtaZ+GeWmrhoVpt4aRUN+GmNlHhqD0s4apaelgxPpPhrnyn4bBag+GzWoZaiOG3NxLhuVqNVhThvFqRdKRalOHBWpfhxFqa4cdanuHKWqFKLuHNjlNap+HRWqrh1Fqt4ddasOHaRr86/+HdWrZauOHhWrtUvOHkWr/h51rC4V1axeHsWsg5u+HwWszh81rPOMTh9juP4fha1vyRWtnh/UN54f9a3+ICWuKZilrl4gda6OIKWuviDVru4hBa8eITPn7iFTpn4hdQaeIZWv1D7jZr4h1HBuIfWwXiIpydWwriJlsNNCNbEOIrWxPiLlsWAks5mOIyWxviNVq74jdbIYoxWyTiPDkz4j5bKgIdWy1bLzjY4kRbM+JHWzbiSls5ZG1bPOJPWz9Hx+JSULziVFtF4ldbSOJaW0viXVtO4mBbUeJj1blbVuJnW1k1+uJqW13ibVtg4nBbZOJzW2cw1ltqXeXieVtuW3DifVtz4oBbdskZW3nihTsd4odbf+KKW4JZjVuF4o9biDqb4pJbjOKVSrzilznS4pk0UeKbW5dI3OKeOdLioF1i4qJboeKlW6VFBOKoW6niq1usfIBbrwt5MpLisVu04rRbuOK3W7w1z0J34rtbweK+SO3iwFvH4sOehFvMOeAxweLIh99b0+LMW9biz1vZOODi0lvd4tVwPl4R4thb5OLbW+dDj+LeW+s7quLhd0Zb8VSB4uVb9eLoW/ji61v7YY3i7tWh4vFcA+L0XAbi91wJ4vpcDOL9XA/jALcBXBTjBAEE4wZcGuMJVQ3jC1wh4w5cJOMRXCfjFDLU4xZcLue64xo/yOMcXDY5NuMfXDrjIlw9QATjJVxB4yhcROMrXEjjLlxL4zFcTuM0XFE9T0ux4zhcVnA2XFnjPVxc40BcX+NDXGI4jzICXGU08+NJXGnjTFxs405cb0uy41FcdF8h41RceONXXHsHaeNaXH/jXVyC42ByHVyH42RcijScNmbjaFyP42tckmoWXJU0CeNwSJDjclycVnHjdUcG9i5couN6XKXjfUGc439uouOBYa7jg5dpN4AHv+OHXLTjijKP44zl2uOON8XjkFy+Mv84++OUogVWu+OXXMbjmlzJQpPjnlzNNn410OOiXNPjpVzW46iDRFzbM8PjrFzfNSnjr1zj47JSJVzn47Zc6uO5XO3jvEU4PT3jv1zz48Jc9kG748Vc+t9UXP3jyjhu48xdAmzi489dBkZ849JdCuPVXQ3j2F0Q49tdE+PeZYtdYePhXRpSc10d4+ZdIOPpWULj610m4+4/i+PwdPJdLeP0aYzj9kFK4/hdNeP7VYPj/V07N9FdPWeD5AFdQeQEXUTkB11H5ApdSuQNXU7kEF1R5BNdVOQWXVfkGV1b5BxdX1BjXWJFcuQhXWZDWOQkXWrkJ11tPBE7ZeQrXXJKTuQuXXc8QTt2XXrkM119NsLkNl2B5DldhOQ8AlnkPjrn5EBdjAflNLbkRDbI5EZdlDPV5EpdmORNXZvkUF2e5FNdoeRWXaRDQORZXajkXF2ruRZdruRhPefkY121Nu1iieRnXbvkajVc5GxdwYqe5G9dxeRyXcjkdV3L5HhdzuR7Mz3kfTkz5H9d1+SCemZd3OSGXd/kibp3XeRd5jkD5I9dweSRXe3klF3wNTLkl130PxXkm134MeHkngbf5KBd/+SjMt3kpV4E5KheB+SrXgrkrj705LBeEF4SM+nktF4W5LdeGeS6XhzkvV4fbfBeIRrpBeDkwl4m5MVMEDKy5MheLOTLXi/kzl4yPPrk0WCxTUEy5eTVXjtoGuTYkvReQOTcXkPk315GR+rk4krY5OReTeTnXlDk6l5TNXbk7kRx5PBeWtJYO5FJOeT1Q+fk9wFKXmTk+l5n5P1eauUAlNheb+UE0w1edDpt5QheeERPQgPlDF5+5Q9egeUSXoQzHeUVXog4wuUYMgblGl6P5R00BeUfXpUzsXd85SNemk6BmoRenkix5Sk7R+UrXqXlLl6pBJvlMV6uZ+rlNV6zOqY/FuU5e2R18+U9Xr7lQEuY5UJew+VFXsblSF7J5UtezDTC5U7bHjhB5VE0P17V5VRe2OVXXts4xuVaXt84KV7h5V47AOVgUzBe6eVkXuw+YThV5Wg5DlE+5Ws3nuVtXvflcEkS5XI5quV0Xv/ld18CXwTle2NvXwnlfzy25YFfD18R5YUQh+WHXxflijiGXxvljV8e5ZCY8V8j5ZRfJuWXXynlmjVI5ZwzouWeXzLloV815aNfOOWmXzvlqV8+CYjlrE1Q5a4z3eWwX0hfUV9L5bVfTuW4X1Hlu5X9X1YBTDG/5cBfWzgX5cM06eXFX2LlyF9lMonlzF9pD0hfbOXRX29GR+XUM5jl1l92Mfrl2V965dxffV9/5eBBDuXiVdzl5F+HA17X8F+LU7Q3ceXrX5Dl7uXa5fBIruXyX5rl9V+dPYtOyeX5PBfl+9uiX6eE+V+q5gFfrjj2NP7mBV+zUDfmCF+35gtfumdCX73mEF/AX8LmFF/FXoJfyLCiX8teq1zuX8/mHl/SRl7mIV/X5iRf2uYnEDXmKV/gYD9f4+YuN+XmMF/o5jNf6+Y2X+7mOV/x5jxf9OY/X/fmQl105kRf/eZHUPnmSWADVILmTGAHpENgCuZRYA3mVD6s5lZgE0Y75llgF1GpYBrmXmAd5mEKAuZjnXNgJeZnYChRWWaS5mtgLT0+R2Hmb2AzQPbmc2A35nZgOuZ5jWZgP+Z9YEJgMjo25oFgR70zMevmhTku5odgT+aKYFLmjWBVgtNgWFaT5pJgXOaVStLml8f+YGSMaOabYGjmnmBr5qFgbuakYHHmp2B15qpgeDNg5q47jOawYH9ggea0YITmt2CH5rpvImCLQhzmv2CP5sJgkubFYJVLY+bIYJmFv+bLYJ3mzmChOvM0FebSYKc60+bVYKvm2GCust3pppCGYLTm3+5iYLnm42C85uZgwObpOLzm6zdg5u1gyQFKnQRgzTP8Nyrm9GDSN6rm+GDWAXHm+2DaNc3m/mDfMgE2bOcCYOTnBWDn5wiwNGDrTEHnDWDw5xBg8+cTYGHnFWD55xhg/ELw5xthAAbcYQLnH2EFMzxIKGEJ5yU8++cn4DVhEWET5yxhFucvQ9jnMWEcOQXnNGEg5zdhIzTbYSbnPF095z5hLPqsYS/nQ2EyYTTnR2E350phOudNYT7nUGFB51NhRDld51ZhSOdZYUvnXGFO519hUediNdLnZGFX52c3YOdpA1fna2Fh525hZAbKYWdPxudzYWvndmFu53lhcW6K53xhded/NpU4t+eCYXvnhWF+54hhgeeLYYTnjmGIYYpWkzIK55RhkOeXYZNBDktf55thmOeeYZs6eTkL56JhoOelYaTnqGGo56thrIsGQ+DnsOj857RBOee2YbjnuV9DYbznvWG/58BhwgJ158MzEOfFYcnnyGHM58phz2HR585h1GHWS4kyy2Ha59Vh3efYGukC5efbYeTn3mHnaGVh6ufjYe0PBufmtjg3cWHzTl7n62H4Yfrn7zQ+Yf4CLkAT5/NiA+f24Pbn+DhUR1NiDOf8Yg/n/2ISL7U8fmIWMtDoBWIbMtzoCGIfNqViIugNYiXoEGIo6BNiK+gWYi4zDwF46BpiM17TM97oHmI56CFiPOgkYj9GZ+gnRm/oKY9LYkc05+gtYkvoMGJO6DNiUeg2YlToOWJX6DxiWug/Yl3oQg/k6EQ3jehGYmcCWOhKYmtV5+hNYm/oUGJy6FNidehWYnjoWWJ76FxrHmKA6GBig+hiYoboZWKK6GhB1+hqYo8+eWKS6G9ilTxx6HpimUU46HZinVar6HpioTY2ENTofg5V6IBiqWKr6IRXLWKwRgmfsuiJVqDoi2K3h6tiuuiQYr3ok2LANeU0R2CcYsU/STMh6Jpiy7I0gNc5YOifYtLoomLVLSLopWLZYtvoqWLeR6vorGLi6K9i5eiyYujotVYKYu3ouUAM6Lti8+i+YvbowWL56MQ2rujGYv7oyWMBNfXozWMF6NBjCTMT6NNjDejWYxCmOWMT6NtjFjb/LbtjGujhYx3o5GMh6OdjJeOUYyjo7A3q6O6uVmMvRzo3dejzQfno9WM36PhjOmGu6Pvnsuj9Y0HpAGNE6QNjRzV0Mm/pB1TbY07pC2NSOAnpDkq8Y1d0JmNaY1zpFWNfNwkySukZY2RjZukdfgdja0bG6SFBGGNw6SVHxeknY3bpKmN5SRLpLQXNY35HOWOB6TNjhOk2Y4c7VjvX6TpjjAbbOPXpPmOR6UEBdulDDXN+vHaOY5npSWOdM1fpTWOhPEjpUGOlQwFNqelUY6qoi2OtMc7pWTnR6VtjtFP6Y7fpYGO6Zi1jvellY8BZGGPDWFljxjM46W1jyulwY83pc2PQ6XZAhOl4Y9Xpe2PYEIerrWPc6YFj3+mEY+LphzNN6Ylj6OmMY+vpjzP6Nm7pkmPx6ZWe62P2RdXpmWP66ZxHVUbj6Z+8N2QB6aNkBOmmZAd+SmQK6atYS+mtODvpr2QTY088++mzZBjptmQbPOQ2I+m6MhnpvGQi6b9kJQUDZCfpw0to6cVkLenIY75kMkHTSlzpzWQ3modkOkfq6dJkPunUN8RkQunYeTnp22RJ6d5kTOniZE+rpunmZFNkYenpNFZkWO/AZFtN7GReZGBar2RjOa3g+lPD6fVkaUHkOZLp+Tls6ftkcTOTR2np/1Mt6gFkeeoEZHzqB2R/PgvqCkFTZIQIJx+p6g9orTxh6hJkjeoVZJDqGGSU6htkmOoeZJvqIWSe6iRkoeonZKTqKgbbNM3qLVLq6i9kro33ZLFFBeo0ZLXqN2S4Q/019WS76jwCWTaD6j9kwd6gZMRBqOpEZMjqR0216klkzjmj6kxk0upPPnrqUWTZ6lRk3epXZODcUmTjgmhk5upeZOrHe2TtQTnqY2Tx6mZk9DoRYaLqamT5Yz1pr2T9NizqcD5L6nJCqOp0ZQc/A+p3ZQsBrzz7ZQ7qfGUR6n8Gr+qBNZ3qg2UY6oZlG+qJZR7qjEouOZ/qj2Uk6pJlJ+qVZSrqmGUtMcXqm2UxAQnqnkij6qBlOOqjZTvV2GU+PifqqGVC6qtlRequZUjqsWVLQLE5R+q1ZVA0q2VTng1lVuq8ZVnqv4/8ZV7qw2Vh6sZlZDSUUqbqymVpOYvqzUka6s9lcOrSZXPq1WV26thleerbZXyp7WV/6uBlgurjOcvq5WWI6uhli2NyZY7q7TXE6u9llOryZZdLpOr2Bcfq+GWe6vtloUu36v5lpQ2Q6wJlqesFZazrCGWvMjPTUGWz6w5ltjdy6xE3busTZbzrFkKh6xiB3mXD6xxCweseYaXrIGXNEe3rIwhm6yVl1EDe6yll2VyS6ywS7jMO6y88gOsxZeMzMOs1ZefrOGXq6ztl7es+ZfDrQWXz60Rl9utHZfnrSmX8601l/+tQZgIx+kTC61RmB+tX6PZmDDtZ61tK4+tdZhPrYExXZhc6DkRKZhs9nGYd62hmIPYHZiPrbWYmY09k4+txZitAb+t0OYrrdmYy63lKEut7ZjjrfrjMZj3rgjII64RmQ+uHZkbrimZJ641mTIY1Zk/rkmZSNOXrlWZW65hmWeubZlzrnmZf66FmaOXs5pNmZ+unZmp1gmZtXtjq9GZy67CtkmZ2UMAy4+u1ZnvruGZ+67tmgToVprdmhevBZojrxGaL68dmj+vKZpI61evNZpbr0GaZ69NmnUBoTS7r16YQZqTr22anNoTr32arN8nr4jQH6+Q4oevmZrU27Wa36+tmugSyZrzr72a/SGDr8mbE6/Vmx+v4Zsrr+2bN6/5m0OwBZtPsBGbW7Adm2mbcOh/sDGbh7A9IvDQI7BJm52ax7BZm6zZO7Bk3mOwbZvLsHlSdZvfsImb77CVm/mHC7ChnA4e8ZwbsLWcJ7DBnDewzZxDsNmcT7Dk8G+w7ZxlBwzrT7D9nHgG97EJnIjy37EVGwexHZyjsSmcr7E1nLuxQZzHsU2c07FZnN+xZZzrsXJ+CZz86qHgwZ0NAX+xjPZHsZWdK7GhnTUCYNbXsbGdS7G9nVVxsBkNnWTrf7HVnXex4Z2AGr2di7H1nZXlPZ2jsgmds7IVnbzRGdzFUpWd07IxBqWd4P/BnejQn7JFnf+yUZ4Lsl2eG7JpbWeycZ4v5jGeO7KGHMGeTNt9Y+eymZ5jsqWec7Kxnn+yvZ6Lssmel7LVnqOy4Na7suhCR7Lx7JGeyTc5ntezC44xN/uzFZ7tubzRM7MlOLuzLZ8Og3uECUj7s0GfJ7NNnzBA4Z87s2GfR7Ntn1OzeZ9dn2cU8Z9zs5Gff7Odn4uzqZ+VS2GfoNEfs72fsPi5AmOzzZ/E1Eez2Z/Xs+Wf47Pxn++z/Z/7tAmgB7QVoBO0IBJXtCmgK7Q1oDYEB7RBoEe0TaBTtFj/i7RhoGj/q7RtoH+0eaCLtIQJ57SNGMTH57SZKDO0oaC7tK2gx7S5oND7zFy7tMjgs7TRoPDNr7TdoQE1DaEPtPGhGOGQEmu1AaEuKDjb37URoUXd8VE7tSGhWSY/tS2haTITtTmhePjftUWhi7VSZjmSV7Vdoau1aaG1sYGhw7V9oc+1iaHftZWh67Whofe1raIE4Bu1vaIbtcmiJ7XVojO14aI9oke18PaHtflYJQ7HtgWia7YRone2HaKA6Ve2LPgvtjWim7ZBoqe2TaKztlmiv7Zly2u2baLVGEO2eaLntoWi8eCNov+2maMLtqWjF7axoyO2vaMt82+2zaM/+hWjS7bg1YO26Ww5o2e2+aNztwWjf7cRo4keV7cdo5jYy7cpCp+3MFP7tzknn7dBo8UMB7dRo9e3XQ9jt2Wj77dxo/rZRaQE0I+3haQXt5GkIMlzt52kMOkQvlu3raRHt7gS/7fBVY+3yQfft9Gkb7fcRB2kf7fppIu39oWtpJu4BaSnuBKIraS7uCGkxXJNpNO4NaTfuEGk67hMHAe4VVMHuF2lD7hppRu4dMgruH2/4aU48fUmRaVFB/+QOaVXuKDbB7ippW9u4aV7uL2lhZlNpZO40ccRpae44aWzuO2lvMvVE/+4/Ak7uQWl3BszuRGl7PBPuR2l/f3TuSmmD7k1phkRA7lE/+DTb7lQyyO5WaZA7oWmS7ltCru5daZjuYGmb7mNpnkpOaaDuZ2mjN4HJUWmnCZJpqQq/7m5pre5xWJHuc2mz7nYDXu54abnue2m8MsTuf2uj7oFpw+6Eacbuh2nJ7oppzII8ac/uj2nSCQfukmnWYcxhO2nZ7pdp3O6aad/unTeoaePuoGnm7qNp6e6maezuqX4uOOHurWnzOJIHf+6xafgFnGTT7rVRR+63agDuumoDZvjuvWoH7sBqCu7Dag3uxmoQ7sk+Wu7LahbuzmoZ7tFqHO7Uah/u12oi7tpqJe7daiju4Gor7uNqLjWzBZ3u52ozQnc5ye7rajju7pOoajxJ6Wo/nJ/u9GpD7vdqRpsKaknu/WpM7wBqT0VuaxJqU+8GYkTvCGpZOR1Mg+8Mal5xQe8PamLvEmpl7xVqaO8YamsIre8bam93+2pyXGs2QTWl7yNqeDH57yY3Tu8oEXPvKmqCVDfvLWqGZD6cn+8xSAc3mu80ao7vN2qR7zpqle89Q4/vP2qcap7vQzVd70VqpDhk70g4vO9KaqxBmO9NT9DvT2qz71Jqtu9Vark5ND1g71lqvluUasFnPDcm7184ge9hasjvZGrLOSjFyWrPOg/vamrT721q1u9wRLjvcgN573Rq3+93auIyPe96N+LvfGrpQI/vf0Ic74Fq8ZWFavQ85jwR74dq+e+KN9jvjGr/Srzvj2sD75JrBznLTcLvljZD75hrD++baxIzm2sUqT9rF++iMs5rG++lax5VgDLk76lrI++saybvrzh0Of5rKlxsZt9rLe+1Nz7vt2sy77prNe+916vvv2s678JrRzI778WTgTR4a0I0be/Ka0ZTqu/N44fvzzV2a01TqO/TUBzv1VL9a1YQD+/Za1o9NjcKa13v3mtg7+FrY+/kND9rZ+/na2rv6p8Ia2/v7m1o7/Brde/za3g8g+/3a3wDTj5b7/trge/+a4SJm2uHvE9rivAFa43wCGuQVujwDFVX8A5rl16Qa5rwE2ud89BroPAYVGHwGjp68BxrqfAfa6zwImuv8CVrsjfX8ClrtvAsa7nwL7YZa77wM2vB8DZrxGEQa8fwO1AS8D1LY/A/ci7wQWvTQS3wRHefNjrwR2vaXBzwSjOH8Ew6sfBONJQxy/BRa+XwVGvo8Fc4I/BZa+7wXAvE8F5H1PBgAXbwYmv58GVBFvBna//wamwC8G1sBfBwbAg1PGwK8HU+gPB3bA/wemwS8H1sFfCAbBjwg2wbRznwhkBCvRJsIfCLbCTwjmwn8JFsKvCUbC0S7vCXVYM8tfCabDRLZDWu8J5sOfChbDzwpGw/VL7wp2xD8KpsRgER8K1sSvCwbE3ws5VobFLwt2xV8LpsWDOR8L5E3/DAbF9/9Gxi8MZsZTme8MlsaUuy8M1sbfDQNPLw0mxz8NWVN2x48NnvX2x98N1sgFU58OBshTuhWGrw5GyK8OcEm/DpbJHw7GyUAcnw72yY8PJsm859bJ7w92yh8PpspPD9bKc33PEAbKtI7vEEbK/xBwhgbLTxC2y3VgBsum8HbL3xEmzANaY4IfEWbMXxGWzINTbxHECyMhTxH2zQTWfxImzUsIHxJWzY8Shs3PErbN/xLmzjU/Q/G/EybOg2IvE1PUrxN2zu8Tps8fE9bPTTfWz38UJDskX98UUJcfFHbQDxSm0D8U1tBvFQbQnxU20MM1rxVm0Q8VltE/FcbRYCeeo0bRpJcfFibR40mvFlbSLxaG0lYrDxbG0q8W80BG0u8XJtMfF1bTTxeG038XttOvF+VRjxgE6d8YJtQ0c2U+nxhm1IYH9hjfGKbU3xjTPG8Y9tUvGSbVU7e21X8ZdtWvGabV1FFDVI8Z5tY/GhQrjxoza78aUGP/GnbzvxqW1yMykx3/GtbXeRvvGwbXvxszwT8bVtgfG4bYUCywho8byQrW2L8cBtjgN18cNtkvHGbZXxyW2Y8cxtnJCOM0jx0G2i4DTx1D43qjZtqPHZhgzx222t8d5tsLJabbPx42228eZtuTWl8eltvfHs9QptwllBbcXx823I8fZty/H5bc465/H9Ngbx/23V8gJt2PWo8gZt3fIJbeA8BfIMbeTyD23n8hI0UfIUbe3yF23w8hlt8zY98hxt9zr58iBt+/Ijbf7yJm4B8iluBF4R8ixuCPIvQAHyMW4P8jQ9ZfI2bhUBOPI6bhlL9TCTbhwCLzZA8kBuIfJDbiTyRm4nYTttCm4r8kxuLvJPbjHkyG40NsJuN/JWVu7yWG498ltuQHzuVT7yYG5F8mNuSPJmbktQjkCmcDZuUPJublPK8W5W8nPq125b8nduXvJ6bmHyfW5lbxhFYEDIaziWmm5t8oVucNwrbmludVOoZaBuefKObnzykW5/M6TylG6D8pduhvKabonynW6N8qBVMPKiTxpulHynbpcGAPKobpvyq26e8q5uofKxbqXytG6o8rdW226t8rtusPK+brPywW628sRuufLHbrzyym6/8s05ZfLPPM/y0dPfbsny1T7T8tduz/LabtLy3T9O8t+fd27ZwY9u3PLlbt81MvLoNBTy6m7nM+BQY/Lubuzy8W7vQUvy9G7z8vdWRG748vtOivL9Scby/28B8wJvBfMFbwmDj28M8wpvD/MNAuXzD28U8xJvF/MVUc/zF28daIXzGnWB8x1vJfMgbyjzI28s8ybHWG8x8ypvNPMtbzcVDF2kbzs6BvMzbz89wfM2b0PzOVg98ztCp/M9b0t6eD/kA8jzQm9R80VvVDllb1bzSW9Z80xvXPNPb19R+zlt81NvZPNWb2f3DG9q81tvbfNeb3DzYW9z82Rvdo4e82hvevNrb31LRDd1829vgvNyb4XzdQJO83dvi/N6b47zfW+RVT9vlPODb5fzhm+a84kQ1POLb6Dzjm+jWPRvpvOTb6nzlm+s85lDkvObb7Hznm+086FvuEud86RHlm+9AbfzqG/B86tvxPOub8fzsW/KNc/ztG/OTzVKLvO4b9Pzu2/W875v2fPBb9zzxDvt88Y0nD+O88lv5TMTUlXzzU0u889v7PPSUZvz1G/yBwNv9PPYb/c6HW/589xBS/PeEN0yT/PhyDhwBPPlcAfz6HAK8+twDT6FcA/z726xcBRI03AX8/VwGvP4cB1SafP7bi5wIzx58/9I1PQBcCr0BHAt9AdwMDV49AqQ+3A2Nqn0D3Im9BFwPPQUAWn0FnBB9BlwRPQccEf0H3BK+2xwTfQlA7twUPQocFM1HPQrQEL0LXBaSZz0MHBe9DNJF/Q1cGP0OFg99DpwafQ9NtH0P3Bv9EJwcmHTcHX0RzUH9ElBsPRLcH4/vzXY9E9wg/RScIb0VTd+9FdwjPRaOV1wkPRdcJT0YHCX9GNwmkOIcJz0Z3CfO//0a3Cj9G5VGnCo9HJwqzep9HYGlPR4cLL0e3C19H5wuPSBcLs6YvSEcL/0h3DC9Ioyh/SM+zlwyfSQcMz0knDP9JVw0vSYcNVLN3DY9J1w2/SgcN70o3Dh9KY2VfSocOf0q3DqNVn0rjXJ9LBw8fSzcPT0tjCdOSf0uXD6ot5w/fS+Szj0wHEC9MNxBTic9MZxCfTJcQz0zHEP9M9xEkmc9NI3PzxP9NVxGfTYcRz023EgMyf03nEk9OFxJ/TkeIz05myHcS4/ifTqcTL07XE19PBxOD2VSfH09HE99PdxQEZUPZpJ3DIp9P1xR1e/cUr1Ajkn9QRxUFVI9QdxVPUKcVf1DT5M9Q9xXXFfcWBDyfUUNWf1Fs2qcWlWgXFs9Rxxb/UfMtv1IXF19SRxePUnMvX1KXF+9SzyevUucYRBHPUxR6T1M3GK9TZxjYrtcZAyTjSd9TxxlfU/VFVxmfVCcZz1RXGf9UhxovVLcaX1TnGo3VJxq/VUca71VzWW9VlxtPVccbczOfVfcbs//P0Mcb88wvVlccP1aHHG9WtxyfVuccx/tnHP9XNx0jts9Xdx1vcvWaVTtDfJcdz1fnHf9YFx4vWEceVD/nHoCUdx6tV9ce04wPWOcfH1ka0+cfb1lXH5R+r1mHH99ZtyAD0u9Z5yBPWhcgf1pHIKdSxyDW3achD1q3IT9a5yFvWxchn1tHH0ch07iPW4ciH1u3Ik9b44wPXAcir1wz3a9cVyL/XIcjL1y3I1OT71znI59dFyPAit9dRyQPXXPE712Td19ds+0nJI9d4zTPXgck7143JRStX15lIm9ehyWPXrclv17nwNcl+FB3Ji9fRyZTlb9fc6bvX5cmv1/DRs9f40bvYAcnI35vYDcnf2BngnO9b2CXJ99gxygPYPcoNBFvYSQQf2FHKK9hdyjfYacpA5bPYecpX2IXKY9iRPrvYmcp4ysm1AcqL2LO6Icqc2MuEncqtFzfYzcq/2NqVzcrMGp6Uscrc6GzWL9j5yvJ3t9kFywPZEcsP2R0rL9kk+0fZLcstFJPZOcs/2UXLSM+P2VHLW9ldOYvZZct1Op6MGcuFolPZfAo5y5vZicun2ZTflMdv2aEFM9mpy8vZtcvX2cHL4Rwr2c1G3du5y/vZ4cwFHCDXz9nxzBkoScwj2gHML9oPry3MQ9odkifaJcxb2jHMZ9o8yqKWCcx72lDI/PzX2l3Ml9pphovaccyqHRXMtOJE4x3MwYsj2pHM0Xns3NPaocznjtXM89q1zPxHq9rA1mPayBxH2tHNI9rdzS/a6c042unNQ9r5zUwJp9sFzV/bEc1r2x3Nd9sqnb3NhRhb2z3NlN2FzZ/bUc2pKuPbXc2722nNx9t1zdPbgc3f243N7awYRe/bnc4APhvbqc4Qy//btc4gzWPbwc4xiX3OO9vRzkVLkc5T2+XOX9vxzmvb/c533AnOg9wV0r/cHRpL3CT4f9wtzq/cOc673EXOx9xRztPcX4i45mvcac7v3HTJC9x9zwTvyMc33I0bG9yVzyPcoNC73KnPN9y1z0Pcwc9P3Mz3Jc9f3NnPaP3Nz3fc7c+D3PnPjQnM+ffdCc+j3RXPrNKE0/vdJMdX3S3PzU5L3TjUc91A2wvdSc/w1p3P+Orz3VzNvOyBUjPdbdAZvKvdeAiT3YFSM92IyFFQkgzD3ZXQT92h0Ftm5dBn3bXQc93B0HzOR93N0I/d2dCZI19NjdCo6eVj7931+JXQx94FsPXQ294V0OfeIdD1k+HRARTf3jnREObv3kXRI95R0S/eXPMP3mXRQ95xIOXRV96B0WDmH96R0XPendF9Rm/eqnvj3rHRm9690afeydGz3tXRvM0pFCfe5dHR4E3R39750ejvd98F0fj/K98R0gvfHdIVlpvfKNaX3zDs3985xJnSQ99IHv/fUdJb31zuU99lSg3Se9910offgdKQ2aMmBdKh3PnSr9+h0rvfrO3Q2y/fudLX38Xq3dLn39UP6dL33+HTASKP3+3TE9/50xzmLdeF0yvgDQB34Bf29dND4CXTTPn34DDZB+A502vgRdN035zzu+BV04vgYMAL4GnTo+B106/ggdO74IzwG+CV09JyR+Cl0+PgsOar4LnT+Qej4MTLO+DN1BFjWdQdPH/g4Bb/4OkMB+Dx1Efg/Pvj4QTiX+EN1GfhGdRz4ST2V+Et1IvhOdSVAOnUoN874VHUs+Fd1L/hadTL4XXU1+GBEyvhiM2D4ZHU8+Gd1P2M3+GsBSnVF+2h1SPhweyr4cnVONO440fh2PkP4eECADlb4e1Sk+H11XPiAdV/4g3ViPe6G8/iHdWf4ivimdWv4jjgn+JB1cVbgQ4V1dfiWdXg98D02+Jp1ffidSrr4n3WD9ew4qTdL+KQu7nWJ+KdDAj02+Kp1jzenENH4rnWU+LF1l/i0dZoz/W7k+Lh1n0E5R0z4vHWkP8lWZvjAdan4w3Ws+MYzJPjIdbH4y3W0+M51t/jRdbr41HW9OmH413XBXHt1xDj8+N11yARIbbJ1zPjjdc/45nXT+Ol11zRCddlh8nXcBwyLkHXg+PJ15E59+Pb7R3XqOaz4+nXuPAN18UfDgvX5AGmM+QJ1+PkFdfv5CGb+PBD5C3YB+Q52BPkRdgf5FHYK+Rd2DfkadhD5HXYTN/P5IDtf+SJ2GVXxdhz5J3Yf+Sp2IvktdiX5MHYo+TN2K/k2di/5OXYy+Tw3zvk+djj5QXY7+UR2PjK8+Ud2Qi/TNVH5S3ZH+U52SvlRMgX5U3ZQ+VZ2U/lZdlb5XHZZ+V92XPliOjL5ZDeL+WZ2Zflpdmj5bHZrMgz5b3ZvQMM+EPlzdnQ//HZ2+Xh2eaRddnwTCzPC+X52gfmBdoT5hDmS+YY5fPmIdoz5i3aP+Y52kjMJ+ZF2lvmUdpn5l3ac+Zp2n0Ez+Z52ozME+aFsRnapOiB2q0fA+ah2r/mrdrL5rna1+bEydPmzdrv5tna+RCRNOHbC+bwMKvm+SrR2yDzPdso5qjkL+cV2z/nIdtKd7XbU3F121/nOdto4nPnRdt751Hbh+dd25PnaducHf/ndduv54HbuVIQ7UfnkdvP55wLU+el2+TQn+e12/fnwM2WeM3cC+fVJDfn3dwj5+ncLE8D5/ncP+gF3E8ysdxb6BncZ+gl3HPoMdx/6D0vjdyM3Nwd/dyb6FXcp+hgBD3ct+ht3MPoedzT6IXc4AXF3Ovomdz2pmHdABEj6K3dERJ36LndIMxB3SlAG+jN3Tvo2d1H6OEbI+jp3Vvo9d1n6QHdcQl0x1vpEMu76RjXSTvD6SUnc+kt3afpOd2z6UULc+lR3cgSy+ldRuPpZOyH6W3d8c3j6XjYu+mB3hALrR0X6ZLqlY6H6Z3eOVFj6a3eSN5n6bneWPFf6cXeafh5Xkwrf+nZObfp4d6T6e3enSZxBDvp/MrH6gY5+PU76hHezOs93tfDvd7hJzne7+o1T5vqPd8E5OjwB+pMBoPqVAss4D/qYd8v6m3fO+p530fqhd9T6pDxGM5j6p3faM8P6qjYT+qx34TMwO7L6sHfm+rMyFPq1d+v6uEepMav6u3fx+r5Q5Xf1DXM8UHf4+sN3+/rFtHd4AK0++sp4BPrNeAf60HgK+tN4DfrW2MR4EkY4Rbv623gX+t5qqfrgeB3643gg+uZZvProeCb663gp+u54LPrxowh4MPr1Bfv69zTZ+vl4Ofr8Pr36/ng+MnL7AnhCECv7BXhG+wh4SW6neExKmvsNDkX7D3hSMpD7EnhW+xV4WfsYev54XjgnMhv7HXhjQf9QY3hm+yJ4afsleGy0l3hvssHvd0JZ+yx4dvsvAQ/7MXh8+zRD56lteIH7OXiE+zxHxfs+eIv7QXA2SSJ4kTNH+0Z4lXikNJL7Snia+00GPvtPeJ9EBvtSeKP7VXin+1h4qvtbeK37Xj34+2B4s3i1QUY8o/tlDAv7Z3i8+2p4v/ttNc37b3jG+3J4yvt1S4n7d+OweNJAUvt8eNadSnjZ+4FUADPjeN37hXjg+4h44zJKeOX7jXjo+5B46zfjP1d47vuVePH7mHj0+5tA4zJf+554+vuhNNH7ozhUeQH7pjfU+6h5B07L+6s94PuthL55D/uxRQX7s0eneRY/2WE4+7h5HO/FRQU/m/u9eSL7vwyp+8F5KPvEddZ5LDIC+8h5MPvLeTNAmJGvQAH70Hk5+9N5PPvWeT/72XlCB2n73HlGWnD74HlKB389U/vkeU/75zX0++k7EjKo++x5WPvveVv78nle+/V5YTfw+/k2oXlm+/x5afv/eWw+Q/wCeXA9LfwFeXQ1kvwIcPt5eceIeXz8Dj5TeYBCcYjU/BJ5hfwVRO38F3mLNuf8G3mPBtv8HjHr/CB5ljIleZhGmnmb/Cd5nvwqeaH8LXmkSfn8MHmo/DN5q5Jzea78OHmxd2/8O3m1/D55uFPjebt0PDo9/ER5wfxHecT8SnnH/E15yvxQec38U3nR/FZ51PxYedeCwfxbN/n8XXnd/GBuljKv/GNSKfxleeYHTHno/Gl56zun/G1WY/xvefI4Lj+u/HN59/x2uyh5/Px6ef/8fXoC/IB6BfyDegn8hnoNQwdKy/yKQen8jHoUMu78j3oY/JJlafyUeh/8l3oi/Jp6JToT/J16KfygeixTcPyjOf78pRJPejT8qHo3VdpdoXo7/K56PosH/LFQCvyzekUyi0AT/Ld6Svy6nr0zkfy9elH8wK/gelZb8HpZ/MZ6XHk0/Mp6YDvz/M56ZPzRO1H803pq/NY5H/zYnF96clqH/Nx6dvzfenlH3vzien385XqA/Oh6gzpL/Ot6iDZq/O56jPzxeo80mPz0epP893qW/Povl3f2epv8/3qe/QKzRnqj/QZ6pj/4S9L9Cnqr/Q16rv0QNhH9EjlX/RR6tv0Xern9Gpkker79HkSc/SB6xP0jescxq/0mestm1/0qPu88Zf0tetL9MHrV/TN62HSyetv9ODZ5/To2sP08euP9P8kCeuczkXrp/UX0+f1IevD9SzHX/U169v1Qevn9UzWSOkT9VqThewD9WoxT/VwQp/1eewj9YXYs/WN7DVil/Wd7Ef1qexRkqwES/W57GVI+/XF7Hf10eyBDAXsi/Xl7Jf18eyj9f1Wc/YFANv2DR2l7Mf2GezT9iXs3mz57Ov2OQ3n9kIF1e0D9lHtDOIFHzv2Ye0g+HP2bDXN7TT0sNef9n3tS/aJ7VUKI/aXfDnta/al7XQGsYL/9rXtiNbhHwP2xaDN7aUEz/bY21v24e2/9u3ty/b4CWP3Ae3j9wwKke308hUTx/ch7gmjhe4U/mHuI/c97i/3SNyD91HuROm0Bq/3YQvj92nuZN1Z7m0fDNZP94Ghze6E44nuj/eZ7pv3pe6l9bP3se63973uw/fI49f30e7b993u5/fo8dv38e7/9/zTt/gFVeP4De8c28j48/gd7zP4Ke8/+DXvSN2D+EBC5/hJ72f4Ve93+GD9u3dD+G3vjRjs3p3vm/iB76f4je+yAGXvvUGP+KHvzT3FMd/4se/j+L3v7/jI4Rv44/jXjEP43/jS7r3wJOEb+PXwNNWk7//5BfBL+RHwVYV9kq/5IOVp2ZHwc/k1UO/5Pcs18I/5TkJF8KP5XNCT+WYo2fC/+XU7r/l98NP5ifDdCrP5lPdp8PP5oNmn+anxC/m18RTaGxmd8Sf5zL2B8Tf52fFA2mTgqfFP+e3xW/n58Wf6BfFz+hHxf/od8YjdmQAX+i3xnNbA4hv6PfGxABf6TfHD+lnxz/pl8dj6mfHj+nVYU9ot8ff6izqz+pXyE/qh8h/6rV8/+rXyMNkBDov6xfJH+tHyU/rd8l/66fJr+vXyd/sBBFP7CfKOdCnymfKixC3yr/sp8rkt//s18sucPfLVy0v7SfLr+1Xy9P+T+2UHi/tt8xDiS/t58yP7hfMv+5EHkPVz+53zR/up81P7tNoz+73zafNxGZ/70fOD+93zj/vp85v79fOk4c/8AfO3/A3zwOfWLinz0/wl89/8MfPr/Dznj/xFPIf8TfQL/FnXq/xh9CP8bfQtGbzPH/x+P9NavfRL/JH0V/yd9GP8qfRs/vf8uN4D/MEEkNnr/M30l/zZ9KP85O4z/O30u/z40/n0x/0E0Bv9DfTY04f9GfTq16309/0x9QP9PfUP/Un1G/1U5lP9XNB//WX1POnY1P/9dfVQ/5v9gfVj/Y0IjQP7/Zn1emYZ9Yf9rOjH/bX1n/3B9anuq/3R8p0D1/3c3fP95fXX/fH14/39O1v+BODH/g32A/4Z9g/+JR5T/i32J/459jP+RfY8Emv+UfZP/l0cffZf/mn2aEg19nHMg/6B9oP+jcL1Y+/+mfaf/qTbj/6t9rf+uOxI/GwWd/7F9tP+0DZD/tn26Tdb/uX2+/7x9wf+/fcT/wk80/8R9yUlzA3P/yH3O/8t90T6VM4f/z33WM/B92DIA/9Q+LP/Wfd42E//ZfeI31EUm/92RJX3p/+F97Dup/+Rf1GE7/+d98z/nBln/6334AXJ1n5teff3/8n4A//V+A//4Xp1+Bz/Q//x+DP//fg8yzUdpQLkGP/yZfhY/gTLhPGWNc2rZfh34Yn4gRFdD/b1wfiU4l34nOQtXfDoYPTY0kUzw7qs6bkSBOnYyS34zOk1+NVNpP9RFQzQGB8VDmD0YawN+P5T6kcV+Q0H/OrxyNUq8Mjnu1hYXRzb1WX5OfcJ+UTWxflM9HbSEflc1NOC+Ab8HaX5ckeB+XzzEM07y6/MffmVIkvKFfmk/QgN0fmwyoEPrAbfnAhDKQDR+dO56fndDNAflfno7JjHhMyFKYX6ASa4zQ/uHfoVYT126QTg3NTj6BKtqmbOIfo8+3/wyfpM38zbwyPl+mEy1fppXf36dOsQL6v4dfqJJcX6kQrozNjMwfqgG3EJPlDZ+rlKkPbw4oX6yPEZ+tFeiNeA6xTWSMkFnQzvENId+vjdmWqh+wjfkPz9MDzWYNBk0yH7JBb05bIm+fs43P0BJP6bxJX7U5vF+18Tqbad+2xYXNNkz5FaoWmZ+4pkAOrtHTH7mRpJ5DFtIfut2on7uOFVHqTYhfvJSz370kbJ+9zy2NUV/dTWANKB+/jgZyn9/AjICNkruW38HOZJ0wTolOUd/DDQNNegTwAcyA09A1n8T49R/FjoSMmxFWTtFfxtQJ0fDD45/HzMb9Gd/IzTuRG+MB38oNKJat19VfyxfAj8IPQkH3zZcRq4TkjjSR1h/+H84NT4vgzbgx6J/PjH8SfE16H9CB5xFWdYuf0c/+06qhed/TDs6f041W0ZWPu8BfVwIf1U37UUF3Cl/WlOlhvP1NTJAutF/YUaLMcQ6S39lM0t/ZxOSNkUyrX9rpfl/bjnbeMNfLgcp68p/dYjEQWgOVzSMVuh/e0BENmFW3EN9MgIFnUIJOWN/hDx2WCA56DoVf4k7dAFhhlB/jm+1A0VhDja6kUBCpzXDNIha8TSvFNV/m//of541rjoAOL4S7jtH04tET2WVf6gFQzcqUl0XCluhf68/Fn+xBZQ7dlK3NqEyBkOTNdT6h2c8VzM0CDbjs8l/wDLYi29/xDUlNUF+w3/JQ/Rbe9dgMmQyTzfGOpoHTjSRXdI1tzgJiN1/2J3tO6OMU0Cqf90yUUdxUibjR3/jMfIzZwXJf+c6xXAWocN/7DNAMwaK7X/x3wx/9EHxQ7YzYzKtM91/+lgk4yJ//rWDgAE00DXjXUWABkLsU5I/1ETQP06ADEjFPE4G9IAQNUA8QXe8gBVE+UBXNI40B1dtEPc4LjHXNuc3Dmb8gCJQMgWJpiaAJ2afgCoz0UMzQCM3gjxMgDBTY+KygDQ4O5IzPp6AOKC7QIk2HT28S8Y1/kyGgEFATzUbWy9d1DPpOzpdWFqks61FCkwKEIc5HTXNEXk1uEe+rQGAVULBaLEMC1XRgFuXqjTFO181bjpJOCc8bV8QecKAZrUNgGmykYBsZgmd7U01XdRFCoByN9Y+TTfvbYJQNV4SyTyAewSVQeORXoCANoQ2vPeqgIUGmjwQQZesGICLOJ9EFNBNNd0z2oCSUCQ9+lYfgJZd/oCZVR+AnD0sgJ771IChNiYzWj/fN9wReAvEgKhPbVG90xY5sDziMeJ97YCxP2RK3V75NqFJgmIYgLjXYG3agLwz1VuIOkg19EPogMNT1UQUBskwnYSWgMo5nTVTP/xCnEjcRQpSA1pwQoY3rjwXPdU0oz6mn3ec4lJGPfWA3Tt/gOAzyYDid1FApUCYgOZfoIDpPBaeOjetVYiA7wJGQOY4XW3Stk0/kAFpetmA+UCxNwlbaTuWRf2A/zTugQFGyYEEQmxVuUODgQlQ51Obs++BDgLigRB32oETqMKBFkBRgRk8a0+FNAaBHUrbQcI5R4EhrMFFDHoGSa5E2ESPQ8pMW0HEyI6BLTkDMqB9VYEygXqBNTSZOd003Tb/P79EqYE9M0qMUzpNBZOGxoFEP/fj24FIZ0aBSk/eOkgQxIFPM/g8egcpPJAJ7IFVeKqBWDK4gVo4LYFcVL6UTYFgNa8/BECsgWRWzVYLl4aBaU8dgWxBojqG+HkyS10UNyMBsF6rAQNRUkBoPpyBej7phvOGDKc8NY2BgKRbgYPcnIGGMcGBiISxgYs9oz1lATRMMgecXBI8bwN0NWE+xzktAX9QNzXiMvhE7wmIOcZplDaLbwZVYz+tTJAzA/yugacYcTz/OY3LYIGtVC9Zq61ZWyaBszuaPP8yNjjmMw0+01lIM7pBxvypgb8/xT+maT2BxAW+l4c4YoHIVS1J4Tmpgc004C5OMyoSTzINN9gyJjMIOQkP9YHZNAoBOTXAAcCB3jdzgxCB4nlPA3POV4HnOBs3CZRTgew8OzVsBtI53Tu5M+k6lkB8Nchb7IH4PT5rozT1Ot+BJYH/lsBEmE3pggQ6jjhSRB1DzHjNggtFBTthPy1aIYIRSMhrBYIVNI9r9YGDghr8kVftQ7I5NjtvR9QzITyzB4IHaVuEgic9k9T5VklBFzoYgi0x1jTGM8g87ALrNlhE7oSVgjdBhDaZNqJFBThQNPUyBzgX96yCQot7gkUJWzgOcLmCSllyQzg0R6u+glBiX4JS3eWCVTMn0LT4gIJaORL2wYJeNoZFYER2WrdVg7i6CYhPWVsHRgkP9TXogmtG/0mPXStwoYJxSRc4CROSNf2Cdj3tPlEP5DyjPu+o3K/Cgn+zJ4KCVzyChZIzgocR6nOnONuozYKNbfDnuTl0fDUyqExBPeA2YlXaNP9AXA/jQFw4VG/Igp4yXje9gqFOD0EmNFqCpkGpNMpByjyCVnpnaTtzStMztzTZgrE0kDlfVzNN1j3hOrE85YK5NYGwS4K9ODVD+kWHgsJH3j5ROqGH+oLIOoEVKUWwgs1t8ILPBL+C0TyMNTZLLlLPNMIynOVKgto9ooLdQoYQOAJ3McYCaZ/lguVVPkESXdI2CRMLOJI6JbOfgu9mCUwK8IEzuGb4O6kBB4L3CluC+V/AQbsztDHFkoaDAD2LSHdVw4MFA1dMWjr4F6I1pVRJRDUzzDi+DKo344y8gxMzk4MVMiSUaoMZAas3CTgY6C01VrJHRV47LYGogyRAATN2X8E230IlQw02E0wKSUqDLhDmgzE2mDbDAk4+MfklgzhWzYVINmxoxjvEgz84f6uKg0NKTWd6g0cEIYNKV2paD4NNagNGNYhNNgZSPjujBt9qA+KEg1hMXk7rYh2DXTwXMdtjIkAIWBhHnDtizluDZzScW8pIQDQ6UQw4LTb9aalg3Es4PdE1gDTcIQow1lDAXFSDemz0bwiDfpeZg4FK5DmcNI02NkCgZD44XoCjg4t9BIOObws4exRiMoeDkxezg5YfqUtEMuuDmwaWYcJYtkgHRP8x1zg1Qq7VF4OmSquDqECYp12DrIBoNxA0tmA2g7I2CDe7Q8mOf4O4Ndpqk03WOqGSj1AkOow1q4PBGulQMzjRPHVBTDDuO5E0sXpKg8w7lD/7Yz07L0wMnpCD1Eylg9dRO09Ig9szGDb0X5dtYfcug+IyAe/dg+YBv0QBg+k9aToTNjky5jrWNwIytzTFQi2D9D0Og/agMl1LMgpQMtsVg/0BKTH/Q+08mz4bhAQyRkDAMe42FTrEEKdCXTNaUP+EDkk5dxCEEUD2eniEFTkshBg44C0YMhw9ORo9hB4BMkaShCE1/QdJNVWEJZKONk5LFEw4WeiBToQtVeU4BlH+OYrd9DenhDQ6VIQ2XLJEVk/ZOdiEPGPwtkSEQEHNhEN7kYRGQRcQp+kHAekP9FIZ+I6ET0AEXEU0/0FMhFRLiUu/MyY/ST/ePjc4EEQ1NaOIDIRgD+Qx8AJFUeuEZjN2TeoyUkT/VPdSJpTShG9N6oRyN2fg7ungoSZAzIR6RSVWaTW7Tz7HH4SBuRmEhDpMBus5BDfIhIpApvMoNwqbX4SQVDE8jzkFLgWElkHGM2M8yVYBhJw3KGY6NUY8OkPYNe8JVTw2au44DDHFXy4zJnN+hKxJd2Q+MrM6gxE5PNnPmgecPEh3ewFp12CEuT6thLs/ToS9OPs5/4TAZm+UaITE17N46ITIQTsy2D61NCCde4TPcvCE0jeCUpkDVgO8Mfg2YERv/aKE3DMPBKYyNzvuNtgyBDbKSY9A/k6uhOg4RoTqAXmxZYTuB52E8E3R596E9eHFcFaE+QKOhPtJ2j3hWZ+FADwFhQJ8NYUFipaCpYUJNJhDv2eDOnk3PjHNTDw2959IhRRX7Tb3Ns4BcpR7TReFHDcsAYVKvDKxhSF6z4UkPVNB9kVag9aFKv0OhS12qYUwT21DzDzZQPw6NEncRdQ8AWHtRjhgZYU9NXAyZos2hUI8IDI1NRw1PEWHhUlVM4VLPbxx5oVPZ4uFUm/qhVU/FYVXPSw3DIVaP4HxJYVeN4+FYDMIMb40FDMOEYs0kU8fQdo98FdYBykzDWCePh9QjlVIPseKHTflGHE3QVEZOQg8EjquYcwxxDmeYNw4ZuXzhYE34juRPco8QT4MREQRB0skNtszk/wbhY5LnVEAAVk9fEmPPxU6X0zWNs9GhYWZNjk5jjl2EXtEQEkSCGiFoXcQ0y2FpTYrNqtBF3P2AjM/jqotNC5FQKazO/mFsjW7gU2FtjqNtsE0pkSceuaFvT7zhcBibzvDM/g36WGhOSI0nTlgAQhjPUfUQh6Fz9UAOFRVOTXUQKqF1gGcOHA+6kRDhds2FUrkASaWIDgOheFd1C+aNa6j8oXnQTldPTnkORI4WkCFgsGQyYXxojWF9ESZNlg9mDz/bfA5Zj2AELk8GAJpQ5Y+IQXDAS47AEdOP784Z0B23q2GCpDRhg00FjnHL5vP3YYTSmB1l4YXEeoDdQG/NV07GEThhh5c+oYhBkE2mzwgPks82fc+hilCYEs5RDgHR1W4DsBEBF+hAlVoODnRNQs5UoY3D1c1Iz5qAROGPEsyT2Q2s4ZAM1ZBnEMxhkVFWIZIPUo3sAXg14eGTja/VNCGUjvcRHFlTYZXSkucn4ZaOY+GXFZAPt8ybT6VeWRkKb1OhmU1yjb5gtw/rTbLVedHHwXDQw07zl/rQqRaPWDdhnU2xTr6NXQ83YZ6NxQ8jQcIXyE4a0SEnhyGg0CPOMI6CIaHAb5KcDHXPeiGjaeJhpBLY0FTuYOGlTNuOn/7gEBS472GnF25hp48B4agQ52Goop9hqU7CFIiP3OfjDtHAuKGrAfFg5pO1jNWOOUCS0PKBQpWzQdnOjlDGQ+PgJE8s2iQMyg4oUATjfuGwjetpsyGxkwLPdREq4bKQSZ3tVnoNuSG0E7gSCGG1DrHPI1J3Db7Mas8Bmh0htx4p4bfNNqG4TQeOWA4awlxR5w0iTeZB2ctIkzWM/c65TsbRVpEajYLdWQ6jm7BNaY1k0wXsuY9nEfANzNH3ophMjY6TDK/bPRV2v1KhwY2zjzChwkynIcLQUGHDk2pN6G5SIcTXPCHFliRNl47kWrPNpmISkT/O5GHH1zmhyLjsEWefAeHJwNzMkCHYkFGaBwDDzwWSNM+TTtHTDjz9kH2OFKHN4pXhzpg+Ic9TDgQ3Tbfh0FASZr9h0UPhlaLh0kzjTcUVN8y9zXBNLI4v0jXQBNnsIdVNVyHVzRWDClG5YdbvdLL0F+Nh2Bu7odiNsif44dmN7sPiDPdO1pGLjkfQlk7HT/8PNk3S02GYRA4kzdQMyCJaYd5NJyHezTLPVM7mTvKQUpPzDjNxreHhU57h4hcbEKHeW6HjcoRBq94pIeRNreHkzuWh5VBFzkJeyp5JoebBn5CgQWdWbwzSvR/Ofb9vDUUiuJL8jYCximHqkQ1PslBhEdKMjc4SKyRh7NmrjIoRc1tJ2orh7qlRIe96BCHwEkDOLHrXvsxh8ZCYIfIVe1BvofMPYMyBDd+N41njFpjNSU9QjLQyimH2DeVM25BlTbUVs2Ed4fgMzo7Jofjkp+H5gG3ctL4SIfrhV2H7kAB7xOH8kG4QzRDBzbGMtybLof6P9A2gzkOQjKH/zhXN+c6KzOpW7VNUIgGe/eICUdOMzZZjYgOQ/wzHGuhiBIxw0ABNtM3LUAdiBk1YAdxQZhBpIgfOvo7lU+8SfkYcTXOOKd2LE7xiCkxxVXvASJLRGbXiDA5hUHkNDYQ5TMGStWINz/kiDni+FX3Nrrnx4g/Uuo3oFreiEQ420RxM2Soh4hKdiw3xYhONZNLUjXgOrVFXm3gVnGIVlaMOvOGv4hbSAkCdUHGTbaIYEUpNMFHTEZA29RCMkaFPt2IalVjhZGIbl8hiHAz6Tc5UmY4ZAitNA6Id3Im7beIe/SYiH5zEIiBQwEGBkF0bWid6D+uPuiZXVaSoIiIjV/5iJBWP3bgiJREk4iXOUrzGoibiKdX2zZPhhWIoTVOOuc11KIqiKdKTUsKXdRnIIitOV6Ir0RzQxZJqTf5iLQ5yweFB8OIuDLjM+Bh0D8PBWSIvwU3O+46UVHGRyWxmIjIO8oCeTgubyo3+D34iM8zRz0OY747BTaVq/2I2Dn+BOo4xgIkPT0BOYjfOwcPPznoec+I5WJERik1RQEQUQ2PpIjtXHM5Bj4zL8Y0sjbqNsmCQge/O1IFA4j5Ni9DYk+4iP49y0Y7U4yJAj08+Tl0dYkHCGYBWpG/txhJ3DfiiQ8zQTvcQh00U543iRbJ30YnNkQBcTqMPn5rITtCmpmJIQ/WN4GB7okmaDSJKeTpiSxdPUrjsz2JMTJsMpG7m4k2SJpBHTcQXrA2CYk8Q7+JP7EbiUJbN4lFU/U4LUeURo+JSl8DjGOJTmgHiVFAw4lTNwKJVVIDfb1Grz3LXhI6FFbgQfyPPw5D0cuJYjkpOKzuvolnUQD0mIlrVo9D/DJDiW88EFXciXIBIga9NRYyP0UkPX4DsgPaUUA2J0LwiX49RUEcbMqJgz3JSplCNjWPTDKJijj2RWlRGV6RiZA0nYmSRN0ybFtuiZbJ3wQ5fr006gLrS7Fg7bvkiaDJcImjOhgzShDmU/QOV3La4kmJrGIYia44OkjcNmw1Y4mzM2RA0VFJibi5ZexRibw1rmJhicA66wE8O2qJxDxONz4/sXJ2N7o3K0gqM56JzUnOOOEFv4pPidNJA2GHZoqJ2AESNfo6AjOiO7k45mZTieFE7k+8RsYGdDn6ShI7/jMITem3BInt3E2J8FQ5ifOTJIn2T9k0FqvgifuWxjKQQ2p5EUUJOnY83VNAigWRB4oIOvOL+YoMUKCKD0SeihE6FDq7N1YzCUXRQrhBMzawOKlF9Gw+ih4zm0zWO7w361WDNP841TrUTtZYJKDAiitBSz9VPEo4O4oxQjQ7p0nKOmE6dgvoPtdKgzZ/TWpuD4o+QpCI1GTaau4FnD+gS0v/84pIBb84nzeYEu55ZES3PHNBFDYyaFCKVEKQ+IeKWJ6Ails7ZXWfUvSKYIpiStVJjDHVNLhdFG0Yimo3ojofZYs3DzO7OvJyTIpzgtw2DE2pinc75z3hNRxWqop9NEw6H7PzioJxEja2SZA9PRDUStUBojP3Q52LPYqOQYuKkTvBNKGKlJVeN3VCBDLxMdeKmjiGRAY/koqfNDGKoXSFA36KpDNDlj6KqGXIPag/rUYJPh2Krge/M/mVLIq0Ojc070fClUo9tZrDiry084q/NVAHvzZAb/mKxTpqNKxV9zc8UUCaw8iUNlFZuYrQ7DuK0zqRT2o3HUl3RBWK2jaGitw2Kw8uiuAK3+oDiuShiURWNoaK6GJyiutA41I1iu9LMjZFNLBNJ1d3ivYw4T56ObBOaIr8A08OVza7AUk4XlFSOHBYRYsGiwhT0IsLPyRtP/0LMv4yqaceixOLFUH/PLdVcDZYPZxDuwEpqaWLH/dniyJe0EBaQWI2JYsofkE1dwwrODU35DQkizBKXICIizQzEzlJQlmGzznkE8AHMos8P5Y/vzh7BRZi6jJVXhE0BItFNPoPjk9MTSqLS2QQSyQ1NTZcWohLQT7yi1OLWYtWMwiLVItaFSk7Bz67MgJnRYth8p+LZDZERww17otoR6QCZK/KOh81Z0EzU7oyoD7cR3EtxGcr6d2LdztKfxeLezJOi30JEE8/Mh8+9DMqSHpBFIuFP3VBdouJWQU4NWIYbJDLC4uQAluLMIuURUAz9DZ4OW00IzmeNsY0pjcJSWk/JjTORxOLozwNBykBvj05QXw8IALgi6sYcQEii64zSzayko2LszipOBA4ezjiQUtEIV10O1ZPeYu+OEaLwEFdOeBJKI6qi8Y1wQFLDkQ1YTZoMkFDnalkRdVDKjSKwFKL1Egci9dCYEeXDXNMR0LHAQR0BU2YPqw+poviQRc+KFTei+dGhT0Oi+qBjYvtwm2L8ElPj5KL9DlfAYVKnTayMzg3E09bSEM5/T4ki/80R4wBMd+ebzMLNrIPV+xQjAk2JzKsOxsyoKYajBA1/TW4RCpI7lA1NDRzpzy6ixRddD7z9M8I3jtKQFwyQ0pGM1JG/0BCNBQ2/TU8TvEPV1GtjCxLUUX+Wm57KjaUjDI+gDYJSCpEskKKp3WMOkMq8LmPzIxAVnyMQwG/jEU6koxI/KeMSwbSPLWMTkHTQqU/+ztCjFQx6DxvSrczS5tCjFs5VDz2VAQ2BIxgNm5k2i9/R8WMZTpqTm2MaQUdhav7B4xu842McTWSXdyMdUJYjHdJwox6tvCMfT6sQj+MgUttN688LjUbQ7uMhzgqB6lNSUKBQekzETQNjI818YyRBylAQlVnjJZF+DoRDkM7wUdhf3GMnj3wMco8czpLNCiRR4ymM7BE+YypRAQ1zj0obWE1pUnYjLA4EGvMMuYyIQOsUOs/ggNJQIySosgejL1m0knCjMEJSECANrs14tZujMgy6wE4BrKMzDZAQFQ3ZzIzOdw2Mk9/OexYZ3eKU+Z4gIzaOFkKWzVOyY2M4JInjOM8jozlTNFQ1YzpNsEvukRmjO431DaUCt4yFwNWY/A/4jdpUo8HaUEmbHXnC4z9YwyNAEb/R5Vqe28utleNBwWPjQoBHDuhPs0wAkDtPYtJ5zwiOAc+0ToVTYCNGEFRNmw6E9MZjR5FNEu0NuI1PEjTjSRT9V8QPx9G0lBpPLo2AmuXc3lWzU6qPLVLfUuyPsmNNEoSjTY+4zsk2BiNOz91PzFMDNI4jUFNhj0t5pONRkCQOOJLY0pwRQJW7jj6QT801BDRBR1U9ThSjVVPEI1YQwxBmElVSE2NXi+6Mgw+yU6BP7pn2E/ZnnmNaIkCqc2NbAvookONcFCiPdqNdF8CjXZ9cTiqQGqNezJqOVo8dFYSP9C4Lo2DY+GNhvh/jYk1wEcyd4oyvFixjZA6hXJ2Bb1gS42WrLKNmUqZOUJBU42eWMVbL1SfXZqNpA3qOS9s9EfDOXuNqja/W2k5uzIxEEc4oVYWPDtvFo21R2pGKjd/Tzk+bTjID4Y1gzOAa/VHH3sBjcNF/T9uUl0PV43IOMA/8YcxaFo2HzZUNDE7ozgGNs+N0zmY+cKN1wW/jdlFWTfcbz+N3k1nSFMzKUO2j0mN5TIINAlI7TiLcjVml43trE8CVTaRfC6N8zHyZGwHEUmwjfmGwI38QmAy91bIjgFFHqv/jgVl1mUxPVxBYgpbc048AVpLjg85uj2hb3COFDgMSRmOGEDaOWYz/VPBjh5BhFksN3U/5pGGjiUtIg/0Mwg/q0GiNc6GDANLAauOL2pqjjJAX440O/UzZDlUa6E6R06nNE8xvTpEQFZdWI5AQYA0145EqqWOR1WJjkpiX0HoNWtQQjxM68SOUjnoOo4v00jUTFuOWDkSbVg5hDJJhBM4YkUU+GSOYjoVNXCUbDbKTwM6RG/mQKZAuWAyShI1kU+uNJlJ1Tc3NKxOjU0OOiE0ujIXTp9hYI58VDFQao6AhIOOgzu/joV8F46IeFM8O44Ljo0yNUK0Nu0yAENCTqqaLo6WQTlWMG4MMk1CgTVrV7+OnwIoOK42xo6jN6mOpYQXEA8HPjW6RCaLsI6tOXY+x3/njrIBE0hDVVd3r0aYM0A4KTVnP8pulj6sCGg0po7AP/Fci47EM806Eku/UNmOykKMQyuOzulRNQ83fETASxxQgI7VCUjaC47ZAi4zYz6RWoYG+I7fT1s5xzgIM+BEHTLZODqrKDhkrOGO6wECQr4znVTFMymO8THoMl84gY71NbBXbTiJBuFaNI77j9k2/zdOZNrtGQ/0Mpk8zwEuOoVRvI8Hu8E/ZIGOjwyAMY8PMnRyqY8TnJ+soUj3TZKPGTW+X348wwFIjx45eo8gS2h8p6TijyU25zoTWDBjaExVaFrGcDhUP/BAbnnOAlg6NDOjNokOwOiwjzgyOTVKQ506YY89YSaPQDTIPqaPQ0qrbZWPR5Qgj0pAUk+GZUyPTwtsgY2PU0YuUhk0kjZFYhiPWRAFM5hCNvgIL7pYaruAj2J7LUyEPS+PZ5FEj2pKnTTZMvpFvghmOBePcU35j3QfqUpY6Ik5BUOTOZ6PezwuDCp8AY+ASGjwn4Kbj4U7kXyn8iaPiml0YX9Nl4+OAUo8fEIdM+Y+Cn/Cj5YBCjYmQAxVgEdqSAs2JY+fUruPoT7bQcoPYTUXj6f8G5K8QEmPgY+tO6w4VTfYUdE0mjQvOhWPtTPeOS45f2WLRTh07Y+9Na4ROUgFUo+Pwkqdj8R21TUrRuSPyFAOj8tGJ4/NkDGP0BAPRkc82TOe3+TbQ4/Yj9qSvILnj943HT4nOso2pGg/j+WzgTIUMe41MkZiXGzE+o/u4fkx/AWTNyI/yfDmj/YyU4/4jXNddBEHQPUyEAInj//Gp5ACMpxMzUHakAaTX5AJS1870DfGusaZRTTUY5s7WUhdkBQ9ZT+eNktHHERPOz9aDzSjNsox4zapOm0/txE5XGKQJVXnO+A2xUEJNpFJ+TTHMJMiGDhGMeMHAURqOpo+ajgLlHuQN5aeBqGQOzuMNzRS6mhRkEGMGZBEB5zHQJBIM864bpBMNLKQTjn2R2o1dkFEO281DugQSoOQcDO5iEJZXZBcRkCEa5BgMpEysjh1RzZh7T9/Myc5uDM5RwpcAJBtWOU1eQZ+NQwz/k2JO5BnpZB3azixkDdxQi0FvTaSPUqnIDsSBq+Qg9xrRCQ6SWObQ5Jk09MjkIyPF22eD/xygpCSDy+QlD+OWh6QmDUlTy5W7jnLSbyQnmG1N3EIJfDrkKRAcUIDkKdDy0DwTm1ajTPZOiJ1QTJFcR6QskZnQOZcMkZiOZpHdD2BO7w2awGAPvmQvkFTkMFNwgIlNViQxXNFkMgyAlt7T8hScUL0ARyQzz/QkNI13jVTkNVHvjaSM+CQ2UIyPBU1PY2dMumF1ThIMtxFVJDk5biQ50hTV+g9aUuYODpsx6CIkPA1FFGKOAlFGgF4UKNPqjUjvEBvAvQM3nOQ/jgMTOdB9zPxOHRt05EFNz7nH5EJPrU2lmZlQqJ5C5EQRxE++DHoUOc7bzOhOZ4zO//skRsEujjSVRhro15IkSJPGpElU/U+3DHF5raRK0fHcMw5NWKqkTCKnvLEQ0NkipE2T1A/65E5AbAFkpE8VdaRP3C1kUI9/nCOT9g5qjZRM0M8F/0xkUy6yJFPM+RlzVloUuo9IDONOWxxxJFZd7o+ahNNRr9rnQUdvCORYjmjadJMzW3TSJzb3pFqTp003T31jayRcD4dNc6PL5F1bPxHl0hjkXpo4jfJNWE3NJF/OaqRgjn2PBU2kDwYOrM5ckl34qaRjEzUQB6DjpGROC7WApGVMkdPvOoTkZrsUpGdL9M5M0TtrFORozgwR8ORpkE4NrM4I07rW6KRrEv1OkpsMpGxdgyRtDtFkbZixkLuRwZT6Tl6NpY1iASckcDecjb3bo+RxT+ene0C6zcIOMSe9ZHNQncC5TTNRNiZNpHUAQ+R1r3okdlLkw5WOhNZb5HfNNRbuT6R08iR5TWV/KeR6U+/QxNV91tpPOU4LTtikfE6SIHYmw+R9tthkfmR++dOkf5D6T1GkgE2eVRhBp4Q9TY7kgdDZTvBAUiSC6G2Ai5CwjmTkhFxZpIUM+ZWYUmVNm036DknSsA0q1q7+buSIDTsM6GHgkefQBWSJziXteuSKxMLNmU1ODiQ6zhE8TWTkjQ90ZI3PHU8szfHAiiSPFfbYdBScZJAOOHNBzNnMmicnzVTPbA45EJZSQk2UU0BPn9U1lL2MxySUUJtZVxw42siFNbNDUY1PBtCbDvMO4wyOUVPQG81OktBNiBjm4MvtjaSZzy6sGBSIkaPuJlLf0hTMuACRVTJknM3iJJ1dDxvLZJ5OrfdmJJ9NtU6iXjDQQ85ETHfO7+ShYm+koiYppKLvVqSjjwkOwBqAz3kO5Y4cj/ZRCCSmDZrM9/mcJKdOXdNVkj3NeWSojOYTfeSpkfhEBySqVSokqx/WpKvbgQ2bgfRQAg0w7Ihc7ySuGpPkruSvTYoUwA1MpLBOXQxxAu6TduSx0zWOdjHbZLMVIxgpDgHUgM07ZLyktRk1ZLWSdg7zzJSj9kx6nUOQ5gBbpLgNXBuNjpbkuRC2j5zPd4TTUEtisiS7JNCTyGTRDr5OBdRkEjJk0oDSTp0M/ptgpL6OPY8bwI+OiIzRDHsN63TcZMEW4hDE0hvW9mTCVbHOwdUuJMOQk+TEQlIAR03oAZ+NvtBkUyQQfw9+HbHkx1BgDU0Mm5DnamykyQTTW79kyham5NJkyxfxT7qMyg52JMxMj9IBznXAtKT8VrwkzmTWJM8WwcyP5M/PeSTXJNDBww6+ZNGlDqTSZL1QOcyP5NSk09gP5NNk1MCdavSk1eTO5NaURqTXTr5Mj84BzsHvKGTYz5Nk2WdfJNoRlg+jlqGEGQFHDRMN4FncNNAk3M3RDdiPrv7xAbXk3pfmwTqk35Mg7smddXIVnXQNFqThaulNECTiGLIR4aTm5OOYguTkTLwS5bl5QYALRh9fJOZM406D5OcXvWTn2z0NiA0o0gFPYHrxpOnSF+Tqnmlk63QWjM5O8g2ygv3UTla9ju/OM2Ttz4mEtOTuzLEMucz3VJyk8ABr1Hak8QSDWoD6buTyZw2N+psgpYj3BOT4pPRlLOT1D3ek9ZnfDkuesGT20mVLcRDNKc63BOT4t6klLM5u1D/ARtAiTfoU/RfIT+jNMST7lthk/DJG5PzYYmS9G8dNTOT+JR7NMkfqVy/k/5G+K6AlAI1Wz6eOeps/Dd8nbmUCmzGAo5LZpQP3TqUEpNHlBU9E5QqlBlDd0KclByBhgypD9OE2pQiPBSUJFnulDkBR0BEP3WUGJQsS1+ULjwUlCSUMToORDuS6ZQ2lEuUOZUElE+UPpRYlEGUWzdnlFhMYTzElENP0JQ4k0eU65Q9lFGUWDywhE+UQ5RWN2eUWJRBlFszKUqaRPE5kkqDlGFFXjuSRCgyYHKSd6o1ekeklGpJ5JRtPpVu8JRxMzuR4E9UlHYGPjZYRxy86jTuO/U7CZlSlIGFYjISNVRaRGv1T8yUiUtBPT43D5SNcbSUkFwcEeo98JH6Nc5EcTwVQPw7+zm4MydNG5SeN86UoFR/lKM9Tk+DaQZZvDfyPgRLSkOWeE2UrjoLlNhkX5SyPIKU1UvDlLfSuZS67YmUvT3+WIY3KWg4lNuUxLrklMcCjpUDlMtJPZS6UUU2VZTklNJT7zyClNVB5EmPO78z/ZTalMOU3V6raplm3zhsM2eU0JTlSY+U5zdxlQOU65kBlO5xY5TxToCVAZT2lQT035TtlPtiCJT+PZRhOzpMlQKU90k9lQZHlQcplQk1M0UaNKKVDVZXPLOVENi9lZ6VFIF4llqV8DHBlaSVHJYHOAwx222Z2jqVJDvOYR9K6pUplRyVLJcrZcuVjpUzlX6VNvV0lTkGlDiOW2GvRJU/lXC2JpVyPLo775WwO1JLiJVrlUyIDJVPbbCVUlgYlVRAw5V8lViXK5WelRSBeJZalaiVYtUyBZwyPpWulUaVaUuIlWs20pU+lW+VQbYmlXJ9BPOrlXY+yTvOYR+VekDDlXyVWJcrlZ6VFJWDlZdW4JWZiE00mZWcY78yuJWOlTOVfpcrlZ6VFJWDlZdW4JWZiE00mZWcY7+VgZWgllqV8DHBlaSVHJYHOAyVYZWqO9wFnDI+la6VRpVplbIzVpW0iC+VwwholcWVuzMylb1qOpXANzyIL5XDCGiVxZVElcgDvDTqlcyeCJXPNskCJVj5ldM4ZEu0UbiTx5Y0ldqWg5WSleyTRJZflm+V55ZUleoxP5ZXle6VoZXwllyWhpZelm6WCJZwlmSWDJZMlmeWGJZqljOWO3mTlgeV9pZwlmSWDJZMX1SWEJRolhNPWpZNlnqWAJZ8loqWMEBElo2WIjj8loOVkpZXlohJ+ZZ9lotARJaNljWWSJUslytly5Y7D2GWg5Y/llI+sJZUleoxP5Xsk0SWX5gQlnOWg5Y/llI+sJZUleoxP5ZXle6VoZXwllyWhpZelm6WCJZwlmSWDJZMlmeWWJYZlz6WO5ZIlgeV9pZwlmSWDJZMX1SWdDV6lhNPWpZNlnqWK5Z8loqWMEBElo2WIjj8loOVkpZXlohJ+ZZ9lotARJaNbWGWj5UsOv+WkmmMZtcBIpaWNPCgajlJlppNiZacM7A1d021EB6Wopdll/OWa5cJlypJGjrV7KiXD5axXdQ2ITt0lxUFHJcdl4mXSzWRlvmXeTbnND9F/pb9lsWXADzeSVM0yJdBlquWzZ3tTySXLpehN6uW1ZbrltiW7pbbna6W5TlVmB+W4pbkUTuW5pbAlumW1pbsltmW7z/Zl0yW+Zd5mCA/2Zb4lr6XeTbnND9F/pb9lsWXAJu9lzmXBJc8lweXP5aplwuWrJdElq+XEJdIlxMyh5cVBRyXHZe7lxqXFZcclriXuzg3lyBDVpcihdVOn2Y6lPI15U/UlyqWzZ3tTySXLpehN6uXMk9kl1qXNj99lqGXOpcFmC+XCZcqSRqXRJavlxCXSJcTl0uW8pa+l4iXz5dSlvmXiJa6AXHfRpdrl1sPYZddMriXXzSml2GXB70xPuuXZYqOlzCXaWCxT2SXWpc2l26XA07Ply6XZ5d0AiSXdlAcT0iYHztAO6Ey21BpMi4BSDl7Ols0802pl8uX45eIl8+Xy5fjl4iWupeQOSnzaJeUPBhnadnwmDCXrpdhlwc0NJgtl2aXMDkLNd6YKJemMq2YLJgSl6qX85Zrl/GYMkkamDQ1i5ezBjc14peEl8yXupcZmACXv12Ml8IyFLqDNcpQxZfHOm5IQJghl7iXzZeJl9CYAZfTmASX1je6o5mX2pf6l92XvzrZl+CXipe4MmCXeZflZglP2EJYBciBapgwl640MZfzlmuX8TQxl/OYFZf2iE2X+JgZl92Xv5gCP06X/5f7l7+YAj9Ol9SYBTsnmAgR7ZeXDFNYxU8kCCeXcpZLmBE53Jeql/OYFZf2iE00nZf5tO0HxDpvSY9QHE9ImB+Xypgil82YJT2Ll6SYKTpMMq2YLJgSl6qX85Zrl/GYMkkamDQ1i5g2BjeYOD7j2BTYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BOYZ5iYMk43/GziPq83ETZINLmYoC+amKIzEAWUM+CYpj5YS9Q4LjZLWS5FGuI1mK8FyDTJmLMxP5i1O8CYuDKHmLpWSDYnmL04q/enYgszEwgl2AnYAtf+2ALX/tgC1/7YAtf+TjWY3vYzmOE4MZjjM61oDWLqZXCY6V7fmOxDyj5SlVWY8UtyB3U+IcmxmPdMwW3wyKmY/Ab8Ph1T/5kBNGWZBDyamQY1b0x32BTYE5hQmQ3i/ZkQOR9O1pkTVgs35TZFBlmZGG+1UUc0iJkcMkWZHj+ChOqfyXAWONVOYjQiPO84C1+SA/VI01ERNXeZLRHqPq02F5kxRDc36BGLkdKZNzMqNkFhiVaoOdIyOwdqUs+ZQE+DPDluEGTaQ2I2QFQA99WZSmGNeVVBVTx7RPl5pZlSW35GCbMamVfqGZlaBxJMC5ldgfSZYDWnTK85RzPkA36ZZqr/mWmZa8p2mW49HWECmXJBwz2BmXVBzzYlmXmZezJvWqSDITfXRuQOVpmCPD+ZhAWUmYZLcgGdD+Q/0VsMmY1oZlNbmZEylziu8PI6C6CgmZhfITBcAaJ7KlbZNYHOOJmhPfBQEkYzPfwBrv+LmalbDwu6SJpiyAkHR6tO3jxvNyQ3REPwYwOZt0qnmbpfFZ1Vmb9ZITcQM1Y2LkS52s6Zx2l2NK8QCT/qOUWZzgX1NhdRDDMWL9mdepnWRBQ8dQlwsvKZ3ALSQZ2Z3zoUOUd001W+meU2ZsKxUOdzDj2ibxyZ7XnUWw893TznAo5C6Zn1h3mZ+DQGmfowAjMDQS+Z/0PwP0ITTTe3ULyaBUehP32aCAEUNCQ3LTqoM2g6nzZ/QvA5Y5oSOkg+sJoVPhw+nJoYOT/udTkfm864gJofO32NxZojPeQ4PjG9/S8yTTmeRQxflVYRN7s52jfXOjI5HfbHmjS1/Zo3QNE5xjPiVqA6OTtFQBO8D5pBMutGr0bjNmtig5SIPjQMC0szmkw2MlJlQ8xPd5pSOzBBC0TAVWNUA5pZVTNFUTPRPZlWzTfOsTGaYp3ZmmVA/kELmmk3DlHhmm04ZPwImnE44Yf6mnUCJDUPaJQ4jVsdN0NtYTtWW6JLClIDMbNs/GGJB9k2tjJRMdhJU2g4moo2hpqMRO9KvD4lk5k2DWruM6s0DzK8U+Y4azj7NutJmnhyPYqanjPDWSxCozTRQqdEbMaumqdOikKhMl2aqzhoNro0njVVmrBDlZqzOh+atVTfMcM4rDbUP4szsJq8OtM2dTMLMz6awTAuNSSaxQWUPnqayD7ROFdQCEgeO787CuLoNps2xFqNQnpuQY4Cmtc3UEi2PSOa3E3pqeaa4DLwNEw0KJrkTXVLXHXQnxSa6ggnU5wIJ/csmvA/tW7JmvTtLpr3PPs1UkjJSema/WIYOTo1LTNDr+GbBDobO4xEBGsGN2xR/j3nVEZG6kYJNgo4NZsRM2Q5JZsUBLniqZsYNOvzhVvQ/QabHj8IPtcBA0urPndFBE5iS6szyDVtmypF8jMRPMkEnBgRUDWZ9pszST1olDo2Bq+bODzutUWldZs+ARI7AIA+m0P4XJtGNeRB41r5VxCbTAQbP+Z5vjgMaGabUkLEl05U3wZxm1g5e0fhPEZNZ0uWm142m0PBRDtCbAS6BUU79Zram2hWjwJ3OOVjZTlBQQp1TwEVYYdMCk9tRAtSZjoxSp0CJY+VM8w4uToVm329NJuAZWybgjQxm4Q7xECYO8g2UW+HQS03mgE5RV45ZpuPUBIx/AX7YjY2GjmUMcJAnWNlB9k+apubAkYGrzQuP8gHaj4latWbpE8/SalKq0Ozm6oz21JmNgM1TkLEPq9GrlYRCoUQ9z02Ct82kz+6QUg6SkHCWnA52DvgBj8/lQW/NX1jWzvOm8U2qD+rUOdnSpvLRZg6MTZsRl4zPTWWm9IBPJvUOzY5rD+mWIY1U5vaPtYyP5vdPxwC5Wlpm+IzBm3g3VwQIzlXm+g3bpvq2Amb7TQe2X+b8TX6m/OILwLiSoMt4DSfm/plD5v9twycABgRRAtesFuXEGQ6xdI7nAkzYDQiNxtXopwOp12cEUOYpOGcFZNHnBg0ZTKtOcY9jpwevfPX/b5NnCQ1kTksnCfq8Dzad9ucLDhSNCecLxrpnDEz1KlNnDUFegY9k0I/+y3EQAR3uJw+AjM8+2uWnENWrJxGO9BEAZxJFwo53D/1NKVKXzxlRjgORTLIA1ecVMTnEIdOilcpnFo4VU6KU/mcX0pOMwhLbTMZlqCcZlGbOGtHwzTQPn1jaC/ZZt9JjDLqPuM1Vj4ESvScdTWYOMM4nTLdp6WcfFhINKZhFJyBPwTNcZyFPLUx1pyINJ03AD31nIzIO5yPnJE3OV6mnJTaBpyXbd+cmjq4P1c7ykClnKBEwjI6MsScpDl4dQecqLIPnKs/NDK4PST4K5yxBTdBmWgcXyKct0NYRzyQSZy8iH2cvxrpA8S4bZzEUklF/0rdBIk0nVXxnMxFJDZEOY8yQjM/nNJNHWmBnNZPWzq2UfsFnUEPBO2c3VoZnOCQ+pzjSPmc5l8+nOk1iz8VqWSc7oMDnPEEQZzzPMJLn5z3b2APBpQ1nPxyJpz+cTidAUlTMT+dBExVqHWdCDHwgmOdDOrQnQ8yPEOdNIw77UC2PQY8yTHei5CdGkHOMAKdHa2WnSBBq8eInSQ2xlRo6OOdKTqJXChIJUEHqDCdMDuVOt80iEtQnTUx//OpnTl4sEa/B2o+tKNknUCGRETIa6M+oTNNLSdM7G3PnUo40TsbN+Y2I51PMuM85jsSnVM0OWTjnVYt4LP5nVpDHTqJMyZXKzdhSc5AWIfNnWQGs17byGSdwZ1qTv2dbDIGnW4CTTwJMdhFmAOsQR4HaTU0nxBnwp16mdY24judNPo21DSy5K2dhDqSBykXogSb3kidizhzU4NMdzccLeA5W4k+EmII3jZ/OWpApUiKMb81JUEJYc9olEKBPlgNkJXLMo9AXz6LOldLiDLDS1Clq+c+nawz+vmpBnQ2yjbGM5NXWJXRnbZFKTVMM0Sy2p28pVGdvzMpAsw6+T6RQlk9pKLjNao8LD8fPzU1lj/wNqHGmFqNUkqd0XqZndRCtDfiAjRISlI+NtFEFAXJnd17Kl7TPHk6RwEUneOqdZ3mOFJOsTnPneo1XkkDne4QpxAMinOd86G7nfZcEmQnMmAx7jvunfx7Fp3/NAQ8m1hzngRtYkQ4U98/jtRingvaHJ4ObDmeEQFcMuu3wp4WOnqWUQn8DJ9J2gQ5NXABE1buAjaeIWNLYCJzlJ4mNU6OHDrzOybVqJ4tQ2KCi54xPbBPGVZTODJ820gHPR2eOZ47QYQQDzQu7fIC608ISBKeQ6+ZnkZIjDjMnkkPjkTvM+q2JkjuO2pBS1V4PHVR+0RzOkh51zaW/WqeWjyQRhY8Oz50OY68qJ5iOTNm755mg+sQNUY4PtEQKz25XcE4qwjcPbxgfze4OU9KwJLgnncy40OdD++eezz9/q2ef3AWNN02822ZnoRAZZ6GSNMP9ev4notMRp6NPd92xp6RNuA1TDS1NptJMQFaQw07c1rYOUE6t2V9np849TUcM5g2ZAFaUbdSIjn2nqgGBjVnnqvNB56uOthNYp6yBNo9udianrc5Sj5LOX81qjo9Truev4QENrCRv1wcSflHqzNMQMOeyEmansqCNJ7NBJoyslWBntI4N57Uu86e10Rxntk4nF10OvMP9J7eNxSLpZ7iUbie5DpHR8Ge5z1pOuvploc1QxM+6zu1TXWe8TsSnvNcxJ72MesBSezUnvs8tzwAnv5PHzYDBvQ14HsqNekyQJ8GPXhPbTh1ATlFXp8MaDufD8rOnxI3i58UOucvxj6uhTs/+aelnxxyNJ8fQ0I5ckzsOGc/Tp8lyP+fKDpMPLoEmzlSMcs6/TSwZxU1QQEyMeaJ8Z825N+fObWgnzxbB58+OPxYEX7Un0OGx59GUEE+UzsBn+Bx20b/OiJASGPwMBEx2J9TBxGfVj34NYRFR59bRMCfXUGdTEcGizqnQtcBQZ9kOWA27VdtO8+faVPZOSVO8UM0CCc8c3N+n3JNqTOhle44VDdsX5dBaEYqCUdIlp9+Rq9TX5+CR2FNqZ+FPaRJjDWlMmpCgZ+LBxI3HjM+Rx+fkDXSZ3yfkwypt+SflzIMn/Wfm2TEyT+fnzyLWjQ62UKhn6RyklUwMzgyN61xn6uZPp+uONKfsF7bn7MOQzwsMfA3rTVhZ3Q4l0IJPFk7Nj81n7877a0gn8M5Lp/FOKlPQ69oWoZM8wO8tC6fz091OH/7HZ/UOdczN3TyX283oTUNAUE2jDKuOBg8TkyfN6I1F0nYNldBqTb9/Qo48pTWp1qf7DZ/XhI1yjpLXQaL2Z/0D7bchJ/4Aqmf+jVBU+l5zjtRWrdDHVIiOdk1tEv0O91OfaAIPO+gCjU3OIsyTKXX1ZQ7jFUwWmM29zO5GBEF1TjlXhJEbkPRPw09uTrPUrtpdzQ6XVxLxqAjTvU/2TV3Dy9Dd6ApPho6LTbGoC1MYUHjNsU8/zU2Tm3WBaA2COsjIoXsoDs7fWbSoD45f1yeN447OknaegZK0Ux3PnegSLN7oEs0LqBNoE82IzvyUUc1UaBUNUZBxjPGuo+gWjzkUupCYDoVoF84CzN0Mzvdo6BlOUI2DaBoMT+uFEEeRUAzD/vhoHBmq/ZroHTGI6B3M247lVrxoHx0rwNLUb06CELCXJ6ghDLEggY2mIMxoIpdYlPDPSs3jjiSoJBEQDXAoJNkJ6CVkfqUX6CZNRA1naCcPxsGBjJLoKBShHksoKRB/0DASgwS7qCpL2AzKuD6yPU0aqCuSR+0jAaeRERcJ91lU+s6DDjhMOE1tW2eofegvUjboMAHR6DCf402mDYGQuxbLVZ9M+Ps+6DMgO6gz3I1S5yg0zerBzyg1zRsaH5LtGILq2kvl9gFvkOg4z3KTHGg5zaQapMPPwJFoOyEdqDvOHCfVTbCkYKg9TkSUDdorzK/Mq4x+aD8zCVU06EAMbVRzzlOoQRapD+CM+k3Zu47W2yhDEP9S7ehDz3BNAyhEky3QFNC+KxxoRhL9DbLNiw+HzbfN1WhH/OvoSLXq6EkNb0zSaEnimEx1VouoSxcElPmfv1GAqEyOg8x47EIoTdHzmxbRtsGADiOB6mhPhArOSlHPEHKS082XjfrO1o9fkAOsVChSxA1NuM9PrWzS7E6FKFSM4c/JFYfUBJBUQJNoVlRkEjJoVw4x6FeU+yhYVHCPhQEpqFlOlA5eAEtOyqhazOhTXZfrEw8+u05HZLzoXQEsjS2QlmheEj3NMG9p6F9eoURizecoYIy1TG16TWhhzrYTYlUNzoIixmhjl5VoZGJTqGUN7jKQ6GYM5s+YjSINxI9YKGeiguhoUzUMm88R1YfN+Whp1woATVRADUlQX8+9UNqO+d1K6GyVbk10jNKQohlbESkQww+9D5iB5RcnaG/op2hwj3nRATSAaHHQVY/0KHKOOJEO6HNN+U6X6HQZPM3HThsQqsBSqHWmZg8RlgYAls0Hz5BokWh313UU8w2XaHkrl9dWALLQgk+rNRYoey+baHvSxQCB0YoSks03aEdofdb0DJqMu+h+8f4of5DEzzPqceiA70cogZUSUNlbYqiCzJCOI06Dk9ZN6UGr01cBvg0AUPR3UiiGF3lohriEaIdRzyuhqIhOSU8zzIxUMUBHTQkW7aiKmhNQ6yiLZtqojC/X6IzYTM2Q2Tj/D2iOWTTD++Mq6I+Pq1/fE2GY2ULxKjJOnpRGUerMg6iSZLzosuiTROSPqY3KjSsOQk7Wk8bolY+9TfkolkzNp/VQFY5n0rjQfk+0TV1Ag3oqKJl8gqiaI/XomtFsy+fO3tKTjVAonE4r0Q0onUQwzTtQ8JB005qOb2P2TUjOZMFFnRFOQkBBUNCtqczP5XpoogBLbqFoowFAzxOoo8HKaKRy9WilDWIOEFD2EYp1Vm9H6KcocGin0CdWnxWfa9soqVu5KKnn+Ctm6m3oq064qKvTyFhzLn/QzlPbaK1rPSiuEScNng38jZ0Rik36TQHNdyUezhobPw6SAFKosY1TVSkNf53fNDsos06AzPNQKRWC0AZd7U+2zPGS1g2TzupMAJHpw+OYYlFt9+vouAPlEMMR8E+pkKjspg0HzcrounF8KLsdeE8vDKLNk+VaGXKB8Si9HkLOC1BWjgwNTkz7J3ki+yS86L/O9RAp0VZOgNE8TSJWnw0H1BpRahJCW/low1bbjLVO9s5fL3goxSU0sf42ApN/qMaNghPxrGmox9SWqMi43xTw6Mlj5WjKETKV1hXRaMtNQy7UKMxAkWjMzh1NaqKZKM4NVk8TqM7NTPmAj3BR0xPzD4sNcpMLDQLYkRh7b30QL2jSavTOHNBRtgJvkKjUjd1srROFaNW45ROE6NZvlPYBr5TThijYterYfe5JNf4xk/X+DRJo2s7lKNtR5dRtwFIo3GzyaN0M4077lCgo3kHK6N8RFg56KN/QVpBlWGHX29JIkKuTyg3LXw2XlZTE6OMRo4zcTbwTyFG/USro5M53j2CnXyjmF5GbyKcHEFMOySvA9gFo1ujozeCo6VEtzTaRZg6xD3VUCc4hzM+CK0/P2LAMzKjskgYQ+A1a1DwVgsMK6O5EPWDswS6PtszWueio8E1tjDuObs19jWtVXFmXKPKZdBEQDoTU5z+V3dKQE+j0ghoAUw9hkGoPnek76PaWHWj3TinNLRGfDJuo+I3mEtcOnQCNRLuo+gBxVvKN41gnjlHo+5JkDvPkbKj83KHo/Zbx6P5PpDC8aP9Py2j/zuhOIkBHD38Mf8/CD8qn0ekCQEIuWBCTEEJOYFXk+HsjOKkE0SkOS2kFpqMpBlDBzJsA3RDqDg0TEE0BgXeUyc2wDndpCU6GGNLpCg01zksQ91RUnhDpC8MKbYkpDNGjqQ1M0s01000htSkO4pBdG2kPzhQP9Ex8KRDNiSkRT0dSFN41DKMgpmkTDbxRgmkTzhIpFE1W0MsM2g5YEM9Od01/QEpBxE8eGGlbc+kX0tt2sGkYzUpNh069I3VpGmcxaRsNTA4jzbXPT2kcTcOpHNk1TX7D5N2taR5LRhDfQcBd5qkf2OqpIJWuz2AMgH7hXiEpIlbtXJxpI1EuKSPNMEEm0s7bopWCUSdNAYK3kCEpJlUgXNOQrhQL16wOJxDAQ+UX61FYqSlOwFjT0GcpKlsjaSsg8WVIqSwP8U1PaSzS7Tg8aS3T21ieaS7U+Fb+012QIw1S0Xrm/SkxEMlMl0z4g07Mf0Em0PCM/jW8BDZOD43qgcIA7xB/z8tZ0NEJDmaPSw44jU4SrpbiKTdRIBBmz+hpOI03URYB9FXA6ToQLEzmDMAyAdZ6DoYTWcz7FSfOHU7ZTxCO0I/KVfJr6+k+mx1bgw2S6T+QE1JdztiRwClBKj3pQdJc1AypQq9pqUNjx6lEO3BPvWgB40iROFmOjLPBhWlGTqaOX+FjaUeMuYyxD1+N0OlI1P8pSWbm0X4MwtAsUtSQpMzwna4PPrHaTgYO1KGsDQeOmI24lRUFQw2UUJzNuY4ij4xBt6yMqVA4KkQuaVDWnA2f6VGTKelSDl0AcEzN0pN9/6lT2iypVIykF4UpVYyakEt/d2lWziXRuilXwyqOVI8MzaQ5KulZkLyYcxHjkPKOUmlbEjcA09nCj2oQLs2OEFKSmBBHqV2SZCleER4RIqlfDNoRmdWqDYEpYFfdkJ6RouxAKWHN5VamztaPYKljF6rNB6ljzmKMzICjqWTREQ28a2+pZh8p5xeNSlNSTVWN7E2sAUdoCY/hAI+Mxw8yD4MM/elqKYXpvGlrdvfpbCKYXS8OZ1LCjYxPPY0Hhm9pbo+KJPgpb4+fkq4NYY2iwHqpcQ5U1E7NWE7RzHJMjUyAzXDS8tb2UGAOoVAfqXSRAQ0wkdsoA5Imj2jAzl6TDctMfI57D2jUDel4TLjPBRQ8Eh3p0Kl6FYJVgttJzr/MpdbL6XvBZ3/CaXzc/Kl9jM6SMlFpjWwrhsCTjMQpf5UYTW9OsijFE1qOIpm3zwnOWs/sT3CpgtNxd+Lpg82UTVVMOE1MFCjRMU1vaYXVXimGW3gMJKmHTxIX8A2Ozg7piJKwJbjGY1eNzj6pigx/zTtVXWmLA+2jEmmMAKOMeEH30BfXqtvO1YVpjgBWVGrAXg3jjlrpj6WTKZBRmIzzEBcDlamRkEUfDaLmaZLScY7SjYHMnRHHIErPrA73WAHplY2u0kXMbMzWT8Eplw3haZfyd/YCU4kpmVIQlYRpmg1Mjvfpmw5Aze6Qi1IQzl//bw0J17upnZD4DH7OHRCiEiMQKumfVYfD9I+HPtPOOHXxDirOWcxzkrbOYF1XKaLVfemjVBBO2ETklDGQ8uvQgkHHWOmlzIOMb1CqDRNZchAUrki2BZOA6aiW/s3XKo4pqc8m0hTpqqhSjzPOUo2tjJxMb8K3kIcprQ8azeORMVFYz8EN9qmuzcobIYzZpyfXqY1kabCPjWmxDVONVIP4zkvX5JW6qbM3NmmzzpuOoyAPTynjfGm1jTuAUym2UTQO/+m3Djgpt5PTETFO5Y5UkVp2fWsAqbnRkA5KAcS1Jqm7TjSCls/0UA4ZCdkcqb14dim+AWUQdIJ7EIjNbU4xzUoOnunAgMFPrCnBTWAPYZCon9Ipws9yDUVpw5RkGBXpxICTTZApxVhm6cYB4I1UpI8px1gA0c/NO5CYKciQipOuTzkTuBC2zpHpyk6xV9vTWo/66cuOZw8BjTupzJTYwEUomWnN0qZTm2nO4hupz5D1DJgp0E/aLIPp0XTHT9op0k9mcoPBOunTQ8vPBEBB6dRZD4y9DwkL5dQoj4kVruiO6dbONg2M0hAOiWnYAFdOLE8gzzPOrGnZjX6MyY4vzWVRhBB40S3Mc1U9zlVp3FXjKd0yn+ndzPdB7+nejsOOAynfU8+WfSngUCsN2Az5gNWOWUzzTofM9pLfTpN/wxbTaePNyA6X6eSNyU8BqeVVglb+7d2p5pLtzXPc9w0Onvaec5IaN3jMjFLiD2CNAXkzEB2POIzD6erMdY3oTKaB79F+D5/Myens0nop7be9ae5QfHkgLYFp75qkkMByQynwzn+ZWxOfafHZm86GTxrp8t/zDIKcPqoXafRNONcczQgZ3Wn10hoPjXVQafcAo41pJlBp+EzXTsbaAqn5kJ3QeRCOEPUPBs04npWp+87R3rdp/NCoTh7M9qNnaf5P98vljqwaaduN6gAAXg2yjlVqAQBv52ZM81ApTWSO6o1jjM3+RmoD0OTN2lJaQRBN61bHT6sMkU1JTTtPH1LSj59Tb9ADnLSW6eoIlzQqCQzpqgnPBc/9XuRqCwxnFRJOZKoMFbwqDNL9QheOo02RDiPM9EBHAQDM+o0rE1qqD+IxFSkQ+tk0z3JFGIH4DXzapJFqnz/qEzL7jW6S1FDOV9vTemoU0wdQu07Ek7xRyWD6ahbYVCoXkXsbsRIoECYPJAwkwEVdqMB3xAiQaIPY/cEx1uobqDoqHEy4qh0OgNINzhaEAw0KKh6WPtLGzfWqH5DnAFIN1RbuTkR56KohtYLqIk6IkaLAnlbyjY4AndWCzYn3aOolDItqJapYqiZBttOimFfOrY17EbTPA00kTIFNkSopHdMqKc4MuuOqKszUmAiA3NHTjokNc32x3DMN6Cu91iGBwGouN3pqLs08DoiP8wG4VW2WqSowjVROpL52qjHS8ZaPTtKC3lBIzIQa5Oo0EEXYtoCL6jUbgk7t1xFSKM5VTU7qNxYAjACMlc5ywczqtOo5EFSqOY2MzHXP/k0r1NjENFO1lSBBgZMgzUSuaGo9Gn1qPc5XUrjPAldSz/rqP04Mjc+PU5lj6kDPQbkEKkHQ9KpCoZHOmqiYecxqRBAjDaWUk/2rKkWQOY3P0ObqRs/FTTQPaNfEK4cVsM1pakjPd5hcTlnB2k/QjfvqSpGXaktSxQxvTQ/UcIFv3xxqTU6wTP3PiU2kLd4qTw0IFcoB05A9QEcgBipRFS+UvypSDJ0PCRHw6lMPEFuDDIpphGZB6lTVIRJDTcbN7E0NjMLP782Gza/otGpXzcIqWG7halkYs0BFTbrWuI1sDdDOhn7NmAXQhmpcUF/nivUz2x1Nvs4J0FSlvCpekS4YjZBnTZERQo9KYZElNwy/kO/ngmnQqmI1S9MRgG/NTw1VGNoqY87qjSPbJACdamUOZhGM0fBN9+pmjrWO46pneDAqaBP2amiNkJLtECMTAtSA+gUZhWpq1fbNAlI9T3fM2tM1DSrNT2ptEB+S1JGVqm4eFWpu2esqb4wLh/vBnc5sjcZQFpSj1fbRuQPlDlaqco3DjPZOIo26wecAeo/1EmgT95yEqnWZlxZvDOum9ep3DnBNLk4cxaQqeE/9/z4qeVBFJqDqek7JDb9OVep7XaBqfAy/GCeMj1Gjqn1Odo3JKxaSwo03an7PB0+xD5MMiU1JaoBATmbtjY3POZSmVYfXGiqCju5AattP0nGWeCqET7zORuqFZZVqhg0rwZBOXdDWEPwNcCAYKohsY+qJDdjqidccKoqzYWqLUnUVzOqMMThqjM4CTbcBfaqOHlMqjvSF6o+VtxF+DVKOvhDvjkfXduqRy+bScSqS/3VONJHlDzZNXbXuqpTNssUPDt2qlcFxz8pQKo/OKpdOJ81r7amZCeKnapkDy9jvzuOe4GqalRJTDcwAjQfX8A3iEKuPVhF1Z3kqnY+izX6OsGqejvzQzNj4qp/qtCqgq4cODEBaaqGOFSqiEa/Skuqi0+LMyaqjjgxAWlUqqkfqpM9vI1hqpdqc6qahkQ2/W1hN7GrTzejNB9Ky6qjWhM28wcSTDdLYgV6UZM5stvNMjo2HV9vOTgQCDkiNN+qtDgoC/d3igKpM9lC8EOpEN2qvTodD/BFGgfEY/A3XAG3vEqqxzTXPBBAww+2N9N3uqrOVOiNGqrSOKo1Eog/qtdGPKraiE0433EdMgwy/0BJMdg52arjNTbo26rnQopfLqrqNjIyQEerTAsBrz3eM5vs0qr0TvGvPKr4SNda4lZINgl/Yar/P6ZEWDUtBYk37WObO+41aUGpOH+ADjzPQP5ppzY3MetScXfRqxNrzDLYzzirGEQ8M1+rG9nSqx41WzIDT9irIlVmqyUQCUS3OsFVCasrNAZB/6suSNQ9/rI0qzNTJ0WzSoM1zzTiBzM//EBEd2/is6s/CQcoQlpKCVXdr6tGUCerSEAQq0s1cAZtPOdox6tRRJgyMjioU+tPeatYQg+rWl8uUXY+66teQ0A5JzQoJmBCIjg7QF+rZjtlN9drfqtrM9WrbUthMos1yTQjPfg1vjJM2byrdwLiNmwzPT/UUDVbLWerq4BEJFQvUa8BrAF9PfUyjDUtOK9JEjiGMimXCKuPPkM2nTkGO6U13TjGOMhFgztoq5pE4TU5Pj+rnzw5NDKEYqukNGXS/74Lq6o5czHABckHEauvM1Y8ATZUQpBE2DxtNovUBau5RWNeH6u9VVdFJV09M2T8zpw/q8VqnDdtWy86rl9vYZqrzS9gNGWr0aNKrwLYCbZkq9s0xT7XMowz/jM4NYV+kKvkpuGr5zZcQ801mTeaRWk8VYBTq/AB6TkLq/MyOzsHq/Zlxqv5YdXU7Kv9QAU9tb1BrAI16FwCrAY8JqwJNiI4aDSvohusDzvuNzs1DTT/rBRCuKwWVVc6TDIyQmM+YuAHrB44Yjt2NSw4xFtvOQhObqwnM2Y1jzPfOK5PhTNDrC43f3grrDI3GTn2rDUDyKU1rDnnzaw8M+IMKzv/OWo6gTwGrjasRT0TNPo542b4TR0/v1CjOhtF+qxQAlmsUvikrFWzjqxYOAY/1mGNQFNMRzcJlMmsYTIoOTSdDaxmWHWsaTQiekxQUjtSPAAFC6xwoResc0nGM0TSZ6x4NPJWqDh1OM1zIDHpUms4CXB+rINNn6yFNaY2ADxEOBeuCayMRilAkkGdPc00KEthtIuslTgdA1esmFV1BkOsnDtWrJ42MkiuO1ZeN/T1NLZHCDsHRexXkzoPbyqsqzu1OpE/dayvQcasse6/rLQxzqy2NQE3QTbGOXwDc6y8Boo69JIzTDc1KF+VQXxEOzH6EPc5VN8gNco6Dzz8rMwDflOMVKWs0ZLrrNQ5fDqfrNc+gDh1Rl40FKzcOAFrvazgAb1fAjpRPOJSuwXIZHOs6TfmN+XNR6zuNAY+HTMYRJ2h16z1NV5uilvCrPqhKaz9Ouus/0pRrQJYEa0EkW2tB0EmXy42V2ziccutDjsmN7qtEUX+NAc8OQHBs/CtGEBFrRs20a0dNJhcRTjPNUiCYq0kQoFASTYXM91JkcUhrSwv2RhxrS86560xmmCtNAKfWg5FHpnMrToLeTW1N6k/xTz6Zeahdq1DOBc8SmX4Z3xP0EYWVuutTEdVENlAaFTYVvqtU0WWOhU+9K1XS5Q1G1Tog5oQyq1dOwCW061hPH08E9TsPERb0K1nkaCtahBkA3OtbXImA36tcDzaNo81HTlAWYGtdzwRRtzXq618Ne1CwmB7PBFp0jr/Ols0OpHmrYc6008oPA01YK6VVdyscaEYOhmtkUtSOrCGUzp0RgWtmHevARsBE0cuQiNEnDYjEDU14Da3B5yS8xJPRW6oeq2pO/g51GByNhp1MK2wXf4+9q20RU+RCa24DwY2dGYJO5w5n1p7rcBHPD36R9RbmgaaAV1E3T8mQOY2qVF6NyytzIqeWQoBYCZga/ut0zWPrdUyOq3XYHJH1GMiZ/St3V3BOaA0NmcVXhGt4wEbRBQ4ia3nUDI4Oo1QrexmbzkdkvMST63xOQ48AK30i9g2Awak7EM4FXKS6e6t/TywTnKuAROSQglr9a4FYbhKfFvZAa81pzWXhgyuDTKQNhoBvT/7RG5A5pcUrhY1yjKHrhlCQUKTPHpRra4fPU5CnDcMriNCho1TMs1SjI5MVbZDqTNlQwIG4a4uNgBB6D5DMhsyG3qFrEOuN0Hxrjk6WzVKZdauPQayAS6uQDaPOI830ZJb0ExDq1+orkkwUq5MOiIoQjQBfr0U1jevj9lM7Fm8PqwEia5YOY9oZlIFSYhATTObRUWuYeeyrmQ1xq5mOJBiAK5qARqNT65uMtY3EXVSrnM8RzNhM8M9mVWSVN9D6/R5rn06Njfm0kmugjh1QH5A9q6GXKOuibkimHyujTI9ro8BLXXbNvNH6j36PH0Re66XASZPyDARFpCunArfNmU1aTu8QFgHvzaVM8gLbK6mNA05ODUWMd9A4K6tOSs6hok+rrE89lAvq9OutU2Orrg9jj2YN5W+XL5L1/3YCdgC1/7YAtf+2AJN/tEIrtI/Qg5WrtU8jzT2rthkt2GlNwpW6a7eOmFV3FQAOL+I8q7lTOxVgDm0ruqCwq7tZ0Pv5q7xRNoDsjHwaJBsDa74AVVW4D2DQ4/OBgWESlyjSq8C2AnYAtf+2ALX/tgC1/7YAtf+TjWvFXS8rxc5c1PpMpAC05bgrx5/NK8hQ+CvIziQMv03zjTcryhFKUruNeVEgTwzawthZz7EQrxaSa80MfBUghT+VuI26johOf81rwZBrz6Pt2epr0I5Tjr/aLE0yEO/2IVHpED2P9bKTq9ONMmvUaNKr1TX/tgC1/5Nz69cMfVffrRnr2E71011P4I52K9nn8lp/a9rOGY/MTnBNIw1rQ8vQ4g4GUcKBzJPNedTr3lCbK97U+ZEauqX3YmvgTxCr4NVcQWJPnpf8q+Jq447yp5yr441Y2XWN9GvkgIkTEcGFQF9B+Fcf6+aVn5U6DxTV+gzjq+gM0FD8Fg6Pfk1vEKGDkN0h6+qQNc+61g9PO84uV1LONs3NEML066vtkx3gpavujQVTxmvvUtQO44ReDWjr8JE8Tgnr8U3NDkINDtC8jw7AnWvzEQBr845uzZ5imE19jSXNpY2QksLQq45fK/ZUVI4F1KmN3U+RE01r+BF6DJYBxE7j2VcUT446wULr+k1FxDZP+YznTPdr+9qx6/y+Yuv9aiwr/j3/lHvQ31vK6/+SQ06ejfsUpU65WsGMd865RBHN5AQHFJmPc1KkLAOQFxMxjf4Pypm37AUPfw0DzIteZJJcTjsNA9h3bAeBH49kwW+QKU4gjdtOrBf/7AoOmFEKi+Xk66wLt9yRks1B7AyNTM9ojUtAjWwNzY4YTuITUaucZpQjT5bsD9AXBAFtDuwRMjXTS5W7kZksEozQz1pOyRL8mp7RQrSKLBTbWpUhLBWMjYJcVKMNC5aoLBdNd5d5VVnsGJEBjKHsGVPrrBn1o+wamNPPBRBDnVJPDk4MlD/Ek9IsUPMBd5KXKwysHkx7lr2ixQ0LjqDNfps1VHvMv9U/bCGRmI5SlTFsIprULCNNzqZapm4sJJRGrCVheZA9TkeVNjUSQVBToozZbCeBq1EgGoDOhg9R0aYNc45n2J+NoOwqd65sKw4j0fCQxOwsDkeQwKCk7C1FNawtzhoXwJDWDSRPQ43jzW4AbfrkrDCS1yEV0dzsMcQR7oQfyawzDOwMvwPL9IAsNIy0ILbsNZEbD7HAUdKLT/nsNw3IEA4sN816E8INRuw40BXTYZAaKTBR86w6T6hOJ8DSTXlP0KbXrDxNVuw88/BOhhJcXPisPkDdZJksP1pp4XzsQEEsl6hMv0y/AY3NDZWkkL4sQpC8EL9sfGxD75T2Aa+U7EVAus85LEYQ+BG5TXaR6sz7d3QsR9WaWNbNfqxIzx0OoOUTV9vOPRHzhirsSw8grEuTopB1GO/uBY+CpZLMhtQCzTBUXZHTrE6NSNScTd8SzlHalNkPY6xQsvP1/3YCdgCTf6xSbqujzCxTUKssU9cLLFSVQoTTWADPta9prFZCVtX+EXUMplEFLFfSMg537FjVmaxZTfSjFGxaTTQRmWxbTM+NLncUrFyNiQGfmC0sXdQMrF5NiNDrzZedvAHaeD6TIQ4/XQDsYRMd/FcNdl3ujTJPYSxjOISsY+QeknOQnGRp7GVAbdCrrGYRsixmmo4sZ01ELGfNd42koLBg9KxpT+Bg/Mzrqelsaux5LGuCYixsFYRj9lIFD5hMxFHqTmFNnkydLG6UUdEbjhrO5lFTzZGNXBHYTfSQ8I1VD7fPBCxyLaZscs/3mVcsc4H2VNksdEyl7e0sdUBGkc/f+2x2j/RVG5AibHeOJJMF+L9seM3c7HlMvg3sUerT3H5zUuWQUQ/FrluRFdCFgLL+NKx9DY3sfZSYbH5PIBB4j2cSIxHgm87VSOyAjU/Nhdi/7IHXVg3t9URsgw2kzxQVMcWym8GPO4uTmADQGVgf0mdiT4+8wJLshv4H7IeXtuyIK1EsiNIQ1PbQ6iyJ1gCsinwCrIsOmmyL174sjI8/GLNXwNKTYCoNTO4rgbMOf43xbBgsj9iwED8PecyrzWjRtdERE3pQ8FMrzHtv2qyTTeeUocBJzwAGBFsG7JVARr5lAe/4UBhifQkSss/v+NWsmBYxrJj6ECEe7JnOu48RLJqRo+ybDbzMjo6gbJwgSayc14STzSCpUt1R5Vw5rJ7Pp4/uTjMNLDctDiXQCM7pFAzB1EHNVcojGKyigWK+OeyjjQYspE5rAd1spQ2HDuhhkmyme0EOTpIOrKeuneyocX5sqQ3844esqiavTX9sqth+UvxMftaSIR7N3Wysjd1srTYBr5ToOGyuZAVRKSNc2A9Piw7qhDRTRm9obLEZqs3gFRoNP88FUMMQUw2/VZhO6Fbe2cestI3KwqFAihBFGyJstkzXDq3stwDddicND+y4Oy+xlrGWMZWEAgBM1W2MJNVQVVxMOF5vgIwODI8m7LwO4xJF0G5svQ3UDnXRx8L6EHkWy04nzQ24PGy/wqFYlHRJrMEOS6zBlKMPS4RPLMLNvlDCza3MtQzSwG+Nbhm+FZxUy0P8LVXBQo1D3pMN1Q6Ezt+R3Uz+bMhNso3pQcpRkw6IlaTi/ezKjl2PGc0wjHqRO01DUNDDXMPL7M0OcZBnT2GPDYv2UfFhb+zPE85QQ4y8HHbuDmzQzXaZOM2ZGsmL9hSA7NKM69WMEY7NLlepjzitXOzU1ToRIE0tTUATUM2zj/UNxRHDLdys1883VBjSfFL9Fbui52zZ0fbs2pHEbNselyzb0WHNyZDmElKR2FBm5zwPN1BlTgDOn9YMFvQgymzf695s4LonLOFPUU7EO3ts4ruhLONR2Ex3DfHDlY1uBAMVMVCgVCOkpqzmQdST8MORTM4s54GfjNKdzVHwkEGOYpByjL9s6dBZ1GrNpVzTjLmRVFFUTZ/NrY2dW1hs7NssTXuQaKzt5n8s7qmJDbbs70/3kAF88OzwjXuYCIwkzpXXClZSDQMO/U1vWqSPrBBfEhcs9E1gj2oZm8B33PcPv84hzPZNJgI3jj2NgA+PDYBOC0+QRDjs+NklTiOAgczkzrYRv85EWXFs+0+EDTyOa3Ru1xFSIOz9TQ0s/c4MrP5O9C4uje7SCdYCghePpE4CFmrMia39bQGOq08M1idtAtIQLQN1z60EEPnS8tOql7TSYxDj68YtBlI9YZENJS0HTdh5x+0IUTYziW0JTWxNre0KHNOQTNFq0L0MlNzurQwMm0z7GGhTAwx+Dm6ck20EbQ6NxSIg0gSOey0P9tAtEI6GbREa/i0RwY3tEk3g7RZtE1TkgNcNXy/8DSwAQM5ErRVMg4+9TQotFlW9QW/tFxBl19UDlf76bZvtGRHMrRmr2C0aTo0ZAm0bUx3OVd9o7RyOuQ5nAEEOa9Uv7R5LkoFyDH1uIK0f+LOgFG0gz5iEPc5NjkmA0o2zzqStIvG27SOBO57FjIlPIM1WAJZSydLUrQPtJlFXlRUen20njXObFG0oj+1Ws20pqj1toC0qvdGtK04CTQfeWQyR5QgPN20tDpLQqG0tzYTtLlHTDcdO909g0CdPBhohaJXTHaZurTFOmG0x1czTzf8CE/eRV48QUJzPuP31LTSQLF33kxntNdVIWhaNiK022HtMzwGiLTfPwS04UX9D2AzOm0nl6W06HNwtOsxzzTJtO/lcrTyPZyszj1OaFpz3DcttPkRQbT8RinTCBC5W/q1AjIzWRa1Bg8FtQkz3zIxWg+1DTTctQ9Y+nYitRM15zghtRZapEoWtRqSM0rVRKMyCMKetSE/ZD2AO2FbpWCkOZOja7UqBJu1LHmSRYk5djUQRMK1Mk0AtTUHKe+atTkBwbU7RDg05bpVtUCGqbVDljG1RjcTNkSDMrVLtQO1TkgLtVA/+0iNtVMU1rVVNlGzGEeyUVliqkgL/oe1Xkdsd6y1Yl1YPUpqnLVnQQZk07VqOf4/STlteLSSCbVxuWdZp7V1NhV3EAEoQ1i1ejICNQcz7ea1tYA3ukhAd5W1hbVOTbYQw0RvM6FiGDSQXHM1OGQnOtNXkzxzOPW1lHJ2QKwxyUAZNRW1mhbKjP21njzJNPVGxjZuOXo/9zHjM9G1p1tXtapDSjvggCK1r09kdxS1s+81tbYE2jKsMvD1C7W8O5p1q7XAYQtSA0QERE8FijWKOna1yDJAMwg73MN9WQC1zwbrS1JCwrXTOl9IdzO6Mh86NzxtQmBjm7XciUro17XgQQ6hXLXkupu150OsPI9afDhdZhu17u5CtfFfb0KHOlu1qLX3Uka1+eittfxbiDXPT2114UhDtgKEsLYFRwgzZkZuNb1k4zOOPq1n6jb0WBRJ2oAxthP9fLYWBgc5LT/8OR2R4LYdBus4AzMdBqc8SAXVtMW2JkGAsnxLGztHRhm2LZ3ltjBwkTbaNZhAPrY2MwO2ONgCmMO2PD5TQ8zbXrZBOtc+GleiNRCCwTI3PcHFDEDXtky2Tgfh2DO2UjjyOAZ4SLZXNk5lPbZbT9m2XU2WtmCr07Zi2AXX/U2VtmhfOrZrWPk2WzKuOIK2cDf4NdY3TGTnTzUJSAYVNTAmYDyASEo8tw3/tn9WfvCNtoM3LDxCPPsx60C9OOBjoTmetowybDW1QOu2kDACPUa2kwHqau5NOWZNA/WxyrabNyBKgwGAOzY426srtqM3jmqZOGRUSTb9PFJAVmHMtqw/xz/1QRZbFzOeMxg226IFQqGRlQaaAii2uUIbQkxnmzVIbZ5HFxbKtsIEWz+etsU1eIs6tsm7PzziPpXQJ7bPMeoBNDoittMzQbbVEXs53jWONydoWp5w3UUzGUiiD+M1WDVYRf224zI6m5tiiV4Ttumn+LbsCGhC/L/JtvGJvLb0PqGlc7b4Bym2+gXIWGpcHDQPNyoQpzw2VGE3p2NLMpC3BgW/bQm3CgWjtw1ERLcPPOi3EkUK2Wy3FkYziQwWyj2qacACTjkdTzdd0lEMtyE+fmnSDkM+x0fDNcNqvLcqOhGluDXDRmdHsLcxARE2CkFoTMZHXGaxRf6Ii7c7QG4yB0BxPbBFslwSQL1HDLdEPG03JtOsN3O3STISNzm3TI0ut0/Mr7dSOGQ3JDs6XpW3WMnftsECNDVIbZ63XnyDt2E5VbdjpEe3ZkFFt2k4qzX2Wy05R7H7t3BLxLdzMAJi6rd2Vj8BvT8tO8w21LUlt351QVUtWZxAZ0s4PT1AjJH6Mz63iEh5q+x6bDnZR1w+RDwAt5A7n0uVuG1JKGqTFzm3mDOTR5g62LecVtxFYregBSc9TzvUQEg1PjARS0o47Liq4Ya3rEUeXSs/ZLewN2kPvEfOTqc/+Tq8+I23uUCtt7w7Ure+Wvk76RJPt8JYGDoUSK63xjrBUhkGQTh4iLu3zUyDNLprobfRt5231DtROHk8k0DtAtNam7fbPXg79VZxRuq34DHWVOJf8rfl7hy36Fr2WSwQ0Ystt+40xUdOt/E3VDPfdtS39vf3t/kzxxcuhee3/jI2NUg+zLgCRpJm+LgFVDFG0zHtVk9EHfYZQs64Dpq8uBFNHbgTdeE9KG7kZR+4GQEFuJxUZbgeMjw1XDtlNdIzS7gkN9I6xQKpuCgMKjbGdixHRembuC9AT7gxSUq4M0rlNrBWETg7uDg1bzARBsy4PDeBAQNBUkApNJh+tjIRQ0BS6kE/PvL807hKdew15bhruE84ikGcRmcQkUKHOGZMd1E/uFkQ5UdOSCo2YTTyW1lDLPGLRJlvuLhlPtuVeFTtuGpBnbhsN+qxZ7hwMmQ9BlUouHVhhTRCM7RkRLh7AXE1BDJDDyNM7Iw9uIM9j2HuuIczPjxtPjK4jGNouI41LNRZuJI7qGAcAoJ7iriYQZxIP7icOlsvYDdqSB41glilXBJWcTHmCQd2fbipNDc6HTHnYaJp9biwNtpbL0X0N4I30Vboau64uJXXuLs9i7i911q4wF3+P7E2DUcGXMO4x0QmOtc0mlj7baq4zqLpVKRaUDL3WrfgcDfya8U3Zzj7uNk6YbjbAso0k7jeMpc2f7jhS6Qy/TxOuOU35TunZNNfwTO5Q+tGBLjuUT5Md7jxPYK48zIZWDrGWcZTTl64+UuIOpuZkbj+OZg12LkBRKun4bkFqVm5CEOPjyS5DAd1acG5EA9+uRM1I1XJPAc9uVaouRkx8DRlOsTYnDQ/suDsvsZaxljGVphcuSZVtkC5cMyZxrksGj2SrbkwOv07kbkzOv84XTTjPyNPhTQkNEK5Ozi8Oh9G/TW4EDi5QUHPOoV0DLlGTWoIJ1V40lU6EVj6RRi5UDXQP206Ubg4O0r5xblYU+a5WjTgBKa5XUQmOHU1hkLCuWJHWFarcHO5Zy7uuWkQCblrU+Y/7kKrAnW5cDUuM2BSRjIDRgk++DZCTyi5eTIuXRREmMbJPt8iGDy8RSU28dVUuYVBnId5uYk9ykMquYw937mOMhu5kDa7uZI1w7mU3r1B/9ZtuZlHnzVpAbICNU1q6oG5oUQmuaNJnbmlAahogrmpPzFAZXSFNZOhNT4LNee5h0PtNblTZA8jOdFHSjmoRdRHDEPgNAxPWT9iN4u5wHfzucJOuQWSucVuNj9kQ7k2IE01ngC5zTgkNNRfuRC+WpvTFrnVRW45xrnYXrW520TCNx+53lYvSCUBJjlgQFk6/YLcXQc1FndKT66sobnsR8NISkHEufD52mmpPvVKvDz/ufZEq6t2ufoQD7n8Mh1nlD7xlPQ0CDwFugNVGHSFVE41IlpEIQpfkroLQk66DVp2P+K6EDSUQiq6E0GUhdcya7oXXA4GiktyBhVIEjvOYs0VDLogAw9CQbojTJCykE0ZTVA/BLopMx3HYjdHPhk/3zzZVAQ/QroyRE82YUEjD+894jI8Xqa6OkU0ROa6PTJyuj9rCrpCRr9AZTp0Ow4CdbpIP/c82bpLOEEzPUxHuk+f7LpSN7tO6za5OOKfsjVpTWRRuLKDul0GPj+SD7bN97pjMAI9iU1kumduWTWAWm55wDNDOrAzxTk682S6ckcMSi48B8dGunjOz7p7NPp3gbp+QZW6gDXxW3u6g0w4OU43Yj/RN0sFHAF2B79QgDeQBIlcKVQAupFZuLqUOXq6luJZupk/Jl+hNw48tUdOS5g6VEYouqIHMrqk9se6p0GAuqkGALqrUKy6rnEdPby6scyMurRFVjqkE026uAEaCXG6uwcRur1t/rrASdVm32YTusUFkpufWAJBagRbOtNtaECdNZk76brQQlk3PFmLutU0BLrXOhFJkVRhNuEQh0DDut5K7j2GuuFEowfFuuRm+LrmATQ3NLrpRwxAdKBOO9Az1F7TuvBCxFGvNoxgt7r2qRi6+W3wRKs87DwoPpMy1zNcNaM/N7sENwx+P7sIAQgyYGuXTHU1d7sONY8R7bsRN4IUnFBjPMm8nbsYOf+7Guo0ux1QNzjEWuIBTDiTQQs1MAepMmj8dz3UONK7K6iDuy4y2D3tRuNWzbszBfs6sTb/S7G7OEJdffO7PMcDuz9M1EQhD9I4vzkzV5i7R0OyRMJB9jj9TCs4eLAEu1AWyrtSPMhFClBBA3k2VUbRU9k4SLtbMcqrzLtfQf9fqxBku2NIaLtlhzC7aEruNy9MkEzWu202IrtvSwoCKLtyYwkwnT4Lyqa7eAcBu3qyF2I2A3Q0OkOoNkaJPLuDTRVobjc+Q1ZfAzmEUow9EzoVRclHpAFySVVaOUrnu5N41buWQu67mT2jPPoBSUc8edO7oDY0MotfVbukMzqsIW7BCYg91jmoNpE9yjIGRRxFyTXKNJE5O7uztXq7tjqZN60EshBkaHQ3Zj4oQcLe87vBAiXiFbvFtA+aNbvJt467zF7TMos8OTcoSTq701GUBjc7j5pMUxc2f7vah0qq+7veDsA2FjXcATQ+sLvkYqo7zjS2P/u76Xsqu+s1HHXQRhm78FUASlyHErv1T1EHxLv4m5K7+zMQN4tsdTakU8y8ATTmvATy8Tq4Dy+8CFpwQXw6wX7PYaJDWPEXvBE8NjoYM7FxHTvIXChWFlXatk08XzTbNko1yUsuLSIzTH8xvCQ68qd0vCgHAzvbvCszEzbDOb1Hl7wweOJGKDDWPvMzJrw2Bm1jm16rvDpHdUmRN6EysDf5V+S8QjnGMto6FXU9vEhGKrxKSK68TAWEeHI2YRcuMoe8UkNCPI/oFzIkdzRFALxaVL5m1zJWSkY3djwVvGE2dTI3SeE2rDnNvGg1pkJtQf+8bDnbMmMyHD4cM9FOalAcvHQzGLx2DXMzLTgG/aW8fEewvH88vDunvIJgIj5/S5gHcXnUO2BhhTfoSVO8jDIDWvlDYryQYcJ0rwcpvJQzWJX3ePzYFNgTvJo39lZ+PlMF9byfQXSDMEJBsLAGlAdqX6tFCss4Nrqj5bysQqhaRDifPwR2cDQPD48CDTVOvLY0x4CRNDwByTxHaZQ0TTexQPU4scZP1/jGT6NpvMU1zTpvvSK8yjHEXCmUzP//dwe80b1qvNQyakFjRbJAHr0dvNsx8jmObOm84Le4Ue9HZY9zvOYBi1t7kwK86ziGeO687zdzvPEx2EKoecS89hAIOQO8+aBZMg87QlJ+tpm9AEFL4y5E7UgLNf08F7xBvQlX1T3BOfqvwr0PvVe9Ejau0sIyNTV0OoO9GFlovRpAE70cMc4GyQV6P+a8yL0jLu44SL0mT2pFY0HGUQw1lL12vS4PlOD3vTKbfr01ObI3ZzHiRBQBXb07EXM5C70+U+a9QFGvAkVEA71FTak3Ff1xNck6TUJZTfi9TgTuTCwMhETROjZAE71VvRC9WL0TvVvp6b1eMxFvKr1hPuO9YzObvWUwLk7gOu5EGbzTS1EBqL1tNwhBqAYHOePtiTkdNBY2J2SJQOtCWb3BNMo3Z718mbi9f2HVSZw3jTMyY4BPNz+tvYdNGTmjMlU9+T9CNMi9jkenSktGxr2SROG9lAIw+5W9mDMnSZG9mzHfvZ0yV08kRb44bDhovaNAzIowrEC9qFlIrLY8BUDtNmG9rkPCNeQ9DUUJNEA4gUtEvbZFYEMZAXYzBr27QmBfqzQBYOAH0TQ9vcNK+b3GNqlkiT0kPmpLFD4mM6EyajWjNR0C4L3S2Aa+U5jQvddJkLJfh1o3G06nM7A1VTkHBH5l/73jPHqYrr3nSY893r3qk8+97TThve9J4VKhvfM3br312AXX/dgJ2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAr5gAFq+YgEFvmQDWyXnLRUqacJfxNECDTEMDgQd575wwz4d5BVZwl/E0S/Tvne/F8NIxK4Zn758vnvDUcSTvoLDVMByw1bAdSaTwHfB3iDSwdARUsHSEJTB1CWAK8UdyytZwdgEGMB1JpPAdwSCwiTB4BUWweYNksHmvsEatcHpwgPD2sR9vsnB8AwqvszB88Hqwg2+0SwRvtPD/L7WJ6jB4cH8wf/B/ifAwgAig8ICwRvD2sR9vsnB8AwqvszB88IMKrzCDiwRvtPD/MISKdsVFsIZvu8wLgRZvt3CUxsmwa6+4sB0vuQmk8B3AovCI8SKwiUUXMIVMC4pWgEkwignKhcmwi2+9QFIvvcV6cPZBh3Efb7+MC4m5Cu/LJe+sCuVvvMwLiZAJNoKBg1/DKvD+b7jwdojEb8TGLG/FcP4LFvDPyxlw0EugycEKLUW6sNGvxfDSALcw04E4sNQEFHDTgTiw1DEsr6TwcjAcsNWwHUmk8B3wd4g0iJ6w0nAfsQMwTwvqsNlwH4nKhcmwIgIQ8Oew2wJv8CPw3AAIMOXwJTDdQj3w3cODcCcw3vAn8N+wKIwRQlwQU7DgwPBw4XAqi+pAiUTksOKBs8HVMCxagXDjwAgwLUujcC3CdM/xcC6w5bDcsOYwNfAwQBtw5wIQ8Oew2wE08Ohw3DAzcOkBMHDpjBgwNPA1cOswMDEERctK6vA3cOzCqTA4cO2BRDDuAZBw7oJK8DqBvHBBcPBwjMSgMR9wR8NnCfMw8jBI8PKG4LA+RZ8wPvA/cPQBvzD578BwOnDvcEEL3DD6sPZBh3EfcEfDZzD3xdWvwUo2ifDK6LBEAYaw+YB1MPTwOrD6sEFMbUB8cPZBh3EfcEfDZwnzMPIwSPDyhuCwPkBpsJDw/vEMCfvw/++dMPEwTG4KQwBwTS+1gEkwTbECAyrwTke7sNgwTzED8E/xBPBQi8wwUUYKMQaIR8utR2rKXIqXC3ZJ2gUUMQjASLBUi9JwVQDwcQRAr3EKw+KIkksmSgwLJ3EMcFhHLEF6Qa9DyMwE8Q2vnDDPifwLLzEOxELxD0W/MQ/wX0JD8FzxEDEScRGxEDESSxsxEPETMF6xE4foTELwYML7i0tL5/EVjEoD0gU7CpKMRcvnxElJmwBAMRiGwHBSsRmL58Ci8GdxGouHsRsvtfBo8RvDmTEchZoxHTBqgW9xHfEk76Cw1TAciOIwl/E0VXXFTUD7AIHwiDAdzFIvzfEiAKlwiTCShjmxJENksSRwlMbJsS0vyYGMcShMYwxbjFjMO8xcyvLLLEOab59xKIxbjGXMO8xc77xvzcxeBMTwiTCSr56KW8QUcTZwlMbJsS0vyYGMcShxL8xjsR/MO/EvMGxxLcxlcTAMXAw7yqdAU/ExDGdwoK/YQjGMaPEy8GYwpUxqsTQDmoxrwKfxNUxtMTYGL8xuQA0MbuVS8TgMcMxxW9eMqcywTHPxOcx0sTqMdUx1zHZVuHE8DLYxPIBEDHlxPUx6zHtMe/E+jgxxPwxxMT+Mfsx/cUCi17FBTIHMgkyCzINMg8yETITxQ7S09CSMhvy8DIfjLRGIzIlxRcyKg+TxRoyLzOOxR1pwMUfawbFITI9Mj8yQTJDyekySMUpMk0yT8YcMlPdpTJXMlnFMjJdhmLFNjKRMmQyJcU6vNVJ5sU+sjnFRMVExUTFRMVExUTFRMVEP2ozkTKKMowBnMVOMpIylBCRNDbFU8XKMqRBS8XOMqHF0TN9xeLFXDOCxV8zhcViM4kykMVlMr7F3jHKxWoyxsVtMk3FbzLMxXIy0TLTMtUy18V3Mtwy3kCgTO0y4/GVxX8y60ZHxYIzvsWFMvbFiDL6OgjFizMACVUzAsWPMwfFkjMMxZUzEjMUN1XFmTMaMxwzHjc6xZ4zIzMlxaJ48DMsMy7Fp1LPxalNXMWrMzozPDM+M0B6LcWybZ/FtTNNM09uYzNSM1Q8p8W8M1o77sW/M2AzYjNkV2DGO8XHNC3FyjN1M3kzecTlxVnFW8XUM4LFXzOFMkkziDK5xdsxzTOMM45DSjOQM5LF4TKpVk3F5ND3M5tfxcXoM6DF6zOlxe4zqDOqxfIzr4lhxfYztsX5M7vFgjO+M8AGbcYAM8Uzx3v9M8vGBgdRxggzCsYKT0zGDDPZM9sPI8YQM+Ez4zPlM+fGFTPrM+0z78YaM/Mz9cYeM/o4XcYhNcbGIzQDxiY0CTQLxik0EMYsM6jGLjQYxjE0HMY0NCHGNzyPxjk0KcXGxj3FyDQuNDDGQs0yNDYQkcZGNDq8wjRGxkzX+MZP1/jGT9f4xk/X+MZP1/jGT9f4xk/X+MZPNFHGXGrhxl9+LMZiNJY0mDSajsM0n8ZpNKM0pTSnxm40qnPKNK4+gsZ0NLbGdjS6xng0vcZ6NMDGfDTFxn6Mx8aANM/GgzTTxoY012L9NNs03Q/0xow04zNUxo8/0MaRlTXwH8aWNPU091eBNPoBL8acNP41ADUCxqE1BsakNQrGpzUPNRE1EzUVNRfHHjUaxrA1H8azNSTGtgE8NSk2Qsa6OoXGvDU0NTY1OJIPNTzGwkNENUPGxlg9xsieJ8bLiryDHtwaxs81XcbRNWLG1DVmNWg1asbZNW41cEWAxt1Y1cbgNXukfUBHxuU1hTWHxuk1jDWONZDG7jWWNZg1mjWcNZ7G9TWhxvg1pjWoxvw2K8b+NbHHADW1Nbc1uTW7vHo1wDXCxwk1xscLPYDHDUW1xxA11ccTNdg12jXcNd5VcccZNeQ15scdNevHIDXwNfLHJDX3xyc1+jX8Nf7HKzYDxy1cSccwNg7HMzYSNhTHNwUDxzk2HUPJxzw2IzYlNic2KTWsx0M2MMdGNjXHSTY6NjzHTTZAx082RcdRPKfHUz7Ex1U2UkkNt/E2VzZZx1w2XcdfNmLHYTZnx2RPgjZvx2g2czZ1MpPHbJLLNnzHcEekx3I2hHDMx3U2iQF4x3gwFcd6NpNes8d+NprHgS+ax4M2oTajNqXHiMjbNqs2rTavNrE2swXJx5A2uMeTNr1PbceWRhPHmYTjx5w2zjbQx6A21cejMrLHpQSJx6c248epNubHqzbqNuw27sewNvI29MezNvfHtVRDNv0J7Me5NwI1tMe8NwfHv4zTx8I3E16ux8Y3GsfJOX322sfNNyg3KsfQNy/H0zcyNzTH1j0dx9iJxsfb//43RTWxx9/RADdNx+M1VcflN1TH5zdYx+o3XE81x+3ktsfwN2XH8zdpN2vH92RHThTH+jd4x/03e8gAN4A3gjeEEAjIBTYVs/nICDePN5FL8cgMN5UBsMgPAQQ3nFlCN583oYkHN6VGi8gXN6zIGjeyyB03tje4yCE3vDe+NVbIJTfCyChPazfJVjDILEBoyC430cgwVifIMkwZPa4248g2N+HIOTfnN+n85Mg+N/HIQTf1NEV52kauyEY3/chJOADITFVjyE44CchQOA3IU5DHOBPIV1n5yFk4GzL/yFw4IMhfOCVIEzgpOCvIZdq8ODLIaDg2ODg+lchsOD04P8hwl7E4ROXaQ2rIdThLyHg4Tsh7dsmPr8h/BkE4WThbS2PIhDhgyIeRPzQIyIqNgjhrOG3Ij5KU45nIkzh4O/3Iljh9Ph04gMibTenInTOwyJ88DsihOJE4kzquyKU4l8inRM7IqjigyK04pP7bq1TIsjityLU4sUuYyLg4tTM5yLsCnMi9PT7Iv1hxOMRrEDjIyMQ4zDjOyMg40zj6yMs42DTNyM443cjROOLI0zjmM5vI1jjrOO3I2jjwyN0+CDj1OPdT5jW9yOM4/sjmOQLI6YeXpjfI7TkPyPA5E1puyPPg+sj1OwjI9zkdyPk5Icj8OSU5J8j/QWnJAju3yQTQs8kHMkrJCTLhyQs5QjBTOUXJEPatOUtAVskURSXJFjlVPD/JGTlaOVw5XjlgOWI5ZAGcOWcJXzlqOWw5bjlwySg5dLzNOXg4+8ktAtTJLzmBOm7JMjmGyTU5ijmMyTk5kTmTyT05lzmZOZs5nTmfyUM5owdSyUY5p8lJO4/JSzmvyU3srTm1yVHuOzm6Obw5vslXOcEPvMlaOcXJXTnKOczJYTnPNtHJZDnUR8zTVDnZyWmNU0enOeHJbkYoyXDdvDnqUMXJdDnvyXc58jZeOfU598l9c5s5/MmBOgE6A1YwyYY9TsmIOgvJijoQOhI6FDoWyZCsTTi+yZOzJjcRyZZDQMmYOinJm3wcNAg6L8mfOjM6NTo3cFM6O8mnOj/JqjpCya06RsmwOks6TT81ybQ6UTcCybdzrsm6OlrJvUnqyb86Ywv2ycI6aMnFOmzJyESryco6czp1yc46eTp7ydI6fjqAOoLJ1zqHNYE6isncOo49ucnfOpJCFsniOHg6l8nmOps8ccnpOp9CccnsswA6pjqoXlbJ8TqsyfQ6sDqyOrTJ+Tq5yfw6vcn/OsDKAjrEOsY6yDXOygc6zTSiygo60soNOteBg8oRQdTKEzlTyhU65DrmOuhKn8oaOu0678oeOvI69EMzyiI6+Dr6MdrKJjr/yig7AzSSyis7BzsJOwszAMownJDKMjVZyjQ7Fso3a53KOdmh3dDKPAjuOyQOVspAOynKQzssykY0yspIOzPKSzs2OzjKT8i2Oz3KUztBylY7RTtHylkHKcpbPfPKXTtRO1PKYTtWymM7W8pmO187YTtjymtW3MptL2DKbwNzynEP4spzO3M7dTt3QnM6W8p5O30Bhcp8O4HKfzuEQKrKgkHkyoQ7jWnHVZM7lDuWEerKizubOTU7nsqQOgLKkjl/ypQ7q8qXO68/D8qad4rKnDu3OZ3Kn4NAO747wDvCQLM7xjORO8k7y8qqO9DKrDY3yq472D3gO9rKslSByrSddjvjyrg75sq7R5fKvTvvNUDKwHzsO/VVSMrEOa/Kxjv9O/88ATIUystJJjwIP5I8C8rRPA/K1DwUytY+nMrY7yNAucrbjRJIkMrePCc8KUWWyuIzzsrkPDHK5wIvyukBLsrrVWg8PcrvtM08Q8rzPEj4KDxMTbfK+EBlyvo8Bcr8jY7K/jxcywE8Xz2hywQ8ZMsHmwE8ajxsPG7LDTbiyw88d8sSPHw8fkZLyxY8hMsZknw8imI/yx42IssgNXDLIjyXNAfLJTycyyg8oMsrPKM2ossuPKcxw8sxAX7LMzyuECM8scs4PLV4+Ty5yz1VbTy/y0E8wvbGPMbLRjzKy0lJ+ctLOPrLTTzUy1A82MtTNCjLVUjcy1cCL8tZPOjLXDX6y1488MthPPM1hT+9y2U8+Tz7PP1HVctqPQI9BKrOc9yGij0Ky3JbND5qy3Y9Est5PRbLfD0ay389HT/xy4JbysuE6SQ9JsuIOQTLij0vy409MsuQPTXLkz05UZvLlj0+O2XLmUUky5s9Rz4fy55EwsugPU49UMukPVTLpz1Xy6o9W8utPV/LsD1jy7MyNcu1PWnLtz1sSuPLuj1wOh1Jkcu+PXXLwWr/PXrLxT1+RSbLyAily8ox2MvM9PU9ycvPPY/L0ZaGy9Q9mD2aNnDL2JY1glzL3D2mMcLL3z2qQiPL4j2uy+U9sku3y+ht5z24PbrL7T2+y/BYlj3Dy/Q9xsv3Pco9zD3Oy/w90T4Ey/891j3YzANGS8wFPeB/Pj3kVXXMCjNXzAxB+cwOPe/MET3zEe3MFD34PfoyHcwYAX7MGj4CzB2Gtj4HzCE+Cz4NzCVU0z4SzClhDswrPhg+GjlqzC8+H5j0RfTMMz4nPinMNz4szDkzGsw7ODHMPQq/zD8+OsxCOpLMRD5AzEc+RcxKPkjMTYpRPk/MUT5TWCs+VsxWPlnMWUSkMIc+X8xenoE+ZUKhzGI+aT5rzGZLf8xoPnHMaz51zG66cT56S5XMcj5/zHQ+g8x3OdfMeXeK0bJF14lCPpA+ksyBUddFxz6azIZMaMlrPqDMij6lzI0+qWh+OpHMkT6wOvLMlP8oPrfMmD66zJsxxsydPsED2j7EMxzMokxBzKQ+zEs9zKg+00pGzKs+2MyuPts+3T3kzLI+4sy1PuYzJD7pzY8+7cy8MgbMvmqXPveOEj77zMQ+/szHPwI/BDS0zMw/CMzOPwvM0UMCzNM/EszWse024P6uPxrM3D8ezN8/IsziPyZbCz8pPyv8Xz8vzOtWTT8zzO4/N8zxPzpt0sz0QgbM9j9CSR/M+T9GzPw/STaYzP8/Tc0CP1HNBT9UzQgEms0KP1vNDT9eARQ/YDIUzRJFDT9nNsnNFz9rNx3NGj9wzR0y8j9zL38/dTP5zSE/eTLyP3vNJT9/OivNKPe5zStCMs0tAX3NLzCTzTE/k800P5fNNz+azTo/ntqcP6LNPz+mP6jNQ14SzUU/sM1IP7TNS7J9zU4/vVTHzVE/wkk9zVQ/x81WUl3NWD/OzVtCxT/Ur0s5Vj/ZPwTNYj/dP9/NZQN+P+PNaT/oQiJ6eD/tzW8/8s1yP/XNdD/5zXYz4M14NcDNekAEQAbNfuHgQAvNgjzDzYRAEs2HQBbTVD5DQBrNjkAdzZFSukAkzZU8/82XBnTNmUAtP4nNnEAxzZ9ANM2iQDg4UM2lQDzNqBBkzapAQm7qNt/NrkBIzbBATM2zQmDNtUBUO6nNuEBaQqjNu0BgPsTNvkBkzcFAac3EQGzNx0BwzcpAdEKhzc1Aec3QzdhAfvh5zdRAg0CFM53N2ECJNiLN20XJzd1AkUCTzeFAls3kPFJAm83oQJ/N60Cjze5AqM3xt7pArs31QLHN90uVzflAdkJdQLpAvM3+QMBskmG4QMXOBK79U52uzc4JQNPODEDWOcfOD0DbzhJA3kgHzhVA4s4YQOZrzM4bQOrOHjzlziBA8c4jQPRA9kO/zicDTs4pPz/OK0EBzi7NFTl6zjFBCU9azjVBEM44Mw/OOkEYzj1BG85AN9jOQkEizkVBJjIlzkhBKs5LQS3OTUEwzlBBM3SyQTbOVUE6zlhBPc5bNUXOXUFDQUXOYjzlzmQO0kFPzmgyhzmOQVaMpkFZzm5BXVQ3znFBYc50QWXOd0FoOSzOekFszn1Bb85/QXJNLs6CQXcvf8lpzoY0o86IQYHOi0GFNsbOjkGJzpEyvM6TQY9BkfHSzplBl0GZWnZSss6fQaDOolVDQaXOpkGoQapBrM6rQa9Bsc6vQbTOskG3zrVBu0VezrhBv2umOX/OvItKD/XOv0HKP5hBzc7EQdHOxy0izsk5WEHazsz2rUHfztBB4kHkOCXO1EHoztZB7Dc6BEjO2kHxOoHO3UH1zuBB+s7jPILO5UIBzuhCBc7rQglDQ87uQg08Ds7xQhJEbE8/zvUGdM73QhtCHWmUzvs+lc79V0dCJ88BQiswLkIuzwZCMUIzjT9CNjq8zwxCO88POVfPEUJBzxNCRM8WBLrPGEJKzxs6Ic8dQlFNZM8gQlXPI0JYQlpRz88nOGLPKTfvzytCZc8uSK7PMEJrzzNYPc81PbzPN0J2zzpCekJ8zz5Cf2Vsz0FChM9ETm1CikjiOkTPSUKQR87PTG6Kz05ClwEPz1GBB89UQp/PV5syz1pCqc9dQq3PX0KxNavPYjqaz2RCuDiLz2czJM9pSbnPbImKQUw2nc9wQsrPc0LNz3ZC0M95QtPPfELXPOlrhc+BQt4zPM+EQuLPh0LmNJxSA8+LN0mTUkLuN+JC8c+SS4nPlEL4TzBC+0L9OZ3PmkMBQwPPnkMGz6FDCs+kvO5DEEb9X5LPqUMWPOLPrEMbhEPgWUMgz7JDI8+1NbjPt3Y7NRzPukMvz705Ts+/QzbPwkM7z8VDP8/IQ0TPy0NHz85UhM/QQ041gs/UQ1LP10NVz9rQJkNbz95DXkO8z+FDYkoSz+ReWkNoz+i2+ENuz+yyOUNzz/BDds/zVdNDfM/3Q4DP+kODz/1Dhjih0AA4F9ACQ420FtAGQ5JDlED2Q5dDmdANQ5zQEDyT0BJ8Z0Ol0BZDqEOq0BpnfNAcQ7DQH0O0OeNDt9Akn7LQJkO+0ClDwzJO0CxDx9AvQ8vQMTtJMz5D0jmjQ9U0Dj4Q0DlD21tEVUjQPZqYQ+PQQUAZ0END6kPs0EdD8T/m0EpD9dBNQ/hIhklP0FJD/9BVNiXSbUQGNpvQWkQK0F1EDtBgRBFBAkQUOhnQZUQY0Ghe09BqMv3QbAEQ0G46m9BwOgbQcpu90HVEMXFB0HlENTWx0HwF1dB+iHJEP0RB0INERdCGREjQiURL0IxmjFWc0I9EUtCSRFXQlbPTRFvQmURe0JxEYdCfBd7QoURnARNEadCmRm/QqERx7hxLWdCsbyrQrkR60LGtq4JXRII/4j5Y0LhAaNC6RIrQvUSNRm7QwESS0MNEldDGRJhEmkK40MpUFkSh0M5EpdDRRKjQ1ESs0NdEr9DaRLLo9fnkPX7Q397URLvQ40S+QGXQ5pktRMU7WkTH0OtEykTM0O9Ez9DyRNPQ9UTW0PhKy9D6RN0QK9D9cW9E5NEBOM/RA0Tq0QZE7kTw0QpE9NENRPcBcWSMRPvRE0T+RQCOaEUDWclFB0Y7RQrRHEUO0R9FEdEiRRXRJUUY0SgMqUUc0SuF7EUh0S9FJUUnaGbRM0Us0TZFL3ZqRTIEQUU00TxFN0U5RTvRQT8/0UM1UtFFNwrRRzqw0UlFSjN20UxFTkVQ0VBFVNFTF6LRVXY7RV3RWTVNprjRXEVm0V8EftFhRW3RZEVx0WdFddFqRXjRbUV70XBFftFzO6TRdTZB0XdFhzbb0Xo4c9F8RY8RBz0s0YAy3QSV0YN3StGFRZwy4dGIRaE2eNGLRaXRjj4U0ZBFrdGTRbDRlkW00ZlFuNGcRbs10tGfQLrRoUXC0aRFxdGnzIU9pDwF0aw+ldGudGbRsUXWPo1F2QgnMunRt0Xe0bpF4dG9ReTRwAcRReg3QdHDRe3RxkXwOy/RyUX20cwzYtHORfxF/kYA0dNGA9HWRgfR2QHq0dtGDdHeRhBU9dHhRhTR5EAE0eZGGjOh0elGHtHsRiLR70Yl0fJGKkYs0fZBVdH4U2nR+tYcRjgy1tH+M7LSAEY/0gNGQ9IGRkZGSNIKRktGTdIORlDSEUZTRlVGV0ZZPtFGXDZ4Rl/SG0ZiA8TSHkZmRmjSImnFRmzSJkZw0ilGc9IsTLfSLkZ50jFGfC+D0jRGgDaY0jdGhNI6Rogwn9I9EerSP0aQhb/SQ0aV0kZGmDmt0klGnNJMRp/ST0ai0lJGpYLcuUtGqdJYOwjSWk0u0lxGsdJfRrTSYjpE0mRGudJnRrw2Q2nA0ms2htJtRsXScOvPRsvSdEbO0ndG0UbTAiXSe0bX0n5G2tKBRt5cAEbh0oZG5tKJRunSjEbt0o9G8NKSRvMBhNKWRvdG+dKaRvzSnUt90p9HA9KiXkRHCBAGRwo3ydKnRw/SqmqT0qxHFdKv38ZHGjmc0rNHH0Yr0rZHI9K5Z33Su0cp0r4y6tLAUnLSwkcyQZ3SxYuyRzjSyUc8NFHSzIVI0s5HQ9LRNubS00dJ0tZFstLYR1GUvEdU0t1HWDS50uA10NLiR2DS5Udk0uhHZ9LrR2pW2zSj0u9HcNLyR3RHdtL2R3o5M9L5R35BsNL8MevS/q8DvgzTAUeQ0wQBr9MGR5dHmTPw0wtHntMOMf/TEBC50xJHqbHoOIvTFkev0xlHsj6Q0xxHttMfAVXTIUe80yT4udMnYOJHxzM20ys7qdMtR83TMEfRBXrTM1K70zVH2NM4R9s6FYOV9QpH4Tm40z9H5dNCR+jTRTjL00dH7kBI00uSfUfzOVXTT0f31ehbL9NTyWhBetNXTJAPBtNaSARIBtNfSArTYkgOWwc1pEgRSBPTaEgXN9jTa0gb025IHmDiSCHTc2By03VIKtQ/SCzTekgv031IMtOASDXTg0Tt04UQCNOHNwnTiUhCSETTjUhH05BISq0bSE1AgDaYSFDTl6gcSFXTm0hY055IW0FW06FIX0VDRy7TpUhkTDc4kNOpRajTq0hs065Ibwlb07FIc9O0SHbTt0h7UQ3Tukh/ZzFIgkkfQCPTwEiH08NIijqa08ZIj9PJSJPTzEiWnRJImUib09JIn0ih09dIpdPaSKnT3Eis099Ir9PiS/HT5Ei10+eTgki70+tIv9PuSMLT8UjF0/Sa+tP3SMzT+kjP0/1YPdP/SNbUAkja1AX7iUjfQ/3UCUjj1AxI5lYW1A9I6jm4OoPUE0jw1BY5/jQ01BlxEUj51B1I/DSs1CBJANQjSQM8DtQmSQfUKUqd1CtJDQEo1C5JEUkT1DJJFkkY1DYNO9Q4SR5JINQ8SSPUPzwG1EFJKjUs1ERCnNRGSTFJcdRJSTXUTDmiAUvUT0k9NW7UUp+y1FRJRNRXSUfUWjzP1FxJTdRfSVHUYoYVhdDUZUla1GhJXdRrSWAy/UHa1G9JZdRySWhJatR2SW3UeUlw1Hxj9kl21IBJejk01INJftSGSYFJg9SKaBrUjEmK1I8zI9SRSZE859SUqYvXrEmYQARJm0mdBprUnFLwSaM3DHi01KFJqThI1KRLmNSmSbHUqUm0Pa/UrUBI1K9Ju9SySb/UtUnCQF/UuEnG1LpJydS9Sc3UwEnROQfUw0nW1MbrDEAp1MlJ39TMVDvUzknl1NE4t9TTNgPU1Tc/1NeRAknz1NtJ99TeSfs12dThSf/U5EoC1OdKBVRUMzfU60oKM0BKDdTwShDU81Ak1PU3rdT3NafU+Uoc1PwGitT+Sh7VAEol1QNKKNUGSis0BkouOrjVCkoyfGJKNdUPSjg2uRDLSjzVFfVQSkHVGUpE1RxKR9UfP9HVIUpP1SRKUtUnSlXVKkpZ1S1KXNUvSl9KYdUzSmRA7dU2SmjVOUpr1TxKbtU/NN3VQUp01UQ3JNVGSnrVSWgMSn85/9VNSoM+N9VQSoc5IlVj1VRKjNVXSo/VWkqSNgNWq9VeSpfVYUqb1WRMK9VmSqJiGNVpSqZ/JUqpY6HVbkquAUtpP9VySrPVdUq2qslKuluPOW/Ve0rA1X1Kw9WASsbVgz/5OhnVhlUK1YhKzzdb1YtK1NWOStiR3UrbO6XVk0rg1ZZK5Erm1ZpK6tWdSu3VoErx99ZK9FWCSvfVp0r61apK/T/w1a1LAtWwSwXVs0sIR2lLCze91bhLD0QmPUbVvF6oSxbVwIJkSxvVw0sf1cZLItXJVmHVy5YtSypYGtXPSy9T5mYp6Y1LNdXWsT7V2Ubq1ds5HUtA1d5LRGg41eE1BNXjS0xUTuGwtdHV6UtVUzTtQEta1e8QK9XxSnzV80tlR9FLaDc51fnbQVPD1fxLcUtzVXXWAEt41gNLe9YGAcDWCEuCOMbWC0uGD7bWDkuL4OFLjtYTS5HWFkuUS5ZmB4ZAS5vWHVK71h9LoTOoEk/WI0un1iZLqkus1ipLr9YtS7PWMNEoS7nWNEu81jdLvz/k1jrspkvE1j431NZAS8rWQ0vO1kYx/9ZINIfWSjUT1kwzuNZORZjWUEvf1lNL4tZWS+XWWcb1S+nWXUvs1mBL79ZjS/PWZkv3NJdMg9ZqS/zWbUv/1nBMAtZzM/3WdUwJ1nhURtZ6TBA00NZ9TBQBKNaAQnHWgkwb1oU5ctaHTCE0/z4m1otMJtaOTCnWkT6j1pNMMEBC1pZMNNaZTDdMOdadfNhMPjiaeGw8o9ajTEXWpkxJ1qlMTDXsS4jWrUxR1rBafNayTFjWtUxcZchMXzRHTGEHxT3g1r3Mhkxo1sBMa9bDM/zWxUxx1shMdNbLTdbWzUx71tBMfkkN1tNMgtbWTIbW2VSoTIvW3UyO1uBMktbjTJVI99bmTJpl0NbpTJ5MoD9OEYvW7kyl1vFMqdb0TKwx4db3YkTW+UyzNphMtTIk1v5MutcBjM9Mv9cFTMM7atcITMjXC0zLOVdMztcQTNLXE0zWO2HXFgfR1xhM3dcbTODcfUzj1yBRGUznRWfXJD/UO7LXJ0zvTPHXKzeD1y1M99cwTPrXM0z91zZNANc5TQTXO00HB0zXPk0L10FND9dETRJDQE0U10hNGNdLTRzXTk0gjFPXUU0k11T5XU0pOWPXWU0t11xNMddfTTTXYk0412VNPD0r12hNQNdrTUPXbk1Gq+NyA01L13RNTmLcTVLXeU1V13xNWTcl+Y5Ap9eBTWDXhDTl14ZNZw/i14nfpE1t141NcNeQTXPXk013AlXXllXa15hNftebBd5NgteeTYVNh9eiXilNjNel1/2vVteoTZvXq02e166u3U2j17JNpte1TanXt02s17pNr9e9TbI3YTM518F4w9fDTbs2hNfON27XyE4L1+nXzNfXTkLX0DIU19JN0ITy19XX2U36TclN+u/RTd3X4Nf21+HeaU2S1+xN9NfnR4vX6ZOKTi/X7E30rDpN99fxTfo0Ztf0TgzX9tfh1/iCok5D1/vYAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tLouSTX+MZP1/jGT9f4xk/X+E5NTmDYGT692BtOZwq/Ts/YH3hT2CFOcU6ZTnQ4nNgmTnjYKdq4Tn1y4E6A2EDZKU6G2iJOoU+o2DZOj9g5TpJWEdJhTpbYP06ZUCrYQjhd2ERO89hHTqZOqNhMOv/YTk6u2FFPYNhTTrbYZ9hYTrxRYdhbTsDYXjK42GBOxU9mTx1Oyk7M2GdOz05rjjxO0+5dTtYymdhuTtoGXFAT2PLYdDaU2IbYmNh5TurYfE7u2H9O8tiCTpVO99iGTvpP7U7+2ItPAYlPTwTYkNhi2JNPC9iW2HcN6tiZTxLYnE8VMrjYj08Z2GJPHTyj2KRPMdjQ2KhPKDjk2KtPLdiuTzHY0NiyvYUxP9i1T2ebpdi6QF3YvE9G8807tdjAOL/Ywk9PT1Ey3djGVJ/YyE9XOKdPWtjNT17Y0E9hXWLY0wRb2NXqRtjXT2rY2U9u2NxAINjeDKnY4E942OPY/4qy2OdDVtjpY4dPhU+dT4nY7wWc2PFPj9kCT5LY9tkGT5gBRzX82PtPnU+JPBVPfGZW2QFPpdkEO8PY90+rNNA1QNkKNeTZDEHk2Q5Pt7GJT7rZE0ef2RVPwNkYT8TZGy+W2R1Py0/NENGUStkjBe1P09kmT9bYME/Z9J1P3EFMT9/ZMGHfT+PZM0+QT+nZN0762TlP7wRckrzZPU/0UYrZQE/WTnSzlk/72UbZIU8PNT5HwtlLUATZTjQ02VBQC2ZWTt9QDtlVUBFQE08WRDvZWlAY2V1QG1Ad2WFQINlk2LFQJAaa2WfYl9kjUCzZbPQxUDHZcHAffnxQOdl1QcLZdzy12XlQQVt42X1QRtmAifdQStmEUE3Zr0wM2YhImtmKzjEBnNmNNDFQWpkuUF3ZklBgRSZQVUM02a/ZmVq32ZsFN9mdUG/ZoFBy2aNRPtmlRC04YjoO2a/ZmVB/2a1Qg1DQRq/Hh1CI2bRQiwcB2bdQkNm6UJPZvVCW2cBQmUPR2cNQndnGTtbZyFCk2ctQp9nnleFQqwJNCNzZ0lCwUL9QwdnqULbZ2lC5MdbZ3ZoLUL9QwdniUMTZ5dnNleFQzAUD2exQ0NnvToDZ8lDXUFDZ9gGi2fg06tn6OMrZ/FDj2f8BPNoBUOraBDTI2gZQcG5jUPNVV9oLUPfaDlD62hFQ/draUQHaFlEERCEtItoaNBJRC9oeYhjaIDNd2iJRFVFU2iVRGtpnUR0jY1Es2ixRg5I52i/aTFFs2k5RpVFJ2jbaRVF02mnaSVFo2j5RQtoy2lxRpVFg2mbaYNpH2lbaa9pLUULaMtpcUaVRYNpm2mDaR9pW2mvaS1FC2jLaXFGlUWDaZtpg2kehMVF52oVRfdpU2mnaSVFo2j7ablGl2nBRbFFFUY04G9p0OY7adlGV5nZRmFGtnGfafVGe2oBRoWIIUaTahUuU2odRqtqKUa5RsEBSUbLaj1G1D2LakjhdBKvalYvVUb/amVHCRbfanFHGRGzan0aI2qFRzdqkVzPapjSL2qhR1tqrUdnarsokUd7aslOS2rRR5DZE2rdR6Nq6UevavVHuUfDawVHz2sRPLNrGxylR+xAH2soRB9rMUgLazzc72tFSCdrUUgza11IP2tpSEkGcAQja3gKc2uBSGjYmB8JSHtrmSD3a6HJU2utSKfih2u9SLjiK2vI3Z9r0UjTa91I32vo8Qdr86IxZvNr/UkLbAlJF2wVSSVJL2wlSTlJQ2w1SUzPCUlbbElJZ2xVSXNsYUmDbG1Jj2x5SZrMjUmlzp9sjUm7bJlJx2yhSddsrUnjbLlJ72zE7kdszUoHbNlKEOzrbOT/U2ztVP6rrUo8xyttAUpPbQ7+zUpjbR1Kc20pSn9tNUqLbUBYX21JSqdtVRrnbV1KvgQlSsttcUrXbX1K522I8SNtkUr/bZzKy22lSxdtsUsjbbzWT23FSztt0UtLbd2GHOK/behDd23xGXmxb239S3tuCUuHbhVLk24hBl9uKdjdS6jJz245S7tuRUvEKWzpX25VS99uYUvrbm1L9255TAFMC26JTBdulUwjbqFML26tT9dutUxHbsFMU27NTF/lWUxrbuFMd27tTINu+BvbbwFMm28NTKjt928b+ulMw28qPptvMUzfbz1M629JTPdvVU0Db2FND29tTRtveU0lDFkJ/2+JTTtvlU1Hb6FNU2+tTVzSaQkFTWtvwU13b81Ng2/bialNmNaY1Vtv7U2zb/lNvM0MCYFNzWhZTdgcR7BRTegFLU3xm+NwLO1Y8QdwOU4Smj1OH3BNTikVY3BZTj9wZNVhTk9Z6U5bcH1OZ3CJTnTLV3CVToU2RU6NZjWtNazzcLJjL3C5TrnQz3DE1uDdxU7PUDFO2MclTuFZbU7vcO1O+3D5TwTQvU8TcQ1PHQIDcRrVBU8zuWFPPN6/cTOkDU9TcUFPYU9rcVFPeU+DcWFPkVifcW1Pp3F1YnlPu3GEyWVPzU/VDDNxmU/kzpNxpOWbca1QARf/cblSq3HBUBz7P3HNUCzhV3HYCLtx4R7RWEUOx3HxUFgN1VMfcgFQbS1KRoVQfitZUIjbiVCXcilQo3I1UK5CwVC7ckuzgVDTcluo2VDncmjYN3JxUP0Ap3J9UQ9yiVEZGH9ylQSTcp1ROgcJUUdysVFU3Q9yvOWbcsVRc3LSVslRhwY/cuFRl3LtUaFGr3L5UbNzBAa/cw3Ri3MUHKdzHVHjcylR7NU1RlNzOW/JUg1SF3NNUiNzWVItUjdzaVJDc3VST3OBUlmuqVJk3Wy3g3OZUntzpVKI7R9zsVKfc78b3VKzc81T13PVDqdz3Rbfc+VS4P2IyaNz9VL6PrFTBNc7dAlaHVMc9YN0GhNBUzTVcR8PdC1TSON7dDjya3RBL9N0SVNw5VPRfZ0bdF1Tj3RpU5t0dWVxU65OZVO7dI1Tx3SZU9N0pOQxU+jCfPtvdLlT/VQHdMgns3TRVB903VQvdOk/I3Tw2AN0+VRTdQVUX3URVG91HVR7dSlUhPiXdTVUl3VBVKN1TVSvdVj503Vg59N1aAXbdXFU33V8P1t1hEtzdY1VB3WZVRN1pVUfdbFVLNlpVTt1xWy7dc1VU3XZVVwaa3XlZLN17qudVYKGBVWM2sN2BVWfdhFRV3YZVbd2JVXBVct2NVXU1Wd2QVXndk1V83ZZVf1WB3Zu1h1WGnL5ViUOoCZLdolWO3aVVkd2oVZRSld2rVZjdrlWb3bFVn920+WZVo20XVabdulWp3b1VrN3AlphVsd3EVbTdx4Yu3cpVvDr5Q/tVwN3QVcNsgt3TVcfd1lXK3dlVzd3cNSRV0t3gVdXd41XY3eZfhNT5Vd/d6z213e1V8lXn009V6n/gVe3d9XR4VfJ+SlX1VfdjIt38Vfvd/zmt3gFWAQyf3gRWBd4HVgjeCjJY3gxWD94PVhNWFd4TVhneFlYcOG4zRN4aViLeHVYl3iBWKV8C3iM2VN4lVjDeJ2x13ilWNt4sVjneL1Y83jJWP1ZB3jZWRF7/VkdWSd48VkzeP3sgVlI6H95DVlY3bjKO3kdWW3kWVl7eTFZiVmTeUXik3lO8m1Zs3ldWb95a2/FWdIFSVnfeYEhv3mJWfFZ+Ph/eZlaCEDhWbd5qOTPebFaKo/xWjVbL3nI1UlaT3nVWlt54VplNK1acM13eflah3oF4pN6DVqfehlarTqfeiVav3oxWsvbH3pBWtt6TVrmLhd6XVr7emlbBP3NWxN6fVsc8djJR3qNWzFbO3qdW0d6qVtTerVbX3rA51N6yPYDetIBbVuI1cFbk3rlW51bp3r1W7N7AVu/ew1c3VvTex1b43spW+1+V3s1W/97QVwLe01cFQc/e1zjP3tkxyAG93txXD97fMvfe4VcV3uRXGN7nVxve6lceWy7e7Vci3vDjpVcn3vRXK9733DdXMNYVVzM2Xt79VzffAFc63wNXPd8GV0BF/t8JV0TfDFdH3w84+98RV02LGFdQAb7fFldUPHjfGVdZ3xzhDlde3yBXYS/YUozfJFdm3ydXad8qV21On98tV3HfMFd03zNXdz4K3zYST984V3/fOzUD3z1Xhd9AV4jfQ1eL30ZXjt9JV5HfTEHaV5XfT1eY31IzTd9UV57fV1eh31pXpd9dV6jfYDZB32JXrd9lV7DcbFez32pXtt9tV7nfcF+S33JXvt91V8HAfd94V8Xfe1fI335XzDMQ34E2y9+DV9M72FfWW4tX2QtsV9zfjFff349X4l3zV+VapN+UPMjfllfs35lX8N+cQHZX9N+fV/c0r9+iV/vfpVf+SsDfqFgCNNzfq1gG365YCVgL37Lkmd+0WBLft1gVQDjfuv5Mph5YHd+/WCAPk08338M1k9/FWCjfyFgr38tYLt/OWnzf0Fg039NYN9/WWDvf2Td839tYQd/eWEQ8AN/hRDvf4+o9WE3f51hQWg/f6lhU3+1YVzeAO8nf8VhcN1Tf9DZe3/ZYYt/5WGXf/DSlWGnf/1hta35YcDjC4ATrsFh2NzsyOuAJWHvgDFh+yfFYgeARWITgFN7GWIngGFiM4BtYj+AeBJrgIFiWPkQ1VOAkWJvgJ1ieOGw8eOArWKPgLjQoWKc4EAYV4DJYrOA1WK/gOFiyYdXgOzlV4D1YuDsD4EBhs1i9EXN4pFjA4EZYw+BJP+7gS1jJ4E5YzP66WM/gU1jSN9M1vOBXo2tY2TNTNOfgXDVs4F4yT+BgWOTgY1joNXd5kuBnWO11r1jw4GxY8+BvWPbgcj2Y4HQySuB2W2/geFkC6ZBZBeB8WQitzlkL4IFZDuCEWRHghznR4IlZF+CMWRoKW+CPNAvgkVkhX8JZJAUKS1pZKOCZ6zVZLFDOWS93klky4KI9u1k34KY1RuCoWT3gq1lA4K423FlE4LFZR+C0WUv+YFlOOnMzWOC6Q3fgvEfD4L5ZWODBWVvgxFle4Mc/VeDJWWPgzFlm4M9ZajYk4NNuluDVWXHg2Fl1Sa7g21l5SUBLWODfPSDg4VmB4ORZhDpI4OdZiODqWYvg7VmO4PBZkaZlWZS5JmIGWZzg+ATq4PpfvFmg4P5TaeEAPJDhAlmp4QT+h1muVn3hCFmy295ZteENWbg4p+EQWbzhElm/Xb9ZwjWK4RhZxlEANmXhHFnL4R9ZzuEiMznhJFnUQLnhJ1nY4SpZ2zXkBszhLlng4TFZ4zMD4TRZ5+E3Wes/kDW/4TtEbOE9WfNoseFAWfez5Vn64UU0O1n+4UhaAeFLWgThTk834VBmTOFSWpVaDOFWWhA6dLSCTNbhW1oX4V5aGuFhWh1Cqzw/WiA7ReFmWBHhaFonQFRApuFsWizhb1ovqeNaMuF0NXzhdlo6DkTheVJG4Xs3yeF9WkQzOOGAOeDhglpL4YVCvIdmWlDhiVpTUgXhjEVj4Y5aWeGRWlzhlHcTWmDhmFpjN7vhm1pn4Z5aauGhWm3hpFQ34aY2UeGoPSzhqlp6WDE+k+GufKfhsFqD4bNahlqI4bc3EuG5Wo1WFOG8WpF0pFqU4cFal+HEWprhx1qe4cpaoUou4c2OU1qn4dFaquHUWq3h11qw4dpGvzr/4d1atlq44eFau1S84eRav+HnWsLhXVrF4exayDm74fBazOHzWs84xOH2O4/h+FrW/JFa2eH9Q3nh/1rf4gJa4pmKWuXiB1ro4gpa6+INWu7iEFrx4hM+fuIVOmfiF1Bp4hla/UPuNmviHUcG4h9bBeIinJ1bCuImWw00I1sQ4itbE+IuWxYCSzmY4jJbG+I1WrviN1shijFbJOI8OTPiPlsqAh1bLVsvONjiRFsz4kdbNuJKWzlkbVs84k9bP0fH4lJQvOJUW0XiV1tI4lpbS+JdW07iYFtR4mPVuVtW4mdbWTX64mpbXeJtW2DicFtk4nNbZzDWW2pd5eJ5W25bcOJ9W3PigFt2yRlbeeKFOx3ih1t/4opbglmNW4Xij1uIOpvikluM4pVKvOKXOdLimTRR4ptbl0jc4p450uKgXWLioluh4qVbpUUE4qhbqeKrW6x8gFuvC3kykuKxW7TitFu44rdbvDXPQnfiu1vB4r5I7eLAW8fiw56EW8w54DHB4siH31vT4sxb1uLPW9k44OLSW93i1XA+XhHi2Fvk4ttb50OP4t5b6zuq4uF3RlvxVIHi5Vv14uhb+OLrW/thjeLu1aHi8VwD4vRcBuL3XAni+lwM4v1cD+MAtwFcFOMEAQTjBlwa4wlVDeMLXCHjDlwk4xFcJ+MUMtTjFlwu57rjGj/I4xxcNjk24x9cOuMiXD1ABOMlXEHjKFxE4ytcSOMuXEvjMVxO4zRcUT1PS7HjOFxWcDZcWeM9XFzjQFxf40NcYjiPMgJcZTTz40lcaeNMXGzjTlxvS7LjUVx0XyHjVFx441dcewdp41pcf+NdXILjYHIdXIfjZFyKNJw2ZuNoXI/ja1ySahZclTQJ43BIkONyXJxWceN1Rwb2Llyi43pcpeN9QZzjf26i44FhruODl2k3gAe/44dctOOKMo/jjOXa4443xeOQXL4y/zj745SiBVa745dcxuOaXMlCk+OeXM02fjXQ46Jc0+OlXNbjqINEXNszw+OsXN81KeOvXOPjslIlXOfjtlzq47lc7eO8RTg9PeO/XPPjwlz2QbvjxVz631Rc/ePKOG7jzF0CbOLjz10GRnzj0l0K49VdDePYXRDj210T495li11h4+FdGlJzXR3j5l0g4+lZQuPrXSbj7j+L4/B08l0t4/RpjOP2QUrj+F014/tVg+P9XTs30V09Z4PkAV1B5ARdROQHXUfkCl1K5A1dTuQQXVHkE11U5BZdV+QZXVvkHF1fUGNdYkVy5CFdZkNY5CRdauQnXW08ETtl5CtdckpO5C5ddzxBO3ZdeuQzXX02wuQ2XYHkOV2E5DwCWeQ+OufkQF2MB+U0tuRENsjkRl2UM9XkSl2Y5E1dm+RQXZ7kU12h5FZdpENA5FldqORcXau5Fl2u5GE95+RjXbU27WKJ5Gddu+RqNVzkbF3Bip7kb13F5HJdyOR1XcvkeF3O5HszPeR9OTPkf13X5IJ6Zl3c5IZd3+SJundd5F3mOQPkj13B5JFd7eSUXfA1MuSXXfQ/FeSbXfgx4eSeBt/koF3/5KMy3eSlXgTkqF4H5KteCuSuPvTksF4QXhIz6eS0Xhbkt14Z5LpeHOS9Xh9t8F4hGukF4OTCXibkxUwQMrLkyF4s5MteL+TOXjI8+uTRYLFNQTLl5NVeO2ga5NiS9F5A5NxeQ+TfXkZH6uTiStjk5F5N5OdeUOTqXlM1duTuRHHk8F5a0lg7kUk55PVD5+T3AUpeZOT6Xmfk/V5q5QCU2F5v5QTTDV50Om3lCF54RE9CA+UMXn7lD16B5RJehDMd5RVeiDjC5RgyBuUaXo/lHTQF5R9elTOxd3zlI16aToGahF6eSLHlKTtH5StepeUuXqkEm+UxXq5n6uU1XrM6pj8W5Tl7ZHXz5T1evuVAS5jlQl7D5UVexuVIXsnlS17MNMLlTtseOEHlUTQ/XtXlVF7Y5Vde2zjG5Vpe3zgpXuHlXjsA5WBTMF7p5WRe7D5hOFXlaDkOUT7lazee5W1e9+VwSRLlcjmq5XRe/+V3XwJfBOV7Y29fCeV/PLblgV8PXxHlhRCH5YdfF+WKOIZfG+WNXx7lkJjxXyPllF8m5ZdfKeWaNUjlnDOi5Z5fMuWhXzXlo1845aZfO+WpXz4JiOWsTVDlrjPd5bBfSF9RX0vltV9O5bhfUeW7lf1fVgFMMb/lwF9bOBflwzTp5cVfYuXIX2UyieXMX2kPSF9s5dFfb0ZH5dQzmOXWX3Yx+uXZX3rl3F99X3/l4EEO5eJV3OXkX4cDXtfwX4tTtDdx5etfkOXu5drl8Eiu5fJfmuX1X509i07J5fk8F+X726Jfp4T5X6rmAV+uOPY0/uYFX7NQN+YIX7fmC1+6Z0JfveYQX8BfwuYUX8Vegl/IsKJfy16rXO5fz+YeX9JGXuYhX9fmJF/a5icQNeYpX+BgP1/j5i435eYwX+jmM1/r5jZf7uY5X/HmPF/05j9f9+ZCXXTmRF/95kdQ+eZJYANUguZMYAekQ2AK5lFgDeZUPqzmVmATRjvmWWAXUalgGuZeYB3mYQoC5mOdc2Al5mdgKFFZZpLma2AtPT5HYeZvYDNA9uZzYDfmdmA65nmNZmA/5n1gQmAyOjbmgWBHvTMx6+aFOS7mh2BP5opgUuaNYFWC02BYVpPmkmBc5pVK0uaXx/5gZIxo5ptgaOaeYGvmoWBu5qRgceanYHXmqmB4M2DmrjuM5rBgf2CB5rRghOa3YIfmum8iYItCHOa/YI/mwmCS5sVglUtj5shgmYW/5stgnebOYKE68zQV5tJgpzrT5tVgq+bYYK6y3emmkIZgtObf7mJguebjYLzm5mDA5uk4vObrN2Dm7WDJAUqdBGDNM/w3Kub0YNI3qub4YNYBceb7YNo1zeb+YN8yATZs5wJg5OcFYOfnCLA0YOtMQecNYPDnEGDz5xNgYecVYPnnGGD8QvDnG2EABtxhAucfYQUzPEgoYQnnJTz75yfgNWERYRPnLGEW5y9D2OcxYRw5Bec0YSDnN2EjNNthJuc8XT3nPmEs+qxhL+dDYTJhNOdHYTfnSmE6501hPudQYUHnU2FEOV3nVmFI51lhS+dcYU7nX2FR52I10udkYVfnZzdg52kDV+drYWHnbmFkBsphZ0/G53Nha+d2YW7neWFxbornfGF15382lTi354Jhe+eFYX7niGGB54thhOeOYYhhilaTMgrnlGGQ55dhk0EOS1/nm2GY555hmzp5OQvnomGg56VhpOeoYajnq2GsiwZD4Oew6PzntEE557ZhuOe5X0NhvOe9Yb/nwGHCAnXnwzMQ58VhyefIYcznymHPYdHnzmHUYdZLiTLLYdrn1WHd59ga6QLl59th5OfeYedoZWHq5+Nh7Q8G5+a2ODdxYfNOXufrYfhh+ufvND5h/gIuQBPn82ID5/bg9uf4OFRHU2IM5/xiD+f/YhIvtTx+YhYy0OgFYhsy3OgIYh82pWIi6A1iJegQYijoE2Ir6BZiLjMPAXjoGmIzXtMz3ugeYjnoIWI86CRiP0Zn6CdGb+gpj0tiRzTn6C1iS+gwYk7oM2JR6DZiVOg5YlfoPGJa6D9iXehCD+ToRDeN6EZiZwJY6Epia1Xn6E1ib+hQYnLoU2J16FZieOhZYnvoXGseYoDoYGKD6GJihuhlYoroaEHX6Gpijz55YpLob2KVPHHoemKZRTjodmKdVqvoemKhNjYQ1Oh+DlXogGKpYqvohFctYrBGCZ+y6IlWoOiLYreHq2K66JBiveiTYsA15TRHYJxixT9JMyHommLLsjSA1zlg6J9i0uiiYtUtIuilYtli2+ipYt5Hq+isYuLor2Ll6LJi6Oi1Vgpi7ei5QAzou2Lz6L5i9ujBYvnoxDau6MZi/ujJYwE19ejNYwXo0GMJMxPo02MN6NZjEKY5YxPo22MWNv8tu2Ma6OFjHejkYyHo52Ml45RjKOjsDero7q5WYy9HOjd16PNB+ej1Yzfo+GM6Ya7o++ey6P1jQekAY0TpA2NHNXQyb+kHVNtjTukLY1I4CekOSrxjV3QmY1pjXOkVY183CTJK6RljZGNm6R1+B2NrRsbpIUEYY3DpJUfF6SdjdukqY3lJEuktBc1jfkc5Y4HpM2OE6TZjhztWO9fpOmOMBts49ek+Y5HpQQF26UMNc368do5jmelJY50zV+lNY6E8SOlQY6VDAU2p6VRjqqiLY60xzulZOdHpW2O0U/pjt+lgY7pmLWO96WVjwFkYY8NYWWPGMzjpbWPK6XBjzelzY9DpdkCE6Xhj1el7Y9gQh6utY9zpgWPf6YRj4umHM03piWPo6Yxj6+mPM/o2bumSY/HplZ7rY/ZF1emZY/rpnEdVRuPpn7w3ZAHpo2QE6aZkB35KZArpq1hL6a04O+mvZBNjTzz76bNkGOm2ZBs85DYj6boyGem8ZCLpv2QlBQNkJ+nDS2jpxWQt6chjvmQyQdNKXOnNZDeah2Q6R+rp0mQ+6dQ3xGRC6dh5OenbZEnp3mRM6eJkT6um6eZkU2Rh6ek0VmRY78BkW03sZF5kYFqvZGM5reD6U8Pp9WRpQeQ5kun5OWzp+2RxM5NHaen/Uy3qAWR56gRkfOoHZH8+C+oKQVNkhAgnH6nqD2itPGHqEmSN6hVkkOoYZJTqG2SY6h5km+ohZJ7qJGSh6idkpOoqBts0zeotUurqL2SujfdksUUF6jRkteo3ZLhD/TX1ZLvqPAJZNoPqP2TB3qBkxEGo6kRkyOpHTbXqSWTOOaPqTGTS6k8+eupRZNnqVGTd6ldk4NxSZOOCaGTm6l5k6sd7ZO1BOepjZPHqZmT0OhFhoupqZPljPWmvZP02LOpwPkvqckKo6nRlBz8D6ndlCwGvPPtlDup8ZRHqfwav6oE1neqDZRjqhmUb6ollHuqMSi45n+qPZSTqkmUn6pVlKuqYZS0xxeqbZTEBCeqeSKPqoGU46qNlO9XYZT4+J+qoZULqq2VF6q5lSOqxZUtAsTlH6rVlUDSrZVOeDWVW6rxlWeq/j/xlXurDZWHqxmVkNJRSpurKZWk5i+rNSRrqz2Vw6tJlc+rVZXbq2GV56ttlfKntZX/q4GWC6uM5y+rlZYjq6GWLY3JljurtNcTq72WU6vJll0uk6vYFx+r4ZZ7q+2WhS7fq/mWlDZDrAmWp6wVlrOsIZa8yM9NQZbPrDmW2N3LrETdu6xNlvOsWQqHrGIHeZcPrHELB6x5hpesgZc0R7esjCGbrJWXUQN7rKWXZXJLrLBLuMw7rLzyA6zFl4zMw6zVl5+s4ZerrO2Xt6z5l8OtBZfPrRGX260dl+etKZfzrTWX/61BmAjH6RMLrVGYH61fo9mYMO1nrW0rj611mE+tgTFdmFzoOREpmGz2cZh3raGYg9gdmI+ttZiZjT2Tj63FmK0Bv63Q5iut2ZjLreUoS63tmOOt+uMxmPeuCMgjrhGZD64dmRuuKZknrjWZMhjVmT+uSZlI05euVZlbrmGZZ65tmXOueZl/roWZo5ezmk2Zn66dmanWCZm1e2Or0ZnLrsK2SZnZQwDLj67Vme+u4Zn7ru2aBOhWmt2aF68FmiOvEZovrx2aP68pmkjrV681mluvQZpnr02adQGhNLuvXphBmpOvbZqc2hOvfZqs3yeviNAfr5Dih6+ZmtTbtZrfr62a6BLJmvOvvZr9IYOvyZsTr9WbH6/hmyuv7Zs3r/mbQ7AFm0+wEZtbsB2baZtw6H+wMZuHsD0i8NAjsEmbnZrHsFmbrNk7sGTeY7Btm8uweVJ1m9+wiZvvsJWb+YcLsKGcDh7xnBuwtZwnsMGcN7DNnEOw2ZxPsOTwb7DtnGUHDOtPsP2ceAb3sQmciPLfsRUbB7EdnKOxKZyvsTWcu7FBnMexTZzTsVmc37FlnOuxcn4JnPzqoeDBnQ0Bf7GM9kexlZ0rsaGdNQJg1texsZ1Lsb2dVXGwGQ2dZOt/sdWdd7HhnYAavZ2LsfWdleU9naOyCZ2zshWdvNEZ3MVSlZ3TsjEGpZ3g/8Gd6NCfskWd/7JRnguyXZ4bsmltZ7Jxni/mMZ47soYcwZ5M231j57KZnmOypZ5zsrGef7K9nouyyZ6XstWeo7Lg1ruy6EJHsvHskZ7JNzme17MLjjE3+7MVnu25vNEzsyU4u7Mtnw6De4QJSPuzQZ8ns02fMEDhnzuzYZ9Hs22fU7N5n12fZxTxn3OzkZ9/s52fi7Opn5VLYZ+g0R+zvZ+w+LkCY7PNn8TUR7PZn9ez5Z/js/Gf77P9n/u0CaAHtBWgE7QgEle0KaArtDWgNgQHtEGgR7RNoFO0WP+LtGGgaP+rtG2gf7R5oIu0hAnntI0YxMfntJkoM7ShoLu0raDHtLmg0PvMXLu0yOCztNGg8M2vtN2hATUNoQ+08aEY4ZASa7UBoS4oONvftRGhRd3xUTu1IaFZJj+1LaFpMhO1OaF4+N+1RaGLtVJmOZJXtV2hq7VpobWxgaHDtX2hz7WJod+1laHrtaGh97WtogTgG7W9ohu1yaIntdWiM7Xhoj2iR7Xw9oe1+VglDse2BaJrthGid7YdooDpV7Ys+C+2NaKbtkGip7ZNorO2WaK/tmXLa7ZtotUYQ7Z5oue2haLx4I2i/7aZowu2paMXtrGjI7a9oy3zb7bNoz/6FaNLtuDVg7bpbDmjZ7b5o3O3BaN/txGjiR5Xtx2jmNjLtykKn7cwU/u3OSeft0GjxQwHt1Gj17ddD2O3ZaPvt3Gj+tlFpATQj7eFpBe3kaQgyXO3naQw6RC+W7etpEe3uBL/t8FVj7fJB9+30aRvt9xEHaR/t+mki7f2ha2km7gFpKe4EoitpLu4IaTFck2k07g1pN+4QaTruEwcB7hVUwe4XaUPuGmlG7h0yCu4fb/hpTjx9SZFpUUH/5A5pVe4oNsHuKmlb27hpXu4vaWFmU2lk7jRxxGlp7jhpbO47aW8y9UT/7j8CTu5BaXcGzO5EaXs8E+5HaX9/dO5KaYPuTWmGREDuUT/4NNvuVDLI7lZpkDuhaZLuW0Ku7l1pmO5gaZvuY2meSk5poO5naaM3gclRaacJkmmpCr/ubmmt7nFYke5zabPudgNe7nhpue57abwyxO5/a6PugWnD7oRpxu6HacnuimnMgjxpz+6PadIJB+6SadZhzGE7adnul2nc7ppp3+6dN6hp4+6gaebuo2np7qZp7O6pfi444e6tafM4kgd/7rFp+AWcZNPutVFH7rdqAO66agNm+O69agfuwGoK7sNqDe7GahDuyT5a7stqFu7Oahnu0Woc7tRqH+7XaiLu2mol7t1qKO7gaivu42ouNbMFne7najNCdznJ7utqOO7uk6hqPEnpaj+cn+70akPu92pGmwpqSe79akzvAGpPRW5rEmpT7wZiRO8Ialk5HUyD7wxqXnFB7w9qYu8SamXvFWpo7xhqawit7xtqb3f7anJcazZBNaXvI2p4MfnvJjdO7ygRc+8qaoJUN+8taoZkPpyf7zFIBzea7zRqju83apHvOmqV7z1Dj+8/apxqnu9DNV3vRWqkOGTvSDi870pqrEGY701P0O9ParPvUmq271VquTk0PWDvWWq+W5RqwWc8NybvXziB72FqyO9kass5KMXJas86D+9qatPvbWrW73BEuO9yA3nvdGrf73dq4jI973o34u98aulAj+9/QhzvgWrxlYVq9DzmPBHvh2r574o32O+Mav9KvO+PawPvkmsHOctNwu+WNkPvmGsP75trEjObaxSpP2sX76Iyzmsb76VrHlWAMuTvqWsj76xrJu+vOHQ5/msqXGxm32st77U3Pu+3azLvums1773Xq++/azrvwmtHMjvvxZOBNHhrQjRt78prRlOq783jh+/PNXZrTVOo79NQHO/VUv1rVhAP79lrWj02NwprXe/ea2Dv4Wtj7+Q0P2tn7+drau/qnwhrb+/ubWjv8Gt17/NreDyD7/drfANOPlvv+2uB7/5rhImba4e8T2uK8AVrjfAIa5BW6PAMVVfwDmuXXpBrmvATa53z0Gug8BhUYfAaOnrwHGup8B9rrPAia6/wJWuyN9fwKWu28CxrufAvthlrvvAza8HwNmvEYRBrx/A7UBLwPUtj8D9yLvBBa9NBLfBEd582OvBHa9pcHPBKM4fwTDqx8E40lDHL8FFr5fBUa+jwVzgj8Flr7vBcC8TwXkfU8GABdvBia/nwZUEW8Gdr//BqbALwbWwF8HBsCDU8bArwdT6A8HdsD/B6bBLwfWwV8IBsGPCDbBtHOfCGQEK9Emwh8ItsJPCObCfwkWwq8JRsLRLu8JdVgzy18JpsNEtkNa7wnmw58KFsPPCkbD9UvvCnbEPwqmxGARHwrWxK8LBsTfCzlWhsUvC3bFXwumxYM5HwvkTf8MBsX3/0bGLwxmxlOZ7wyWxpS7LwzWxt8NA08vDSbHPw1ZU3bHjw2e9fbH3w3WyAVTnw4GyFO6FYavDkbIrw5wSb8OlskfDsbJQByfDvbJjw8mybzn1snvD3bKHw+myk8P1spzfc8QBsq0ju8QRsr/EHCGBstPELbLdWAGy6bwdsvfESbMA1pjgh8RZsxfEZbMg1NvEcQLIyFPEfbNBNZ/EibNSwgfElbNjxKGzc8Sts3/EubONT9D8b8TJs6DYi8TU9SvE3bO7xOmzx8T1s9NN9bPfxQkOyRf3xRQlx8UdtAPFKbQPxTW0G8VBtCfFTbQwzWvFWbRDxWW0T8VxtFgJ56jRtGklx8WJtHjSa8WVtIvFobSVisPFsbSrxbzQEbS7xcm0x8XVtNPF4bTfxe2068X5VGPGATp3xgm1DRzZT6fGGbUhgf2GN8YptTfGNM8bxj21S8ZJtVTt7bVfxl21a8ZptXUUUNUjxnm1j8aFCuPGjNrvxpQY/8advO/GpbXIzKTHf8a1td5G+8bBte/GzPBPxtW2B8bhthQLLCGjxvJCtbYvxwG2OA3Xxw22S8cZtlfHJbZjxzG2ckI4zSPHQbaLgNPHUPjeqNm2o8dmGDPHbba3x3m2wslpts/Hjbbbx5m25NaXx6W298ez1Cm3CWUFtxfHzbcjx9m3L8fltzjrn8f02BvH/bdXyAm3Y9ajyBm3d8glt4DwF8gxt5PIPbefyEjRR8hRt7fIXbfDyGW3zNj3yHG33OvnyIG378iNt/vImbgHyKW4EXhHyLG4I8i9AAfIxbg/yND1l8jZuFQE48jpuGUv1MJNuHAIvNkDyQG4h8kNuJPJGbidhO20KbivyTG4u8k9uMeTIbjQ2wm438lZW7vJYbj3yW25AfO5VPvJgbkXyY25I8mZuS1COQKZwNm5Q8m5uU8rxblbyc+rXblvyd25e8npuYfJ9bmVvGEVgQMhrOJaabm3yhW5w3CtuaW51U6hloG558o5ufPKRbn8zpPKUboPyl26G8ppuifKdbo3yoFUw8qJPGm6UfKdulwYA8qhum/Krbp7yrm6h8rFupfK0bqjyt1bbbq3yu26w8r5us/LBbrbyxG658sduvPLKbr/yzTll8s88z/LR099uyfLVPtPy127P8tpu0vLdP07y3593btnBj27c8uVu3zUy8ug0FPLqbucz4FBj8u5u7PLxbu9BS/L0bvPy91ZEbvjy+06K8v1JxvL/bwHzAm8F8wVvCYOPbwzzCm8P8w0C5fMPbxTzEm8X8xVRz/MXbx1ohfMadYHzHW8l8yBvKPMjbyzzJsdYbzHzKm808y1vNxUMXaRvOzoG8zNvPz3B8zZvQ/M5WD3zO0Kn8z1vS3p4P+QDyPNCb1HzRW9UOWVvVvNJb1nzTG9c809vX1H7OW3zU29k81ZvZ/cMb2rzW29t815vcPNhb3PzZG92jh7zaG9682tvfUtEN3Xzb2+C83JvhfN1Ak7zd2+L83pvjvN9b5FVP2+U84Nvl/OGb5rziRDU84tvoPOOb6NY9G+m85NvqfOWb6zzmUOS85tvsfOeb7TzoW+4S53zpEeWb70Bt/Oob8Hzq2/E865vx/Oxb8o1z/O0b85PNUou87hv0/O7b9bzvm/Z88Fv3PPEO+3zxjScP47zyW/lMxNSVfPNTS7zz2/s89JRm/PUb/IHA2/089hv9zodb/nz3EFL894Q3TJP8+HIOHAE8+VwB/PocArz63ANPoVwD/PvbrFwFEjTcBfz9XAa8/hwHVJp8/tuLnAjPHnz/0jU9AFwKvQEcC30B3AwNXj0CpD7cDY2qfQPcib0EXA89BQBafQWcEH0GXBE9BxwR/QfcEr7bHBN9CUDu3BQ9ChwUzUc9CtAQvQtcFpJnPQwcF70M0kX9DVwY/Q4WD30OnBp9D020fQ/cG/0QnByYdNwdfRHNQf0SUGw9Etwfj+/Ndj0T3CD9FJwhvRVN370V3CM9Fo5XXCQ9F1wlPRgcJf0Y3CaQ4hwnPRncJ87//RrcKP0blUacKj0cnCrN6n0dgaU9HhwsvR7cLX0fnC49IFwuzpi9IRwv/SHcML0ijKH9Iz7OXDJ9JBwzPSScM/0lXDS9Jhw1Us3cNj0nXDb9KBw3vSjcOH0pjZV9Khw5/SrcOo1WfSuNcn0sHDx9LNw9PS2MJ05J/S5cPqi3nD99L5LOPTAcQL0w3EFOJz0xnEJ9MlxDPTMcQ/0z3ESSZz00jc/PE/01XEZ9NhxHPTbcSAzJ/TecST04XEn9OR4jPTmbIdxLj+J9OpxMvTtcTX08HE4PZVJ8fT0cT3093FARlQ9mkncMin0/XFHV79xSvUCOSf1BHFQVUj1B3FU9QpxV/UNPkz1D3FdcV9xYEPJ9RQ1Z/UWzapxaVaBcWz1HHFv9R8y2/UhcXX1JHF49Scy9fUpcX71LPJ69S5xhEEc9TFHpPUzcYr1NnGNiu1xkDJONJ31PHGV9T9UVXGZ9UJxnPVFcZ/1SHGi9UtxpfVOcajdUnGr9VRxrvVXNZb1WXG09VxxtzM59V9xuz/8/QxxvzzC9WVxw/Voccb1a3HJ9W5xzH+2cc/1c3HSO2z1d3HW9y9ZpVO0N8lx3PV+cd/1gXHi9YRx5UP+cegJR3Hq1X1x7TjA9Y5x8fWRrT5x9vWVcflH6vWYcf31m3IAPS71nnIE9aFyB/Wkcgp1LHINbdpyEPWrchP1rnIW9bFyGfW0cfRyHTuI9bhyIfW7ciT1vjjA9cByKvXDPdr1xXIv9chyMvXLcjU5PvXOcjn10XI8CK311HJA9dc8TvXZN3X12z7Sckj13jNM9eByTvXjclFK1fXmUib16HJY9etyW/XufA1yX4UHcmL19HJlOVv19zpu9flya/X8NGz1/jRu9gBycjfm9gNyd/YGeCc71vYJcn32DHKA9g9yg0EW9hJBB/YUcor2F3KN9hpykDls9h5ylfYhcpj2JE+u9iZynjKybUByovYs7ohypzYy4Sdyq0XN9jNyr/Y2pXNyswanpSxytzobNYv2PnK8ne32QXLA9kRyw/ZHSsv2ST7R9ktyy0Uk9k5yz/ZRctIz4/ZUctb2V05i9lly3U6nowZy4WiU9l8CjnLm9mJy6fZlN+Ux2/ZoQUz2anLy9m1y9fZwcvhHCvZzUbd27nL+9nhzAUcINfP2fHMGShJzCPaAcwv2g+vLcxD2h2SJ9olzFvaMcxn2jzKopYJzHvaUMj8/NfaXcyX2mmGi9pxzKodFcy04kTjHczBiyPakczReezc09qhzOeO1czz2rXM/Eer2sDWY9rIHEfa0c0j2t3NL9rpzTja6c1D2vnNTAmn2wXNX9sRzWvbHc132yqdvc2FGFvbPc2U3YXNn9tRzakq49tdzbvbac3H23XN09uBzd/bjc3trBhF79udzgA+G9upzhDL/9u1ziDNY9vBzjGJfc4729HORUuRzlPb5c5f2/HOa9v9znfcCc6D3BXSv9wdGkvcJPh/3C3Or9w5zrvcRc7H3FHO09xfiLjma9xpzu/cdMkL3H3PBO/IxzfcjRsb3JXPI9yg0Lvcqc833LXPQ9zBz0/czPclz1/c2c9o/c3Pd9ztz4Pc+c+NCcz5990Jz6PdFc+s0oTT+90kx1fdLc/NTkvdONRz3UDbC91Jz/DWnc/46vPdXM287IFSM91t0Bm8q914CJPdgVIz3YjIUVCSDMPdldBP3aHQW2bl0GfdtdBz3cHQfM5H3c3Qj93Z0JkjX02N0Kjp5WPv3fX4ldDH3gWw9dDb3hXQ594h0PWT4dEBFN/eOdEQ5u/eRdEj3lHRL95c8w/eZdFD3nEg5dFX3oHRYOYf3pHRc96d0X1Gb96qe+PesdGb3r3Rp97J0bPe1dG8zSkUJ97l0dHgTdHf3vnR6O933wXR+P8r3xHSC98d0hWWm98o1pffMOzf3znEmdJD30ge/99R0lvfXO5T32VKDdJ733XSh9+B0pDZoyYF0qHc+dKv36HSu9+s7dDbL9+50tffxerd0uff1Q/p0vff4dMBIo/f7dMT3/nTHOYt14XTK+ANAHfgF/b100PgJdNM+ffgMNkH4DnTa+BF03TfnPO74FXTi+BgwAvgadOj4HXTr+CB07vgjPAb4JXT0nJH4KXT4+Cw5qvgudP5B6PgxMs74M3UEWNZ1B08f+DgFv/g6QwH4PHUR+D8++PhBOJf4Q3UZ+EZ1HPhJPZX4S3Ui+E51JUA6dSg3zvhUdSz4V3Uv+Fp1MvhddTX4YETK+GIzYPhkdTz4Z3U/Yzf4awFKdUX7aHVI+HB7KvhydU407jjR+HY+Q/h4QIAOVvh7VKT4fXVc+IB1X/iDdWI97obz+Id1Z/iK+KZ1a/iOOCf4kHVxVuBDhXV1+JZ1eD3wPTb4mnV9+J1KuvifdYP17DipN0v4pC7udYn4p0MCPTb4qnWPN6cQ0fiudZT4sXWX+LR1mjP9buT4uHWfQTlHTPi8daQ/yVZm+MB1qfjDdaz4xjMk+Mh1sfjLdbT4znW3+NF1uvjUdb06YfjXdcFce3XEOPz43XXIBEhtsnXM+ON1z/jmddP46XXXNEJ12WHyddwHDIuQdeD48nXkTn349vtHdeo5rPj6de48A3XxR8OC9fkAaYz5AnX4+QV1+/kIZv48EPkLdgH5DnYE+RF2B/kUdgr5F3YN+Rp2EPkddhM38/kgO1/5InYZVfF2HPkndh/5KnYi+S12Jfkwdij5M3Yr+TZ2L/k5djL5PDfO+T52OPlBdjv5RHY+Mrz5R3ZCL9M1UflLdkf5TnZK+VEyBflTdlD5VnZT+Vl2Vvlcdln5X3Zc+WI6MvlkN4v5ZnZl+Wl2aPlsdmsyDPlvdm9Awz4Q+XN2dD/8dnb5eHZ5pF12fBMLM8L5fnaB+YF2hPmEOZL5hjl8+Yh2jPmLdo/5jnaSMwn5kXaW+ZR2mfmXdpz5mnafQTP5nnajMwT5oWxGdqk6IHarR8D5qHav+at2svmudrX5sTJ0+bN2u/m2dr5EJE04dsL5vAwq+b5KtHbIPM92yjmqOQv5xXbP+ch20p3tdtTcXXbX+c522jic+dF23vnUduH513bk+dp25wd/+d126/ngdu5UhDtR+eR28/nnAtT56Xb5NCf57Xb9+fAzZZ4zdwL59UkN+fd3CPn6dwsTwPn+dw/6AXcTzKx3FvoGdxn6CXcc+gx3H/oPS+N3Izc3B393JvoVdyn6GAEPdy36G3cw+h53NPohdzgBcXc6+iZ3PamYd0AESPord0REnfoud0gzEHdKUAb6M3dO+jZ3Ufo4Rsj6OndW+j13WfpAd1xCXTHW+kQy7vpGNdJO8PpJSdz6S3dp+k53bPpRQtz6VHdyBLL6V1G4+lk7Ifpbd3xzePpeNi76YHeEAutHRfpkuqVjofpnd45UWPprd5I3mfpud5Y8V/pxd5p+HleTCt/6dk5t+nh3pPp7d6dJnEEO+n8ysfqBjn49TvqEd7M6z3e18O93uEnOd7v6jVPm+o93wTk6PAH6kwGg+pUCyzgP+ph3y/qbd876nnfR+qF31PqkPEYzmPqnd9ozw/qqNhP6rHfhMzA7svqwd+b6szIU+rV36/q4R6kxq/q7d/H6vlDld/UNczxQd/j6w3f7+sW0d3gArT76yngE+s14B/rQeAr603gN+tbYxHgSRjhFu/rbeBf63mqp+uB4HfrjeCD65lm8+uh4JvrreCn67ngs+vGjCHgw+vUF+/r3NNn6+Xg5+vw+vfr+eD4ycvsCeEIQK/sFeEb7CHhJbqd4TEqa+w0ORfsPeFIykPsSeFb7FXhZ+xh6/nheOCcyG/sdeGNB/1BjeGb7Inhp+yV4bLSXeG+ywe93Qln7LHh2+y8BD/sxeHz7NEPnqW14gfs5eIT7PEfF+z54i/tBcDZJIniRM0f7RniVeKQ0kvtKeJr7TQY++094n0QG+1J4o/tVeKf7WHiq+1t4rftePfj7YHizeLVBRjyj+2UMC/tneLz7ani/+201zftveMb7cnjK+3VLift347B40kBS+3x41p1KeNn7gVQAM+N43fuFeOD7iHjjMkp45fuNeOj7kHjrN+M/V3ju+5V48fuYePT7m0DjMl/7nnj6+6E00fujOFR5AfumN9T7qHkHTsv7qz3g+62EvnkP+7FFBfuzR6d5Fj/ZYTj7uHkc78VFBT+b+715Ivu/DKn7wXko+8R11nksMgL7yHkw+8t5M0CYka9AAfvQeTn703k8+9Z5P/vZeUIHafvceUZacPvgeUoHfz1T++R5T/vnNfT76TsSMqj77HlY++95W/vyeV779XlhN/D7+TaheWb7/Hlp+/95bD5D/AJ5cD0t/AV5dDWS/Ahw+3l5x4h5fPwOPlN5gEJxiNT8EnmF/BVE7fwXeYs25/wbeY8G2/weMev8IHmWMiV5mEaaeZv8J3me/Cp5ofwteaRJ+fwweaj8M3mrknN5rvw4ebF3b/w7ebX8Pnm4U+N5u3Q8Oj38RHnB/Ed5xPxKecf8TXnK/FB5zfxTedH8VnnU/Fh514LB/Fs3+fxded38YG6WMq/8Y1Ip/GV55gdMeej8aXnrO6f8bVZj/G958jguP678c3n3/Ha7KHn8/Hp5//x9egL8gHoF/IN6CfyGeg1DB0rL/IpB6fyMehQy7vyPehj8kmVp/JR6H/yXeiL8mnolOhP8nXop/KB6LFNw/KM5/vylEk96NPyoejdV2l2hejv8rno+iwf8sVAK/LN6RTKLQBP8t3pK/LqevTOR/L16UfzAr+B6Vlvweln8xnpceTT8ynpgO/P8znpk/NE7UfzTemr81jkf/NicX3pyWof83Hp2/N96eUfe/OJ6ffzleoD86HqDOkv863qINmr87nqM/PF6jzSY/PR6k/z3epb8+i+Xd/Z6m/z/ep79ArNGeqP9BnqmP/hL0v0Keqv9DXqu/RA2Ef0SOVf9FHq2/Rd6uf0amSR6vv0eRJz9IHrE/SN6xzGr/SZ6y2bX/So+7zxl/S160v0wetX9M3rYdLJ62/04Nnn9Ojaw/Tx64/0/yQJ65zOReun9RfT5/Uh68P1LMdf9TXr2/VB6+f1TNZI6RP1WpOF7AP1ajFP9XBCn/V57CP1hdiz9Y3sNWKX9Z3sR/Wp7FGSrARL9bnsZUj79cXsd/XR7IEMBeyL9eXsl/Xx7KP1/VZz9gUA2/YNHaXsx/YZ7NP2JezebPns6/Y5Def2QgXV7QP2Ue0M4gUfO/Zh7SD4c/ZsNc3tNPSw15/2fe1L9ontVQoj9pd8Oe1r9qXtdAaxgv/2te2I1uEfA/bFoM3tpQTP9tjbW/bh7b/27e3L9vgJY/cB7eP3DAqR7fTyFRPH9yHuCaOF7hT+Ye4j9z3uL/dI3IP3Ue5E6bQGr/dhC+P3ae5k3VnubR8M1k/3gaHN7oTjie6P95num/el7qX1s/ex7rf3ve7D98jj1/fR7tv33e7n9+jx2/fx7v/3/NO3+AVV4/gN7xzbyPjz+B3vM/gp7z/4Ne9I3YP4QELn+EnvZ/hV73f4YP27d0P4be+NGOzene+b+IHvp/iN77IAZe+9QY/4oe/NPcUx3/ix7+P4ve/v+MjhG/jj+NeMQ/jf+NLuvfAk4Rv49fA01aTv//kF8Ev5EfBVhX2Sr/kg5WnZkfBz+TVQ7/k9yzXwj/lOQkXwo/lc0JP5ZijZ8L/5dTuv+X3w0/mJ8N0Ks/mU92nw8/mg2af5qfEL+bXxFNobGZ3xJ/nMvYHxN/nZ8UDaZOCp8U/57fFb+fnxZ/oF8XP6EfF/+h3xiN2ZABf6LfGc1sDiG/o98bEAF/pN8cP6WfHP+mXx2PqZ8eP6dVhT2i3x9/qLOrP6lfIT+qHyH/qtXz/6tfIw2QEOi/rF8kf60fJT+t3yX/rp8mv69fJ3+wEEU/sJ8o50KfKZ8qLELfKv+ynyuS3/+zXyy5w98tXLS/tJ8uv7VfL0/5P7ZQeL+23zEOJL+3nzI/uF8y/7kQeQ9XP7nfNH+6nzU/u02jP7vfNp83EZn/vR84P73fOP++nzm/v186Thz/wB87f8DfPA59YuKfPT/CXz3/wx8+v8POeP/EU8h/xN9Av8Wder/GH0I/xt9C0ZvM8f/H4/01q99Ev8kfRX/J30Y/yp9Gz+9/y43gP8wQSQ2ev8zfSX/Nn0o/zk7jP87fS7/PjT+fTH/QTQG/0N9NjTh/0Z9OrXrfT3/TH1A/099Q/9SfUb/VTmU/1c0H/9ZfU86djU//119VD/m/2B9WP9jQiNA/v9mfV6Zhn1h/2s6Mf9tfWf/cH1qe6r/dHynQPX/dzd8/3l9df98fXj/f07W/4E4Mf+DfYD/hn2D/4lHlP+LfYn/jn2M/5F9jwSa/5R9k/+XRx99l/+afZoSDX2ccyD/oH2g/6NwvVj7/6Z9p/+pNuP/q32t/647Ej8bBZ3/sX20/7QNkP+2fbpN1v+5fb7/vH3B/799xP/CTzT/xH3JSXMDc//Ifc7/y33RPpUzh//PfdYz8H3YMgD/1D4s/9Z93jYT/9l94jfURSb/3ZElfen/4X3sO6n/5F/UYTv/533zP+cGWf/rffgBcnWfm159/f/yfgD/9X4D//henX4HP9D//H4M//9+DzLNR2lAuQY//Jl+Fj+BMuE8ZY1zatl+HfhifiBEV0P9vXB+JTiXfic5C1d8Ohg9NjSRTPDuqzpuRIE6djJLfjM6TX41U2k/1EVDNAYHxUOYPRhrA34/lPqRxX5DQf86vHI1SrwyOe7WFhdHNvVZfk59wn5RNbF+Uz0dtIR+VzU04L4BvwdpflyR4H5fPMQzTvLr8x9+ZUiS8oV+aT9CA3R+bDKgQ+sBt+cCEMpANH507np+d0M0B+V+ejsmMeEzIUphfoBJrjND+4d+hVhPXbpBODc1OPoEq2qZs4h+jz7f/DJ+kzfzNvDI+X6YTLV+mld/fp06xAvq/h1+oklxfqRCujM2MzB+qAbcQk+UNn6uUqQ9vDihfrI8Rn60V6I14DrFNZIyQWdDO8Q0h36+N2ZaqH7CN+Q/P0wPNZg0GTTIfskFvTlsib5+zjc/QEk/pvElftTm8X7XxOptp37bFhc02TPkVqhaZn7imQA6u0dMfuZGknkMW0h+63aifu44VUepNiF+8lLPfvSRsn73PLY1RX91NYA0oH7+OBnKf38CMgI2Su5bfwc5knTBOiU5R38MNA016BPABzIDT0DWfxPj1H8WOhIybEVZO0V/G1AnR8MPjn8fMxv0Z38jNO5Eb4wHfyg0olq3X1V/LF8CPwg9CQffNlxGrhOSONJHWH/4fzg1Pi+DNuDHon8+MfxJ8TXof0IHnEVZ1i5/Rz/7TqqF539MOzp/TjVbRlY+7wF9XAh/VTftRQXcKX9aU6WG8/U1MkC60X9hRosxxDpLf2UzS39nE5I2RTKtf2ul+X9uOdt4w18uBynryn91iMRBaA5XNIxW6H97QEQ2YVbcQ30yAgWdQgk5Y3+EPHZYIDnoOhV/iTt0AWGGUH+Ob7UDRWEONrqRQEKnNcM0iFrxNK8U1X+b/+h/njWuOgA4vhLuO0fTi0RPZZV/qAVDNypSXRcKW6F/rz8Wf7EFlDt2Urc2oTIGQ5M11PqHZzxXMzQINuOzyX/AMtiLb3/ENSU1QX7Df8lD9Ft712AyZDJPN8Y6mgdONJFd0jW3OAmI3X/Yne07o4xTQKp/3TJRR3FSJuNHf+Mx8jNnBcl/5zrFcBahw3/sM0AzBortf/HfDH/0QfFDtjNjMq0z3X/6WCTjIn/+tYOAATTQNeNdRYAGQuxTkj/URNA/ToAMSMU8Tgb0gBA1QDxBd7yAFUT5QFc0jjQHV20Q9zguMdc25zcOZvyAIlAyBYmmJoAnZp+AKjPRQzNAIzeCPEyAMFNj4rKANDg7kjM+noA4oLtAiTYdPbxLxjX+TIaAQUBPNRtbL13UM+k7Ol1YWqSzrUUKTAoQhzkdNc0ReTW4R76tAYBVQsFosQwLVdGAW5eqNMU7XzVuOkk4JzxtXxB5woBmtQ2AabKRgGxmCZ3tTTVd1EUKgHI31j5NN+9tglA1XhLJPIB7BJVB45FegIA2hDa896qAhQaaPBBBl6wYgIs4n0QU0E013TPagJJQJD36Vh+All3+gJlVH4CcPSyAnvvUgKE2JjNaP9833BF4C8SAqE9tUb3TFjmwPOIx4n3tgLE/ZErdXvk2oUmCYhiAuNdgbdqAvDPVW4g6SDX0Q+iAw1PVRBQGyTCdhJaAyjmdNVM//EKcSNxFClIDWnBChjeuPBc91TSjPqafd5ziUkY99YDdO3+A4DPJgOJ3UUClQJiA5l+ggOk8Fp46N61ViIDvAkZA5jhdbdK2TT+QAWl62YD5QLE3CVtpO5ZF/YD/NO6BAUbJgQRCbFW5Q4OBCVDnU5uz74EOAuKBEHfagROowoEWQFGBGTxrT4U0BoEdSttBwjlHgSGswUUMegZJrkTYRI9DykxbQcTIjoEtOQMyoH1VgTKBeoE1NJk53TTdNv8/v0SpgT0zSoxTOk0Fk4bGgUQ/9+PbgUhnRoFKT946SBDEgU8z+Dx6Byk8kAnsgVV4qoFYMriBWjgtgVxUvpRNgWA1rz8EQKyBZFbNVguXhoFpTx2BbEGiOob4eTJLXRQ3IwGwXqsBA1FSQGg+nIF6PumG84YMpzw1jYGApFuBg9ycgYYxwYGIhLGBiz2jPWUBNEwyB5xcEjxvA3Q1YT7HOS0Bf1A3NeIy+ETvCYg5xmmUNotvBlVjP61MkDMD/K6BpxhxPP85jctgga1UL1mrrVlbJoGzO5o8/zI2OOYzDT7TWUgzukHG/KmBvz/FP6ZpPYHEBb6XhzhigchVLUnhOamBzTTgLk4zKhJPMg032DImMwg5CQ/1gdk0CgE5NcABwIHeN3ODEIHieU8Dc85Xgec4GzcJlFOB7Dw7NWwG0jndO7kz6TqWQHw1yFvsgfg9PmujNPU634Elgf+WwESYTemCBDqOOFJEHUPMeM2CC0UFO2E/LVohghFIyGsFghU0j2v1gYOCGvyRV+1Dsjk2O29H1DMhPLMHggdpW4SCJz2T1PlWSUEXOhiCLTHWNMYzyDzsAus2WETuhJWCN0GENpk2okUFOFA09TIHOBf3rIJCi3uCRQlbOA5wuYJKWXJDODRHq76CUGJfglLd5YJVMyfQtPiAglo5EvbBgl42hkVgRHZat1WDuLoJiE9ZWwdGCQ/1NeiCa0b/SY9dK3ChgnFJFzgJE5I1/YJ2Pe0+UQ/kPKM+76jcr8KCf7MngoJXPIKFkjOChxHqc6c426jNgo1t8Oe5OXR8NTKoTEE94DZiVdo0/0BcD+NAXDhUb8iCnjJeN72CoU4PQSY0WoKmQak0ykHKPIJWemdpO3NK0zO3NNmCsTSQOV9XM03WPeE6sTzlgrk1gbBLgr04NUP6RYeCwkfePlE6oYf6gsg6gRUpRbCCzW3wgs8Ev4LRPIw1NksuUs80wjKc5UqC2j2igt1ChhA4AncxxgJpn+WC5VU+QRJd0jYJEws4kjols5+C72YJTArwgTO4Zvg7qQEHgvcKW4L5X8BBuzO0McWShoMAPYtId1XDgwUDV0xaOvgXojWlVElENTPMOL4MqjfjjLyDEzOTgxUyJJRqgxkBqzcJOBjoLTVWskdFXjstgaiDJEABM3ZfwTbfQiVDDTYTTApJSoMuEOaDMTaYNsMCTj4x+SWDOFbNhUg2bGjGO8SDPzh/q4qDQ0pNZ3qDRwQhg0pXaloPg01qA0Y1iE02BlI+O6MG32oD4oSDWExeTutiHYNdPBcx22MiQAhYGEecO2LOW4NnNJxbykhANDpRDDgtNv1pqWDcSzg90TWANNwhCjDWUMBcVIN6bPRvCIN+l5mDgUrkOZw0jTY2QKBkPjhegKODi30Eg45vCzh7FGIyh4OTF7ODlh+pS0Qy64ObBpZhwli2SAdE/zHXODVCrtUXg6ZKq4OoQJinXYOsgGg3EDS2YDaDsjYIN7tDyY5/g7g12mqTTdY6oZKPUCQ6jDWrg8Ea6VAzONE8dUFMMO47kTSxekqDzDuUP/tjPTsvTAyekIPUTKWD11E7T0iD2zMYNvRfl21h9y6D4jIB792D5gG/RAGD6T1pOhM2OTLmOtY3AjK3NMVCLYP0PQ6D9qAyXUsyClAy2xWD/QEpMf9D7TybPhuEBDJGQMAx7jYVOsQQp0JdM1pQ/4QOSTl3EIQRQPZ6eIQVOSyEGDjgLRgyHD05Gj2EHgEyRpKEITX9B0k1VYQlko42TksUTDhZ6IFOhC1V5TgGUf45it30N6eENDpUhDZcskRWT9k52IQ8Y/C2RIRAQc2EQ3uRhEZBFxCn6QcB6Q/0Uhn4joRPQARcRTT/QUyEVEuJS78zJj9JP94+NzgQRDU1o4gMhGAP5DHwAkVR64RmM3ZN6jJSRP9U91ImlNKEb03qhHI3Z+Du6eChJkDMhHpFJVZpNbtPPscfhIG5GYSEOkwG6zkEN8iEikCm8yg3CptfhJBUMTyPOQUuBYSWQcYzYzzJVgGEnDcoZjo1Rjw6Q9g17wlVPDZq7jgMMcVfLjMmc36ErEl3ZD4yszqDETk82c+aB5w8SHd7AWnXYIS5Pq2Euz9OhL04+zn/hMBmb5RohMTXs3johMhBOzLYPrU0IJ17hM9y8ITSN4JSmQNWA7wx+DZgRG/9ooTcMw8EpjI3O+422DIENspJj0D+Tq6E6DhGhOoBebFlhO4HnYTwTdHn3oT14cVwVoT5Ao6E+0naPeFZn4UAPAWFAnw1hQWKloKlhQk0mEO/Z4M6eTc+Mc1MPDb3n0iFFFftNvc2zgFylHtNF4UcNywBhUq8MrGFIXrPhSQ9U0H2RVqD1oUq/Q6FLXaphTBPbUPMPNlA/Do0SdxF1DwBYe1GOGBlhT01cDJmizaFQjwgMjU1HDU8RYeFSVUzhUs9vHHmhU9ni4VSb+qFVT8VhVc9LDcMhVo/gfElhV43j4VgMwgxvjQUMw4RizSRTx9B2j3wV1gHKTMNYJ4+H1COVUg+x4odN+UYcTdBURk5CDwSOq5hzDHEOZ5g3Dhm5fOFgTfiO5E9yjxBPgxERBEHSyQ22zOT/BuFjkudUQABWT18SY8/FTpfTNY2z0aFhZk2OTmOOXYRe0RASRIIaIWhdxDTLYWlNis2q0EXc/YCMz+Oqi00LkVAprM7+YWyNbuBTYW2Oo22wTSmRJx65oW9PvOFwGJvO8Mz+DfpYaE5IjSdOWABCGM9R9RCHoXP1QA4VFU5NdRAqoXWAZw4cD7qREOF2zYVSuQBJpYgOA6F4V3UL5o1rqPyhedBOV09OeQ5EjhaQIWCwZDJhfGiNYX0RJk2WD2YPP9t8DlmPYAQuTwYAmlDlj4hBcMBLjsAR04/vzhnQHberYYKkNGGDTQWOccvm8/dhhNKYHWXhhcR6gN1Ab81XTsYROGGHlz6hiEGQTabPCA+SzzZ9z6GKUJgSzlEOAdHVbgOwEQEX6ECVWg4OdE1CzlShjcPVzUjPmoBE4Y8SzJPZDazhkAzVkGcQzGGRUVYhkg9SjewBeDXh4ZONr9U0IZSO9xEcWVNhldKS5yfhlo5j4ZcVkA+3zJtPpV5ZGQpvU6GZTXKNvmC3D+tNstV50cfBcNDDTvOX+tCpFo9YN2GdTbFOvo1dDzdhno3FDyNBwhfIThrRISeHIaDQI84wjoIhocBvkpwMdc96IaNp4mGkEtjQVO5g4aVM246f/uAQFLjvYacXbmGnjwHhqBDnYaiin2GpTsIUiI/c5+MO0cC4oasB8WDmk7WM1Y45QJLQ8oFClbNB2c6OUMZD4+AkTyzaJAzKDihQBON+4bCN62mzIbGTAs91ESrhspBJne1Weg25IbQTuBIIYbUOsc8jUncNvsxqzwGaHSG3Hinht802obhNB45YDhrCXFHnDSJN5kHZy0iTNYz9zrlOxtFWkRqNgt1ZDqObsE1pjWTTBey5j2cR8A3M0feimEyNjpMMr9s9FXa/UqHBjbOPMKHCTKchwtBQYcOTak3oblIhxNc8IcWWJE2XjuRas82mYhKRP87kYcfXOaHIuOwRZ58B4cnA3MyQIdiQUZoHAMPPBZI0z5NO0dMOPP2QfY4Uoc3ileHOmD4hz1MOBDdNt+HQUBJmv2HRQ+GVouHSTONNxRU3zL3NcE0sji/SNdAE2ewh1U1XIdXNFYMKUblh1u90svQX42HYG7uh2I2yJ/jh2Y3uw+IM907WkYuOR9CWTsdP/w82TdLTYZhEDiTN1AzIIlph3k0nId7NMs9UzuZO8pBSk/MOM3Gt4eFTnuHiFxsQod5boeNyhEGr3ikh5E2t4eTO5aHlUEXOQl7Knkmh5sGfkKBBZ1ZvDNK9H859v28NRSK4kvyNgLGKYeqRDU+yUGER0oyNzhIrJGHs2auMihFzW0naiuHuqVEh73oEIfASQM4sete+zGHxkJgh8hV7UG+h8w9gzIEN343jWeMWmM1JT1CMtDKKYfYN5UzbkGVNtRWzYR3h+AzOjsmh+OSn4fmAbdy0vhIh+uFXYfuQAHvE4fyQbhDNEMHNsYy3Jsuh/o/0DaDOQ5CMof/OFc35zorM6lbtU1QiAZ794gJR04zNlmNiA5D/DMca6GIEjHDQAE20zctQB2IGTVgB3FBmEGkiB86+juVT7xJ+RhxNc44p3YsTvGIKTHFVe8BIktEZteIMDmFQeQ0NhDlMwZK1Yg3P+SIOeL4Vfc2uufHiD9S6jegWt6IRDjbRHEzZKiHiEp2LDfFiE41k0tSNeA6tUVebeBWcYhWVow684a/iFtICQJ1QcZNtohgRSk0wUdMRkDb1EIyRoU+3YhqVWOFkYhuXyGIcDPpNzlSZjhkCK00Doh3cibtt4h79JiIfnMQiIFDAQYGQXRtaJ3oP64+6JldVpKgiIiNX/mIkFY/duCIlESTiJc5SvMaiJuIp1fbNk+GFYihNU465zXUoiqIp0pNSwpd1GcgiK05XoivRHNDFkmpN/mItDnLB4UHw4i4MuMz4GHQPw8FZIi/BTc77jpRUcZHJbGYiMg7ygJ5OC5vKjf4PfiIzzNHPQ5jvjsFNpWr/YjYOf4E6jjGAiQ9PQE5iN87Bw8/Oeh5z4jlYkRGKTVFARBRDY+kiO1cczkGPjMvxjSyNuo2yYJCB787UgUDiPk2L0NiT7iI/j3LRjtTjIkCPTz5OXR1iQcIZgFakb+3GEncN+KJDzNBO9xCHTRTnjeJFsnfRic2RAFxOow+fmshO0KamYkhD9Y3gYHuiSZoNIkp5OmJLF09SuOzPYkxMmwykbubiTZImkEdNxBesDYJiTxDv4k/sRuJQls3iUVT9TgtR5RGj4lKXwOMY4lOaAeJUUDDiVM3AolVUgN9vUavPcteEjoUVuBB/I8/DkPRy4liOSk4rO6+iWdRAPSYiWtWj0P8MkOJbzwQVdyJcgEiBr01FjI/RSQ9fgOyA9pRQDYnQvCJfj1FQRxsyomDPclKmUI2NY9MMomKOPZFaVEZXpGJkDSdiZJE3TJsW26JlsnfBDl+vTTqAutLsWDtu+SJoMlwiaM6GDNKEOZT9A5XctriSYmsYhiJrjg6SNw2bDVjibMzZEDRUUmJuLll7FGJvDWuYmGJwDrrATw7aonEPE43Pj+xcnY3ujcrSCoznonNSc444QW/ik+J00kDYYdmionYARI1+joCM6I7uTjmZlOJ4UTuT7xGxgZ0OfpKEjv+MwhN6bcEie3cTYnwVDmJ85MkifZP2TQWq+CJ+5bGMpBDankRRQk6djzdU0CKBZEHigg684v5igxQoIoPRJ6KEToUOrs3VjMJRdFCuEEzNrA4qUX0bD6KHjObTNY7vDfrVYM0/zjVOtRO1lgkoMCKK0FLP1U8Sjg7ijFCNDunSco6YTp2C+g+10qDNn9Nam4Pij5CkIjUZNpq7gWcP6BLS//zikgFvzifN5gS7nlkRLc8c0EUNjJoUIpUQpD4h4pYnoCKWztldZ9S9IpgimJK1UmMMdU0uF0UbRiKajeiOh9lizcPM7s68nJMinOC3DYMTamKdzvnPeE1HFaqin00TDofs/OKgnESNrZJkD09ENRK1QGiM/dDnYs9io5Bi4qRO8E0oYqUlV43dUIEMvEx14qaOIZEBj+Sip80MYqhdIUDfoqkM0OWPoqoZcg9qD+tRgk+HYquB78z+ZUsirQ6NzTvR8KVSj21msOKvLTzir81UAe/NkBv+YrFOmo0rFX3NzxRQJrDyJQ2UVm5itDsO4rTOpFPajcdSXdEFYraNoaK3DYrDy6K4Arf6gOK5KGJRFY2horoYnKK60DjUjWK70syNkU0sE0nV3eK9jDhPno5sE5oivwDTw5XNrsBSTheUVI4cFhFiwaLCFPQiws/JG0//Qsy/jKppx6LE4sVQf88t1VwNlg9nEO7ASmppYsf92eLIl7QQFpBYjYliyh+QTV3DCs4NTfkNCSLMEpcgIiLNDMTOUlCWYbPOeQTwAcyizw/lj+/OHsFFmLqMlVeETQEi0U0+g+OT0xNKotLZBBLJDU1NlxaiEtBPvKLU4tZi1YzCItUi1oVKTsHPrsyAmdFi2Hyn4tkNkRHDDXui2hHpAJkr8o6HzVnQTNTujKgPtxHcS3EZyvp3Yt3O0p/F4t7Mk6LfQkQTz8yHz70MypIekEUi4U/dUF2i4lZBTg1YhhskMsLi5ACW4swi5RFQDP0Nng5bTQjOZ42xjSmNwlJaT8mNM5HE4ujPA0HKQG+PTlBfDwgAuCLqxhxASKLrjNLNrKSjYuzOKk4EDh7OOJBS0QhXXQ7Vk95i744RovAQV054EkojqqLxjXBAUsORDVhNmgyQUOdqWRF1UMqNIrAUovUSByL10JgR5cNc0xHQscBBHQFTZg+rD6mi+JBFz4oVN6L50aFPQ6L6oGNi+3CbYvwSU+Pkov0OV8BhUqdNrIzODcTT1tIQzn9PiSL/zRHjAEx355vMws2sg9X7FCMCTYnMqw7GzKgphqMEDX9NbhEKkjuUDU0NHOnPLqLFF10PvP0zwjeO0pAXDJDSkYzUkb/QEI0FDb9NTxO8Q9XUa2MLEtRRf5abnsqNpSMMj6ANglIKkSyQoqndYw6QyrwuY/MjEBWfIxDAb+MRTqSjEj8p4xLBtI8tYxOQdNCpT/7O0KMVDHoPG9KtzNLm0KMWzlUPPZUBDYEjGA2bmTaL39HxYxlOmpObYxpBR2Fq/sHjG7zjYxxNZJd3Ix1QliMd0nCjHq28Ix9PqxCP4yBS203rzwuNRtDu4yHOCoHqU1JQoFB6TMRNA2MjzXxjJEHKUBCVWeMlkX4OhEOQzvBR2F/cYyePfAxyjxzOks0KJFHjKYzsET5jKlEBDXOPShtYTWlSdiMsDgQa8wy5jIhA6xQ6z+CA0lAjJKiyB6MvWbSScKMwQlIQIA2uzXi1m6MyDLrATgGsozMNkBAVDdnMjM53DYyT3857Fhnd4pT5niAjNo4WQpbNU7JjYzgkieM4zyOjOVM0VDVjOk2wS+6RGaM7jfUNpQK3jIXA1Zj8D/iN2lSjwdpQSZsdecLjP1jDI0ARv9HlWp7by62V40HBY+NCgEcO6E+zTACQO09i0nnPCI4Bz7ROhVNgI0YQVE2bDoT0xmNHkU0S7Q24jU8SNONJFP1XxA/H0bSUGk8ujYCa5dzeVbNTqo8tUt9S7I+yY00ShKNNj7jOyTYGI07P3U/MUwM0jiNQU2GPS3mk41GQJA44ktjSnBFAlbuOPpBPzTUENEFHVT1OFKNVU8QjVhDDEGYSVVITY1eL7oyDD7JToE/umfYT9meeY1oiQKpzY1sC+iiQ41wUKI92o10XwKNdn1xOKpAao17Mmo5Wjx0VhI/0LgujYNj4Y2G+H+NiTXARzJ3ijK8WLGNkDqFcnYFvWBLjZasso2ZSpk5QkFTjZ5YxVsvVJ9dmo2kDeo5L2z0R8M5e42qNr9baTm7MjEQRzihVhY8O28WjbVHakYqN39POT5tOMgPhjWDM4Br9UcfewGNw0X9P25SXQ9Xjcg4wD/xhzFoWjYfNlQ0MTujOAY2z43TOZj5wo3XBb+N2UVZN9xvP43eTWdIUzMpQ7aPSY3lMgg0CUjtOItyNWaXje2sTwJVNpF8Lo3zMfJkbAcRSbCN+YbAjfxCYDL3VsiOAUUeq/+OBWXWZTE9XEFiCltzTjwBWkuODzm6PaFvcI4UOAxJGY4YQNo5ZjP9U8GOHkGEWSw3dT/mkYaOJS0iD/QzCD+rQaI1zoYMA0sBq44vamqOMkBfjjQ79TNkOVRroTpHTqc0TzG9OkRAVl1YjkBBgDTXjkSqpY5HVYmOSmJfQeg1a1BCPEzrxI5SOeg6ji/TSNRMW45YORJtWDmEMkmEEzhiRRT4ZI5iOhU1cJRsNspPAzpEb+ZApkC5YDJKEjWRT640mUnVNzc0rE6NTQ46ITS6MhdOn2FgjnxUMVBqjoCEg46DO7+OhXwXjoh4Uzw7jguOjTI1QrQ27TIAQ0JOqpoujpZBOVYwbgwyTUKBNWtXv46fAig4rjbGjqM3qY6lhBcQDwc+NbpEJouwjq05dj7Hf+eOsgETSENVV3evRpgzQDgpNWc/ym6WPqwIaDSmjsA/8VyLjsQzzToSS79Q2Y7KQoxDK47O6VE1Dzd8RMBLHFCAjtUJSNoLjtkCLjNjPpFahgb4jt9PWznHOAgz4EQdMtk4OqsoOGSs4Y7rAQJCvjOdVMUzKY7xMegyXziBjvU1sFdtOIkG4Vo0jvuP2Tb/N05k2u0ZD/QymTzPAS46hVG8jwe7wT9kgY6PDIAxjw8ydHKpjxOcn6yhSPdNko8ZNb5ffjzDAUiPHjl6jyBLaHynpOKPJTbnOhNYMGNoTFVoWsZwOFQ/8EBuec4CWDo0M6M2iQ7A6LCPODI5NUpDnTphjz1hJo9ANMg+po9DSqttlY9HlCCPSkBST4ZlTI9PC2yBjY9TRi5SGTSSNkViGI9ZEAUzmEI2+Agvulhqu4CPYnstTIQ9L49nkUSPakqdNNky+kW+CGY4F49xTfmPdB+pSljoiTkFQ5M5no97PC4MKnwBj4BIaPCfgpuPhTuRfKfyJo+KaXRhf02Xj44BSjx8Qh0z5j4Kf8KPlgEKNiZADFWAR2pICzYlj59Su4+hPttByg9hNRePp/wbkrxASY+Bj607rDhVN9hR0TSaNC86FY+1M945Ljl/ZYtFOHTtj701rhE5SAVSj4/CSp2PxHbVNStG5I/IUA6Py0Ynj82QMY/QEA9GRzzZM57f5NtDj9iP2pK8gueP3jcdPic6yjakaD+P5bOBMhQx7jUyRmJcbMT6j+7h+TH8BZM3Ij/J8OaP9jJTj/iNc110EQdA9TIQAieP/8ankAIynEzNQdqQBpNfkAlLXzvQN8a6xplFNNRjmztZSF2QFD1lP542S0ccRE87P1oPNKM2yjHjNqk6bT+3ETlcYpAlVec74DbFQQk2kUn5NMcwkyIYOEYx4wcBRGo6mj5qOAuUe5A3lp4GoZA7O4w3NFLqaFGQQYwZkEQHnMdAkEgzzrhukEw0spBOOfZHajV2QUQ7bzUO6BBKg5BwM7mIQlldkFxGQIRrkGAykTKyOHVHNmHtP38zJzm4MzlHClwAkG1Y5TV5Bn41DDP+TYk7kGelkHdrOLGQN3FCLQW9NpI9SqcgOxIGr5CD3GtEJDpJY5tDkmTT0yOQjI8XbZ4P/HKCkJIPL5CUP45aHpCYNSVPLlbuOctJvJCeYbU3cQgl8OuQpEBxQgOQp0PLQPBObVqNM9k6InVBMkVxHpCyRmdA5lwyRmI5mkd0PYE7vDZrAYA++ZC+QVOQwU3CAiU1WJDFc0WQyDICW3tPyFJxQvQBHJDPP9CQ0jXeNVOQ1Ue+NpIz4JDZQjI8FTU9jZ0y6YXVOEgy3EVUkOTluJDnSFNX6D1pS5g4OmzHoIiQ8DUUUYo4CUUaAXhQo0+qNSO8QG8C9Azec5D+OAxM50H3M/E4dG3TkQU3PucfkQk+tTaWZmVConkLkRBHET74MehQ5ztvM6E5njM7/+yRGwS6ONJVGGujXkiRIk8akSVT9T7cMcXmtpErR8dwzDk1YqqRMIqe8sRDQ2SKkTZPUD/rkTkBsAWSkTxV1pE/cLWRQj3+cI5P2DmqNlEzQzwX/TGRTLrIkU8z5GXNWWhS6j0gM405bHHEkVl3uj5qE01Gv2udBR28I5FiOaNp0kzNbdNInNvekWpOnTTdPfWNrJFwPh01zo8vkXVs/EeXSGORemjiN8k1YTc0kX85qpGCOfY8FTaQPBg6szlySXfippGMTNRAHoOOkZE4LtYCkZUyR0+86hORmuxSkZ0v0zkzRO2sU5GjODBHw5GmQTg2szgjTutbopGsS/U6SmwykbF2DJG0O0WRtmLGQu5HBlPpOXo2ljWIBJyRwN5yNvduj5HFP56d7QLrNwg4xJ71kc1CdwLlNM1E2Jk2kdQBD5HWveiR2UuTDlY6E1lvkd801Fu5PpHTyJHlNZX8p5HpT79DE1X3W2k85TgtO2KR8TpIgdibD5H222GR+ZH7506R/kPpPUaSATZ5VGEGnhD1NjuSB0NlO8EBSJILobYCLkLCOZOSEXFmkhQz5lZhSZU2bTfoOSdKwDSrWrv5u5IgNOwzoYeCR59AFZInOJe165IrEws2ZTU4OJDrOETxNZOSND3Rkjc8dTyzN8cCKJI8V9th0FJxkkA44c0HM2cyaJyfNVM9sDjkQllJCTZRTQE+f1TWUvYzHJJRQm1lXHDjayIU1s0NRjU8G0JsO8w7jDI5RU9AbzU6S0E2IGObgy+2NpJnPLqwYFIiRo+4mUt/SFMy4AJFVMmSczeIknV0PG8tknk6t92Ykn021TqJeMNBDzkRMd87v5KFib6SiJimkou9WpKOPCQ7AGoDPeQ7ljhyP9lEIJKYNmsz3+Zwkp05d01WSPc15ZKiM5hN95KmR+EQHJKpVKiSrH9akq9uBDZuB9FACDTDsiFzvJK4ak+Su5K9NihTADUyksE5dDHEC7pN25LHTNY52MdtksxUjGCkOAdSAzTtkvKS1GTVktZJ2DvPMlKP2THqdQ5DmAFukuA1cG42OluS5ELaPnM93hNNQS2KyJLsk0JPIZNEOvk4F1GQSMmTSgNJOnQz+m2Ckvo49jxvAj46IjNEMew3rdNxkwRbiEMTSG9b2ZMJVsc7B1S4kw5CT5MRCUgBHTegBn42+0GRTJBB/D34dseTHUGANTQybkOdqbKTJBNNbv2TKFqbk0mTLF/FPuozKDnYkzEyP0gHOdcC0pPxWvCTOZNYkzxbBzI/kz895JNck0MHDDr5k0aUOpNJkvVA5zI/k1KTT2A/k02TUwJ1q9KTV5M7k1pRGpNdOvkyPzgHOwe8oZNjPk2TZZ18k2hGWD6OWoYQZAUcNEw3gWdw00CTczdEN2I+u/vEBteTel+bBOqTfkyDuyZ11chWddA0WpOFq6U0QJOIYshHhpObk45iC5ORMvBLluXlBgAtGH18k5kzjToPk5xe9ZOfbPQ2IDSjSAU9gevGk6dIX5OqeaWTrdBaMzk7yDbKC/dROVr2O784zZO3PiYS05O7MsQy5zPdUnKTwAGvUdqTxBINagPpu5PJnDY36myCliPcE5Pik9GUs5PUPd6T1md8OS56wZPbSZUtxEM0pzrcE5Pi3qSUszm7UP8BG0CJN+hT9F8hP6M0xJPuW2GT8Mkbk/NhiZL0bx01M5P4lHs0yR+pXL+T/kb4roCUAjVbPp456mz8N3yduZQKbMYCjktmlA/dOpQSk0eUFT0TlCqUGUN3QpyUHIGGDKkP04TalCI8FJQkWe6UOQFHQEQ/dZQYlCxLX5QuPBSUJJQxOg5EO5LplDaUS5Q5lQSUT5Q+lFiUQZRbN2eUWExhPMSUQ0/QlDiTR5TrlD2UUZRYPLCET5RDlFY3Z5RYlEGUWzMpSppE8TmSSoOUYUVeO5JEKDJgcpJ3qjV6R6SUaknklG0+lW7wlHEzO5HgT1SUdgY+NlhHHLzqNO479TsJmVKUgYViMhI1VFpEa/VPzJSJS0E9PjcPlI1xtJSQXBwR6j3wkfo1zkRxPBVA/Dv7ObgzJ00blJ43zpSgVH+Uoz1OT4NpBlm8N/I+BEtKQ5Z4TZSuOguU2GRflLI8gpTVS8OUt9K5lLrtiZS9Pf5YhjcpaDiU25TEuuSUxwKOlQOUy0k9lLpRRTZVlOSU0lPvPIKU1UHkSY87vzP9lNqUw5TdXqtqmWbfOGwzZ5TQlOVJj5TnN3GVA5TrmQGU7nFjlPFOgJUBlPaVBPTflO2U+2IIlP49lGE7OkyVApT3ST2VBkeVBymVCTUzRRo0opUNVlc8s5UQ2L2VnpUUgXiWWpXwMcGVpJUclgc4DDHbbZnaOpUkO85hH0rqlSmVHJUslytly5WOlTOVfpU29XSVOQaUOI5bYa9ElT+VcLYmlXI8ujvvlbA7UkuIlWuVTIgMlU9tsJVSWBiVVEDDlXyVWJcrlZ6VFIF4llqVqJVi1TIFnDI+la6VRpVpS4iVazbSlT6Vb5VBtiaVcn0E86uVdj7JO85hH5V6QMOVfJVYlyuVnpUUlYOVl1bglZmITTSZlZxjvzK4lY6VM5V+lyuVnpUUlYOVl1bglZmITTSZlZxjv5WBlaCWWpXwMcGVpJUclgc4DJVhlao73AWcMj6VrpVGlWmVsjNWlbSIL5XDCGiVxZW7MzKVvWo6lcA3PIgvlcMIaJXFlUSVyAO8NOqVzJ4Ilc82yQIlWPmV0zhkS7RRuJPHljSV2paDlZKV7JNEll+Wb5XnllSV6jE/lleV7pWhlfCWXJaGll6WbpYIlnCWZJYMlkyWZ5YYlmqWM5Y7eZOWB5X2lnCWZJYMlkxfVJYQlGiWE09alk2WepYAlnyWipYwQESWjZYiOPyWg5WSlleWiEn5ln2Wi0BElo2WNZZIlSyXK2XLljsPYZaDlj+WUj6wllSV6jE/leyTRJZfmBCWc5aDlj+WUj6wllSV6jE/lleV7pWhlfCWXJaGll6WbpYIlnCWZJYMlkyWZ5ZYlhmXPpY7lkiWB5X2lnCWZJYMlkxfVJZ0NXqWE09alk2WepYrlnyWipYwQESWjZYiOPyWg5WSlleWiEn5ln2Wi0BElo1tYZaPlSw6/5aSaYxm1wEilpY08KBqOUmWmk2JlpwzsDV3TbUQHpail2WX85ZrlwmXKkkaOtXsqJcPlrFd1DYhO3SXFQUclx2XiZdLNZGW+Zd5Nuc0P0X+lv2WxZcAPN5JUzTIl0GWq5bNne1PJJcul6E3q5bVluuW2JbultudrpblOVWYH5biluRRO5bmlsCW6ZbWluyW2ZbvP9mXTJb5l3mYID/ZlviWvpd5Nuc0P0X+lv2WxZcAm72XOZcElzyXB5c/lqmXC5asl0SWr5cQl0iXEzKHlxUFHJcdl7uXGpcVlxyWuJe7ODeXIENWlyKF1U6fZjqU8jXlT9SXKpbNne1PJJcul6E3q5cyT2SXWpc2P32WoZc6lwWYL5cJlypJGpdElq+XEJdIlxOXS5bylr6XiJfPl1KW+ZeIlroBcd9Gl2uXWw9hl10yuJdfNKaXYZcHvTE+65dlio6XMJdpYLFPZJdalzaXbpcDTs+XLpdnl3QCJJd2UBxPSJgfO0A7oTLbUGkyLgFIOXs6WzTzTamXy5fjl4iXz5fLl+OXiJa6l5A5KfNol5Q8GGdp2fCYMJeul2GXBzQ0mC2XZpcwOQs13pgol6YyrZgsmBKXqpfzlmuX8ZgySRqYNDWLl7MGNzXil4SXzJe6lxmYAJe/XYyXwjIUuoM1ylDFl8c6bkhAmCGXuJfNl4mX0JgBl9OYBJfWN7qjmZfal/qX3Ze/OtmX4JeKl7gyYJd5l+VmCU/YQlgFyIFqmDCXrjQxl/OWa5fxNDGX85gVl/aITZf4mBmX3Ze/mAI/Tpf/l/uXv5gCP06X1JgFOyeYCBHtl5cMU1jFTyQIJ5dylkuYETncl6qX85gVl/aITTSdl/m07QfEOm9Jj1AcT0iYH5fKmCKXzZglPYuXpJgpOkwyrZgsmBKXqpfzlmuX8ZgySRqYNDWLmDYGN5g4PuPYFNgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE5hnmJgyTjf8bOI+rzcRNkg0uZigL5qYojMQBZQz4JimPlhL1DguNktZLkUa4jWYrwXINMmYszE/mLU7wJi4MoeYulZINieYvTir96diCzMTCCXYCdgC1/7YAtf+2ALX/tgC1/5ONZje9jOY4TgxmOMzrWgNYuplcJjpXt+Y7EPKPlKVVZjxS3IHdT4hybGY90zBbfDIqZj8Bvw+HVP/mQE0ZZkEPJqZBjVvTHfYFNgTmFCZDeL9mRA5H07WmRNWCzflNkUGWZkYb7VRRzSImRwyRZkeP4KE6p/JcBY41U5iNCI87zgLX5ID9UjTURE1d5ktEeo+rTYXmTFENzfoEYuR0pk3Myo2QWGJVqg50jI7B2pSz5lAT4M8OW4QZNpDYjZAVAD31ZlKYY15VUFVPHtE+XmlmVJbfkYJsxqZV+oZmVoHEkwLmV2B9JlgNadMrzlHM+QDfplmqv+ZaZlrynaZbj0dYQKZckHDPYGZdUHPNiWZeZl7Mm9apIMhN9dG5A5WmYI8P5mEBZSZhktyAZ0P5D/RWwyZjWhmU1uZkTKXOK7w8joLoKCZmF8hMFwBonsqVtk1gc44maE98FASRjM9/AGu/4uZqVsPC7pImmLICQdHq07ePG83JDdEQ/BjA5m3SqeZul8VnVWZv1khNxAzVjYuRLnazpnHaXY0rxAJP+o5RZnOBfU2F1EMMxYv2Z16mdZEFDx1CXCy8pncAtJBnZnfOhQ5R3TTVb6Z5TZmwrFQ53MOPaJvHJntedRbDz3dPOcCjkLpmfWHeZn4NAaZ+jACMwNBL5n/Q/A/QhNNN7dQvJoFR6E/fZoIARQ0JDctOqgzaDqfNn9C8DljmhI6SD6wmhU+HD6cmhg5P+51OR+bzriAmh87fY3FmiM95Dg+Mb39LzJNOZ5FDF+VVhE3uznaN9c6Mjkd9seaNLX9mjdA0TnGM+JWoDo5O0VAE7wPmkEy60avRuM2a2KDlIg+NAwLSzOaTDYyUmVDzE93mlI7MEELRMBVY1QDmllVM0VRM9E9mVbNN86xMZpindmaZUD+QQuaaTcOUeGabThk/AiacTjhh/qadQIkNQ9olDiNWx03Q21hO1ZboksKUgMxs2z8YYkH2Ta2MlEx2ElTaDiaijaGmoxE70q8PiWTmTYNau4zqzQPMrxT5jhrOPs260maeHI9ipqeM8NZLEKjNNFCp0Rsxq6ap06KQqEyXZqrOGg2ujSeNVWasEOVmrM6H5q1VN8xwzisNtQ/izOwmrw60zZ1MwszPprBMC41JJrFBZQ+eprIPtE4V1AISB47vzsK4ug2mzbEWo1Cem5BjgKa1zdQSLY9I5rcTemp5prgMvA0TDQomuRNdUtcddCfFJrqCCdTnAgn9yya8D+1bsma9O0umvc8+zVSSMlJ6Zr9Yhg5OjUtM0Ov4ZsEOhs7jEQEawY3bFH+PedURkbqRgk2Cjg1mxEzZDklmxQEueKpmxg06/OFW9D9BpsePwg+1wEDS6s+d0UETmJLqzPINW2bKkXyMxE8yQScGBFQNZn2mzNJPWiUOjYGr5s4PO61RaV1mz4BEjsAgD6bQ/hcm0Y15EHjWvlXEJtMBBs/5nm+OAxoZptSQsSXTlTfBnGbWDl7R+E8Rk1nS5abXjabQ8FEO0JsBLoFRTv1mtqbaFaPAnc45WNlOUFBCnVPARVhh0wKT21EC1JmOjFKnQIlj5UzzDi5OhWbfb00m4BlbJuCNDGbhDvEQJg7yDZRb4dBLTeaATlFXjlmm49QEjH8BftiNjYaOZQxwkCdY2UH2T5qm5sCRgavNC4/yAdqPiVq1ZukTz9JqUqrQ7ObqjPbUmY2AzVOQsQ+r0auVhEKhRD3PTYK3zaTP7pBSDpKQcJacDnYO+AGPz+VBb81fWNbO86bxTaoP6tQ52dKm8tFmDoxNmxGXjM9NZab0gE8m9Q7NjmsP6ZYhjVTm9o+1jI/m90/HALlaWmb4jMGbeDdXBAjOVeb6Ddum+rYCZvtNB7Zf5vxNfqb84gvAuJKgy3gNJ+b+mUPm/23DJwAGBFEC16wW5cQZDrF0jucCTNgNCI3G1einA6nXZwRQ5ik4ZwVk0ecGDRlMq05xj2OnB6989f9vk2cJDWROSycJ+rwPNp325wsOFI0J5wvGumcMTPUqU2cNQV6Bj2TQj/7LcRABHe4nD4CMzz7a5acQ1asnEY70EQBnEkXCjncP/U0pUpfPGVGOA5FMsgDV5xUxOcQh06KVymcWjhVTopT+ZxfSk4zCEttMxmWoJxmUZs4a0fDNNA+fWNoL9lm30mMMuo+4zVWPgRK9Jx1NZg4wzidMt2npZx8WEg0pmEUnIE/BM1xnIU8tTHWnIg0nTcAPfWcjMg7nI+ckTc5XqaclNoGnJdt35yaOrg/VzvKQKWcoETCMjoyxJykOXh1B5yosg+cqz80Mrg9JPgrnLEFN0GZaBxfIpy3Q1hHPJBJnLyIfZy/GukDxLhtnMRSSUX/St0EiTSdVfGczEUkNkQ5jzJCMz+c0k0daYGc1k9bOrZR+wWdQQ8E7ZzdWhmc4JD6nONI+ZzmXz6c6TWLPxWpZJzugwOc8QRBnPM8wkufnPdvYA8GlDWc/HImnP5xOJ0BSVMxP50ETFWodZ0IMfCCY50M6tCdDzI8Q500jDvtQLY9BjzJMd6LkJ0aQc4wAp0drZadIEGrx4idJDbGVGjo450pOolcKEglQQeoMJ0wO5U63zSIS1CdNTH/86mdOXiwRr8Haj60o2SdQIZERMhroz6hM00tJ0zsbc+dSjjROxs35jYjnU8y4zzmOxKdUzQ5ZOOdVi3gs/mdWkMdOokzJlcrN2FJzkBYh82dZAazXtvIZJ3BnWpO/Z1sMgadbgJNPAkx2EWYA6xBHgdpNTSfEGfCnXqZ1jbiO500+jbUNLLkrZ2EOpIHKReiBJveSJ2LOHNTg0x3Nxwt4DlbiT4SYgjeNn85akClSIoxvzUlQQlhz2iUQoE+WA2Qlcsyj0BfPos6V0uIMsNLUKWr5z6drDP6+akGdDbKNsYzk1dYldGdtkUpNUwzRLLanbylUZ2/MykCzDr5PpFCWT2kouM1qjwsPx8/NTWWP/A2ocaYWo1SSp3Repmd1EK0N+ICNEhKUj420UQUBcmd3XsqXtM8eTpHARSd46p1neY4Uk6xOc+d6jVeSQOd7hCnEAyKc53zobud9lwSZCcyYDHuO+6d/HsWnf80BDybWHOeBG1iRDhT3z+O1GKeC9ocng5sOZ4RAVwy67fCnhY6epZRCfwMn0naBDk1cAETVu4CNp4hY0tgInOUniY1To4cOvM7JtWoni1DYoKLnjE9sE8ZVlM4MnzbSAc9HZ45njtBhBAPNC7t8gLrTwhIEp5Dr5meRkiMOMyeSQ+ORO8z6rYmSO47akFLVXg8dVH7RHM6SHnXNpb9ap5aPJBGFjw7PnQ5jryonmI5M2bvnmaD6xA1Rjg+0RArPbldwTirCNw9vGB/N7g5T0rAkuCedzLjQ50P7557PP3+rZ5/cBY03TbzbZmehEBlnoZI0w/16/iei0xGno0933bGnpE24DVMNLU2m0kxAVpDDTtzWtg5QTq3ZX2enzj1NRwzmDZkAVpRt1IiOfaeqAYGNWeeq80Hnq462E1inrIE2j252JqetzlKPks5fzWqOj1Ou56/hAQ2sJG/XBxJ+UerM0xAw57ISZqeyoI0ns0EmjKyVYGe0jg3ntS7zp7XRHGe2TicXXQ68w/0nt43FIulnuJRuJ7kOkdHwZ7nPWk66+mWhzVDEz7rO7VNdZ7xOxKe81zEnvYx6wFJ7NSe+zy3PACe/k8fNgMG9DXgeyo16TJAnwY9eE9tOHUBOUVenwxoO58Pys6fEjeLnxQ65y/GPq6FOz/5p6WfHHI0nx9DQjlyTOw4Zz9OnyXI/58oOkw8ugSbOVIxyzr9NLBnFTVBATIx5onxnzbk3585taCfPFsHnz44/FgRftSfQ4bHn0ZQQT5TOwGf4HHbRv86IkBIY/AwETHYn1MHEZ9WPfg1hEVHn1tEwJ9dQZ1MRwaLOqdC1wFBn2Q5YDbtV207z59pU9k5JU7xQzQIJzxzc36fck2pM6GV7jhUN2xfl0FoRioJR0iWn35Gr1Nfn4JHYU2pn4U9pEmMNaUyakKBn4sHEjceMz5HH5+QNdJnfJ+TDKm35J+XMgyf9Z+bZMTJP5+fPItaNDrZQqGfpHKSVTAzODI3rXGfq5k+n6440p+wXtufsw5DPCwx8DetNWFndDiXQgk8WTs2PzWfvzvtrSCfwzkun8U4qU9Dr2hahkzzA7y0Lp/PT3U4f/sdn9Q51zM3dPJfbzehNQ0BQTaMMq44GDxOTJ83ojUXSdg2V0GpNv39CjjylNanWp/sNn9eEjXKOktdBovZn/QPttyEn/gCqZ/6NUFT6XnOO1Fat0MdUiI52TW0S/Q73U59oAg876AKNTc4izJMpdfVlDuMVTBaYzb3M7kYEQXVOOVeEkRuQ9E/DT25Os9Su2l3NDpdXEvGoCNO9T/ZNXcPL0N3oCk+GjotNsagLUxhQeM2xTz/NTZObdYFoDYI6yMiheygOzt9ZtKgPjl/XJ43jjs6Sdp6BkrRTHc+d6BIs3ugSzQuoE2gTzYjO/JRRzVRoFQ1RkHGM8a6j6BaPORS6kJgOhWgXzgLM3QzO92joGU5QjYNoGgxP64UQR5FQDMP++GgcGar9mugdMYjoHczbjuVWvGgfHSvA0tRvToIQsJcnqCEMsSCBjaYgzGgil1iU8M9KzeOOJKgkERANcCgk2QnoJWR+pRfoJk1EDWdoJw/GwYGMkugoFKEeSygpEH/QMBKDBLuoKkvYDMq4PrI9TRqoK5JH7SMBp5ERFwn3WVT6zoMOOEw4TW1bZ6h96C9SNugwAdHoMJ/jTaYNgZC7FstVn0z4+z7oMyA7qDPcjVLnKDTN6sHPKDXNGxofku0YguraS+X2AW+Q6DjPcpMcaDnNpBqkw8/AkWg7IR2oO84cJ9VNsKRgqD1ORJQN2ivMr8yrjH5oPzMJVTToQAxtVHPOU6hBFqkP4Iz6Tdm7jtbbKEMQ/1Lt6EPPcE0DKESTLdAU0L4rHGhGEv0Nss2LD4fNt83VaEf86+hIteroSQ1vTNJoSeKYTHVWi6hLFwSU+Z+/UYCoTI6DzHjsQihN0fObFtG2wYAOI4HqaE+ECs5KUc8QcpLTzZeN+s7Wj1+QA6xUKFLEDU24z0+tbNLsToUoVIzhz8kVh9QEkFRAk2hWVGQSMmhXDjHoV5T7KFhUcI+FASmoWU6UDl4AS07KqFrM6FNdl+sTDz67TkdkvOhdASyNLZCWaF4SPc0wb2noX16hRGLN5yhgjLVMbXpNaGHOthNiVQ3OgiLGaGOXlWhkYlOoZQ3uMpDoZgzmz5iNIg3Ej1goZ6KC6GhTNQybzxHVh835aGnXCgBNVEANSVBfz71Q2o753UrobJVuTXSM0pCiGVsRKRDDD70PmIHlFydob+inaHCPedEBNIBocdBVj/Qoco44kQ7oc035TpfodBk8zcdOGxCqwFKodaZmDxGWBgCWzQfPkGiRaHfXdRTzDZdoeSuX11YAstCCT6s1Fih7L5toe9LFAIHRihKSzTdoR2h91vQMmoy76H7x/ih/kMTPM+px6IDvRyiBlRJQ2VtiqILMkI4jToOT1k3pQavTVwG+DQBQ9HdSKIYXeWiGuIRoh1HPK6GoiE5JTzPMjFQxQEdNCRbtqIqaE1DrKItm2qiML9fojNhMzZDZOP8PaI5ZNMP74yroj4+rX98TYZjZQvEqMk6elEZR6syDqJJkvOiy6JNE5I+pjcqNKw5CTtaTxuiVj71N+SiWTM2n9VAVjmfSuNB+T7RNXUCDeioomXyCqJoj9eia0WzL587e0pONUCicTivRDSidRDDNO1DwkHTTmo5vY/ZNSM5kwUWdEU5CQEFQ0K2pzM/lemiiAEtuoWijAUDPE6ijwcpopHL1aKUNYg4QUPYRinVWb0fopyhwaKfQJ1afFZ9r2yipW7koqef4K2bqbeirTrioq9PIWHMuf9DOU9torWs9KK4RJw2eDfyNnRGKTfpNAc13JR7OGhs/DpIAUqixjVNVKQ1/nd80OyizToDM81ApFYLQBl3tT7bM8ZLWDZPO6kwAkenD45hiUW336+i4A+UQwxHwT6mQqOymDQfNyui6cXwoux14Ty8Mos2T5VoZcoHxKL0eQs4LUFaODA1OTPsneSL7JLzov871ECnRVk6A0TxNIlafDQfUGlFqEkJb+WjDVtuMtU72zl8veCjFJTSx/jYCk3+oxo2CE/GsaajH1JaoyLjfFPDoyWPlaMoRMpXWFdFoy01DLtQozECRaMzOHU1qopkozg1WTxOozs1M+YCPcFHTE/MPiw1ykwsNAtiRGHtvfRAvaNJq9M4c0FG2Am+QqNSN3WytE4Vo1bjlE4To1m+U9gGvlNOGKNi16th97kk1/jGT9f4NEmjazuUo21Hl1G3AUijcbPJo3QzjTvuUKCjeQcro3xEWDnoo39BWkGVYYdfb0kiQq5PKDctfDZeVlMTo4xGjjNxNvBPIUb9RKujkznePYKdfKOYXkZvIpwcQUw7JK8D2AWjW6OjN4KjpUS3NNpFmDrEPdVQJziHMz4IrT8/YsAzMqOySBhD4DVrUPBWCwwro7kQ9YOzBLo+2zNa56KjwTW2MO45uzX2Na1VcWZco8pl0ERAOhNTnP5Xd0pAT6PSCGgBTD2GQag+d6Tvo9pYdaPdOKc0tEZ8Mm6j4jeYS1w6dAI1Eu6j6AHFW8o3jWCeOUej7kmQO8+RsqPzcoej9lvHo/k+kMLxo/0/LaP/O6E4iQEcPfwx/z8IPyqfR6QJAQi5YEJMQQk5gVeT4eyM4qQTRKQ5LaQWmoykGUMHMmwDdEOoODRMQTQGBd5TJzbAOd2kJToYY0ukKDTXOSxD3VFSeEOkLwwptiSkM0aOpDUzSzTXTTSG1KQ7ikF0baQ/OFA/0THwpEM2JKRFPR1IU3jUMoyCmaRMNvFGCaRPOEikUTVbQywzaDlgQz053TX9ASkHETx4YaVtz6RfS23awaRjNSk2HTr0jdWkaZzFpGw1MDiPNtc9PaRxNw6kc2TVNfsPk3a1pHktGEN9BwF3mqR/Y6qkgla7PYAyAfuFeISkiVu1cnGkjUS4pI80wQSbSztuilYJRJ00BgreQISkmVSBc05CuFAvXrA4nEMBD5RfrUVipKU7AWNPQZykqWyNpKyDxZUipLA/xTU9pLNLtODxpLdPbWJ5pLtT4Vv7TXZAjDVLReub9KTEQyUyXTPiDTsx/QSbQ8Iz+NbwENk4PjeqBwgDvEH/Py1nQ0QkOZo9LDjiNThKuluIpN1EgEGbP6Gk4jTdRFgH0VcDpOhAsTOYMwDIB1noOhhNZzPsVJ84dTtlPEI7Qj8pV8mvr6T6bHVuDDZLpP5ATUl3O2JHAKUEqPelB0lzUDKlCr2mpQ2PHqUQ7cE+9aAHjSJE4WY6Ms8GFaUZOpo5f4WNpR4y5jLEPX43Q6UjU/ylJZubRfgzC0CxS1JCkzPCdrg8+sdpOBg7UoawNB46YjbiVFQVDDZRQnM25jiKPjEG3rIypUDgqRC5pUNacDZ/pUZMp6VIOXQBwTM3Sk33/qVPaLKlUjKQXhSlVjJqQS393aVbOJdG6KVfDKo5UjwzNpDkq6VmQvJhzEeOQ8o5SaVsSNwDT2cKPahAuzY4QUpKYEEepXZJkKV4RHhEiqV8M2hGZ1aoNgSlgV92QnpGi7EApYc3lVqbO1o9gqWMXqs0HqWPOYozMgKOpZNERDbxrb6lmHynnF41KU1JNVY3sTawBR2gJj+EAj4zHDzIPgwz96Wophem8aWt29+lsIphdLw5nUsKNjE89jQeGb2luj4ok+Clvj5+Srg1hjaLAeqlxDlTUTs1YTtHMckyNTIDNcNLy1vZQYA6hUB+pdJEBDTCR2ygDkiaPaMDOXpMNy0x8jnsPaNQN6XhMuM8FFDwSHenQqXoVglWC20nOv8yl1svpe8Fnf8JpfNz8qX2MzpIyUWmNbCuGwJOMxCl/lRhNb06yKMUTWo4imbfPCc5az+xPcKmC03F34umDzZRNVUw4TUwUKNExTW9phdVeKYZbeAwkqYdPEhfwDY7ODumIkrAluMZjV43OPqmKDH/NO1VdaYsD7aMSaYwAo4x4QffQF9eq287VhWmOAFZUasBeDeOOWumPpZMpkFGYjPMQFwOVqZGQRR8NouZpktJxjtKNgcydEccgSs+sDvdYAemVja7SRcxszNZPwSmXDeFpl/J39gJTiSmZUhCVhGmaDUyO9+mbDkDN7pCLUhDOX/9vDQnXu6mdkPgMfs4dEKISIxAq6Z9Vh8P0j4c+0844dfEOKs5ZzHOSts5gXVcpotV96aNUEE7YROSUMZDy69CCQcdY6aXMg4xvUKoNE1lyEBSuSLYFk4DpqJb+zdcqjimpzybSFOmqqFKPM85Sja2MnExvwreQhymtDxrN45ExUVjPwQ32qa7NyhshjNmnJ9epjWRpsI+NabENU41Ug/jOS9fklbqpszc2abPOm46jIA9PKeN8abWNO4BTKbZRNA7/6bcOOCm3k9MRMU7ljlSRWnZ9awCpudGQDkoBxLUmqbtONIKWz/RQDhkJ2RypvXh2Kb4BZRB0gnsQiM1tTjHNSg6e6cCAwU+sKcFNYA9hkKif0inCz3INRWnDlGQYFenEgJNNkCnFWGbpxgHgjVSkjynHWADRz807kJgpyJCKk65PORO4ELbOkenKTrFX29Naj/rpy45nDwGNO6nMlNjARSiZac3SplObac7iG6nPkPUMmCnQT9osg+nRdMdP2inST2Zyg8E66dNDy88EQEHp1FkPjL0PCQvl1CiPiRWu6I7p1s42DYzSEA6JadgAV04sTyDPM86sadmNfozJji/NZVGEEHjRLcxzVT3OVWncVeMp3TKf6d3M90Hv6d6Ow44DKd9Tz5Z9KeBQKw3YDPmA1Y5ZTPNOh8z2kt9Ok3/DFtNp483IDpfp5I3JTwGp5VWCVv7t3anmku3Nc9z3DQ6e9p5zkho3eMyMUuIPYI0BeTMQHY84jMPp6sx1jehMpoHv0X4Pn8zJ6ezSeintt71p7lB8eSAtgWnvmqSQwHJDKfDOf5lbE59p8dmbzoZPGuny3/MMgpw+qhdp9E041xzNCBndafXSGg+NdVBp9wCjjWkmUGn4TNdOxtoCqfmQndB5EI4Q9Q8GzTielan7ztHet2n80KhOHsz2o2dp/k/3y+WOrBpp243qAABeDbKOVWoBAG/nZkzzUClNZI7qjWOMzf5GagPQ5M3aUlpBEE3rVsdPqwyRTUlNO08fUtKPn1Nv0AOctJbp6giXNCoJDOmqCc8Fz/1e5GoLDGcVEk5kqgwVvCoM0v1CF46jTZEOI8z0QEcBAMz6jSsTWqoP4jEVKRD62TTPckUYgfgNfNqkkWqfP+oTMvuNbpLUUM5X29N6ahTTB1C7TsSTvFHJYPpqFthUKheRexuxEigQJg8kDCTARV2owHfECJBog9j9wTHW6huoOiocTLiqHQ6A0g3OFoQDDQoqHpY+0sbN9aofkOcAUg3VFu5ORHnoqiG1guoiToiRosCeVvKNjgCd1YLNifdo6iUMi2olqliqJkG206KYV86tjXsRtM8DTSRMgU2RKikd0yopzgy646oqzNSYCIDc0dOOiQ1zfbHcMw3oK73WIYHAai43emouzTwOiI/zAbhVbZapKjCNVE6kvnaqMdLxlo9O0oLeUEjMhBrk6jQQRdi2gIvqNRuCTu3XEVIozlVNTuo3FgCMAIyVznLBzOq06jkQVKo5jYzMdc/+TSvU2MQ0U7WVIEGBkyDNRK5oaj0afWo9zldSuM8CV1LP+uo/TgyNz49TmWPqQM9BuQQqQdD0qkKhkc6aqJh5zGpEECMNpZST/asqRZA5jc/Q5upGz8VNNA9o18QrhxWwzWlqSM93mFxOWcHaT9CN++pKkZdqS1LFDG9ND9RwgW/fHGpNTrBM/c+JTaQt3ipPDQgVygHTkD1ARyAGKlEVL5S/KlIMnQ8JEfDqUw8QW4MMimmEZkHqVNUhEkNNxs3sTQ2Mws/vzYbNr+i0alfNwipYbuFqWRizQEVNuta4jWwN0M6Gfs2YBdCGalxQX+eK9TPbHU2+zgnQVKW8Kl6RLhiNkGdNkRFCj0phkSU3DL+Q7+eCadCqYjVL0xGAb81PDVUY2ipjzuqNI9skAJ1qZQ5mEYzR8E336maOtY7jqmd4MCpoE/ZqaI2Qku0QIxMC1ID6BRmFamrV9s0CUj1Pd8za0zUNKs1Pam0QH5LUkZWqbh4Vam7Z6ypvjAuH+8GdzmyNxlAWlKPV9tG5A+UOVqpyjcOM9k4ijbrB5wB6j/USaBP3nISqdZmXFm8M66b16ncOcE0uThzFpCp4T/3/Pip5UEUmoOp6TskNv05V6ntdoGp8DL8YJ4yPUaOqfU52jckrFpLCjTdqfs8HT7EPkwyJTUlqgEBOZu2Njc85lKZVh9caKoKO7kBq20/ScZZ4KoRPvM5G6oVllWqGDSvBkE5d0NYQ/A1wIBgqiGxj6okN2OqJ1xwqirNhaotSdRXM6owxOGqMzgJNtwF9qo4eUyqO9IXqj5W3EX4NUo6+EO+OR9d26pHL5tJxKpL/dU40keUPNk1dte6qlM2yxQ8O3aqVwXHPylAqj84ql04nzWvtqZkJ4qdqmQPL2O/O457gapqVElMNzACNB9fwDeIQq49WEXVneSqdj6LNfo6wap6O/NDM2Piqn+q0KqCrhw4MQFpqoY4VKqIRr9KS6qLT4szJqqOODEBaVSqqR+qkz28jWGql2pzqpqGRDb9bWE3satPN6M0H0rLqqNaEzbzBxJMN0tiBXpRkzmy280yOjYdX285OBAIOSI036q0OCgL93eKAqkz2ULwQ6kQ3aq9Oh0P8EUaB8Rj8DdcAbe8SqrHNNc8EEDDD7Y303e6qs5U6I0aqtI4qjUSiD+q10Y8qtqITTjfcR0yDDL/QEkx2DnZquM1NujbqudCil8uquo2MjJAR6tMCwGvPd4zm+zSqvRO8a88qvhI11riVkg2CX9hqv8/pkRYNS0FiTftY5s77jVpQak4f4AOPM9A/mmnNjcx61Jxd9GrE2vMMtjPOKsYRDwzX6sb2dKrHjVbMgNP2KsiVWarJRAJRLc6wVUJqys0BkH/qy5I1D3+sjSrM1MnRbNKgzXPNOIHMz/8QER3b+Kzqz8JByhCWkoJVd2vq0ZQJ6tIQBCrSzVwBm0852jHq1FEmDIyOKhT6095q1hCD6taXy5Rdj7rq15DQDknNCgmYEIiODtAX6tmO2U312t+q2sz1attS2EyizXJNCM9+DW+MkzZvKt3AuI2bDM9P9RQNVstZ6urgEQkVC9RrwGsAX099TKMNS04r0kSOIYyKZcIq48+QzadOQY7pTXdOMY4yEWDO2irmkThNTk+P6ufPDk0MoRiq6Q0ZdL/vgurqjlzMcAFyQcRq68zVjwBNlRCkETYPG02i9QFq7lFY14fq71VV0UlXT0zZPzOnD+rxWqcN21bLzquX29hmqvNL2A0ZavRo0qvAtgJtmSr2zTFPtcyjDP+Mzg1hX6Qq+Sm4avnNlxDzTWZN5pFaTxVgFOr8AHpOQur8zI7Ower9mXGq/lh1dTsq/1ABT21vUGsAjXoXAKsBjwmrAk2IjhoNK+iG6wPO+43OzUNNP+sFEK4rBZVVzpMMjJCYz5i4AesHjhiO3Y1LDjEW285CE5urCczZjWPM984rk+FM0OsLjd/eCusMjcZOfasNQPIpTWsOefNrDwz4gwrO/85ajqBPAauNqxFPRM0+jnjZvhNHT+/UKM6G0X6rFACWaxS+KSsVbOOrFg4Bj/WYY1AU0xHNwmUyaxhMig5NJ0NrGZYdaxpNCJ6TFBSO1I8AAULrHChF6xzScYzRNJnrHg08laoOHU4zXMgMelSazgJcH6sg02frIU1pjYAPEQ4F64JrIxGKUCSQZ09zTQoS2G0i6yVOB0DV6yYVXUGQ6ycO1asnjYySK47Vl439PU0tkcIOwdF7FeTOg9vKqyrO7U6kT91rK9Bxqyx7r+stDHOrLY1ATdBNsY5fANzrLwGijr0kjNMNzUoX5VBfEQ7MfoQ9zlU3yA1yjoPPPyszAN+U4xUpazRkuus1Dl8Op+s1z6AOHVGXjQUrNw4AWu9rOABvV8COlE84lK7Bchkc6zpN+Y35c1HrO40Bj4dMxhEnaHXrPU1Xm6KW8Ks+qEprP0666z/SlGtAlgRrQSRba0HQSZfLjZXbOJxy60OOyY3uq0RRf40Bzw5AcGz8K0YQEWtGzbRrR00mFxFOM81SIJirSRCgUBJNhcz3UmRxSGtLC/ZGHGtLzrnrTGaYK00Ap9aDkUemcytOgt5NbU3qT/FPPpl5qF2rUM4FzxKZfhnfE/QRhZW661MR1UQ2UBoVNhW+q1TRZY6FT70rVdLlDUbVOiDmhDKrV07AJbTrWE8fTwT1Ow8RFvQrWeRoK1qEGQDc61tciYDfq1wPNo2jzUdOUBZga13PBFG3NerrXw17ULCYHs8EWnSOv86WzQ6keathzrTTyg8DTVgrpVV3KxxoRg6Ga2RS1I6sIZTOnRGBa2Yd68BGwETRy5CI0ScNiMQNTXgNrcHnJLzEk9Fbqh6rak7+DnUYHI2GnUwrbBd/j72rbRFT5EJrbgPBjZ0Zgk7nDmfWnutwEc8PfpH1FuaBpoBXUTdPyZA5japUXo3LK3Mip5ZCgFgJmBr+63TNY+t1TI6rddgckfUYyJn9K3dXcE5oDQ2ZxVeEa3jARtEFDiJredQMjg6jVCt7GZvOR2S8xJPrfE5DjwArfSL2DYDBqTsQzgVcpLp7q39PLBOcq4BE5JCCWv1rgVhuEp8W9kBrzWnNZeGDK4NMpA2GgG9P/tEbkDmlxSuFjXKMoeuGUJBQpM8elGtrh89TkKcNwyuI0KGjVMyzVKMjkxVtkOpM2VDAgbhri42AEHoPkMyGzIbeoWsQ643QfGuOTpbNUpl1q49BrIBLq5ANo84jzfRklvQTEOrX6iuSTBSrkw6IihCNAF+vRTWN6+P2UzsWbw+rASJrlg5j2hmUgVJiEBNM5tFRa5h57KuZDXGrmY4kGIArmoBGo1Prm4y1jcRdVKuczxHM2Ezwz2ZVZJU30Pr9HmufTo2N+bSSa6COHVAfkD2roZco66JuSKYfK6NMj2ujwEtdds280fqPfo8fRF7rpcBJk/IMBEWkK6cCt82ZTVpO7xAWAe/NpUzyAtsrqY0DTk4NRYx30Dgrq05KzqGiT6usTz2UC+r0661TY6uuD2OPZg3lb5cvkvX/dgJ2ALX/tgC1/7YAk3+0Qiu0j9CDlau1TyPNPau2GS3YaU3Clbprt46YVXcVAA4v4jyruVM7FWAObSu6oLCru1nQ+/mrvFE2gOyMfBokGwNrvgBVVbgPYNDj84GBYRKXKNKrwLYCdgC1/7YAtf+2ALX/tgC1/5ONa8VdLyvFzlzU+kykALTluCvHn80ryFD4K8jOJAy/TfONNyvKEUpSu415USBPDNrC2FnPsRCvFpJrzQx8FSCFP5W4jbqOiE5/zWvBkGvPo+3Z6mvQjlOOv9osTTIQ7/YhUekQPY/1spOr040ya9Ro0qvVNf+2ALX/k3Pr1wx9V9+tGevYTvXTXU/gjnYr2efyWn9r2s4Zj8xOcE0jDWtDy9DiDgZRwoHMk8151OveUJsr3tT5kRq6pfdia+BPEKvg1VxBYk+el/yr4mrjjvKnnKvjjVjZdY30a+SAiRMRwYVAX0H4Vx/r5pWflToPFNX6DOOr6AzQUPwWDo9+TW8QoYOQ3SHr6pA1z7rWD087zi5XUs42zc0QwvTrq+2THeClq+6NBVPGa+9S1A7jhF4NaOvwkTxOCevxTc0OQg0O0LyPDsCda/MRAGvzjm7NnmKYTX2NJc2ljZCSwtCrjl8r9lRUjgXUqY3dT5ETTWv4EXoMlgHETuPZVxRPjjrBQuv6TUXENk/5jOdM92v72rHr/L5i6/1qLCv+Pf+Ue9DfW8rr/5JDTp6N+xSlTrlawYx3zrlEEc3kBAcUmY9zUqQsA5AXEzGN/g/KmbfsBQ9/DQPMi15kklxOOw0D2HdsB4Efj2TBb5ApTiCN206sF//sCg6YUQqL5eTrrAu33JGSzUHsDI1Mz2iNS0CNbA3NjhhO4hNRq5xmlCNPluwP0BcEAW0O7BEyNdNLlbuRmSwSjNDPWk7JEvyantFCtIosFNtalSEsFYyNglxUow0LlqgsF013l3lVWewYkQGMoewZU+usGfWj7BqY088FEEOdUk8OTgyUP8ST0ixQ8wF3kpcrDKweTHuWvaLFDQuOoM1+mzVUe8y/1T9sIZGYjlKVMWwimtQsI03OplqmbiwklEasJWF5kD1OR5U2NRJBUFOijNlsJ4GrUSAagM6GD1HRpg1zjmfYn42g7Cp3rmwrDiPR8JDE7CwOR5DAoKTsLUU1rC3OGhfAkNYNJE9DjePNbgBt+uSsMJLXIRXR3OwxxBHuhB/JrDMM7Ay/A8v0gCw0jLQgtuw1kRsPscBR0otP+ew3DcgQDiw3zXoTwg1G7DjQFdNhkBopMFHzrDpPqE4nwNJNeU/QptesPE1W7Dzz8E6GElxc+Kw+QN1kmSw/WmnhfOxAQSyXqEy/TL8Bjc0NlaSQvixCkLwQv2x8bEPvlPYBr5TsRUC6zzksRhD4EblNdpHqzPt3dCxH1ZpY1s1+rEjPHQ6g5RNX2849EfOGKuxLDyCsS5OikHUY7+4Fj4KlksyG1ALNMFRdkdOsTo1I1JxN3xLOUdqU2Q9jrFCy8/X/dgJ2AJN/rFJuq6PMLFNQqyxT1wssVJVChNNYAM+1r2msVkJW1f4RdQymUQUsV9IyDnfsWNWZrFlN9KMUbFpNNBGZbFtMz40udxSsXI2JAZ+YLSxd1AysXk2I0OvNl528Adp4PpMhDj9dAOxhEx38Vw12Xe6NMk9hLGM4hKxj5B6Sc5CcZGnsZUBt0KusZhGyLGaajixnTUQsZ813jaSgsGD0rGlP4GD8zOup6Wxq7Hksa4JiLGwVhGP2UgUPmEzEUepOYU2eTJ0sbpRR0RuOGs7mUVPNkY1cEdhN9JDwjVUPt88ELHItpmxyz/eZVyxzgfZU2Sx0TKXt7Sx1QEaRz9/7bHaP9FUbkCJsd44kkwX4v2x4zdzseUy+DexR6tPcfnNS5ZBRD8WuW5EV0IWAsv40rH0Njex9lJhsfk8gEHiPZxIjEeCbztVI7ICNT82F2L/sgddWDe31RGyDDaTPFBUxxbKbwY87i5OYANAZWB/SZ2JPj7zAkuyG/gfsh5e27IgrUSyI0hDU9tDqLInWAKyKfAKsiw6abIvXviyMjz8Ys1fA0pNgKg1M7iuBsw5/jfFsGCyP2LAQPw95zKvNaNG10RETelDwUyvMe2/arJNN55ShwEnPAAYEWwbslUBGvmUB7/hQGGJ9CRKyz+/41ayYFjGsmPoQIR7smc67jxEsmpGj7JsNvMyOjqBsnCBJrJzXhJPNIKlS3VHlXDmsns+nj+5OMw0sNy0OJdAIzukUDMHUQc1VyiMYrKKBYr457KONBiykTmsB3WylDYcO6GGSbKZ7QQ5Okg6sp66d7KhxfmypDfzjh6yqJq9Nf2yq2H5S/Ex+1pIhHs3dbKyN3WytNgGvlOg4bK5kBVEpI1zYD0+LDuqENFNGb2hssRmqzeAVGg0/zwVQwxBTDb9VmE7oVt7Zx6y0jcrCoUCKEEUbImy2TNcOrey3AN12Jw0P7Lg7L7GWsZYxlYQCAEzVbYwk1VBVXEw4Xm+AjA4MjybsvA7jEkXQbmy9DdQOddHHwvoQeRbLTifNDbg8bL/CoViUdEmswQ5LrMGUow9LhE8sws2+UMLNrcy1DNLAb41uGb4VnFTLQ/wtVcFCjUPekw3VDoTO35HdTP5syE2yjelBylGTDoiVpOL97MqOXY8ZzTCMepE7TUNQ0MNcw8vszQ5xkGdPYY8Ni/ZR8WFv7M8TzlBDjLwcdu4ObNDNdpk4zZkayYv2FIDs0ozr1YwRjs0uV6mPOK1c7NTVOhEgTS1NQBNQzbOP9Q3FEcMt3KzXzzdUGNJ8Uv0Vu6LnbNnR9uzakcRs2x6XLNvRYc3JkOYSUpHYUGbnPA83UGVOAM6f1gwW9CDKbN/r3mzguics4U9RTsQ7e2ziu6Es41HYTHcN8cOVjW4EAxUxUKBUI6SmrOZB1JPww5FMzizngZ+M0p3NUfCQQY5ikHKMv2zp0FnUas2lXNOMuZFUUVRNn82tjZ1bWGzs2yxNe5BorO3mfyzuqYkNtuzvT/eQAXzw7PCNe5gIjCTOldcKVlINAw79TW9apI+sEF8SFyz0TWCPahmbwHfc9w+/ziHM9k0mAjeOPY2AD48NgE4LT5BEOOz42SVOI4CBzOTOthG/zkRZcWz7T4QNPI5rdG7XEVIg7P1NDSz9zgys/k70Li6N7tIJ1gKCF4+kTgIWasyJrf1tAY6rTwzWJ20C0hAtA3XPrQQQ+dLy06qXtNJjEOPrxi0GUj1hkQ0lLQdN2HnH7QhRNjOJbQlNbE2t7Qoc05BM0WrQvQyU3O6tDAybTPsYaFMDDH4ObpyTbQRtDo3FIiDSBI57LQ/20C0QjoZtERr+LRHBje0STeDtFm0TVOSA1w1fL/wNLABAzkStFUyDj71NCi0WVb1Bb+0XEGXX1QOV/vptm+0ZEcytGavYLRpOjRkCbRtTHc5V32jtHI65DmcAQQ5r1S/tHkuSgXIMfW4grR/4s6AUbSDPmIQ9zk2OSYDSjbPOpK0i8bbtI4E7nsWMiU8gzVYAllLJ0tStA+0mUVeVFR6fbSeNc5sUbSiP7VazbSmqPW2gLSq90a0rTgJNB95ZDJHlCA83bS0OktCobS3NhO0uUdMNx073T2DQJ08GGiFoldMdpm6tMU6YbTHVzNPN/wIT95FXjxBQnM+4/fUtNJAsXfeTGe011UhaFo2IrTbYe0zPAaItN8/BLThRf0PYDM6bSeXpbToc3C06zHPNMm07+VytPI9nKzOPU5oWnPcNy20+RFBtPxGKdMIELlb+rUCMjNZFrUGDwW1CTPfMjFaD7UNNNy1D1j6diK1EzXnOCG1FlqkSha1GpIzStVEozIIwp61IT9kPYA7YVulYKQ5k6NrtSoEm7UseZJFiTl2NRBEwrUyTQC1NQcp75q1OQHBtTtEODTlulW1QIaptUOWMbVGNxM2RIMytUu1A7VOSAu1UD/7SI21UxTWtVU2UbMYR7JRWWKqSAv+h7VeR2x3rLViXVg9SmqctWdBBmTTtWo5/j9JOW14tJIJtXG5Z1mntXU2FXcQAShDWLV6MgI1BzPt5rW1gDe6SEB3lbWFtU5NthDDRG8zoWIYNJBcczU4ZCc601eTPHM49bWUcnZArDHJQBk1FbWaFsqM/bWePMk09UbGNm45ej/3MeMz0bWnW1e1qkNKO+CAIrWvT2R3FLWz7zW1tgTaMqwy8PULtbw7mnWrtcBhC1IDRARETwWKNYo6drXIMkAzCDvcw31ZALXPButLUkLCtdM6X0h3M7oyHzo3PG1CYGObtdyJSujXteBBDqFcteS6m7XnQ6w8j1p8OF1mG7Xu7kK18V9vQoc6W7WotfdSRrX56K21/FuINc9PbXXhSEO2AoSwtgVHCDNmRm41vWTjM44+rWfqNvRYFEnagDG2E/18thYGBzktP/w5HZHgth0G6zgDMx0GpzxIBdW0xbYmQYCyfEsbO0dGGbYtneW2MHCRNto1mEA+tjYzA7Y42AKYw7Y8PlNDzNtetkE61z4aV6I1EILBMjc9wcUMQNe2TLZOB+HYM7ZSOPI4BnhItlc2TmU9tltP2bZdTZa2YKvTtmLYBdf9TZW2aF86tmtY+TZbMq44grZwN/g11jdMZOdPNQlIBhU1MCZgPIBISjy3Df+2f1Z+8I22gzcsPEI8+zHrQL044GOhOZ62jDJsNbVA67aQMAI9RraTAepq7k05Zk0D9bHKtps3IEqDAYA7Njjbqyu2ozeOapk4ZFRJNv08UkBWYcy2rD/HP/VBFlsXM54zGDbbogVCoZGVBpoCKLa5QhtCTGebNUhtnkcXFsq2wgRbP562xTV4izq2ybs/POI+ldAnts8x6gE0OiK20zNBttURezneNY43J2hannDdRTMZSKIP4zVYNVhF/bbjMjqbm2KJXhO26af4tuwIaEL8v8m28Ym8tvQ+oaVztvgHKbb6BchYalwcNA83KhCnPDZUYTenY0sykLcGBb9tCbcKBaO3DUREtw886LcSRQrZbLcWRjOJDBbKPappwAJOOR1PN13SUQy3IT5+adIOQz7HR8M1w2q8tyo6EaW4NcNGZ0ewtzEBETYKQWhMxkdcZrFF/oiLtztAbjIHQHE9sEWyXBJAvUcMt0Q8bTcm06w3c7dJMhI3ObdMjS63T8yvt1I4ZDckOzpelbdYyd+2wQI0NUhtnrdefIO3YTlVt2OkR7dmQUW3aTirNfZbLTlHsfu3cEvEt3MwAmLqt3ZWPwG9Py07zDbUtSW3fnVBVS1ZnEBnSzg9PUCMkfozPreISHmr7HpsOdlHXD5EPAC3kDufS5W4bUkoapMXObeYM5NHmDrYt5xW3EVit6AFJz1PO9RASDU+MBFLSjjsuKrhhresRR5dKz9kt7A3aQ+8R85Opz/5Orz4jbe5QK23vDtSt75a+TvpEk+3wlgYOhRIrrfGOsFSGQZBOHiIu7fNTIM0umuht9G3nbfUO1E4eTyTQO0C01qbt9s9eDv1VnFG6rfgMdZU4l/yt+XuHLfoWvZZLBDRiy237jTFR0638TdUM9921Lf29/e3+TPHFy6F57f+MjY1SD7MuAJGkmb4uAVUMUbTMe1WT0Qd9hlCzrgOmry4EU0duBN14T0obuRlH7gZAQW4nFRluB4yPDVcO2U10jNLuCQ30jrFAqm4KAwqNsZ2LEdF6Zu4L0BPuDFJSrgzSuU2sFYRODu4ODVvMBEGzLg8N4EBA0FSQCk0mH62MhFDQFLqQT8+8vzTuEp17DXluGu4TziKQZxGZxCRQoc4Zkx3UT+4WRDlR05IKjZhNPJbWUMs8YtEmW+4uGU+25V4VO24akGduGw36rFnuHAyZD0GVSi4dWGFNEIztGREuHsBcTUEMkMPI0zsjD24gz2PYe64hzM+PG0+MriMY2i4jjUs1Fm4kjuoYBwCgnuKuJhBnEg/uJw6Wy9gN2pIHjWCWKVcElZxMeYJB3Z9uKk0NzodMedhomn1uLA22lsvRfQ3gjfRVuhq7ri4lde4uz2LuL3XWrjAXf4/sTYNRwZcw7jHRCY61zSaWPttqrjOoulUpFpQMvdat+BwN/JrxTdnOPu42TphuNsCyjSTuN4ylzZ/uOFLpDL9PE645TflO6dk01/BM7lD60YEuO5RPkx3uPE9grjzMhlYOsZZxlNOXrj5S4g6m5mRuP45mDXYuQFEq6fhuQWpWbkIQ4+PJLkMB3VpwbkQD365EzUjVck8Bz25Vqi5GTHwNGU6xNicND+y4Oy+xlrGWMZWmFy5JlW2QLlwzJnGuSwaPZKtuTA6/TuRuTM6/zhdNOM/I0+FNCQ0Qrk7OLw6H0b9NbgQOLlBQc86hXQMuUZNaggnVXjSVToRWPpFGLlQNdA/bTpRuDg7SvnFuVhT5rlaNOAEprldRCY4dTWGQsK5YkdYVqtwc7lnLu65aRAJuWtT5j/uQqsCdblwNS4zYFJGMgNGCT74NkJPKLl5Mi5dFESYxsk+3yIYPLxFJTbx1VS5hUGch3m5iT3KQyq5jD3fuY4yG7mQNru5kjXDuZTevUH/1m25mUefNWkBsgI1TWrqgbmhRCa5o0mduaUBqGiCuak/MUBldIU1k6E1Pgs157mHQ+01uVNkDyM50UdKOahF1EcMQ+A0DE9ZP2I3i7nAd/O5wk65BZK5xW42P2RDuTYgTTWeALnNOCQ01F+5EL5am9MWudVFbjnGudhetbnbRMI3H7neVi9IJQEmOWBAWTr9gtxdBzUWd0pPrqyhuexHw0hKQcS58Pnaaak+9Uq8PP+59kSrq3a5+hAPufwyHWeUPvGU9DQIPAW6A1UYdIVUTjUiWkQhCl+SugtCTroNWnY/4roQNJRCKroTQZSF1zJruhdcDgaKS3IGFUgSO85izRUMuiADD0JBuiNMkLKQTRlNUD8EuikzHcdiN0c+GT/fPNlUBD9CujJETzZhQSMP7z3iMjxepro6RTRE5ro9MnK6P2sKukJGv0BlOnQ7DgJ1ukg/9zzZuks4QTM9TEe6T5/sulI3u07rNrk44p+yNWlNZFG4soO6XQY+P5IPts33umMwAj2JTWS6Z25ZNYBabnnAM0M6sDPFOTrzZLpyRwxKLjwHx0a6eM7Puns0+neBun5BlbqANfFbe7qDTDg5TjdiP9E3SwUcAXYHv1CAN5AEiVwpVAC6kVm4upQ5erqW4lm6mT8mX6E3Djy1R05LmDpURii6ogcyuqT2x7qnQYC6qQYAuqtQrLqucR09vLqxzIy6tEVWOqQTTbq4ARoJcbq7BxG6vW3+usBJ1WbfZhO6xQWSm59YAkFqBFs6021oQJ01mTvputBCWTc8WYu61TQEutc6EUmRVGE24RCHQMO63kruPYa64USjB8W65Gb4uuYBNDc0uulHDEB0oE470DPUXtO68ELEUa82jGC3uvapGLr5bfBEqzzsPCg+kzLXM1w1oz83uwQ3DH4/uwgBCDJga5dMdTV3uw41jxHtuxE3ghScUGM8ybyduxg5/7sa6jS7HVA3OMRa4gFMOJNBCzUwB6kyaPx3PdQ40rsrqIO7LjLYPe1G41bNuzMF+zqxNv9Lsbs4Ql1987s8xwO7P0zURCEP0ji/OTNXmLtHQ7JEwkH2OP1MKzh4sAS7UBbKu1I8yEUKUEEDeTZVRtFT2ThIu1sxyqvMu19B/1+rEGS7Y0hou2WHMLtoSu43L0yQTNa7bTYiu29LCgIou3JjCTCdPgvKprt4BwG7erIXYjYDdDQ6Q6g2Rok8u4NNFWhuNz5DVl8DOYRSjD0TOhVFyUekAXJJVVo5Sue7k3jVu5ZC7ruZPaM8+gFJRzx507ugNjQyi19Vu6QzOqwhbsEJiD3WOag2kT3KMgZFHEXJNco0kTk7u7O1eru2Opk3rQSyEGRodDdmPihBwt7zu8ECJeIVu8W0D5o1u8m3jrvMXtMyizw5NyhJOrvTUZQGNzuPmkxTFzZ/u9qHSqr7u94OwDYWNdwBND6wu+RiqjvONLY/+7vpeyq76zUcddBGGbvwVQBKXIcSu/VPUQfEu/ibkrv7MxA3i2x1NqRTzLwBNOa8BPLxOrgPL7wIWnBBfDrBfs9hokNY8Re8ETw2OhgzsXEdO8hcKFYWVdq2TTxfNNs2SjXJSy4tIjNMfzG8JDryp3S8KAcDO9u8KzMTNsM5vUeXvDB44kYoMNY+8zMmvDYGbWObXqu8Okd1SZE3oTKwN/lX5LxCOcYy2joVdT28SEYqvEpIrrxMBYR4cjZhFy4yh7xSQ0I8j+gXMiR3NEUAvFpUvmbXMlZKRjd2PBW8YTZ1MjdJ4TasOc28aDWmQm1B/7xsOdsyYzIcPhwz0U5qUBy8dDMYvHYNczMtOAb9pbx8R7C8fzy8O6e8gmAiPn9LmAdxedQ7YGGFN+hJU7yMMgNa+UNivJBhwnSvBym8lDNYlfd4/NgU2BO8mjf2Vn4+UwX1vJ9BdIMwQkGwsAaUB2pfq0UKyzg2uqPlvKxCqFpEOJ8/BHZwNA8PjwINNU68tjTHgJE0PAHJPEdplDRNN7FA9Tixxk/X+MZPo2m8xTXNOm+9IrzKMcRcKZTM//93B7zRvWq81DJqQWNFskAevR282zHyOY5s6bzgt7hR70dlj3O85gGLW3uTArzrOIZ47rzvN3O88THYQqh5xLz2EAg5A7z5oFkyDztCUn62mb0AQUvjLkTtSAs1/TwXvEG9CVfVPcE5+q/CvQ+9V70SNq7SwjI1NXQ6g70YWWi9GkATvRwxzgbJBXo/5rzIvSMu7jhIvSZPakVjQcZRDDWUvXa9Lg+U4Pe9Mpt+vTU5sjdnMeJEFAFdvTsRczkLvT5T5r1AUa8CRUQDvUVNqTcV/XE1yTpNQllN+L1OBO5MLAyERNE6NkATvVW9EL1YvRO9W+npvV4zEW8qvWE+471jM5u9ZTAuTuA67kQZvNNLUQGovW03CEGoBgc54+2JOR00FjYnZIlA60JZvcE0yjdnvXyZuL1/YdVJnDeNMzJjgE83P629h00ZOaMyVT35P0I0yL2OR6dKS0bGvZJE4b2UAjD7lb2YMydJkb2bMd+9nTJXTyRFvjhsOGi9o0DMijCsQL2oWUistjwFQO02Yb2uQ8I15D0NRQk0QDiBS0S9tkVgQxkBdjMGvbtCYF+rNAFg4AfRND29w0r5vcY2qWSJPSQ+aksUPiYzoTJqNaM1HQLgvdLYBr5TmNC910mQsl+HWjcbTqczsDVVOQcEfmX/veM8epiuvedJjz3eveqTz73tNOG970nhUqG98zduvfXYBdf92AnYAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgCvmAAWr5iAQW+ZANbJectFSppwl/E0QINMQwOBB3nvnDDPh3kFVnCX8TRL9O+d78Xw0jErhmfvny+e8NRxJO+gsNUwHLDVsB1JpPAd8HeINLB0BFSwdIQlMHUJYArxR3LK1nB2AQYwHUmk8B3BILCJMHgFRbB5g2Swea+wRq1wenCA8PaxH2+ycHwDCq+zMHzwerCDb7RLBG+08P8vtYnqMHhwfzB/8H+J8DCACKDwgLBG8PaxH2+ycHwDCq+zMHzwgwqvMIOLBG+08P8whIp2xUWwhm+7zAuBFm+3cJTGybBrr7iwHS+5CaTwHcCi8IjxIrCJRRcwhUwLilaASTCKCcqFybCLb71AUi+9xXpw9kGHcR9vv4wLsDnwm/D3xdWvwXCCSbBvvMwLiZAJNoKBg1/DKvD+cQvLPEEjR1REW2/FcPkwdDCmAhowlHEcAILwlq/IcJTGybEtL8mBjHEob8qvxy/LcS8wbHEt8JQvzS/LgG6vzfEiAKlwiQhLMJrMX3CUMJvEFHCcQiywnMnKcJ1wx/AOcJ4v1LCesMfwDnCeMJ+ERrExb9gv2K/ZL9xv2e/dL9q3yW/bcKNwwTCh790v2o7YsKTHVcDOMKWxM/EQwvFwprCbb8tENu/hMKfv4jCojmov7/Cpb+Pv5HCqb+Uv+7CrL+ZwE3CsC0Yv54CXr+gwtHDIMLTv9AANMLRwyDC07/Qv68AIsAEwsK/tS/JwsXC/MLHACLArMLJAl7DGsLNwB3ANsK2wtLAOr9bwtXCy8MLwxy/2sBFww/DK8MRv+TDFMLiAszDF8AuwyO/8DuGwybAQr/2wu5sCr/8wvLzXMAAwEvC+MLDL8nCxcL8wscAIsCswsnDAQP8wwPAE8MGwBbDCcLLwwvDHL/awEXDD8MrwxG/5MMUwuICzMMXwC7AMMLLwwvDHMA2wnvC08Miwue/8DuGwybAQr/2wEXDD8MrwxEDTsBLADzATcMxFd0F1cM0ApzDNgEEwzgrwMPgLgnBX8EswF4W6sSFw//AYgA1wGTEbcNdw2bDTBBRw04E4sNQxLK+k8HIwHLDVsB1JpPAd8HeINIiesNJwH7EDME8L6rDZcB+JyoXJsCICEPDnsNsCb/Aj8NwACDDl8CUw3UI98N3Dg3AnMN7wJ/DfsCiMEUJcEFOw4MDwcOFwKovqQIlE5LDigbPB1TAsWoFw48AIMC1Lo3AtwnTP8XAusOWw3LDmMDXwMEAbcOcCEPDnsNsBNPDocNwwM3DpATBw6YwYMDTwNXDrMDAxBEXLSurwN3DswqkwOHDtgUQw7gGQcO6CSvA6gbxwQXDwcIzEoDEfcEfDZwnzMPIwSPDyhuCwPkWfMD7wP3D0Ab8w+e/AcDpw73BBC9ww+rD2QYdxH3BHw2cw98XVr8FKNonwyuiwRAGGsPmAdTD08Dqw+rBBTG1AfHD2QYdxH3BHw2cJ8zDyMEjw8obgsD5AabCQ8P7xDAn78P/vnTDxMExuCkMAcE0vtYBJME2xAgMq8E5Hu7DYME8xA/BP8QTwUIvMMFFGCjEGiEfLrUdqylyKlwt2SdoFFDEIwEiwVIvScFUA8HEEQK9xCsPiiJJLJkoMCydxDHBYRyxBekGvQ8jMBPENr5wwz4n8Cy8xDsRC8Q9FvzEP8F9CQ/Bc8RAxEnERsRAxEksbMRDxEzBesROH6ExC8GDxFJJ8VRiv0sCB8GKxFjBl8GPxFwTTAA9L58RJSZsAQDEYiEnwY4avcRmL58Ci8GdxGouHsRsvtfBo8RvDmTEchZoxHTBqgW9xHfEk76Cw1TAciOIwl/E0VXXFTUD7AIHwiDAdzFIvzfEiAKlwiTCSr56GZ++fL57w1HEk76Cw1TAcsNWwHUmk8B3wd4g0sHQEVLB0hCUwdQlgCvFHcsrWcHYBBjAdSaTwHcEgsIkweAVFsHmDZLB5r7BGrXB6cIDw9rEfb7JwfAMKr7MwfPB6sINvtEsEb7Tw/y+1ieoweHB/MH/wf4nwMIAIoPCAsEbw9rEfb7JwfAMKr7MwfPCDCq8wg4sEb7Tw/zCEinbFRbCGb7vMC4EWb7dwlMbJsGuvuLAdL7kJpPAdwKLwiPEisIlFFzCFTAuKVoBJMIoJyoXJsItvvUBSL73FenD2QYdxH2+/jAuwOfCb8PfF1a/BcIJJsG+8zAuJkAk2goGDX8Mq8P5xC8s8QSNHVERbb8Vw+TB0MKYCGjCUcRwAgvCWr8hwlMbJsS0vyYGMcShvyq/HL8txLzBscS3wlC/NL8uAbq/N8SIAqXCJCEswmsxfcJQwm8QUcJxCLLCcycpwnXDH8A5wni/UsJ6wx/AOcJ4wn4RGsTFv2C/Yr9kv3G/Z790v2rfJb9two3DBMKHv3S/ajtiwpMdVwM4wpbEz8RDC8XCmsJtvy0Q27+Ewp+/iMKiOai/v8Klv4+/kcKpv5S/7sKsv5nATcKwLRi/ngJev6DC0cMgwtO/0AA0wtHDIMLTv9C/rwAiwATCwr+1L8nCxcL8wscAIsCswskCXsMaws3AHcA2wrbC0sA6v1vC1cLLwwvDHL/awEXDD8MrwxG/5MMUwuICzMMXwC7DI7/wO4bDJsBCv/bC7mwKv/zC8vNcwADAS8L4wsMvycLFwvzCxwAiwKzCycMBA/zDA8ATwwbAFsMJwsvDC8Mcv9rARcMPwyvDEb/kwxTC4gLMwxfALsAwwsvDC8McwDbCe8LTwyLC57/wO4bDJsBCv/bARcMPwyvDEQNOwEsAPMBNwzEV3QXVwzQCnMM2AQTDOCvAw+AuCcFfwSzAXhbqxIXD/8BiADXAZMRtw13DZsNMEFHDTgTiw1DEsr6TwcjAcsNWwHUmk8B3wd4g0iJ6w0nAfsQMwTwvqsNlwH4nKhcmwIgIQ8Oew2wJv8CPw3AAIMOXwJTDdQj3w3cODcCcw3vAn8N+wKIwRQlwQU7DgwPBw4XAqi+pAiUTksOKBs8HVMCxagXDjwAgwLUujcC3CdM/xcC6w5bDcsOYwNfAwQBtw5wIQ8Oew2wE08Ohw3DAzcOkBMHDpjBgwNPA1cOswMDEERctK6vA3cOzCqTA4cO2BRDDuAZBw7oJK8DqBvHBBcPBwjMSgMR9wR8NnCfMw8jBI8PKG4LA+RZ8wPvA/cPQBvzD578BwOnDvcEEL3DD6sPZBh3EfcEfDZzD3xdWvwUo2ifDK6LBEAYaw+YB1MPTwOrD6sEFMbUB8cPZBh3EfcEfDZwnzMPIwSPDyhuCwPkBpsJDw/vEMCfvw/++dMPEwTG4KQwBwTS+1gEkwTbECAyrwTke7sNgwTzED8E/xBPBQi8wwUUYKMQaIR8utR2rKXIqXC3ZJ2gUUMQjASLBUi9JwVQDwcQRAr3EKw+KIkksmSgwLJ3EMcFhHLEF6Qa9DyMwE8Q2vnDDPifwLLzEOxELxD0W/MQ/wX0JD8FzxEDEScRGxEDESSxsxEPETMF6xE4foTELwYPEUgEDMBa/SwIHwYrEWAakxGTEXBNMAD0vnxElJmwBAMRiISfEZMGZFLgvnwKLwZ3Eai4exGy+18GjxG8OZMRyFmjEdMGqBb3Ed8STvoLDVMByI4jCX8TRVdcVNQPsAgfCIMB3MUi/N8SIAqXCJMJKGObEkQ2SxJHCUxsmxLS/JgYxxKExjDFuMWMw7zFzK8sssQ5pvn3EojFuMZcw7zFzvvG/NzF4ExPCJMJKvnopbxBRxNnCUxsmxLS/JgYxxKHEvzGOxH8w78S8wbHEtzGVxMAxcDDvKp0BT8TEMZ3Cgr9hCMYxo8TLwZjClTGqxNAOajGvAp/E1TG0xNgYvzG5ADQxu5VLxOAxwzHFb14ypzLBMc/E5zHSxOox1THXMdlW4cTwMtjE8gEQMeXE9THrMe0x78T6ODHE/DHExP4x+zH9xQKLXsUFMgcyCTILMg0yDzIRMhPFDtLT0JIyG/LwMh+MtEYjMiXFFzIqD5PFGjIvM47FHWnAxR9rBsUhMj0yPzJBMkPJ6TJIxSkyTTJPxhwyU92lMlcyWcUyMl2GYsU2MpEyZDIlxTq81UnmxT6yOcVExUTFRMVExUTFRMVExUQ/ajORMooyjAGcxU4ykjKUEJE0NsVTxcoypEFLxc4yocXRM33F4sVcM4LFXzOFxWIziTKQxWUyvsXeMcrFajLGxW0yTcVvMszFcjLRMtMy1TLXxXcy3DLeQKBM7TLj8ZXFfzLrRkfFgjO+xYUy9sWIMvo6CMWLMwAJVTMCxY8zB8WSMwzFlTMSMxQ3VcWZMxozHDMeNzrFnjMjMyXFonjwMywzLsWnUs/FqU1cxaszOjM8Mz4zQHotxbJtn8W1M00zT25jM1IzVDynxbwzWjvuxb8zYDNiM2RXYMY7xcc0LcXKM3UzeTN5xOXFWcVbxdQzgsVfM4UySTOIMrnF2zHNM4wzjkNKM5AzksXhMqlWTcXk0Pczm1/FxegzoMXrM6XF7jOoM6rF8jOviWHF9jO2xfkzu8WCM74zwAZtxgAzxTPHe/0zy8YGB1HGCDMKxgpPTMYMM9kz2w8jxhAz4TPjM+Uz58YVM+sz7TPvxhoz8zP1xh4z+jhdxiE1xsYjNAPGJjQJNAvGKTQQxiwzqMYuNBjGMTQcxjQ0IcY3PI/GOTQpxcbGPcXINC40MMZCzTI0NhCRxkY0OrzCNEbGTNf4xk/X+MZP1/jGT9f4xk/X+MZP1/jGT9f4xk80UcZcauHGX34sxmI0ljSYNJqOwzSfxmk0ozSlNKfGbjSqc8o0rj6CxnQ0tsZ2NLrGeDS9xno0wMZ8NMXGfozHxoA0z8aDNNPGhjTXYv002zTdD/TGjDTjM1TGjz/QxpGVNfAfxpY09TT3V4E0+gEvxpw0/jUANQLGoTUGxqQ1CsanNQ81ETUTNRU1F8ceNRrGsDUfxrM1JMa2ATw1KTZCxro6hca8NTQ1NjU4kg81PMbCQ0Q1Q8bGWD3GyJ4nxsuKvIMe3BrGzzVdxtE1YsbUNWY1aDVqxtk1bjVwRYDG3VjVxuA1e6R9QEfG5TWFNYfG6TWMNY41kMbuNZY1mDWaNZw1nsb1NaHG+DWmNajG/DYrxv41sccANbU1tzW5Nbu8ejXANcLHCTXGxws9gMcNRbXHEDXVxxM12DXaNdw13lVxxxk15DXmxx0168cgNfA18sckNffHJzX6Nfw1/scrNgPHLVxJxzA2DsczNhI2FMc3BQPHOTYdQ8nHPDYjNiU2JzYpNazHQzYwx0Y2NcdJNjo2PMdNNkDHTzZFx1E8p8dTPsTHVTZSSQ238TZXNlnHXDZdx182YsdhNmfHZE+CNm/HaDZzNnUyk8dskss2fMdwR6THcjaEcMzHdTaJAXjHeDAVx3o2k16zx342mseBL5rHgzahNqM2pceIyNs2qzatNq82sTazBcnHkDa4x5M2vU9tx5ZGE8eZhOPHnDbONtDHoDbVx6MysselBInHpzbjx6k25serNuo27Dbux7A28jb0x7M298e1VEM2/Qnsx7k3AjW0x7w3B8e/jNPHwjcTXq7Hxjcax8k5ffbax803KDcqx9A3L8fTNzI3NMfWPR3H2InGx9v//jdFNbHH39EAN03H4zVVx+U3VMfnN1jH6jdcTzXH7eS2x/A3ZcfzN2k3a8f3ZEdOFMf6N3jH/Td7yAA3gDeCN4QQCMgFNhWz+cgIN483kUvxyAw3lQGwyA8BBDecWUI3nzehiQc3pUaLyBc3rMgaN7LIHTe2N7jIITe8N741VsglN8LIKE9rN8lWMMgsQGjILjfRyDBWJ8gyTBk9rjbjyDY34cg5N+c36fzkyD438chBN/U0RXnaRq7IRjf9yEk4AMhMVWPITjgJyFA4DchTkMc4E8hXWfnIWTgbMv/IXDggyF84JUgTOCk4K8hl2rw4MshoODY4OD6VyGw4PTg/yHCXsThE5dpDash1OEvIeDhOyHt2yY+vyH8GQThZOFtLY8iEOGDIh5E/NAjIio2COGs4bciPkpTjmciTOHg7/ciWOH0+HTiAyJtN6cidM7DInzwOyKE4kTiTOq7IpTiXyKdEzsiqOKDIrTik/turVMiyOK3ItTixS5jIuDi1MznIuwKcyL09Psi/WHE4xGsQOMjIxDjMOM7IyDjTOPrIyzjYNM3IzjjdyNE44sjTOOYzm8jWOOs47cjaOPDI3T4IOPU491PmNb3I4zj+yOY5Asjph5emN8jtOQ/I8DkTWm7I8+D6yPU7CMj3OR3I+TkhyPw5JTknyP9BackCO7fJBNCzyQcySskJMuHJCzlCMFM5RckQ9q05S0BWyRRFJckWOVU8P8kZOVo5XDleOWA5YjlkAZw5ZwlfOWo5bDluOXDJKDl0vM05eDj7yS0C1MkvOYE6bskyOYbJNTmKOYzJOTmROZPJPTmXOZk5mzmdOZ/JQzmjB1LJRjmnyUk7j8lLOa/JTeytObXJUe47Obo5vDm+yVc5wQ+8yVo5xcldOco5zMlhOc820clkOdRHzNNUOdnJaY1TR6c54cluRijJcN28OepQxcl0Oe/JdznyNl459Tn3yX1zmzn8yYE6AToDVjDJhj1OyYg6C8mKOhA6EjoUOhbJkKxNOL7Jk7MmNxHJlkNAyZg6KcmbfBw0CDovyZ86Mzo1OjdwUzo7yac6P8mqOkLJrTpGybA6SzpNPzXJtDpRNwLJt3Ouybo6Wsm9SerJvzpjC/bJwjpoycU6bMnIRKvJyjpzOnXJzjp5OnvJ0jp+OoA6gsnXOoc1gTqKydw6jj25yd86kkIWyeI4eDqXyeY6mzxxyek6n0JxyeyzADqmOqheVsnxOqzJ9DqwOrI6tMn5OrnJ/Dq9yf86wMoCOsQ6xjrINc7KBzrNNKLKCjrSyg0614GDyhFB1MoTOVPKFTrkOuY66Eqfyho67Trvyh468jr0QzPKIjr4Ovox2somOv/KKDsDNJLKKzsHOwk7CzMAyjCckMoyNVnKNDsWyjdrnco52aHd0Mo8CO47JA5WykA7KcpDOyzKRjTKykg7M8pLOzY7OMpPyLY7PcpTO0HKVjtFO0fKWQcpyls988pdO1E7U8phO1bKYztbymY7XzthO2PKa1bcym0vYMpvA3PKcQ/iynM7czt1O3dCczpbynk7fQGFynw7gcp/O4RAqsqCQeTKhDuNacdVkzuUO5YR6sqLO5s5NTueypA6AsqSOX/KlDurypc7rz8Pypp3isqcO7c5ncqfg0A7vjvAO8JAszvGM5E7yTvLyqo70MqsNjfKrjvYPeA72sqyVIHKtJ12O+PKuDvmyrtHl8q9O+81QMrAfOw79VVIysQ5r8rGO/07/zwBMhTKy0kmPAg/kjwLytE8D8rUPBTK1j6cytjvI0C5ytuNEkiQyt48JzwpRZbK4jPOyuQ8McrnAi/K6QEuyutVaDw9yu+0zTxDyvM8SPgoPExNt8r4QGXK+jwFyvyNjsr+PFzLATxfPaHLBDxkywebATxqPGw8bssNNuLLDzx3yxI8fDx+RkvLFjyEyxmSfDyKYj/LHjYiyyA1cMsiPJc0B8slPJzLKDygyys8ozaiyy48pzHDyzEBfsszPK4QIzyxyzg8tXj5PLnLPVVtPL/LQTzC9sY8xstGPMrLSUn5y0s4+stNPNTLUDzYy1M0KMtVSNzLVwIvy1k86MtcNfrLXjzwy2E88zWFP73LZTz5PPs8/UdVy2o9Aj0Eqs5z3IaKPQrLcls0PmrLdj0Sy3k9Fst8PRrLfz0dP/HLglvKy4TpJD0my4g5BMuKPS/LjT0yy5A9NcuTPTlRm8uWPT47ZcuZRSTLmz1HPh/LnkTCy6A9Tj1Qy6Q9VMunPVfLqj1by609X8uwPWPLszI1y7U9acu3PWxK48u6PXA6HUmRy749dcvBav89esvFPX5FJsvICKXLyjHYy8z09T3Jy889j8vRlobL1D2YPZo2cMvYljWCXMvcPaYxwsvfPapCI8viPa7L5T2yS7fL6G3nPbg9usvtPb7L8FiWPcPL9D3Gy/c9yj3MPc7L/D3RPgTL/z3WPdjMA0ZLzAU94H8+PeRVdcwKM1fMDEH5zA4978wRPfMR7cwUPfg9+jIdzBgBfswaPgLMHYa2PgfMIT4LPg3MJVTTPhLMKWEOzCs+GD4aOWrMLz4fmPRF9MwzPic+Kcw3PizMOTMazDs4Mcw9Cr/MPz46zEI6ksxEPkDMRz5FzEo+SMxNilE+T8xRPlNYKz5WzFY+WcxZRKQwhz5fzF6egT5lQqHMYj5pPmvMZkt/zGg+ccxrPnXMbrpxPnpLlcxyPn/MdD6DzHc518x5d4rRskXXiUI+kD6SzIFR10XHPprMhkxoyWs+oMyKPqXMjT6paH46kcyRPrA68syU/yg+t8yYPrrMmzHGzJ0+wQPaPsQzHMyiTEHMpD7MSz3MqD7TSkbMqz7YzK4+2z7dPeTMsj7izLU+5jMkPunNjz7tzLwyBsy+apc+944SPvvMxD7+zMc/Aj8ENLTMzD8IzM4/C8zRQwLM0z8SzNax7Tbg/q4/GszcPx7M3z8izOI/JlsLPyk/K/xfPy/M61ZNPzPM7j83zPE/Om3SzPRCBsz2P0JJH8z5P0bM/D9JNpjM/z9NzQI/Uc0FP1TNCASazQo/W80NP14BFD9gMhTNEkUNP2c2yc0XP2s3Hc0aP3DNHTLyP3Mvfz91M/nNIT95MvI/e80lP386K80o97nNK0IyzS0Bfc0vMJPNMT+TzTQ/l803P5rNOj+e2pw/os0/P6Y/qM1DXhLNRT+wzUg/tM1Lsn3NTj+9VMfNUT/CST3NVD/HzVZSXc1YP87NW0LFP9SvSzlWP9k/BM1iP90/381lA34/481pP+hCInp4P+3Nbz/yzXI/9c10P/nNdjPgzXg1wM16QARABs1+4eBAC82CPMPNhEASzYdAFtNUPkNAGs2OQB3NkVK6QCTNlTz/zZcGdM2ZQC0/ic2cQDHNn0A0zaJAODhQzaVAPM2oEGTNqkBCbuo2382uQEjNsEBMzbNCYM21QFQ7qc24QFpCqM27QGA+xM2+QGTNwUBpzcRAbM3HQHDNykB0QqHNzUB5zdDN2EB++HnN1ECDQIUznc3YQIk2Is3bRcnN3UCRQJPN4UCWzeQ8UkCbzehAn83rQKPN7kCozfG3ukCuzfVAsc33S5XN+UB2Ql1AukC8zf5AwGySYbhAxc4Erv1Tna7NzglA084MQNY5x84PQNvOEkDeSAfOFUDizhhA5mvMzhtA6s4ePOXOIEDxziNA9ED2Q7/OJwNOzik/P84rQQHOLs0VOXrOMUEJT1rONUEQzjgzD846QRjOPUEbzkA32M5CQSLORUEmMiXOSEEqzktBLc5NQTDOUEEzdLJBNs5VQTrOWEE9zls1Rc5dQUNBRc5iPOXOZA7SQU/OaDKHOY5BVoymQVnObkFdVDfOcUFhznRBZc53QWg5LM56QWzOfUFvzn9Bck0uzoJBdy9/yWnOhjSjzohBgc6LQYU2xs6OQYnOkTK8zpNBj0GR8dLOmUGXQZladlKyzp9BoM6iVUNBpc6mQahBqkGszqtBr0Gxzq9BtM6yQbfOtUG7RV7OuEG/a6Y5f868i0oP9c6/Qco/mEHNzsRB0c7HLSLOyTlYQdrOzPatQd/O0EHiQeQ4Jc7UQejO1kHsNzoESM7aQfE6gc7dQfXO4EH6zuM8gs7lQgHO6EIFzutCCUNDzu5CDTwOzvFCEkRsTz/O9QZ0zvdCG0IdaZTO+z6Vzv1XR0InzwFCKzAuQi7PBkIxQjONP0I2OrzPDEI7zw85V88RQkHPE0JEzxYEus8YQkrPGzohzx1CUU1kzyBCVc8jQlhCWlHPzyc4Ys8pN+/PK0Jlzy5Irs8wQmvPM1g9zzU9vM83QnbPOkJ6QnzPPkJ/ZWzPQUKEz0RObUKKSOI6RM9JQpBHzs9MborPTkKXAQ/PUYEHz1RCn89XmzLPWkKpz11Crc9fQrE1q89iOprPZEK4OIvPZzMkz2lJuc9siYpBTDadz3BCys9zQs3PdkLQz3lC0898Qtc86WuFz4FC3jM8z4RC4s+HQuY0nFIDz4s3SZNSQu434kLxz5JLic+UQvhPMEL7Qv05nc+aQwFDA8+eQwbPoUMKz6S87kMQRv1fks+pQxY84s+sQxuEQ+BZQyDPskMjz7U1uM+3djs1HM+6Qy/PvTlOz79DNs/CQzvPxUM/z8hDRM/LQ0fPzlSEz9BDTjWCz9RDUs/XQ1XP2tAmQ1vP3kNeQ7zP4UNiShLP5F5aQ2jP6Lb4Q27P7LI5Q3PP8EN2z/NV00N8z/dDgM/6Q4PP/UOGOKHQADgX0AJDjbQW0AZDkkOUQPZDl0OZ0A1DnNAQPJPQEnxnQ6XQFkOoQ6rQGmd80BxDsNAfQ7Q540O30CSfstAmQ77QKUPDMk7QLEPH0C9Dy9AxO0kzPkPSOaND1TQOPhDQOUPbW0RVSNA9mphD49BBQBnQQ0PqQ+zQR0PxP+bQSkP10E1D+EiGSU/QUkP/0FU2JdJtRAY2m9BaRArQXUQO0GBEEUECRBQ6GdBlRBjQaF7T0Goy/dBsARDQbjqb0HA6BtBym73QdUQxcUHQeUQ1NbHQfAXV0H6IckQ/REHQg0RF0IZESNCJREvQjGaMVZzQj0RS0JJEVdCVs9NEW9CZRF7QnERh0J8F3tChRGcBE0Rp0KZGb9CoRHHuHEtZ0KxvKtCuRHrQsa2rgldEgj/iPljQuEBo0LpEitC9RI1GbtDARJLQw0SV0MZEmESaQrjQylQWRKHQzkSl0NFEqNDURKzQ10Sv0NpEsuj1+eQ9ftDf3tREu9DjRL5AZdDmmS1ExTtaRMfQ60TKRMzQ70TP0PJE09D1RNbQ+ErL0PpE3RAr0P1xb0Tk0QE4z9EDROrRBkTuRPDRCkT00Q1E9wFxZIxE+9ETRP5FAI5oRQNZyUUHRjtFCtEcRQ7RH0UR0SJFFdElRRjRKAypRRzRK4XsRSHRL0UlRSdoZtEzRSzRNkUvdmpFMgRBRTTRPEU3RTlFO9FBPz/RQzVS0UU3CtFHOrDRSUVKM3bRTEVORVDRUEVU0VMXotFVdjtFXdFZNU2muNFcRWbRXwR+0WFFbdFkRXHRZ0V10WpFeNFtRXvRcEV+0XM7pNF1NkHRd0WHNtvRejhz0XxFjxEHPSzRgDLdBJXRg3dK0YVFnDLh0YhFoTZ40YtFpdGOPhTRkEWt0ZNFsNGWRbTRmUW40ZxFuzXS0Z9AutGhRcLRpEXF0afMhT2kPAXRrD6V0a50ZtGxRdY+jUXZCCcy6dG3Rd7RukXh0b1F5NHABxFF6DdB0cNF7dHGRfA7L9HJRfbRzDNi0c5F/EX+RgDR00YD0dZGB9HZAerR20YN0d5GEFT10eFGFNHkQATR5kYaM6HR6UYe0exGItHvRiXR8kYqRizR9kFV0fhTadH61hxGODLW0f4zstIARj/SA0ZD0gZGRkZI0gpGS0ZN0g5GUNIRRlNGVUZXRlk+0UZcNnhGX9IbRmIDxNIeRmZGaNIiacVGbNImRnDSKUZz0ixMt9IuRnnSMUZ8L4PSNEaANpjSN0aE0jpGiDCf0j0R6tI/RpCFv9JDRpXSRkaYOa3SSUac0kxGn9JPRqLSUkalgty5S0ap0lg7CNJaTS7SXEax0l9GtNJiOkTSZEa50mdGvDZDacDSazaG0m1GxdJw689Gy9J0Rs7Sd0bRRtMCJdJ7RtfSfkba0oFG3lwARuHShkbm0olG6dKMRu3Sj0bw0pJG8wGE0pZG90b50ppG/NKdS33Sn0cD0qJeREcIEAZHCjfJ0qdHD9KqapPSrEcV0q/fxkcaOZzSs0cfRivStkcj0rlnfdK7RynSvjLq0sBSctLCRzJBndLFi7JHONLJRzw0UdLMhUjSzkdD0tE25tLTR0nS1kWy0thHUZS8R1TS3UdYNLnS4DXQ0uJHYNLlR2TS6Edn0utHalbbNKPS70dw0vJHdEd20vZHejkz0vlHfkGw0vwx69L+rwO+DNMBR5DTBAGv0wZHl0eZM/DTC0ee0w4x/9MQELnTEkepseg4i9MWR6/TGUeyPpDTHEe20x8BVdMhR7zTJPi50ydg4kfHMzbTKzup0y1HzdMwR9EFetMzUrvTNUfY0zhH2zoVg5X1CkfhObjTP0fl00JH6NNFOMvTR0fuQEjTS5J9R/M5VdNPR/fV6Fsv01PJaEF601dMkA8G01pIBEgG019ICtNiSA5bBzWkSBFIE9NoSBc32NNrSBvTbkgeYOJIIdNzYHLTdUgq1D9ILNN6SC/TfUgy04BINdODRO3ThRAI04c3CdOJSEJIRNONSEfTkEhKrRtITUCANphIUNOXqBxIVdObSFjTnkhbQVbToUhfRUNHLtOlSGRMNziQ06lFqNOrSGzTrkhvCVvTsUhz07RIdtO3SHtRDdO6SH9nMUiCSR9AI9PASIfTw0iKOprTxkiP08lIk9PMSJadEkiZSJvT0kifSKHT10il09pIqdPcSKzT30iv0+JL8dPkSLXT55OCSLvT60i/0+5IwtPxSMXT9Jr60/dIzNP6SM/T/Vg90/9I1tQCSNrUBfuJSN9D/dQJSOPUDEjmVhbUD0jqObg6g9QTSPDUFjn+NDTUGXERSPnUHUj8NKzUIEkA1CNJAzwO1CZJB9QpSp3UK0kNASjULkkRSRPUMkkWSRjUNg071DhJHkkg1DxJI9Q/PAbUQUkqNSzUREKc1EZJMUlx1ElJNdRMOaIBS9RPST01btRSn7LUVElE1FdJR9RaPM/UXElN1F9JUdRihhWF0NRlSVrUaEld1GtJYDL9QdrUb0ll1HJJaElq1HZJbdR5SXDUfGP2SXbUgEl6OTTUg0l+1IZJgUmD1IpoGtSMSYrUjzMj1JFJkTzn1JSpi9esSZhABEmbSZ0GmtScUvBJozcMeLTUoUmpOEjUpEuY1KZJsdSpSbQ9r9StQEjUr0m71LJJv9S1ScJAX9S4ScbUuknJ1L1JzdTASdE5B9TDSdbUxusMQCnUyUnf1MxUO9TOSeXU0Ti31NM2A9TVNz/U15ECSfPU20n31N5J+zXZ1OFJ/9TkSgLU50oFVFQzN9TrSgozQEoN1PBKENTzUCTU9Tet1Pc1p9T5ShzU/AaK1P5KHtUASiXVA0oo1QZKKzQGSi46uNUKSjJ8Yko11Q9KODa5EMtKPNUV9VBKQdUZSkTVHEpH1R8/0dUhSk/VJEpS1SdKVdUqSlnVLUpc1S9KX0ph1TNKZEDt1TZKaNU5SmvVPEpu1T803dVBSnTVRDck1UZKetVJaAxKfzn/1U1Kgz431VBKhzkiVWPVVEqM1VdKj9VaSpI2A1ar1V5Kl9VhSpvVZEwr1WZKomIY1WlKpn8lSqljodVuSq4BS2k/1XJKs9V1SraqyUq6W485b9V7SsDVfUrD1YBKxtWDP/k6GdWGVQrViErPN1vVi0rU1Y5K2JHdSts7pdWTSuDVlkrkSubVmkrq1Z1K7dWgSvH31kr0VYJK99WnSvrVqkr9P/DVrUsC1bBLBdWzSwhHaUsLN73VuEsPRCY9RtW8XqhLFtXAgmRLG9XDSx/Vxksi1clWYdXLli1LKlga1c9LL1PmZinpjUs11daxPtXZRurV2zkdS0DV3ktEaDjV4TUE1eNLTFRO4bC10dXpS1VTNO1AS1rV7xAr1fFKfNXzS2VH0UtoNznV+dtBU8PV/EtxS3NVddYAS3jWA0t71gYBwNYIS4I4xtYLS4YPttYOS4vg4UuO1hNLkdYWS5RLlmYHhkBLm9YdUrvWH0uhM6gST9YjS6fWJkuqS6zWKkuv1i1Ls9Yw0ShLudY0S7zWN0u/P+TWOuymS8TWPjfU1kBLytZDS87WRjH/1kg0h9ZKNRPWTDO41k5FmNZQS9/WU0vi1lZL5dZZxvVL6dZdS+zWYEvv1mNL89ZmS/c0l0yD1mpL/NZtS//WcEwC1nMz/dZ1TAnWeFRG1npMEDTQ1n1MFAEo1oBCcdaCTBvWhTly1odMITT/PibWi0wm1o5MKdaRPqPWk0wwQELWlkw01plMN0w51p182Ew+OJp4bDyj1qNMRdamTEnWqUxMNexLiNatTFHWsFp81rJMWNa1TFxlyExfNEdMYQfFPeDWvcyGTGjWwExr1sMz/NbFTHHWyEx01stN1tbNTHvW0Ex+SQ3W00yC1tZMhtbZVKhMi9bdTI7W4EyS1uNMlUj31uZMmmXQ1ulMnkygP04Ri9buTKXW8Uyp1vRMrDHh1vdiRNb5TLM2mEy1MiTW/ky61wGMz0y/1wVMwztq1whMyNcLTMs5V0zO1xBM0tcTTNY7YdcWB9HXGEzd1xtM4Nx9TOPXIFEZTOdFZ9ckP9Q7stcnTO9M8dcrN4PXLUz31zBM+tczTP3XNk0A1zlNBNc7TQcHTNc+TQvXQU0P10RNEkNATRTXSE0Y10tNHNdOTSCMU9dRTSTXVPldTSk5Y9dZTS3XXE0x119NNNdiTTjXZU08PSvXaE1A12tNQ9duTUar43IDTUvXdE1OYtxNUtd5TVXXfE1ZNyX5jkCn14FNYNeENOXXhk1nD+LXid+kTW3XjU1w15BNc9eTTXcCVdeWVdrXmE1+15sF3k2C155NhU2H16JeKU2M16XX/a9W16hNm9erTZ7Xrq7dTaPXsk2m17VNqde3TazXuk2v171NsjdhMznXwXjD18NNuzaE1843btfITgvX6dfM19dOQtfQMhTX0k3QhPLX1dfZTfpNyU3679FN3dfg1/bX4d5pTZLX7E301+dHi9fpk4pOL9fsTfSsOk331/FN+jRm1/RODNf21+HX+IKiTkPX+9gC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+0ui5JNf4xk/X+MZP1/jGT9f4Tk1OYNgZPr3YG05nCr9Oz9gfeFPYIU5xTplOdDic2CZOeNgp2rhOfXLgToDYQNkpTobaIk6hT6jYNk6P2DlOklYR0mFOltg/TplQKthCOF3YRE7z2EdOpk6o2Ew6/9hOTq7YUU9g2FNOtthn2FhOvFFh2FtOwNheMrjYYE7FT2ZPHU7KTszYZ07PTmuOPE7T7l1O1jKZ2G5O2gZcUBPY8th0NpTYhtiY2HlO6th8Tu7Yf07y2IJOlU732IZO+k/tTv7Yi08BiU9PBNiQ2GLYk08L2JbYdw3q2JlPEticTxUyuNiPTxnYYk8dPKPYpE8x2NDYqE8oOOTYq08t2K5PMdjQ2LK9hTE/2LVPZ5ul2LpAXdi8T0bzzTu12MA4v9jCT09PUTLd2MZUn9jIT1c4p09a2M1PXtjQT2FdYtjTBFvY1epG2NdPatjZT27Y3EAg2N4MqdjgT3jY49j/irLY50NW2Oljh0+FT51PidjvBZzY8U+P2QJPktj22QZPmAFHNfzY+0+dT4k8FU98ZlbZAU+l2QQ7w9j3T6s00DVA2Qo15NkMQeTZDk+3sYlPutkTR5/ZFU/A2RhPxNkbL5bZHU/LT80Q0ZRK2SMF7U/T2SZP1tgwT9n0nU/cQUxP39kwYd9P49kzT5BP6dk3TvrZOU/vBFySvNk9T/RRitlAT9ZOdLOWT/vZRtkhTw81PkfC2UtQBNlONDTZUFALZlZO31AO2VVQEVATTxZEO9laUBjZXVAbUB3ZYVAg2WTYsVAkBprZZ9iX2SNQLNls9DFQMdlwcB9+fFA52XVBwtl3PLXZeVBBW3jZfVBG2YCJ91BK2YRQTdmvTAzZiEia2YrOMQGc2Y00MVBamS5QXdmSUGBFJlBVQzTZr9mZWrfZmwU32Z1Qb9mgUHLZo1E+2aVELThiOg7Zr9mZUH/ZrVCDUNBGr8eHUIjZtFCLBwHZt1CQ2bpQk9m9UJbZwFCZQ9HZw1Cd2cZO1tnIUKTZy1Cn2eeV4VCrAk0I3NnSULBQv1DB2epQttnaULkx1tndmgtQv1DB2eJQxNnl2c2V4VDMBQPZ7FDQ2e9OgNnyUNdQUNn2AaLZ+DTq2fo4ytn8UOPZ/wE82gFQ6toENMjaBlBwbmNQ81VX2gtQ99oOUPraEVD92tpRAdoWUQREIS0i2ho0ElEL2h5iGNogM13aIlEVUVTaJVEa2mdRHSNjUSzaLFGDkjnaL9pMUWzaTlGlUUnaNtpFUXTaadpJUWjaPlFC2jLaXFGlUWDaZtpg2kfaVtpr2ktRQtoy2lxRpVFg2mbaYNpH2lbaa9pLUULaMtpcUaVRYNpm2mDaR6ExUXnahVF92lTaadpJUWjaPtpuUaXacFFsUUVRjTgb2nQ5jtp2UZXmdlGYUa2cZ9p9UZ7agFGhYghRpNqFS5Tah1Gq2opRrlGwQFJRstqPUbUPYtqSOF0Eq9qVi9VRv9qZUcJFt9qcUcZEbNqfRojaoVHN2qRXM9qmNIvaqFHW2qtR2dquyiRR3tqyU5LatFHkNkTat1Ho2rpR69q9Ue5R8NrBUfPaxE8s2sbHKVH7EAfayhEH2sxSAtrPNzva0VIJ2tRSDNrXUg/a2lISQZwBCNreApza4FIaNiYHwlIe2uZIPdroclTa61Ip+KHa71IuOIra8jdn2vRSNNr3Ujfa+jxB2vzojFm82v9SQtsCUkXbBVJJUkvbCVJOUlDbDVJTM8JSVtsSUlnbFVJc2xhSYNsbUmPbHlJmsyNSaXOn2yNSbtsmUnHbKFJ12ytSeNsuUnvbMTuR2zNSgds2UoQ7Ots5P9TbO1U/qutSjzHK20BSk9tDv7NSmNtHUpzbSlKf201SottQFhfbUlKp21VGudtXUq+BCVKy21xStdtfUrnbYjxI22RSv9tnMrLbaVLF22xSyNtvNZPbcVLO23RS0tt3YYc4r9t6EN3bfEZebFvbf1Le24JS4duFUuTbiEGX24p2N1LqMnPbjlLu25FS8QpbOlfblVL325hS+tubUv3bnlMAUwLbolMF26VTCNuoUwvbq1P1261TEduwUxTbs1MX+VZTGtu4Ux3bu1Mg274G9tvAUybbw1MqO33bxv66UzDbyo+m28xTN9vPUzrb0lM929VTQNvYU0Pb21NG295TSUMWQn/b4lNO2+VTUdvoU1Tb61NXNJpCQVNa2/BTXdvzU2Db9uJqU2Y1pjVW2/tTbNv+U28zQwJgU3NaFlN2BxHsFFN6AUtTfGb43As7VjxB3A5ThKaPU4fcE1OKRVjcFlOP3Bk1WFOT1npTltwfU5ncIlOdMtXcJVOhTZFTo1mNa01rPNwsmMvcLlOudDPcMTW4N3FTs9QMU7YxyVO4VltTu9w7U77cPlPBNC9TxNxDU8dAgNxGtUFTzO5YU883r9xM6QNT1NxQU9hT2txUU95T4NxYU+RWJ9xbU+ncXVieU+7cYTJZU/NT9UMM3GZT+TOk3Gk5ZtxrVABF/9xuVKrccFQHPs/cc1QLOFXcdgIu3HhHtFYRQ7HcfFQWA3VUx9yAVBtLUpGhVB+K1lQiNuJUJdyKVCjcjVQrkLBULtyS7OBUNNyW6jZUOdyaNg3cnFQ/QCncn1RD3KJURkYf3KVBJNynVE6BwlRR3KxUVTdD3K85ZtyxVFzctJWyVGHBj9y4VGXcu1RoUavcvlRs3MEBr9zDdGLcxQcp3MdUeNzKVHs1TVGU3M5b8lSDVIXc01SI3NZUi1SN3NpUkNzdVJPc4FSWa6pUmTdbLeDc5lSe3OlUojtH3OxUp9zvxvdUrNzzVPXc9UOp3PdFt9z5VLg/YjJo3P1Uvo+sVME1zt0CVodUxz1g3QaE0FTNNVxHw90LVNI43t0OPJrdEEv03RJU3DlU9F9nRt0XVOPdGlTm3R1ZXFTrk5lU7t0jVPHdJlT03Sk5DFT6MJ8+290uVP9VAd0yCezdNFUH3TdVC906T8jdPDYA3T5VFN1BVRfdRFUb3UdVHt1KVSE+Jd1NVSXdUFUo3VNVK91WPnTdWDn03VoBdt1cVTfdXw/W3WES3N1jVUHdZlVE3WlVR91sVUs2WlVO3XFbLt1zVVTddlVXBprdeVks3Xuq51VgoYFVYzaw3YFVZ92EVFXdhlVt3YlVcFVy3Y1VdTVZ3ZBVed2TVXzdllV/VYHdm7WHVYacvlWJQ6gJkt2iVY7dpVWR3ahVlFKV3atVmN2uVZvdsVWf3bT5ZlWjbRdVpt26VandvVWs3cCWmFWx3cRVtN3Hhi7dylW8OvlD+1XA3dBVw2yC3dNVx93WVcrd2VXN3dw1JFXS3eBV1d3jVdjd5l+E1PlV393rPbXd7VXyVefTT1Xqf+BV7d31dHhV8n5KVfVV92Mi3fxV+93/Oa3eAVYBDJ/eBFYF3gdWCN4KMljeDFYP3g9WE1YV3hNWGd4WVhw4bjNE3hpWIt4dViXeIFYpXwLeIzZU3iVWMN4nbHXeKVY23ixWOd4vVjzeMlY/VkHeNlZEXv9WR1ZJ3jxWTN4/eyBWUjof3kNWVjduMo7eR1ZbeRZWXt5MVmJWZN5ReKTeU7ybVmzeV1Zv3lrb8VZ0gVJWd95gSG/eYlZ8Vn4+H95mVoIQOFZt3mo5M95sVoqj/FaNVsvecjVSVpPedVaW3nhWmU0rVpwzXd5+VqHegXik3oNWp96GVqtOp96JVq/ejFay9sfekFa23pNWuYuF3pdWvt6aVsE/c1bE3p9Wxzx2MlHeo1bMVs7ep1bR3qpW1N6tVtfesDnU3rI9gN60gFtW4jVwVuTeuVbnVunevVbs3sBW797DVzdW9N7HVvjeylb7X5XezVb/3tBXAt7TVwVBz97XOM/e2THIAb3e3FcP3t8y997hVxXe5FcY3udXG97qVx5bLt7tVyLe8OOlVyfe9Fcr3vfcN1cw1hVXMzZe3v1XN98AVzrfA1c93wZXQEX+3wlXRN8MV0ffDzj73xFXTYsYV1ABvt8WV1Q8eN8ZV1nfHOEOV17fIFdhL9hSjN8kV2bfJ1dp3ypXbU6f3y1Xcd8wV3TfM1d3PgrfNhJP3zhXf987NQPfPVeF30BXiN9DV4vfRleO30lXkd9MQdpXld9PV5jfUjNN31RXnt9XV6HfWlel311XqN9gNkHfYlet32VXsNxsV7Pfale2321Xud9wX5Lfcle+33VXwcB933hXxd97V8jfflfMMxDfgTbL34NX0zvYV9Zbi1fZC2xX3N+MV9/fj1fiXfNX5Vqk35Q8yN+WV+zfmVfw35xAdlf0359X9zSv36JX+9+lV/5KwN+oWAI03N+rWAbfrlgJWAvfsuSZ37RYEt+3WBVAON+6/kymHlgd379YIA+TTzffwzWT38VYKN/IWCvfy1gu385afN/QWDTf01g339ZYO9/ZN3zf21hB395YRDwA3+FEO9/j6j1YTd/nWFBaD9/qWFTf7VhXN4A7yd/xWFw3VN/0Nl7f9lhi3/lYZd/8NKVYad//WG1rflhwOMLgBOuwWHY3OzI64AlYe+AMWH7J8ViB4BFYhOAU3sZYieAYWIzgG1iP4B4EmuAgWJY+RDVU4CRYm+AnWJ44bDx44CtYo+AuNChYpzgQBhXgMlis4DVYr+A4WLJh1eA7OVXgPVi4OwPgQGGzWL0Rc3ikWMDgRljD4Ek/7uBLWMngTljM/rpYz+BTWNI30zW84Feja1jZM1M05+BcNWzgXjJP4GBY5OBjWOg1d3mS4GdY7XWvWPDgbFjz4G9Y9uByPZjgdDJK4HZbb+B4WQLpkFkF4HxZCK3OWQvggVkO4IRZEeCHOdHgiVkX4IxZGgpb4I80C+CRWSFfwlkkBQpLWlko4JnrNVksUM5ZL3eSWTLgoj27WTfgpjVG4KhZPeCrWUDgrjbcWUTgsVlH4LRZS/5gWU46czNY4LpDd+C8R8PgvllY4MFZW+DEWV7gxz9V4MlZY+DMWWbgz1lqNiTg026W4NVZceDYWXVJruDbWXlJQEtY4N89IODhWYHg5FmEOkjg51mI4OpZi+DtWY7g8FmRpmVZlLkmYgZZnOD4BOrg+l+8WaDg/lNp4QA8kOECWanhBP6HWa5WfeEIWbLb3lm14Q1ZuDin4RBZvOESWb9dv1nCNYrhGFnGUQA2ZeEcWcvhH1nO4SIzOeEkWdRAueEnWdjhKlnbNeQGzOEuWeDhMVnjMwPhNFnn4TdZ6z+QNb/hO0Rs4T1Z82ix4UBZ97PlWfrhRTQ7Wf7hSFoB4UtaBOFOTzfhUGZM4VJalVoM4VZaEDp0tIJM1uFbWhfhXloa4WFaHUKrPD9aIDtF4WZYEeFoWidAVECm4WxaLOFvWi+p41oy4XQ1fOF2WjoOROF5UkbhezfJ4X1aRDM44YA54OGCWkvhhUK8h2ZaUOGJWlNSBeGMRWPhjlpZ4ZFaXOGUdxNaYOGYWmM3u+GbWmfhnlpq4aFabeGkVDfhpjZR4ag9LOGqWnpYMT6T4a58p+GwWoPhs1qGWojhtzcS4blajVYU4bxakXSkWpThwVqX4cRamuHHWp7hylqhSi7hzY5TWqfh0Vqq4dRareHXWrDh2ka/Ov/h3Vq2Wrjh4Vq7VLzh5Fq/4edawuFdWsXh7FrIObvh8FrM4fNazzjE4fY7j+H4Wtb8kVrZ4f1DeeH/Wt/iAlrimYpa5eIHWujiClrr4g1a7uIQWvHiEz5+4hU6Z+IXUGniGVr9Q+42a+IdRwbiH1sF4iKcnVsK4iZbDTQjWxDiK1sT4i5bFgJLOZjiMlsb4jVau+I3WyGKMVsk4jw5M+I+WyoCHVstWy842OJEWzPiR1s24kpbOWRtWzziT1s/R8fiUlC84lRbReJXW0jiWltL4l1bTuJgW1HiY9W5W1biZ1tZNfrialtd4m1bYOJwW2Tic1tnMNZbal3l4nlbbltw4n1bc+KAW3bJGVt54oU7HeKHW3/iiluCWY1bheKPW4g6m+KSW4zilUq84pc50uKZNFHim1uXSNzinjnS4qBdYuKiW6HipVulRQTiqFup4qtbrHyAW68LeTKS4rFbtOK0W7jit1u8Nc9Cd+K7W8Hivkjt4sBbx+LDnoRbzDngMcHiyIffW9PizFvW4s9b2Tjg4tJb3eLVcD5eEeLYW+Ti21vnQ4/i3lvrO6ri4XdGW/FUgeLlW/Xi6Fv44utb+2GN4u7VoeLxXAPi9FwG4vdcCeL6XAzi/VwP4wC3AVwU4wQBBOMGXBrjCVUN4wtcIeMOXCTjEVwn4xQy1OMWXC7nuuMaP8jjHFw2OTbjH1w64yJcPUAE4yVcQeMoXETjK1xI4y5cS+MxXE7jNFxRPU9LseM4XFZwNlxZ4z1cXONAXF/jQ1xiOI8yAlxlNPPjSVxp40xcbONOXG9LsuNRXHRfIeNUXHjjV1x7B2njWlx/411cguNgch1ch+NkXIo0nDZm42hcj+NrXJJqFlyVNAnjcEiQ43JcnFZx43VHBvYuXKLjelyl431BnON/bqLjgWGu44OXaTeAB7/jh1y044oyj+OM5drjjjfF45BcvjL/OPvjlKIFVrvjl1zG45pcyUKT455czTZ+NdDjolzT46Vc1uOog0Rc2zPD46xc3zUp469c4+OyUiVc5+O2XOrjuVzt47xFOD09479c8+PCXPZBu+PFXPrfVFz948o4buPMXQJs4uPPXQZGfOPSXQrj1V0N49hdEOPbXRPj3mWLXWHj4V0aUnNdHePmXSDj6VlC4+tdJuPuP4vj8HTyXS3j9GmM4/ZBSuP4XTXj+1WD4/1dOzfRXT1ng+QBXUHkBF1E5AddR+QKXUrkDV1O5BBdUeQTXVTkFl1X5BldW+QcXV9QY11iRXLkIV1mQ1jkJF1q5CddbTwRO2XkK11ySk7kLl13PEE7dl165DNdfTbC5DZdgeQ5XYTkPAJZ5D465+RAXYwH5TS25EQ2yORGXZQz1eRKXZjkTV2b5FBdnuRTXaHkVl2kQ0DkWV2o5Fxdq7kWXa7kYT3n5GNdtTbtYonkZ1275Go1XORsXcGKnuRvXcXkcl3I5HVdy+R4Xc7kezM95H05M+R/XdfkgnpmXdzkhl3f5Im6d13kXeY5A+SPXcHkkV3t5JRd8DUy5Jdd9D8V5Jtd+DHh5J4G3+SgXf/kozLd5KVeBOSoXgfkq14K5K4+9OSwXhBeEjPp5LReFuS3Xhnkul4c5L1eH23wXiEa6QXg5MJeJuTFTBAysuTIXizky14v5M5eMjz65NFgsU1BMuXk1V47aBrk2JL0XkDk3F5D5N9eRkfq5OJK2OTkXk3k515Q5OpeUzV25O5EceTwXlrSWDuRSTnk9UPn5PcBSl5k5PpeZ+T9XmrlAJTYXm/lBNMNXnQ6beUIXnhET0ID5QxefuUPXoHlEl6EMx3lFV6IOMLlGDIG5Rpej+UdNAXlH16VM7F3fOUjXppOgZqEXp5IseUpO0flK16l5S5eqQSb5TFermfq5TVeszqmPxblOXtkdfPlPV6+5UBLmOVCXsPlRV7G5UheyeVLXsw0wuVO2x44QeVRND9e1eVUXtjlV17bOMblWl7fOCle4eVeOwDlYFMwXunlZF7sPmE4VeVoOQ5RPuVrN57lbV735XBJEuVyOarldF7/5XdfAl8E5Xtjb18J5X88tuWBXw9fEeWFEIflh18X5Yo4hl8b5Y1fHuWQmPFfI+WUXybll18p5Zo1SOWcM6Llnl8y5aFfNeWjXzjlpl875alfPgmI5axNUOWuM93lsF9IX1FfS+W1X07luF9R5buV/V9WAUwxv+XAX1s4F+XDNOnlxV9i5chfZTKJ5cxfaQ9IX2zl0V9vRkfl1DOY5dZfdjH65dlfeuXcX31ff+XgQQ7l4lXc5eRfhwNe1/Bfi1O0N3Hl61+Q5e7l2uXwSK7l8l+a5fVfnT2LTsnl+TwX5fvbol+nhPlfquYBX6449jT+5gVfs1A35ghft+YLX7pnQl+95hBfwF/C5hRfxV6CX8iwol/LXqtc7l/P5h5f0kZe5iFf1+YkX9rmJxA15ilf4GA/X+PmLjfl5jBf6OYzX+vmNl/u5jlf8eY8X/TmP1/35kJddOZEX/3mR1D55klgA1SC5kxgB6RDYArmUWAN5lQ+rOZWYBNGO+ZZYBdRqWAa5l5gHeZhCgLmY51zYCXmZ2AoUVlmkuZrYC09Pkdh5m9gM0D25nNgN+Z2YDrmeY1mYD/mfWBCYDI6NuaBYEe9MzHr5oU5LuaHYE/mimBS5o1gVYLTYFhWk+aSYFzmlUrS5pfH/mBkjGjmm2Bo5p5ga+ahYG7mpGBx5qdgdeaqYHgzYOauO4zmsGB/YIHmtGCE5rdgh+a6byJgi0Ic5r9gj+bCYJLmxWCVS2PmyGCZhb/my2Cd5s5goTrzNBXm0mCnOtPm1WCr5thgrrLd6aaQhmC05t/uYmC55uNgvObmYMDm6Ti85us3YObtYMkBSp0EYM0z/Dcq5vRg0jeq5vhg1gFx5vtg2jXN5v5g3zIBNmznAmDk5wVg5+cIsDRg60xB5w1g8OcQYPPnE2Bh5xVg+ecYYPxC8OcbYQAG3GEC5x9hBTM8SChhCeclPPvnJ+A1YRFhE+csYRbnL0PY5zFhHDkF5zRhIOc3YSM022Em5zxdPec+YSz6rGEv50NhMmE050dhN+dKYTrnTWE+51BhQedTYUQ5XedWYUjnWWFL51xhTudfYVHnYjXS52RhV+dnN2DnaQNX52thYeduYWQGymFnT8bnc2Fr53Zhbud5YXFuiud8YXXnfzaVOLfngmF754VhfueIYYHni2GE545hiGGKVpMyCueUYZDnl2GTQQ5LX+ebYZjnnmGbOnk5C+eiYaDnpWGk56hhqOerYayLBkPg57Do/Oe0QTnntmG457lfQ2G8571hv+fAYcICdefDMxDnxWHJ58hhzOfKYc9h0efOYdRh1kuJMsth2ufVYd3n2BrpAuXn22Hk595h52hlYern42HtDwbn5rY4N3Fh805e5+th+GH65+80PmH+Ai5AE+fzYgPn9uD25/g4VEdTYgzn/GIP5/9iEi+1PH5iFjLQ6AViGzLc6AhiHzalYiLoDWIl6BBiKOgTYivoFmIuMw8BeOgaYjNe0zPe6B5iOeghYjzoJGI/RmfoJ0Zv6CmPS2JHNOfoLWJL6DBiTugzYlHoNmJU6DliV+g8YlroP2Jd6EIP5OhEN43oRmJnAljoSmJrVefoTWJv6FBicuhTYnXoVmJ46Flie+hcax5igOhgYoPoYmKG6GViiuhoQdfoamKPPnlikuhvYpU8ceh6YplFOOh2Yp1Wq+h6YqE2NhDU6H4OVeiAYqliq+iEVy1isEYJn7LoiVag6Itit4erYrrokGK96JNiwDXlNEdgnGLFP0kzIeiaYsuyNIDXOWDon2LS6KJi1S0i6KVi2WLb6Kli3ker6Kxi4uivYuXosmLo6LVWCmLt6LlADOi7YvPovmL26MFi+ejENq7oxmL+6MljATX16M1jBejQYwkzE+jTYw3o1mMQpjljE+jbYxY2/y27Yxro4WMd6ORjIejnYyXjlGMo6OwN6ujurlZjL0c6N3Xo80H56PVjN+j4Yzphruj757Lo/WNB6QBjROkDY0c1dDJv6QdU22NO6QtjUjgJ6Q5KvGNXdCZjWmNc6RVjXzcJMkrpGWNkY2bpHX4HY2tGxukhQRhjcOklR8XpJ2N26SpjeUkS6S0FzWN+RzljgekzY4TpNmOHO1Y71+k6Y4wG2zj16T5jkelBAXbpQw1zfrx2jmOZ6UljnTNX6U1joTxI6VBjpUMBTanpVGOqqItjrTHO6Vk50elbY7RT+mO36WBjumYtY73pZWPAWRhjw1hZY8YzOOltY8rpcGPN6XNj0Ol2QITpeGPV6Xtj2BCHq61j3OmBY9/phGPi6YczTemJY+jpjGPr6Y8z+jZu6ZJj8emVnutj9kXV6Zlj+umcR1VG4+mfvDdkAemjZATppmQHfkpkCumrWEvprTg76a9kE2NPPPvps2QY6bZkGzzkNiPpujIZ6bxkIum/ZCUFA2Qn6cNLaOnFZC3pyGO+ZDJB00pc6c1kN5qHZDpH6unSZD7p1DfEZELp2Hk56dtkSeneZEzp4mRPq6bp5mRTZGHp6TRWZFjvwGRbTexkXmRgWq9kYzmt4PpTw+n1ZGlB5DmS6fk5bOn7ZHEzk0dp6f9TLeoBZHnqBGR86gdkfz4L6gpBU2SECCcfqeoPaK08YeoSZI3qFWSQ6hhklOobZJjqHmSb6iFknuokZKHqJ2Sk6ioG2zTN6i1S6uovZK6N92SxRQXqNGS16jdkuEP9NfVku+o8Alk2g+o/ZMHeoGTEQajqRGTI6kdNtepJZM45o+pMZNLqTz566lFk2epUZN3qV2Tg3FJk44JoZObqXmTqx3tk7UE56mNk8epmZPQ6EWGi6mpk+WM9aa9k/TYs6nA+S+pyQqjqdGUHPwPqd2ULAa88+2UO6nxlEep/Bq/qgTWd6oNlGOqGZRvqiWUe6oxKLjmf6o9lJOqSZSfqlWUq6phlLTHF6ptlMQEJ6p5Io+qgZTjqo2U71dhlPj4n6qhlQuqrZUXqrmVI6rFlS0CxOUfqtWVQNKtlU54NZVbqvGVZ6r+P/GVe6sNlYerGZWQ0lFKm6splaTmL6s1JGurPZXDq0mVz6tVldurYZXnq22V8qe1lf+rgZYLq4znL6uVliOroZYtjcmWO6u01xOrvZZTq8mWXS6Tq9gXH6vhlnur7ZaFLt+r+ZaUNkOsCZanrBWWs6whlrzIz01Bls+sOZbY3cusRN27rE2W86xZCoesYgd5lw+scQsHrHmGl6yBlzRHt6yMIZuslZdRA3uspZdlckussEu4zDusvPIDrMWXjMzDrNWXn6zhl6us7Ze3rPmXw60Fl8+tEZfbrR2X560pl/OtNZf/rUGYCMfpEwutUZgfrV+j2Zgw7WetbSuPrXWYT62BMV2YXOg5ESmYbPZxmHetoZiD2B2Yj621mJmNPZOPrcWYrQG/rdDmK63ZmMut5ShLre2Y46364zGY964IyCOuEZkPrh2ZG64pmSeuNZkyGNWZP65JmUjTl65VmVuuYZlnrm2Zc655mX+uhZmjl7OaTZmfrp2ZqdYJmbV7Y6vRmcuuwrZJmdlDAMuPrtWZ767hmfuu7ZoE6Faa3ZoXrwWaI68Rmi+vHZo/rymaSOtXrzWaW69BmmevTZp1AaE0u69emEGak69tmpzaE699mqzfJ6+I0B+vkOKHr5ma1Nu1mt+vrZroEsma86+9mv0hg6/JmxOv1Zsfr+GbK6/tmzev+ZtDsAWbT7ARm1uwHZtpm3Dof7Axm4ewPSLw0COwSZudmsewWZus2TuwZN5jsG2by7B5UnWb37CJm++wlZv5hwuwoZwOHvGcG7C1nCewwZw3sM2cQ7DZnE+w5PBvsO2cZQcM60+w/Zx4BvexCZyI8t+xFRsHsR2co7EpnK+xNZy7sUGcx7FNnNOxWZzfsWWc67Fyfgmc/Oqh4MGdDQF/sYz2R7GVnSuxoZ01AmDW17GxnUuxvZ1VcbAZDZ1k63+x1Z13seGdgBq9nYux9Z2V5T2do7IJnbOyFZ280RncxVKVndOyMQalneD/wZ3o0J+yRZ3/slGeC7JdnhuyaW1nsnGeL+YxnjuyhhzBnkzbfWPnspmeY7KlnnOysZ5/sr2ei7LJnpey1Z6jsuDWu7LoQkey8eyRnsk3OZ7XswuOMTf7sxWe7bm80TOzJTi7sy2fDoN7hAlI+7NBnyezTZ8wQOGfO7Nhn0ezbZ9Ts3mfXZ9nFPGfc7ORn3+znZ+Ls6mflUthn6DRH7O9n7D4uQJjs82fxNRHs9mf17Pln+Oz8Z/vs/2f+7QJoAe0FaATtCASV7QpoCu0NaA2BAe0QaBHtE2gU7RY/4u0YaBo/6u0baB/tHmgi7SECee0jRjEx+e0mSgztKGgu7StoMe0uaDQ+8xcu7TI4LO00aDwza+03aEBNQ2hD7TxoRjhkBJrtQGhLig429+1EaFF3fFRO7UhoVkmP7UtoWkyE7U5oXj437VFoYu1UmY5kle1XaGrtWmhtbGBocO1faHPtYmh37WVoeu1oaH3ta2iBOAbtb2iG7XJoie11aIzteGiPaJHtfD2h7X5WCUOx7YFomu2EaJ3th2igOlXtiz4L7Y1opu2QaKntk2is7ZZor+2Zctrtm2i1RhDtnmi57aFovHgjaL/tpmjC7aloxe2saMjtr2jLfNvts2jP/oVo0u24NWDtulsOaNntvmjc7cFo3+3EaOJHle3HaOY2Mu3KQqftzBT+7c5J5+3QaPFDAe3UaPXt10PY7dlo++3caP62UWkBNCPt4WkF7eRpCDJc7edpDDpEL5bt62kR7e4Ev+3wVWPt8kH37fRpG+33EQdpH+36aSLt/aFraSbuAWkp7gSiK2ku7ghpMVyTaTTuDWk37hBpOu4TBwHuFVTB7hdpQ+4aaUbuHTIK7h9v+GlOPH1JkWlRQf/kDmlV7ig2we4qaVvbuGle7i9pYWZTaWTuNHHEaWnuOGls7jtpbzL1RP/uPwJO7kFpdwbM7kRpezwT7kdpf3907kppg+5NaYZEQO5RP/g02+5UMsjuVmmQO6Fpku5bQq7uXWmY7mBpm+5jaZ5KTmmg7mdpozeByVFppwmSaakKv+5uaa3ucViR7nNps+52A17ueGm57ntpvDLE7n9ro+6BacPuhGnG7odpye6KacyCPGnP7o9p0gkH7pJp1mHMYTtp2e6Xadzummnf7p03qGnj7qBp5u6jaenupmns7ql+Ljjh7q1p8ziSB3/usWn4BZxk0+61UUfut2oA7rpqA2b47r1qB+7Aagruw2oN7sZqEO7JPlruy2oW7s5qGe7Rahzu1Gof7tdqIu7aaiXu3Woo7uBqK+7jai41swWd7udqM0J3Ocnu62o47u6TqGo8SelqP5yf7vRqQ+73akabCmpJ7v1qTO8Aak9FbmsSalPvBmJE7whqWTkdTIPvDGpecUHvD2pi7xJqZe8VamjvGGprCK3vG2pvd/tqclxrNkE1pe8jangx+e8mN07vKBFz7ypqglQ37y1qhmQ+nJ/vMUgHN5rvNGqO7zdqke86apXvPUOP7z9qnGqe70M1Xe9FaqQ4ZO9IOLzvSmqsQZjvTU/Q709qs+9SarbvVWq5OTQ9YO9Zar5blGrBZzw3Ju9fOIHvYWrI72RqyzkoxclqzzoP72pq0+9tatbvcES473IDee90at/vd2riMj3vejfi73xq6UCP739CHO+BavGVhWr0POY8Ee+HavnvijfY74xq/0q8749rA++Sawc5y03C75Y2Q++Yaw/vm2sSM5trFKk/axfvojLOaxvvpWseVYAy5O+payPvrGsm7684dDn+aypcbGbfay3vtTc+77drMu+6azXvvder779rOu/Ca0cyO+/Fk4E0eGtCNG3vymtGU6rvzeOH7881dmtNU6jv01Ac79VS/WtWEA/v2WtaPTY3Cmtd795rYO/ha2Pv5DQ/a2fv52tq7+qfCGtv7+5taO/wa3Xv82t4PIPv92t8A04+W+/7a4Hv/muEiZtrh7xPa4rwBWuN8AhrkFbo8AxVV/AOa5dekGua8BNrnfPQa6DwGFRh8Bo6evAca6nwH2us8CJrr/Ala7I31/Apa7bwLGu58C+2GWu+8DNrwfA2a8RhEGvH8DtQEvA9S2PwP3Iu8EFr00Et8ER3nzY68Edr2lwc8Eozh/BMOrHwTjSUMcvwUWvl8FRr6PBXOCPwWWvu8FwLxPBeR9TwYAF28GJr+fBlQRbwZ2v/8GpsAvBtbAXwcGwINTxsCvB1PoDwd2wP8HpsEvB9bBXwgGwY8INsG0c58IZAQr0SbCHwi2wk8I5sJ/CRbCrwlGwtEu7wl1WDPLXwmmw0S2Q1rvCebDnwoWw88KRsP1S+8KdsQ/CqbEYBEfCtbErwsGxN8LOVaGxS8LdsVfC6bFgzkfC+RN/wwGxff/RsYvDGbGU5nvDJbGlLsvDNbG3w0DTy8NJsc/DVlTdsePDZ719sffDdbIBVOfDgbIU7oVhq8ORsivDnBJvw6WyR8OxslAHJ8O9smPDybJvOfWye8PdsofD6bKTw/WynN9zxAGyrSO7xBGyv8QcIYGy08Qtst1YAbLpvB2y98RJswDWmOCHxFmzF8RlsyDU28RxAsjIU8R9s0E1n8SJs1LCB8SVs2PEobNzxK2zf8S5s41P0PxvxMmzoNiLxNT1K8Tds7vE6bPHxPWz0031s9/FCQ7JF/fFFCXHxR20A8UptA/FNbQbxUG0J8VNtDDNa8VZtEPFZbRPxXG0WAnnqNG0aSXHxYm0eNJrxZW0i8WhtJWKw8WxtKvFvNARtLvFybTHxdW008XhtN/F7bTrxflUY8YBOnfGCbUNHNlPp8YZtSGB/YY3xim1N8Y0zxvGPbVLxkm1VO3ttV/GXbVrxmm1dRRQ1SPGebWPxoUK48aM2u/GlBj/xp2878altcjMpMd/xrW13kb7xsG178bM8E/G1bYHxuG2FAssIaPG8kK1ti/HAbY4DdfHDbZLxxm2V8cltmPHMbZyQjjNI8dBtouA08dQ+N6o2bajx2YYM8dttrfHebbCyWm2z8eNttvHmbbk1pfHpbb3x7PUKbcJZQW3F8fNtyPH2bcvx+W3OOufx/TYG8f9t1fICbdj1qPIGbd3yCW3gPAXyDG3k8g9t5/ISNFHyFG3t8hdt8PIZbfM2PfIcbfc6+fIgbfvyI23+8iZuAfIpbgReEfIsbgjyL0AB8jFuD/I0PWXyNm4VATjyOm4ZS/Uwk24cAi82QPJAbiHyQ24k8kZuJ2E7bQpuK/JMbi7yT24x5MhuNDbCbjfyVlbu8lhuPfJbbkB87lU+8mBuRfJjbkjyZm5LUI5ApnA2blDybm5TyvFuVvJz6tduW/J3bl7yem5h8n1uZW8YRWBAyGs4lppubfKFbnDcK25pbnVTqGWgbnnyjm588pFufzOk8pRug/KXbobymm6J8p1ujfKgVTDyok8abpR8p26XBgDyqG6b8qtunvKubqHysW6l8rRuqPK3VtturfK7brDyvm6z8sFutvLEbrnyx2688spuv/LNOWXyzzzP8tHT327J8tU+0/LXbs/y2m7S8t0/TvLfn3du2cGPbtzy5W7fNTLy6DQU8upu5zPgUGPy7m7s8vFu70FL8vRu8/L3VkRu+PL7Tory/UnG8v9vAfMCbwXzBW8Jg49vDPMKbw/zDQLl8w9vFPMSbxfzFVHP8xdvHWiF8xp1gfMdbyXzIG8o8yNvLPMmx1hvMfMqbzTzLW83FQxdpG87OgbzM28/PcHzNm9D8zlYPfM7QqfzPW9Leng/5API80JvUfNFb1Q5ZW9W80lvWfNMb1zzT29fUfs5bfNTb2TzVm9n9wxvavNbb23zXm9w82Fvc/Nkb3aOHvNob3rza299S0Q3dfNvb4Lzcm+F83UCTvN3b4vzem+O831vkVU/b5Tzg2+X84ZvmvOJENTzi2+g845vo1j0b6bzk2+p85ZvrPOZQ5Lzm2+x855vtPOhb7hLnfOkR5ZvvQG386hvwfOrb8Tzrm/H87FvyjXP87Rvzk81Si7zuG/T87tv1vO+b9nzwW/c88Q77fPGNJw/jvPJb+UzE1JV881NLvPPb+zz0lGb89Rv8gcDb/Tz2G/3Oh1v+fPcQUvz3hDdMk/z4cg4cATz5XAH8+hwCvPrcA0+hXAP8+9usXAUSNNwF/P1cBrz+HAdUmnz+24ucCM8efP/SNT0AXAq9ARwLfQHcDA1ePQKkPtwNjap9A9yJvQRcDz0FAFp9BZwQfQZcET0HHBH9B9wSvtscE30JQO7cFD0KHBTNRz0K0BC9C1wWkmc9DBwXvQzSRf0NXBj9DhYPfQ6cGn0PTbR9D9wb/RCcHJh03B19Ec1B/RJQbD0S3B+P7812PRPcIP0UnCG9FU3fvRXcIz0WjldcJD0XXCU9GBwl/RjcJpDiHCc9Gdwnzv/9Gtwo/RuVRpwqPRycKs3qfR2BpT0eHCy9HtwtfR+cLj0gXC7OmL0hHC/9IdwwvSKMof0jPs5cMn0kHDM9JJwz/SVcNL0mHDVSzdw2PSdcNv0oHDe9KNw4fSmNlX0qHDn9Ktw6jVZ9K41yfSwcPH0s3D09LYwnTkn9Llw+qLecP30vks49MBxAvTDcQU4nPTGcQn0yXEM9MxxD/TPcRJJnPTSNz88T/TVcRn02HEc9NtxIDMn9N5xJPThcSf05HiM9OZsh3EuP4n06nEy9O1xNfTwcTg9lUnx9PRxPfT3cUBGVD2aSdwyKfT9cUdXv3FK9QI5J/UEcVBVSPUHcVT1CnFX9Q0+TPUPcV1xX3FgQ8n1FDVn9RbNqnFpVoFxbPUccW/1HzLb9SFxdfUkcXj1JzL19SlxfvUs8nr1LnGEQRz1MUek9TNxivU2cY2K7XGQMk40nfU8cZX1P1RVcZn1QnGc9UVxn/VIcaL1S3Gl9U5xqN1Scav1VHGu9Vc1lvVZcbT1XHG3Mzn1X3G7P/z9DHG/PML1ZXHD9WhxxvVrccn1bnHMf7Zxz/VzcdI7bPV3cdb3L1mlU7Q3yXHc9X5x3/WBceL1hHHlQ/5x6AlHcerVfXHtOMD1jnHx9ZGtPnH29ZVx+Ufq9Zhx/fWbcgA9LvWecgT1oXIH9aRyCnUscg1t2nIQ9atyE/Wuchb1sXIZ9bRx9HIdO4j1uHIh9btyJPW+OMD1wHIq9cM92vXFci/1yHIy9ctyNTk+9c5yOfXRcjwIrfXUckD11zxO9dk3dfXbPtJySPXeM0z14HJO9eNyUUrV9eZSJvXoclj163Jb9e58DXJfhQdyYvX0cmU5W/X3Om71+XJr9fw0bPX+NG72AHJyN+b2A3J39gZ4JzvW9glyffYMcoD2D3KDQRb2EkEH9hRyivYXco32GnKQOWz2HnKV9iFymPYkT672JnKeMrJtQHKi9izuiHKnNjLhJ3KrRc32M3Kv9jalc3KzBqelLHK3Ohs1i/Y+cryd7fZBcsD2RHLD9kdKy/ZJPtH2S3LLRST2TnLP9lFy0jPj9lRy1vZXTmL2WXLdTqejBnLhaJT2XwKOcub2YnLp9mU35THb9mhBTPZqcvL2bXL19nBy+EcK9nNRt3bucv72eHMBRwg18/Z8cwZKEnMI9oBzC/aD68tzEPaHZIn2iXMW9oxzGfaPMqilgnMe9pQyPz819pdzJfaaYaL2nHMqh0VzLTiROMdzMGLI9qRzNF57NzT2qHM547VzPPatcz8R6vawNZj2sgcR9rRzSPa3c0v2unNONrpzUPa+c1MCafbBc1f2xHNa9sdzXfbKp29zYUYW9s9zZTdhc2f21HNqSrj213Nu9tpzcfbdc3T24HN39uNze2sGEXv253OAD4b26nOEMv/27XOIM1j28HOMYl9zjvb0c5FS5HOU9vlzl/b8c5r2/3Od9wJzoPcFdK/3B0aS9wk+H/cLc6v3DnOu9xFzsfcUc7T3F+IuOZr3GnO79x0yQvcfc8E78jHN9yNGxvclc8j3KDQu9ypzzfctc9D3MHPT9zM9yXPX9zZz2j9zc933O3Pg9z5z40JzPn33QnPo90Vz6zShNP73STHV90tz81OS9041HPdQNsL3UnP8Nadz/jq891czbzsgVIz3W3QGbyr3XgIk92BUjPdiMhRUJIMw92V0E/dodBbZuXQZ9210HPdwdB8zkfdzdCP3dnQmSNfTY3QqOnlY+/d9fiV0MfeBbD10NveFdDn3iHQ9ZPh0QEU39450RDm795F0SPeUdEv3lzzD95l0UPecSDl0VfegdFg5h/ekdFz3p3RfUZv3qp7496x0ZvevdGn3snRs97V0bzNKRQn3uXR0eBN0d/e+dHo73ffBdH4/yvfEdIL3x3SFZab3yjWl98w7N/fOcSZ0kPfSB7/31HSW99c7lPfZUoN0nvfddKH34HSkNmjJgXSodz50q/fodK736zt0Nsv37nS19/F6t3S59/VD+nS99/h0wEij9/t0xPf+dMc5i3XhdMr4A0Ad+AX9vXTQ+Al00z59+Aw2QfgOdNr4EXTdN+c87vgVdOL4GDAC+Bp06PgddOv4IHTu+CM8BvgldPSckfgpdPj4LDmq+C50/kHo+DEyzvgzdQRY1nUHTx/4OAW/+DpDAfg8dRH4Pz74+EE4l/hDdRn4RnUc+Ek9lfhLdSL4TnUlQDp1KDfO+FR1LPhXdS/4WnUy+F11NfhgRMr4YjNg+GR1PPhndT9jN/hrAUp1RftodUj4cHsq+HJ1TjTuONH4dj5D+HhAgA5W+HtUpPh9dVz4gHVf+IN1Yj3uhvP4h3Vn+Ir4pnVr+I44J/iQdXFW4EOFdXX4lnV4PfA9NviadX34nUq6+J91g/XsOKk3S/ikLu51ifinQwI9NviqdY83pxDR+K51lPixdZf4tHWaM/1u5Pi4dZ9BOUdM+Lx1pD/JVmb4wHWp+MN1rPjGMyT4yHWx+Mt1tPjOdbf40XW6+NR1vTph+Nd1wVx7dcQ4/PjddcgESG2ydcz443XP+OZ10/jpddc0QnXZYfJ13AcMi5B14PjydeROffj2+0d16jms+Pp17jwDdfFHw4L1+QBpjPkCdfj5BXX7+Qhm/jwQ+Qt2AfkOdgT5EXYH+RR2CvkXdg35GnYQ+R12Ezfz+SA7X/kidhlV8XYc+Sd2H/kqdiL5LXYl+TB2KPkzdiv5NnYv+Tl2Mvk8N875PnY4+UF2O/lEdj4yvPlHdkIv0zVR+Ut2R/lOdkr5UTIF+VN2UPlWdlP5WXZW+Vx2Wflfdlz5Yjoy+WQ3i/lmdmX5aXZo+Wx2azIM+W92b0DDPhD5c3Z0P/x2dvl4dnmkXXZ8Ewszwvl+doH5gXaE+YQ5kvmGOXz5iHaM+Yt2j/mOdpIzCfmRdpb5lHaZ+Zd2nPmadp9BM/medqMzBPmhbEZ2qTogdqtHwPmodq/5q3ay+a52tfmxMnT5s3a7+bZ2vkQkTTh2wvm8DCr5vkq0dsg8z3bKOao5C/nFds/5yHbSne121Nxddtf5znbaOJz50Xbe+dR24fnXduT52nbnB3/53Xbr+eB27lSEO1H55Hbz+ecC1Pnpdvk0J/ntdv358DNlnjN3Avn1SQ3593cI+fp3CxPA+f53D/oBdxPMrHcW+gZ3GfoJdxz6DHcf+g9L43cjNzcHf3cm+hV3KfoYAQ93LfobdzD6Hnc0+iF3OAFxdzr6Jnc9qZh3QARI+it3RESd+i53SDMQd0pQBvozd076NndR+jhGyPo6d1b6PXdZ+kB3XEJdMdb6RDLu+kY10k7w+klJ3PpLd2n6Tnds+lFC3PpUd3IEsvpXUbj6WTsh+lt3fHN4+l42Lvpgd4QC60dF+mS6pWOh+md3jlRY+mt3kjeZ+m53ljxX+nF3mn4eV5MK3/p2Tm36eHek+nt3p0mcQQ76fzKx+oGOfj1O+oR3szrPd7Xw73e4Sc53u/qNU+b6j3fBOTo8AfqTAaD6lQLLOA/6mHfL+pt3zvqed9H6oXfU+qQ8RjOY+qd32jPD+qo2E/qsd+EzMDuy+rB35vqzMhT6tXfr+rhHqTGr+rt38fq+UOV39Q1zPFB3+PrDd/v6xbR3eACtPvrKeAT6zXgH+tB4CvrTeA361tjEeBJGOEW7+tt4F/reaqn64Hgd+uN4IPrmWbz66Hgm+ut4KfrueCz68aMIeDD69QX7+vc02fr5eDn6/D69+v54PjJy+wJ4QhAr+wV4RvsIeElup3hMSpr7DQ5F+w94UjKQ+xJ4VvsVeFn7GHr+eF44JzIb+x14Y0H/UGN4ZvsieGn7JXhstJd4b7LB73dCWfsseHb7LwEP+zF4fPs0Q+epbXiB+zl4hPs8R8X7PniL+0FwNkkieJEzR/tGeJV4pDSS+0p4mvtNBj77T3ifRAb7Unij+1V4p/tYeKr7W3it+149+PtgeLN4tUFGPKP7ZQwL+2d4vPtqeL/7bTXN+294xvtyeMr7dUuJ+3fjsHjSQFL7fHjWnUp42fuBVAAz43jd+4V44PuIeOMySnjl+4146PuQeOs34z9XeO77lXjx+5h49PubQOMyX/ueePr7oTTR+6M4VHkB+6Y31PuoeQdOy/urPeD7rYS+eQ/7sUUF+7NHp3kWP9lhOPu4eRzvxUUFP5v7vXki+78MqfvBeSj7xHXWeSwyAvvIeTD7y3kzQJiRr0AB+9B5OfvTeTz71nk/+9l5Qgdp+9x5Rlpw++B5Sgd/PVP75HlP++c19PvpOxIyqPvseVj773lb+/J5Xvv1eWE38Pv5NqF5Zvv8eWn7/3lsPkP8AnlwPS38BXl0NZL8CHD7eXnHiHl8/A4+U3mAQnGI1PwSeYX8FUTt/Bd5izbn/Bt5jwbb/B4x6/wgeZYyJXmYRpp5m/wneZ78Knmh/C15pEn5/DB5qPwzeauSc3mu/Dh5sXdv/Dt5tfw+ebhT43m7dDw6PfxEecH8R3nE/Ep5x/xNecr8UHnN/FN50fxWedT8WHnXgsH8Wzf5/F153fxgbpYyr/xjUin8ZXnmB0x56Pxpees7p/xtVmP8b3nyOC4/rvxzeff8drsoefz8enn//H16AvyAegX8g3oJ/IZ6DUMHSsv8ikHp/Ix6FDLu/I96GPySZWn8lHof/Jd6IvyaeiU6E/ydein8oHosU3D8ozn+/KUST3o0/Kh6N1XaXaF6O/yuej6LB/yxUAr8s3pFMotAE/y3ekr8up69M5H8vXpR/MCv4HpWW/B6WfzGelx5NPzKemA78/zOemT80TtR/NN6avzWOR/82JxfenJah/zcenb833p5R9784np9/OV6gPzoeoM6S/zreog2avzueoz88XqPNJj89HqT/Pd6lvz6L5d39nqb/P96nv0Cs0Z6o/0GeqY/+EvS/Qp6q/0Neq79EDYR/RI5V/0Uerb9F3q5/RqZJHq+/R5EnP0gesT9I3rHMav9JnrLZtf9Kj7vPGX9LXrS/TB61f0zeth0snrb/Tg2ef06NrD9PHrj/T/JAnrnM5F66f1F9Pn9SHrw/Usx1/1Nevb9UHr5/VM1kjpE/Vak4XsA/VqMU/1cEKf9XnsI/WF2LP1jew1Ypf1nexH9ansUZKsBEv1uexlSPv1xex39dHsgQwF7Iv15eyX9fHso/X9VnP2BQDb9g0dpezH9hns0/Yl7N5s+ezr9jkN5/ZCBdXtA/ZR7QziBR879mHtIPhz9mw1ze009LDXn/Z97Uv2ie1VCiP2l3w57Wv2pe10BrGC//a17YjW4R8D9sWgze2lBM/22Ntb9uHtv/bt7cv2+Alj9wHt4/cMCpHt9PIVE8f3Ie4Jo4XuFP5h7iP3Pe4v90jcg/dR7kTptAav92EL4/dp7mTdWe5tHwzWT/eBoc3uhOOJ7o/3me6b96XupfWz97Hut/e97sP3yOPX99Hu2/fd7uf36PHb9/Hu//f807f4BVXj+A3vHNvI+PP4He8z+CnvP/g170jdg/hAQuf4Se9n+FXvd/hg/bt3Q/ht740Y7N6d75v4ge+n+I3vsgBl771Bj/ih7809xTHf+LHv4/i97+/4yOEb+OP414xD+N/40u698CThG/j18DTVpO//+QXwS/kR8FWFfZKv+SDladmR8HP5NVDv+T3LNfCP+U5CRfCj+VzQk/lmKNnwv/l1O6/5ffDT+Ynw3Qqz+ZT3afDz+aDZp/mp8Qv5tfEU2hsZnfEn+cy9gfE3+dnxQNpk4KnxT/nt8Vv5+fFn+gXxc/oR8X/6HfGI3ZkAF/ot8ZzWwOIb+j3xsQAX+k3xw/pZ8c/6ZfHY+pnx4/p1WFPaLfH3+os6s/qV8hP6ofIf+q1fP/q18jDZAQ6L+sXyR/rR8lP63fJf+unya/r18nf7AQRT+wnyjnQp8pnyosQt8q/7KfK5Lf/7NfLLnD3y1ctL+0ny6/tV8vT/k/tlB4v7bfMQ4kv7efMj+4XzL/uRB5D1c/ud80f7qfNT+7TaM/u982nzcRmf+9Hzg/vd84/76fOb+/XzpOHP/AHzt/wN88Dn1i4p89P8JfPf/DHz6/w854/8RTyH/E30C/xZ16v8YfQj/G30LRm8zx/8fj/TWr30S/yR9Ff8nfRj/Kn0bP73/LjeA/zBBJDZ6/zN9Jf82fSj/OTuM/zt9Lv8+NP59Mf9BNAb/Q302NOH/Rn06tet9Pf9MfUD/T31D/1J9Rv9VOZT/VzQf/1l9Tzp2NT//XX1UP+b/YH1Y/2NCI0D+/2Z9XpmGfWH/azox/219Z/9wfWp7qv90fKdA9f93N3z/eX11/3x9eP9/Ttb/gTgx/4N9gP+GfYP/iUeU/4t9if+OfYz/kX2PBJr/lH2T/5dHH32X/5p9mhINfZxzIP+gfaD/o3C9WPv/pn2n/6k24/+rfa3/rjsSPxsFnf+xfbT/tA2Q/7Z9uk3W/7l9vv+8fcH/v33E/8JPNP/EfclJcwNz/8h9zv/LfdE+lTOH/8991jPwfdgyAP/UPiz/1n3eNhP/2X3iN9RFJv/dkSV96f/hfew7qf/kX9RhO//nffM/5wZZ/+t9+AFydZ+bXn39//J+AP/1fgP/+F6dfgc/0P/8fgz//34PMs1HaUC5Bj/8mX4WP4Ey4TxljXNq2X4d+GJ+IERXQ/29cH4lOJd+JzkLV3w6GD02NJFM8O6rOm5EgTp2Mkt+MzpNfjVTaT/URUM0BgfFQ5g9GGsDfj+U+pHFfkNB/zq8cjVKvDI57tYWF0c29Vl+Tn3CflE1sX5TPR20hH5XNTTgvgG/B2l+XJHgfl88xDNO8uvzH35lSJLyhX5pP0IDdH5sMqBD6wG35wIQykA0fnTuen53QzQH5X56OyYx4TMhSmF+gEmuM0P7h36FWE9dukE4NzU4+gSrapmziH6PPt/8Mn6TN/M28Mj5fphMtX6aV39+nTrEC+r+HX6iSXF+pEK6MzYzMH6oBtxCT5Q2fq5SpD28OKF+sjxGfrRXojXgOsU1kjJBZ0M7xDSHfr43ZlqofsI35D8/TA81mDQZNMh+yQW9OWyJvn7ONz9AST+m8SV+1ObxftfE6m2nftsWFzTZM+RWqFpmfuKZADq7R0x+5kaSeQxbSH7rdqJ+7jhVR6k2IX7yUs9+9JGyfvc8tjVFf3U1gDSgfv44Gcp/fwIyAjZK7lt/BzmSdME6JTlHfww0DTXoE8AHMgNPQNZ/E+PUfxY6EjJsRVk7RX8bUCdHww+Ofx8zG/RnfyM07kRvjAd/KDSiWrdfVX8sXwI/CD0JB982XEauE5I40kdYf/h/ODU+L4M24Meifz4x/EnxNeh/QgecRVnWLn9HP/tOqoXnf0w7On9ONVtGVj7vAX1cCH9VN+1FBdwpf1pTpYbz9TUyQLrRf2FGizHEOkt/ZTNLf2cTkjZFMq1/a6X5f24523jDXy4HKevKf3WIxEFoDlc0jFbof3tARDZhVtxDfTICBZ1CCTljf4Q8dlggOeg6FX+JO3QBYYZQf45vtQNFYQ42upFAQqc1wzSIWvE0rxTVf5v/6H+eNa46ADi+Eu47R9OLRE9llX+oBUM3KlJdFwpboX+vPxZ/sQWUO3ZStzahMgZDkzXU+odnPFczNAg247PJf8Ay2Itvf8Q1JTVBfsN/yUP0W3vXYDJkMk83xjqaB040kV3SNbc4CYjdf9id7TujjFNAqn/dMlFHcVIm40d/4zHyM2cFyX/nOsVwFqHDf+wzQDMGiu1/8d8Mf/RB8UO2M2MyrTPdf/pYJOMif/61g4ABNNA1411FgAZC7FOSP9RE0D9OgAxIxTxOBvSAEDVAPEF3vIAVRPlAVzSONAdXbRD3OC4x1zbnNw5m/IAiUDIFiaYmgCdmn4AqM9FDM0AjN4I8TIAwU2PisoA0ODuSMz6egDigu0CJNh09vEvGNf5MhoBBQE81G1svXdQz6Ts6XVhapLOtRQpMChCHOR01zRF5NbhHvq0BgFVCwWixDAtV0YBbl6o0xTtfNW46STgnPG1fEHnCgGa1DYBpspGAbGYJne1NNV3URQqAcjfWPk03722CUDVeEsk8gHsElUHjkV6AgDaENrz3qoCFBpo8EEGXrBiAizifRBTQTTXdM9qAklAkPfpWH4CWXf6AmVUfgJw9LICe+9SAoTYmM1o/3zfcEXgLxICoT21RvdMWObA84jHife2AsT9kSt1e+TahSYJiGIC412Bt2oC8M9VbiDpINfRD6IDDU9VEFAbJMJ2EloDKOZ01Uz/8QpxI3EUKUgNacEKGN648Fz3VNKM+pp93nOJSRj31gN07f4DgM8mA4ndRQKVAmIDmX6CA6TwWnjo3rVWIgO8CRkDmOF1t0rZNP5ABaXrZgPlAsTcJW2k7lkX9gP807oEBRsmBBEJsVblDg4EJUOdTm7PvgQ4C4oEQd9qBE6jCgRZAUYEZPGtPhTQGgR1K20HCOUeBIazBRQx6BkmuRNhEj0PKTFtBxMiOgS05AzKgfVWBMoF6gTU0mTndNN02/z+/RKmBPTNKjFM6TQWThsaBRD/349uBSGdGgUpP3jpIEMSBTzP4PHoHKTyQCeyBVXiqgVgyuIFaOC2BXFS+lE2BYDWvPwRArIFkVs1WC5eGgWlPHYFsQaI6hvh5MktdFDcjAbBeqwEDUVJAaD6cgXo+6YbzhgynPDWNgYCkW4GD3JyBhjHBgYiEsYGLPaM9ZQE0TDIHnFwSPG8DdDVhPsc5LQF/UDc14jL4RO8JiDnGaZQ2i28GVWM/rUyQMwP8roGnGHE8/zmNy2CBrVQvWautWVsmgbM7mjz/MjY45jMNPtNZSDO6Qcb8qYG/P8U/pmk9gcQFvpeHOGKByFUtSeE5qYHNNOAuTjMqEk8yDTfYMiYzCDkJD/WB2TQKATk1wAHAgd43c4MQgeJ5TwNzzleB5zgbNwmUU4HsPDs1bAbSOd07uTPpOpZAfDXIW+yB+D0+a6M09TrfgSWB/5bARJhN6YIEOo44UkQdQ8x4zYILRQU7YT8tWiGCEUjIawWCFTSPa/WBg4Ia/JFX7UOyOTY7b0fUMyE8sweCB2lbhIInPZPU+VZJQRc6GIItMdY0xjPIPOwC6zZYRO6ElYI3QYQ2mTaiRQU4UDT1Mgc4F/esgkKLe4JFCVs4DnC5gkpZckM4NEervoJQYl+CUt3lglUzJ9C0+ICCWjkS9sGCXjaGRWBEdlq3VYO4ugmIT1lbB0YJD/U16IJrRv9Jj10rcKGCcUkXOAkTkjX9gnY97T5RD+Q8oz7vqNyvwoJ/syeCglc8goWSM4KHEepzpzjbqM2CjW3w57k5dHw1MqhMQT3gNmJV2jT/QFwP40BcOFRvyIKeMl43vYKhTg9BJjRagqZBqTTKQco8glZ6Z2k7c0rTM7c02YKxNJA5X1czTdY94TqxPOWCuTWBsEuCvTg1Q/pFh4LCR94+UTqhh/qCyDqBFSlFsILNbfCCzwS/gtE8jDU2Sy5SzzTCMpzlSoLaPaKC3UKGEDgCdzHGAmmf5YLlVT5BEl3SNgkTCziSOiWzn4LvZglMCvCBM7hm+DupAQeC9wpbgvlfwEG7M7QxxZKGgwA9i0h3VcODBQNXTFo6+BeiNaVUSUQ1M8w4vgyqN+OMvIMTM5ODFTIklGqDGQGrNwk4GOgtNVayR0VeOy2BqIMkQAEzdl/BNt9CJUMNNhNMCklKgy4Q5oMxNpg2wwJOPjH5JYM4Vs2FSDZsaMY7xIM/OH+rioNDSk1neoNHBCGDSldqWg+DTWoDRjWITTYGUj47owbfagPihINYTF5O62Idg108FzHbYyJACFgYR5w7Ys5bg2c0nFvKSEA0OlEMOC02/WmpYNxLOD3RNYA03CEKMNZQwFxUg3ps9G8Ig36XmYOBSuQ5nDSNNjZAoGQ+OF6Ao4OLfQSDjm8LOHsUYjKHg5MXs4OWH6lLRDLrg5sGlmHCWLZIB0T/Mdc4NUKu1ReDpkqrg6hAmKddg6yAaDcQNLZgNoOyNgg3u0PJjn+DuDXaapNN1jqhko9QJDqMNauDwRrpUDM40Tx1QUww7juRNLF6SoPMO5Q/+2M9Oy9MDJ6Qg9RMpYPXUTtPSIPbMxg29F+XbWH3LoPiMgHv3YPmAb9EAYPpPWk6EzY5MuY61jcCMrc0xUItg/Q9DoP2oDJdSzIKUDLbFYP9ASkx/0PtPJs+G4QEMkZAwDHuNhU6xBCnQl0zWlD/hA5JOXcQhBFA9np4hBU5LIQYOOAtGDIcPTkaPYQeATJGkoQhNf0HSTVVhCWSjjZOSxRMOFnogU6ELVXlOAZR/jmK3fQ3p4Q0OlSENlyyRFZP2TnYhDxj8LZEhEBBzYRDe5GERkEXEKfpBwHpD/RSGfiOhE9ABFxFNP9BTIRUS4lLvzMmP0k/3j43OBBENTWjiAyEYA/kMfACRVHrhGYzdk3qMlJE/1T3UiaU0oRvTeqEcjdn4O7p4KEmQMyEekUlVmk1u08+xx+EgbkZhIQ6TAbrOQQ3yISKQKbzKDcKm1+EkFQxPI85BS4FhJZBxjNjPMlWAYScNyhmOjVGPDpD2DXvCVU8NmruOAwxxV8uMyZzfoSsSXdkPjKzOoMROTzZz5oHnDxId3sBaddghLk+rYS7P06EvTj7Of+EwGZvlGiExNezeOiEyEE7Mtg+tTQgnXuEz3LwhNI3glKZA1YDvDH4NmBEb/2ihNwzDwSmMjc77jbYMgQ2ykmPQP5OroToOEaE6gF5sWWE7gedhPBN0efehPXhxXBWhPkCjoT7Sdo94VmfhQA8BYUCfDWFBYqWgqWFCTSYQ79ngzp5Nz4xzUw8NvefSIUUV+029zbOAXKUe00XhRw3LAGFSrwysYUhes+FJD1TQfZFWoPWhSr9DoUtdqmFME9tQ8w82UD8OjRJ3EXUPAFh7UY4YGWFPTVwMmaLNoVCPCAyNTUcNTxFh4VJVTOFSz28ceaFT2eLhVJv6oVVPxWFVz0sNwyFWj+B8SWFXjePhWAzCDG+NBQzDhGLNJFPH0HaPfBXWAcpMw1gnj4fUI5VSD7Hih035RhxN0FRGTkIPBI6rmHMMcQ5nmDcOGbl84WBN+I7kT3KPEE+DEREEQdLJDbbM5P8G4WOS51RAAFZPXxJjz8VOl9M1jbPRoWFmTY5OY45dhF7REBJEghohaF3ENMthaU2KzarQRdz9gIzP46qLTQuRUCmszv5hbI1u4FNhbY6jbbBNKZEnHrmhb0+84XAYm87wzP4N+lhoTkiNJ05YAEIYz1H1EIehc/VADhUVTk11ECqhdYBnDhwPupEQ4XbNhVK5AEmliA4DoXhXdQvmjWuo/KF50E5XT055DkSOFpAhYLBkMmF8aI1hfREmTZYPZg8/23wOWY9gBC5PBgCaUOWPiEFwwEuOwBHTj+/OGdAdt6thgqQ0YYNNBY5xy+bz92GE0pgdZeGFxHqA3UBvzVdOxhE4YYeXPqGIQZBNps8ID5LPNn3PoYpQmBLOUQ4B0dVuA7ARARfoQJVaDg50TULOVKGNw9XNSM+agEThjxLMk9kNrOGQDNWQZxDMYZFRViGSD1KN7AF4NeHhk42v1TQhlI73ERxZU2GV0pLnJ+GWjmPhlxWQD7fMm0+lXlkZCm9ToZlNco2+YLcP602y1XnRx8Fw0MNO85f60KkWj1g3YZ1NsU6+jV0PN2GejcUPI0HCF8hOGtEhJ4choNAjzjCOgiGhwG+SnAx1z3oho2niYaQS2NBU7mDhpUzbjp/+4BAUuO9hpxduYaePAeGoEOdhqKKfYalOwhSIj9zn4w7RwLihqwHxYOaTtYzVjjlAktDygUKVs0HZzo5QxkPj4CRPLNokDMoOKFAE437hsI3rabMhsZMCz3URKuGykEmd7VZ6DbkhtBO4EghhtQ6xzyNSdw2+zGrPAZodIbceKeG3zTahuE0HjlgOGsJcUecNIk3mQdnLSJM1jP3OuU7G0VaRGo2C3VkOo5uwTWmNZNMF7LmPZxHwDczR96KYTI2Okwyv2z0Vdr9SocGNs48wocJMpyHC0FBhw5NqTehuUiHE1zwhxZYkTZeO5FqzzaZiEpE/zuRhx9c5oci47BFnnwHhycDczJAh2JBRmgcAw88FkjTPk07R0w48/ZB9jhShzeKV4c6YPiHPUw4EN0234dBQEma/YdFD4ZWi4dJM403FFTfMvc1wTSyOL9I10ATZ7CHVTVch1c0VgwpRuWHW73Sy9BfjYdgbu6HYjbIn+OHZje7D4gz3TtaRi45H0JZOx0//DzZN0tNhmEQOJM3UDMgiWmHeTSch3s0yz1TO5k7ykFKT8w4zca3h4VOe4eIXGxCh3luh43KEQaveKSHkTa3h5M7loeVQRc5CXsqeSaHmwZ+QoEFnVm8M0r0fzn2/bw1FIriS/I2AsYph6pENT7JQYRHSjI3OEiskYezZq4yKEXNbSdqK4e6pUSHvegQh8BJAzix6177MYfGQmCHyFXtQb6HzD2DMgQ3fjeNZ4xaYzUlPUIy0Moph9g3lTNuQZU21FbNhHeH4DM6OyaH45Kfh+YBt3LS+EiH64Vdh+5AAe8Th/JBuEM0Qwc2xjLcmy6H+j/QNoM5DkIyh/84VzfnOiszqVu1TVCIBnv3iAlHTjM2WY2IDkP8MxxroYgSMcNAATbTNy1AHYgZNWAHcUGYQaSIHzr6O5VPvEn5GHE1zjindixO8YgpMcVV7wEiS0Rm14gwOYVB5DQ2EOUzBkrViDc/5Ig54vhV9za658eIP1LqN6Ba3ohEONtEcTNkqIeISnYsN8WITjWTS1I14Dq1RV5t4FZxiFZWjDrzhr+IW0gJAnVBxk22iGBFKTTBR0xGQNvUQjJGhT7diGpVY4WRiG5fIYhwM+k3OVJmOGQIrTQOiHdyJu23iHv0mIh+cxCIgUMBBgZBdG1oneg/rj7omV1WkqCIiI1f+YiQVj924IiURJOIlzlK8xqIm4inV9s2T4YViKE1TjrnNdSiKoinSk1LCl3UZyCIrTleiK9Ec0MWSak3+Yi0OcsHhQfDiLgy4zPgYdA/DwVkiL8FNzvuOlFRxkclsZiIyDvKAnk4Lm8qN/g9+IjPM0c9DmO+OwU2lav9iNg5/gTqOMYCJD09ATmI3zsHDz856HnPiOViREYpNUUBEFENj6SI7VxzOQY+My/GNLI26jbJgkIHvztSBQOI+TYvQ2JPuIj+PctGO1OMiQI9PPk5dHWJBwhmAVqRv7cYSdw34okPM0E73EIdNFOeN4kWyd9GJzZEAXE6jD5+ayE7QpqZiSEP1jeBge6JJmg0iSnk6YksXT1K47M9iTEybDKRu5uJNkiaQR03EF6wNgmJPEO/iT+xG4lCWzeJRVP1OC1HlEaPiUpfA4xjiU5oB4lRQMOJUzcCiVVSA329Rq89y14SOhRW4EH8jz8OQ9HLiWI5KTis7r6JZ1EA9JiJa1aPQ/wyQ4lvPBBV3IlyASIGvTUWMj9FJD1+A7ID2lFANidC8Il+PUVBHGzKiYM9yUqZQjY1j0wyiYo49kVpURlekYmQNJ2JkkTdMmxbbomWyd8EOX69NOoC60uxYO275ImgyXCJozoYM0oQ5lP0Dldy2uJJiaxiGImuODpI3DZsNWOJszNkQNFRSYm4uWXsUYm8Na5iYYnAOusBPDtqicQ8Tjc+P7Fydje6NytIKjOeic1JzjjhBb+KT4nTSQNhh2aKidgBEjX6OgIzoju5OOZmU4nhRO5PvEbGBnQ5+koSO/4zCE3ptwSJ7dxNifBUOYnzkySJ9k/ZNBar4In7lsYykENqeRFFCTp2PN1TQIoFkQeKCDrzi/mKDFCgig9EnooROhQ6uzdWMwlF0UK4QTM2sDipRfRsPooeM5tM1ju8N+tVgzT/ONU61E7WWCSgwIorQUs/VTxKODuKMUI0O6dJyjphOnYL6D7XSoM2f01qbg+KPkKQiNRk2mruBZw/oEtL//OKSAW/OJ83mBLueWREtzxzQRQ2MmhQilRCkPiHiliegIpbO2V1n1L0imCKYkrVSYwx1TS4XRRtGIpqN6I6H2WLNw8zuzryckyKc4LcNgxNqYp3O+c94TUcVqqKfTRMOh+z84qCcRI2tkmQPT0Q1ErVAaIz90Odiz2KjkGLipE7wTShipSVXjd1QgQy8THXipo4hkQGP5KKnzQxiqF0hQN+iqQzQ5Y+iqhlyD2oP61GCT4diq4HvzP5lSyKtDo3NO9HwpVKPbWaw4q8tPOKvzVQB782QG/5isU6ajSsVfc3PFFAmsPIlDZRWbmK0Ow7itM6kU9qNx1Jd0QVito2horcNisPLorgCt/qA4rkoYlEVjaGiuhicorrQONSNYrvSzI2RTSwTSdXd4r2MOE+ejmwTmiK/ANPDlc2uwFJOF5RUjhwWEWLBosIU9CLCz8kbT/9CzL+MqmnHosTixVB/zy3VXA2WD2cQ7sBKamlix/3Z4siXtBAWkFiNiWLKH5BNXcMKzg1N+Q0JIswSlyAiIs0MxM5SUJZhs855BPABzKLPD+WP784ewUWYuoyVV4RNASLRTT6D45PTE0qi0tkEEskNTU2XFqIS0E+8otTi1mLVjMIi1SLWhUpOwc+uzICZ0WLYfKfi2Q2REcMNe6LaEekAmSvyjofNWdBM1O6MqA+3EdxLcRnK+ndi3c7Sn8Xi3syTot9CRBPPzIfPvQzKkh6QRSLhT91QXaLiVkFODViGGyQywuLkAJbizCLlEVAM/Q2eDltNCM5njbGNKY3CUlpPyY0zkcTi6M8DQcpAb49OUF8PCAC4IurGHEBIouuM0s2spKNi7M4qTgQOHs44kFLRCFddDtWT3mLvjhGi8BBXTngSSiOqovGNcEBSw5ENWE2aDJBQ52pZEXVQyo0isBSi9RIHIvXQmBHlw1zTEdCxwEEdAVNmD6sPqaL4kEXPihU3ovnRoU9DovqgY2L7cJti/BJT4+Si/Q5XwGFSp02sjM4NxNPW0hDOf0+JIv/NEeMATHfnm8zCzayD1fsUIwJNicyrDsbMqCmGowQNf01uEQqSO5QNTQ0c6c8uosUXXQ+8/TPCN47SkBcMkNKRjNSRv9AQjQUNv01PE7xD1dRrYwsS1FF/lpueyo2lIwyPoA2CUgqRLJCiqd1jDpDKvC5j8yMQFZ8jEMBv4xFOpKMSPynjEsG0jy1jE5B00KlP/s7QoxUMeg8b0q3M0ubQoxbOVQ89lQENgSMYDZuZNovf0fFjGU6ak5tjGkFHYWr+weMbvONjHE1kl3cjHVCWIx3ScKMerbwjH0+rEI/jIFLbTevPC41G0O7jIc4KgepTUlCgUHpMxE0DYyPNfGMkQcpQEJVZ4yWRfg6EQ5DO8FHYX9xjJ498DHKPHM6SzQokUeMpjOwRPmMqUQENc49KG1hNaVJ2IywOBBrzDLmMiEDrFDrP4IDSUCMkqLIHoy9ZtJJwozBCUhAgDa7NeLWbozIMusBOAayjMw2QEBUN2cyMzncNjJPfznsWGd3ilPmeICM2jhZCls1TsmNjOCSJ4zjPI6M5UzRUNWM6TbBL7pEZozuN9Q2lAreMhcDVmPwP+I3aVKPB2lBJmx15wuM/WMMjQBG/0eVantvLrZXjQcFj40KARw7oT7NMAJA7T2LSec8IjgHPtE6FU2AjRhBUTZsOhPTGY0eRTRLtDbiNTxI040kU/VfED8fRtJQaTy6NgJrl3N5Vs1Oqjy1S31Lsj7JjTRKEo02PuM7JNgYjTs/dT8xTAzSOI1BTYY9LeaTjUZAkDjiS2NKcEUCVu44+kE/NNQQ0QUdVPU4Uo1VTxCNWEMMQZhJVUhNjV4vujIMPslOgT+6Z9hP2Z55jWiJAqnNjWwL6KJDjXBQoj3ajXRfAo12fXE4qkBqjXsyajlaPHRWEj/QuC6Ng2PhjYb4f42JNcBHMneKMrxYsY2QOoVydgW9YEuNlqyyjZlKmTlCQVONnljFWy9Un12ajaQN6jkvbPRHwzl7jao2v1tpObsyMRBHOKFWFjw7bxaNtUdqRio3f085Pm04yA+GNYMzgGv1Rx97AY3DRf0/blJdD1eNyDjAP/GHMWhaNh82VDQxO6M4BjbPjdM5mPnCjdcFv43ZRVk33G8/jd5NZ0hTMylDto9JjeUyCDQJSO04i3I1ZpeN7axPAlU2kXwujfMx8mRsBxFJsI35hsCN/EJgMvdWyI4BRR6r/44FZdZlMT1cQWIKW3NOPAFaS44PObo9oW9wjhQ4DEkZjhhA2jlmM/1TwY4eQYRZLDd1P+aRho4lLSIP9DMIP6tBojXOhgwDSwGrji9qao4yQF+ONDv1M2Q5VGuhOkdOpzRPMb06REBWXViOQEGANNeORKqljkdViY5KYl9B6DVrUEI8TOvEjlI56DqOL9NI1Exbjlg5Em1YOYQySYQTOGJFFPhkjmI6FTVwlGw2yk8DOkRv5kCmQLlgMkoSNZFPrjSZSdU3NzSsTo1NDjohNLoyF06fYWCOfFQxUGqOgISDjoM7v46FfBeOiHhTPDuOC46NMjVCtDbtMgBDQk6qmi6OlkE5VjBuDDJNQoE1a1e/jp8CKDiuNsaOozepjqWEFxAPBz41ukQmi7COrTl2Psd/546yARNIQ1VXd69GmDNAOCk1Zz/KbpY+rAhoNKaOwD/xXIuOxDPNOhJLv1DZjspCjEMrjs7pUTUPN3xEwEscUICO1QlI2guO2QIuM2M+kVqGBviO309bOcc4CDPgRB0y2Tg6qyg4ZKzhjusBAkK+M51UxTMpjvEx6DJfOIGO9TWwV204iQbhWjSO+4/ZNv83TmTa7RkP9DKZPM8BLjqFUbyPB7vBP2SBjo8MgDGPDzJ0cqmPE5yfrKFI902Sjxk1vl9+PMMBSI8eOXqPIEtofKek4o8lNuc6E1gwY2hMVWhaxnA4VD/wQG55zgJYOjQzozaJDsDosI84Mjk1SkOdOmGPPWEmj0A0yD6mj0NKq22Vj0eUII9KQFJPhmVMj08LbIGNj1NGLlIZNJI2RWIYj1kQBTOYQjb4CC+6WGq7gI9iey1MhD0vj2eRRI9qSp002TL6Rb4IZjgXj3FN+Y90H6lKWOiJOQVDkzmej3s8LgwqfAGPgEho8J+Cm4+FO5F8p/Imj4ppdGF/TZePjgFKPHxCHTPmPgp/wo+WAQo2JkAMVYBHakgLNiWPn1K7j6E+20HKD2E1F4+n/BuSvEBJj4GPrTusOFU32FHRNJo0LzoVj7Uz3jkuOX9li0U4dO2PvTWuETlIBVKPj8JKnY/EdtU1K0bkj8hQDo/LRiePzZAxj9AQD0ZHPNkznt/k20OP2I/akryC54/eNx0+JzrKNqRoP4/ls4EyFDHuNTJGYlxsxPqP7uH5MfwFkzciP8nw5o/2MlOP+I1zXXQRB0D1MhACJ4//xqeQAjKcTM1B2pAGk1+QCUtfO9A3xrrGmUU01GObO1lIXZAUPWU/njZLRxxETzs/Wg80ozbKMeM2qTptP7cROVxikCVV5zvgNsVBCTaRSfk0xzCTIhg4RjHjBwFEajqaPmo4C5R7kDeWngahkDs7jDc0UupoUZBBjBmQRAecx0CQSDPOuG6QTDSykE459kdqNXZBRDtvNQ7oEEqDkHAzuYhCWV2QXEZAhGuQYDKRMrI4dUc2Ye0/fzMnObgzOUcKXACQbVjlNXkGfjUMM/5NiTuQZ6WQd2s4sZA3cUItBb02kj1KpyA7EgavkIPca0QkOkljm0OSZNPTI5CMjxdtng/8coKQkg8vkJQ/jloekJg1JU8uVu45y0m8kJ5htTdxCCXw65CkQHFCA5CnQ8tA8E5tWo0z2ToidUEyRXEekLJGZ0DmXDJGYjmaR3Q9gTu8NmsBgD75kL5BU5DBTcICJTVYkMVzRZDIMgJbe0/IUnFC9AEckM8/0JDSNd41U5DVR742kjPgkNlCMjwVNT2NnTLphdU4SDLcRVSQ5OW4kOdIU1foPWlLmDg6bMegiJDwNRRRijgJRRoBeFCjT6o1I7xAbwL0DN5zkP44DEznQfcz8Th0bdORBTc+5x+RCT61NpZmZUKieQuREEcRPvgx6FDnO28zoTmeMzv/7JEbBLo40lUYa6NeSJEiTxqRJVP1Ptwxxea2kStHx3DMOTViqpEwip7yxENDZIqRNk9QP+uROQGwBZKRPFXWkT9wtZFCPf5wjk/YOao2UTNDPBf9MZFMusiRTzPkZc1ZaFLqPSAzjTlsccSRWXe6PmoTTUa/a50FHbwjkWI5o2nSTM1t00ic296Rak6dNN099Y2skXA+HTXOjy+RdWz8R5dIY5F6aOI3yTVhNzSRfzmqkYI59jwVNpA8GDqzOXJJd+KmkYxM1EAeg46RkTgu1gKRlTJHT7zqE5Ga7FKRnS/TOTNE7axTkaM4MEfDkaZBODazOCNO61uikaxL9TpKbDKRsXYMkbQ7RZG2YsZC7kcGU+k5ejaWNYgEnJHA3nI2926PkcU/np3tAus3CDjEnvWRzUJ3AuU0zUTYmTaR1AEPkda96JHZS5MOVjoTWW+R3zTUW7k+kdPIkeU1lfynkelPv0MTVfdbaTzlOC07YpHxOkiB2JsPkfbbYZH5kfvnTpH+Q+k9RpIBNnlUYQaeEPU2O5IHQ2U7wQFIkguhtgIuQsI5k5IRcWaSFDPmVmFJlTZtN+g5J0rANKtau/m7kiA07DOhh4JHn0AVkic4l7XrkisTCzZlNTg4kOs4RPE1k5I0PdGSNzx1PLM3xwIokjxX22HQUnGSQDjhzQczZzJonJ81Uz2wOORCWUkJNlFNAT5/VNZS9jMcklFCbWVccONrIhTWzQ1GNTwbQmw7zDuMMjlFT0BvNTpLQTYgY5uDL7Y2kmc8urBgUiJGj7iZS39IUzLgAkVUyZJzN4iSdXQ8by2SeTq33ZiSfTbVOol4w0EPOREx3zu/koWJvpKImKaSi71ako48JDsAagM95DuWOHI/2UQgkpg2azPf5nCSnTl3TVZI9zXlkqIzmE33kqZH4RAckqlUqJKsf1qSr24ENm4H0UAINMOyIXO8krhqT5K7kr02KFMANTKSwTl0McQLuk3bksdM1jnYx22SzFSMYKQ4B1IDNO2S8pLUZNWS1knYO88yUo/ZMep1DkOYAW6S4DVwbjY6W5LkQto+cz3eE01BLYrIkuyTQk8hk0Q6+TgXUZBIyZNKA0k6dDP6bYKS+jj2PG8CPjoiM0Qx7Det03GTBFuIQxNIb1vZkwlWxzsHVLiTDkJPkxEJSAEdN6AGfjb7QZFMkEH8Pfh2x5MdQYA1NDJuQ52pspMkE01u/ZMoWpuTSZMsX8U+6jMoOdiTMTI/SAc51wLSk/Fa8JM5k1iTPFsHMj+TPz3kk1yTQwcMOvmTRpQ6k0mS9UDnMj+TUpNPYD+TTZNTAnWr0pNXkzuTWlEak106+TI/OAc7B7yhk2M+TZNlnXyTaEZYPo5ahhBkBRw0TDeBZ3DTQJNzN0Q3Yj67+8QG15N6X5sE6pN+TIO7JnXVyFZ10DRak4WrpTRAk4hiyEeGk5uTjmILk5Ey8EuW5eUGAC0YfXyTmTONOg+TnF71k59s9DYgNKNIBT2B68aTp0hfk6p5pZOt0FozOTvINsoL91E5WvY7vzjNk7c+JhLTk7syxDLnM91ScpPAAa9R2pPEEg1qA+m7k8mcNjfqbIKWI9wTk+KT0ZSzk9Q93pPWZ3w5LnrBk9tJlS3EQzSnOtwTk+LepJSzObtQ/wEbQIk36FP0XyE/ozTEk+5bYZPwyRuT82GJkvRvHTUzk/iUezTJH6lcv5P+RviugJQCNVs+njnqbPw3fJ25lApsxgKOS2aUD906lBKTR5QVPROUKpQZQ3dCnJQcgYYMqQ/ThNqUIjwUlCRZ7pQ5AUdARD91lBiULEtflC48FJQklDE6DkQ7kumUNpRLlDmVBJRPlD6UWJRBlFs3Z5RYTGE8xJRDT9CUOJNHlOuUPZRRlFg8sIRPlEOUVjdnlFiUQZRbMylKmkTxOZJKg5RhRV47kkQoMmBykneqNXpHpJRqSeSUbT6VbvCUcTM7keBPVJR2Bj42WEccvOo07jv1OwmZUpSBhWIyEjVUWkRr9U/MlIlLQT0+Nw+UjXG0lJBcHBHqPfCR+jXORHE8FUD8O/s5uDMnTRuUnjfOlKBUf5SjPU5Pg2kGWbw38j4ES0pDlnhNlK46C5TYZF+UsjyClNVLw5S30rmUuu2JlL09/liGNyloOJTblMS65JTHAo6VA5TLST2UulFFNlWU5JTSU+88gpTVQeRJjzu/M/2U2pTDlN1eq2qZZt84bDNnlNCU5UmPlOc3cZUDlOuZAZTucWOU8U6AlQGU9pUE9N+U7ZT7YgiU/j2UYTs6TJUClPdJPZUGR5UHKZUJNTNFGjSilQ1WVzyzlRDYvZWelRSBeJZalfAxwZWklRyWBzgMMdttmdo6lSQ7zmEfSuqVKZUclSyXK2XLlY6VM5V+lTb1dJU5BpQ4jlthr0SVP5VwtiaVcjy6O++VsDtSS4iVa5VMiAyVT22wlVJYGJVUQMOVfJVYlyuVnpUUgXiWWpWolWLVMgWcMj6VrpVGlWlLiJVrNtKVPpVvlUG2JpVyfQTzq5V2Psk7zmEflXpAw5V8lViXK5WelRSVg5WXVuCVmYhNNJmVnGO/MriVjpUzlX6XK5WelRSVg5WXVuCVmYhNNJmVnGO/lYGVoJZalfAxwZWklRyWBzgMlWGVqjvcBZwyPpWulUaVaZWyM1aVtIgvlcMIaJXFlbszMpW9ajqVwDc8iC+VwwholcWVRJXIA7w06pXMngiVzzbJAiVY+ZXTOGRLtFG4k8eWNJXaloOVkpXsk0SWX5ZvleeWVJXqMT+WV5XulaGV8JZcloaWXpZulgiWcJZklgyWTJZnlhiWapYzljt5k5YHlfaWcJZklgyWTF9UlhCUaJYTT1qWTZZ6lgCWfJaKljBARJaNliI4/JaDlZKWV5aISfmWfZaLQESWjZY1lkiVLJcrZcuWOw9hloOWP5ZSPrCWVJXqMT+V7JNEll+YEJZzloOWP5ZSPrCWVJXqMT+WV5XulaGV8JZcloaWXpZulgiWcJZklgyWTJZnlliWGZc+ljuWSJYHlfaWcJZklgyWTF9UlnQ1epYTT1qWTZZ6liuWfJaKljBARJaNliI4/JaDlZKWV5aISfmWfZaLQESWjW1hlo+VLDr/lpJpjGbXASKWljTwoGo5SZaaTYmWnDOwNXdNtRAelqKXZZfzlmuXCZcqSRo61eyolw+WsV3UNiE7dJcVBRyXHZeJl0s1kZb5l3k25zQ/Rf6W/ZbFlwA83klTNMiXQZarls2d7U8kly6XoTerltWW65bYlu6W252uluU5VZgfluKW5FE7luaWwJbpltaW7JbZlu8/2ZdMlvmXeZggP9mW+Ja+l3k25zQ/Rf6W/ZbFlwCbvZc5lwSXPJcHlz+WqZcLlqyXRJavlxCXSJcTMoeXFQUclx2Xu5calxWXHJa4l7s4N5cgQ1aXIoXVTp9mOpTyNeVP1Jcqls2d7U8kly6XoTerlzJPZJdalzY/fZahlzqXBZgvlwmXKkkal0SWr5cQl0iXE5dLlvKWvpeIl8+XUpb5l4iWugFx30aXa5dbD2GXXTK4l180ppdhlwe9MT7rl2WKjpcwl2lgsU9kl1qXNpdulwNOz5cul2eXdAIkl3ZQHE9ImB87QDuhMttQaTIuAUg5ezpbNPNNqZfLl+OXiJfPl8uX45eIlrqXkDkp82iXlDwYZ2nZ8Jgwl66XYZcHNDSYLZdmlzA5CzXemCiXpjKtmCyYEpeql/OWa5fxmDJJGpg0NYuXswY3NeKXhJfMl7qXGZgAl79djJfCMhS6gzXKUMWXxzpuSECYIZe4l82XiZfQmAGX05gEl9Y3uqOZl9qX+pfdl7862Zfgl4qXuDJgl3mX5WYJT9hCWAXIgWqYMJeuNDGX85Zrl/E0MZfzmBWX9ohNl/iYGZfdl7+YAj9Ol/+X+5e/mAI/TpfUmAU7J5gIEe2XlwxTWMVPJAgnl3KWS5gROdyXqpfzmBWX9ohNNJ2X+bTtB8Q6b0mPUBxPSJgfl8qYIpfNmCU9i5ekmCk6TDKtmCyYEpeql/OWa5fxmDJJGpg0NYuYNgY3mDg+49gU2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgTmGeYmDJON/xs4j6vNxE2SDS5mKAvmpiiMxAFlDPgmKY+WEvUOC42S1kuRRriNZivBcg0yZizMT+YtTvAmLgyh5i6Vkg2J5i9OKv3p2ILMxMIJdgJ2ALX/tgC1/7YAtf+2ALX/k41mN72M5jhODGY4zOtaA1i6mVwmOle35jsQ8o+UpVVmPFLcgd1PiHJsZj3TMFt8MipmPwG/D4dU/+ZATRlmQQ8mpkGNW9Md9gU2BOYUJkN4v2ZEDkfTtaZE1YLN+U2RQZZmRhvtVFHNIiZHDJFmR4/goTqn8lwFjjVTmI0IjzvOAtfkgP1SNNRETV3mS0R6j6tNheZMUQ3N+gRi5HSmTczKjZBYYlWqDnSMjsHalLPmUBPgzw5bhBk2kNiNkBUAPfVmUphjXlVQVU8e0T5eaWZUlt+RgmzGplX6hmZWgcSTAuZXYH0mWA1p0yvOUcz5AN+mWaq/5lpmWvKdpluPR1hAplyQcM9gZl1Qc82JZl5mXsyb1qkgyE310bkDlaZgjw/mYQFlJmGS3IBnQ/kP9FbDJmNaGZTW5mRMpc4rvDyOgugoJmYXyEwXAGieypW2TWBzjiZoT3wUBJGMz38Aa7/i5mpWw8LukiaYsgJB0erTt48bzckN0RD8GMDmbdKp5m6XxWdVZm/WSE3EDNWNi5EudrOmcdpdjSvEAk/6jlFmc4F9TYXUQwzFi/ZnXqZ1kQUPHUJcLLymdwC0kGdmd86FDlHdNNVvpnlNmbCsVDncw49om8cme151FsPPd085wKOQumZ9Yd5mfg0Bpn6MAIzA0Evmf9D8D9CE003t1C8mgVHoT99mggBFDQkNy06qDNoOp82f0LwOWOaEjpIPrCaFT4cPpyaGDk/7nU5H5vOuICaHzt9jcWaIz3kOD4xvf0vMk05nkUMX5VWETe7Odo31zoyOR32x5o0tf2aN0DROcYz4lagOjk7RUATvA+aQTLrRq9G4zZrYoOUiD40DAtLM5pMNjJSZUPMT3eaUjswQQtEwFVjVAOaWVUzRVEz0T2ZVs03zrExmmKd2ZplQP5BC5ppNw5R4ZptOGT8CJpxOOGH+pp1AiQ1D2iUOI1bHTdDbWE7VluiSwpSAzGzbPxhiQfZNrYyUTHYSVNoOJqKNoaajETvSrw+JZOZNg1q7jOrNA8yvFPmOGs4+zbrSZp4cj2Kmp4zw1ksQqM00UKnRGzGrpqnTopCoTJdmqs4aDa6NJ41VZqwQ5WaszofmrVU3zHDOKw21D+LM7CavDrTNnUzCzM+msEwLjUkmsUFlD56msg+0ThXUAhIHju/Owri6DabNsRajUJ6bkGOAprXN1BItj0jmtxN6anmmuAy8DRMNCia5E11S1x10J8UmuoIJ1OcCCf3LJrwP7VuyZr07S6a9zz7NVJIyUnpmv1iGDk6NS0zQ6/hmwQ6GzuMRARrBjdsUf4951RGRupGCTYKODWbETNkOSWbFAS54qmbGDTr84Vb0P0Gmx4/CD7XAQNLqz53RQROYkurM8g1bZsqRfIzETzJBJwYEVA1mfabM0k9aJQ6Ngavmzg87rVFpXWbPgESOwCAPptD+FybRjXkQeNa+VcQm0wEGz/meb44DGhmm1JCxJdOVN8GcZtYOXtH4TxGTWdLlpteNptDwUQ7QmwEugVFO/Wa2ptoVo8CdzjlY2U5QUEKdU8BFWGHTApPbUQLUmY6MUqdAiWPlTPMOLk6FZt9vTSbgGVsm4I0MZuEO8RAmDvINlFvh0EtN5oBOUVeOWabj1ASMfwF+2I2Nho5lDHCQJ1jZQfZPmqbmwJGBq80Lj/IB2o+JWrVm6RPP0mpSqtDs5uqM9tSZjYDNU5CxD6vRq5WEQqFEPc9NgrfNpM/ukFIOkpBwlpwOdg74AY/P5UFvzV9Y1s7zpvFNqg/q1DnZ0qby0WYOjE2bEZeMz01lpvSATyb1Ds2Oaw/pliGNVOb2j7WMj+b3T8cAuVpaZviMwZt4N1cECM5V5voN26b6tgJm+00Htl/m/E1+pvziC8C4kqDLeA0n5v6ZQ+b/bcMnAAYEUQLXrBblxBkOsXSO5wJM2A0IjcbV6KcDqddnBFDmKThnBWTR5wYNGUyrTnGPY6cHr3z1/2+TZwkNZE5LJwn6vA82nfbnCw4UjQnnC8a6ZwxM9SpTZw1BXoGPZNCP/stxEAEd7icPgIzPPtrlpxDVqycRjvQRAGcSRcKOdw/9TSlSl88ZUY4DkUyyANXnFTE5xCHTopXKZxaOFVOilP5nF9KTjMIS20zGZagnGZRmzhrR8M00D59Y2gv2WbfSYwy6j7jNVY+BEr0nHU1mDjDOJ0y3aelnHxYSDSmYRScgT8EzXGchTy1MdaciDSdNwA99ZyMyDucj5yRNzleppyU2gacl23fnJo6uD9XO8pApZygRMIyOjLEnKQ5eHUHnKiyD5yrPzQyuD0k+CucsQU3QZloHF8inLdDWEc8kEmcvIh9nL8a6QPEuG2cxFJJRf9K3QSJNJ1V8ZzMRSQ2RDmPMkIzP5zSTR1pgZzWT1s6tlH7BZ1BDwTtnN1aGZzgkPqc40j5nOZfPpzpNYs/FalknO6DA5zxBEGc8zzCS5+c929gDwaUNZz8ciac/nE4nQFJUzE/nQRMVah1nQgx8IJjnQzq0J0PMjxDnTSMO+1Atj0GPMkx3ouQnRpBzjACnR2tlp0gQavHiJ0kNsZUaOjjnSk6iVwoSCVBB6gwnTA7lTrfNIhLUJ01Mf/zqZ05eLBGvwdqPrSjZJ1AhkREyGujPqEzTS0nTOxtz51KONE7GzfmNiOdTzLjPOY7Ep1TNDlk451WLeCz+Z1aQx06iTMmVys3YUnOQFiHzZ1kBrNe28hkncGdak79nWwyBp1uAk08CTHYRZgDrEEeB2k1NJ8QZ8KdepnWNuI7nTT6NtQ0suStnYQ6kgcpF6IEm95InYs4c1ODTHc3HC3gOVuJPhJiCN42fzlqQKVIijG/NSVBCWHPaJRCgT5YDZCVyzKPQF8+izpXS4gyw0tQpavnPp2sM/r5qQZ0Nso2xjOTV1iV0Z22RSk1TDNEstqdvKVRnb8zKQLMOvk+kUJZPaSi4zWqPCw/Hz81NZY/8DahxphajVJKndF6mZ3UQrQ34gI0SEpSPjbRRBQFyZ3deype0zx5OkcBFJ3jqnWd5jhSTrE5z53qNV5JA53uEKcQDIpznfOhu532XBJkJzJgMe477p38exad/zQEPJtYc54EbWJEOFPfP47UYp4L2hyeDmw5nhEBXDLrt8KeFjp6llEJ/AyfSdoEOTVwARNW7gI2niFjS2Aic5SeJjVOjhw68zsm1aieLUNigoueMT2wTxlWUzgyfNtIBz0dnjmeO0GEEA80Lu3yAutPCEgSnkOvmZ5GSIw4zJ5JD45E7zPqtiZI7jtqQUtVeDx1UftEczpIedc2lv1qnlo8kEYWPDs+dDmOvKieYjkzZu+eZoPrEDVGOD7RECs9uV3BOKsI3D28YH83uDlPSsCS4J53MuNDnQ/vnns8/f6tnn9wFjTdNvNtmZ6EQGWehkjTD/Xr+J6LTEaejT3fdsaekTbgNUw0tTabSTEBWkMNO3Na2DlBOrdlfZ6fOPU1HDOYNmQBWlG3UiI59p6oBgY1Z56rzQeerjrYTWKesgTaPbnYmp63OUo+Szl/Nao6PU67nr+EBDawkb9cHEn5R6szTEDDnshJmp7KgjSezQSaMrJVgZ7SODee1LvOntdEcZ7ZOJxddDrzD/Se3jcUi6We4lG4nuQ6R0fBnuc9aTrr6ZaHNUMTPus7tU11nvE7Ep7zXMSe9jHrAUns1J77PLc8AJ7+Tx82Awb0NeB7KjXpMkCfBj14T204dQE5RV6fDGg7nw/Kzp8SN4ufFDrnL8Y+roU7P/mnpZ8ccjSfH0NCOXJM7DhnP06fJcj/nyg6TDy6BJs5UjHLOv00sGcVNUEBMjHmifGfNuTfnzm1oJ88WwefPjj8WBF+1J9DhsefRlBBPlM7AZ/gcdtG/zoiQEhj8DARMdifUwcRn1Y9+DWERUefW0TAn11BnUxHBos6p0LXAUGfZDlgNu1XbTvPn2lT2TklTvFDNAgnPHNzfp9yTakzoZXuOFQ3bF+XQWhGKglHSJaffkavU1+fgkdhTamfhT2kSYw1pTJqQoGfiwcSNx4zPkcfn5A10md8n5MMqbfkn5cyDJ/1n5tkxMk/n588i1o0OtlCoZ+kcpJVMDM4MjetcZ+rmT6frjjSn7Be25+zDkM8LDHwN601YWd0OJdCCTxZOzY/NZ+/O+2tIJ/DOS6fxTipT0OvaFqGTPMDvLQun89PdTh/+x2f1DnXMzd08l9vN6E1DQFBNowyrjgYPE5MnzeiNRdJ2DZXQak2/f0KOPKU1qdan+w2f14SNco6S10Gi9mf9A+23ISf+AKpn/o1QVPpec47UVq3Qx1SIjnZNbRL9DvdTn2gCDzvoAo1NziLMkyl19WUO4xVMFpjNvczuRgRBdU45V4SRG5D0T8NPbk6z1K7aXc0Ol1cS8agI071P9k1dw8vQ3egKT4aOi02xqAtTGFB4zbFPP81Nk5t1gWgNgjrIyKF7KA7O31m0qA+OX9cnjeOOzpJ2noGStFMdz53oEize6BLNC6gTaBPNiM78lFHNVGgVDVGQcYzxrqPoFo85FLqQmA6FaBfOAszdDM73aOgZTlCNg2gaDE/rhRBHkVAMw/74aBwZqv2a6B0xiOgdzNuO5Va8aB8dK8DS1G9OghCwlyeoIQyxIIGNpiDMaCKXWJTwz0rN444kqCQREA1wKCTZCeglZH6lF+gmTUQNZ2gnD8bBgYyS6CgUoR5LKCkQf9AwEoMEu6gqS9gMyrg+sj1NGqgrkkftIwGnkREXCfdZVPrOgw44TDhNbVtnqH3oL1I26DAB0egwn+NNpg2BkLsWy1WfTPj7PugzIDuoM9yNUucoNM3qwc8oNc0bGh+S7RiC6tpL5fYBb5DoOM9ykxxoOc2kGqTDz8CRaDshHag7zhwn1U2wpGCoPU5ElA3aK8yvzKuMfmg/MwlVNOhADG1Uc85TqEEWqQ/gjPpN2buO1tsoQxD/Uu3oQ89wTQMoRJMt0BTQviscaEYS/Q2yzYsPh823zdVoR/zr6Ei16uhJDW9M0mhJ4phMdVaLqEsXBJT5n79RgKhMjoPMeOxCKE3R85sW0bbBgA4jgepoT4QKzkpRzxByktPNl436ztaPX5ADrFQoUsQNTbjPT61s0uxOhShUjOHPyRWH1ASQVECTaFZUZBIyaFcOMehXlPsoWFRwj4UBKahZTpQOXgBLTsqoWszoU12X6xMPPrtOR2S86F0BLI0tkJZoXhI9zTBvaehfXqFEYs3nKGCMtUxtek1oYc62E2JVDc6CIsZoY5eVaGRiU6hlDe4ykOhmDObPmI0iDcSPWChnooLoaFM1DJvPEdWHzfloadcKAE1UQA1JUF/PvVDajvndSuhslW5NdIzSkKIZWxEpEMMPvQ+YgeUXJ2hv6KdocI950QE0gGhx0FWP9ChyjjiRDuhzTflOl+h0GTzNx04bEKrAUqh1pmYPEZYGAJbNB8+QaJFod9d1FPMNl2h5K5fXVgCy0IJPqzUWKHsvm2h70sUAgdGKEpLNN2hHaH3W9AyajLvofvH+KH+QxM8z6nHogO9HKIGVElDZW2KogsyQjiNOg5PWTelBq9NXAb4NAFD0d1Iohhd5aIa4hGiHUc8roaiITklPM8yMVDFAR00JFu2oipoTUOsoi2baqIwv1+iM2EzNkNk4/w9ojlk0w/vjKuiPj6tf3xNhmNlC8SoyTp6URlHqzIOokmS86LLok0Tkj6mNyo0rDkJO1pPG6JWPvU35KJZMzaf1UBWOZ9K40H5PtE1dQIN6KiiZfIKomiP16JrRbMvnzt7Sk41QKJxOK9ENKJ1EMM07UPCQdNOajm9j9k1IzmTBRZ0RTkJAQVDQranMz+V6aKIAS26haKMBQM8TqKPBymikcvVopQ1iDhBQ9hGKdVZvR+inKHBop9AnVp8Vn2vbKKlbuSip5/grZupt6KtOuKir08hYcy5/0M5T22itaz0orhEnDZ4N/I2dEYpN+k0BzXclHs4aGz8OkgBSqLGNU1UpDX+d3zQ7KLNOgMzzUCkVgtAGXe1PtszxktYNk87qTACR6cPjmGJRbffr6LgD5RDDEfBPqZCo7KYNB83K6LpxfCi7HXhPLwyizZPlWhlygfEovR5CzgtQVo4MDU5M+yd5IvskvOi/zvUQKdFWToDRPE0iVp8NB9QaUWoSQlv5aMNW24y1TvbOXy94KMUlNLH+NgKTf6jGjYIT8axpqMfUlqjIuN8U8OjJY+VoyhEyldYV0WjLTUMu1CjMQJFozM4dTWqimSjODVZPE6jOzUz5gI9wUdMT8w+LDXKTCw0C2JEYe299EC9o0mr0zhzQUbYCb5Co1I3dbK0ThWjVuOUThOjWb5T2Aa+U04Yo2LXq2H3uSTX+MZP1/g0SaNrO5SjbUeXUbcBSKNxs8mjdDONO+5QoKN5ByujfERYOeijf0FaQZVhh19vSSJCrk8oNy18Nl5WUxOjjEaOM3E28E8hRv1Eq6OTOd49gp18o5heRm8inBxBTDskrwPYBaNbo6M3gqOlRLc02kWYOsQ91VAnOIczPgitPz9iwDMyo7JIGEPgNWtQ8FYLDCujuRD1g7MEuj7bM1rnoqPBNbYw7jm7NfY1rVVxZlyjymXQREA6E1Oc/ld3SkBPo9IIaAFMPYZBqD53pO+j2lh1o904pzS0RnwybqPiN5hLXDp0AjUS7qPoAcVbyjeNYJ45R6PuSZA7z5Gyo/Nyh6P2W8ej+T6QwvGj/T8to/87oTiJARw9/DH/Pwg/Kp9HpAkBCLlgQkxBCTmBV5Ph7IzipBNEpDktpBaajKQZQwcybAN0Q6g4NExBNAYF3lMnNsA53aQlOhhjS6QoNNc5LEPdUVJ4Q6QvDCm2JKQzRo6kNTNLNNdNNIbUpDuKQXRtpD84UD/RMfCkQzYkpEU9HUhTeNQyjIKZpEw28UYJpE84SKRRNVtDLDNoOWBDPTndNf0BKQcRPHhhpW3PpF9LbdrBpGM1KTYdOvSN1aRpnMWkbDUwOI821z09pHE3DqRzZNU1+w+TdrWkeS0YQ30HAXeapH9jqqSCVrs9gDIB+4V4hKSJW7VycaSNRLikjzTBBJtLO26KVglEnTQGCt5AhKSZVIFzTkK4UC9esDicQwEPlF+tRWKkpTsBY09BnKSpbI2krIPFlSKksD/FNT2ks0u04PGkt09tYnmku1PhW/tNdkCMNUtF65v0pMRDJTJdM+INOzH9BJtDwjP41vAQ2Tg+N6oHCAO8Qf8/LWdDRCQ5mj0sOOI1OEq6W4ik3USAQZs/oaTiNN1EWAfRVwOk6ECxM5gzAMgHWeg6GE1nM+xUnzh1O2U8QjtCPylXya+vpPpsdW4MNkuk/kBNSXc7YkcApQSo96UHSXNQMqUKvaalDY8epRDtwT71oAeNIkThZjoyzwYVpRk6mjl/hY2lHjLmMsQ9fjdDpSNT/KUlm5tF+DMLQLFLUkKTM8J2uDz6x2k4GDtShrA0HjpiNuJUVBUMNlFCczbmOIo+MQbesjKlQOCpELmlQ1pwNn+lRkynpUg5dAHBMzdKTff+pU9osqVSMpBeFKVWMmpBLf3dpVs4l0bopV8MqjlSPDM2kOSrpWZC8mHMR45DyjlJpWxI3ANPZwo9qEC7NjhBSkpgQR6ldkmQpXhEeESKpXwzaEZnVqg2BKWBX3ZCekaLsQClhzeVWps7Wj2CpYxeqzQepY85ijMyAo6lk0RENvGtvqWYfKecXjUpTUk1VjexNrAFHaAmP4QCPjMcPMg+DDP3paimF6bxpa3b36WwimF0vDmdSwo2MTz2NB4ZvaW6PiiT4KW+Pn5KuDWGNosB6qXEOVNROzVhO0cxyTI1MgM1w0vLW9lBgDqFQH6l0kQENMJHbKAOSJo9owM5ekw3LTHyOew9o1A3peEy4zwUUPBId6dCpehWCVYLbSc6/zKXWy+l7wWd/wml83PypfYzOkjJRaY1sK4bAk4zEKX+VGE1vTrIoxRNajiKZt88JzlrP7E9wqYLTcXfi6YPNlE1VTDhNTBQo0TFNb2mF1V4phlt4DCSph08SF/ANjs4O6YiSsCW4xmNXjc4+qYoMf807VV1piwPtoxJpjACjjHhB99AX16rbztWFaY4AVlRqwF4N445a6Y+lkymQUZiM8xAXA5WpkZBFHw2i5mmS0nGO0o2BzJ0RxyBKz6wO91gB6ZWNrtJFzGzM1k/BKZcN4WmX8nf2AlOJKZlSEJWEaZoNTI736ZsOQM3ukItSEM5f/28NCde7qZ2Q+Ax+zh0QohIjECrpn1WHw/SPhz7Tzjh18Q4qzlnMc5K2zmBdVymi1X3po1QQTthE5JQxkPLr0IJBx1jppcyDjG9Qqg0TWXIQFK5ItgWTgOmolv7N1yqOKanPJtIU6aqoUo8zzlKNrYycTG/Ct5CHKa0PGs3jkTFRWM/BDfaprs3KGyGM2acn16mNZGmwj41psQ1TjVSD+M5L1+SVuqmzNzZps86bjqMgD08p43xptY07gFMptlE0Dv/ptw44KbeT0xExTuWOVJFadn1rAKm50ZAOSgHEtSapu040gpbP9FAOGQnZHKm9eHYpvgFlEHSCexCIzW1OMc1KDp7pwIDBT6wpwU1gD2GQqJ/SKcLPcg1FacOUZBgV6cSAk02QKcVYZunGAeCNVKSPKcdYANHPzTuQmCnIkIqTrk85E7gQts6R6cpOsVfb01qP+unLjmcPAY07qcyU2MBFKJlpzdKmU5tpzuIbqc+Q9QyYKdBP2iyD6dF0x0/aKdJPZnKDwTrp00PLzwRAQenUWQ+MvQ8JC+XUKI+JFa7ojunWzjYNjNIQDolp2ABXTixPIM8zzqxp2Y1+jMmOL81lUYQQeNEtzHNVPc5VadxV4yndMp/p3cz3Qe/p3o7DjgMp31PPln0p4FArDdgM+YDVjllM806HzPaS306Tf8MW02njzcgOl+nkjclPAanlVYJW/u3dqeaS7c1z3PcNDp72nnOSGjd4zIxS4g9gjQF5MxAdjziMw+nqzHWN6Eymge/Rfg+fzMnp7NJ6Ke23vWnuUHx5IC2Bae+apJDAckMp8M5/mVsTn2nx2ZvOhk8a6fLf8wyCnD6qF2n0TTjXHM0IGd1p9dIaD411UGn3AKONaSZQafhM107G2gKp+ZCd0HkQjhD1DwbNOJ6VqfvO0d63afzQqE4ezPajZ2n+T/fL5Y6sGmnbjeoAAF4Nso5VagEAb+dmTPNQKU1kjuqNY4zN/kZqA9DkzdpSWkEQTetWx0+rDJFNSU07Tx9S0o+fU2/QA5y0lunqCJc0KgkM6aoJzwXP/V7kagsMZxUSTmSqDBW8KgzS/UIXjqNNkQ4jzPRARwEAzPqNKxNaqg/iMRUpEPrZNM9yRRiB+A182qSRap8/6hMy+41uktRQzlfb03pqFNMHULtOxJO8Uclg+moW2FQqF5F7G7ESKBAmDyQMJMBFXajAd8QIkGiD2P3BMdbqG6g6KhxMuKodDoDSDc4WhAMNCioelj7Sxs31qh+Q5wBSDdUW7k5EeeiqIbWC6iJOiJGiwJ5W8o2OAJ3Vgs2J92jqJQyLaiWqWKomQbbTophXzq2NexG0zwNNJEyBTZEqKR3TKinODLrjqirM1JgIgNzR046JDXN9sdwzDegrvdYhgcBqLjd6ai7NPA6Ij/MBuFVtlqkqMI1UTqS+dqox0vGWj07Sgt5QSMyEGuTqNBBF2LaAi+o1G4JO7dcRUijOVU1O6jcWAIwAjJXOcsHM6rTqORBUqjmNjMx1z/5NK9TYxDRTtZUgQYGTIM1ErmhqPRp9aj3OV1K4zwJXUs/66j9ODI3Pj1OZY+pAz0G5BCpB0PSqQqGRzpqomHnMakQQIw2llJP9qypFkDmNz9Dm6kbPxU00D2jXxCuHFbDNaWpIz3eYXE5ZwdpP0I376kqRl2pLUsUMb00P1HCBb98cak1OsEz9z4lNpC3eKk8NCBXKAdOQPUBHIAYqURUvlL8qUgydDwkR8OpTDxBbgwyKaYRmQepU1SESQ03GzexNDYzCz+/Nhs2v6LRqV83CKlhu4WpZGLNARU261riNbA3QzoZ+zZgF0IZqXFBf54r1M9sdTb7OCdBUpbwqXpEuGI2QZ02REUKPSmGRJTcMv5Dv54Jp0KpiNUvTEYBvzU8NVRjaKmPO6o0j2yQAnWplDmYRjNHwTffqZo61juOqZ3gwKmgT9mpojZCS7RAjEwLUgPoFGYVqatX2zQJSPU93zNrTNQ0qzU9qbRAfktSRlapuHhVqbtnrKm+MC4f7wZ3ObI3GUBaUo9X20bkD5Q5WqnKNw4z2TiKNusHnAHqP9RJoE/echKp1mZcWbwzrpvXqdw5wTS5OHMWkKnhP/f8+KnlQRSag6npOyQ2/TlXqe12ganwMvxgnjI9Ro6p9TnaNySsWksKNN2p+zwdPsQ+TDIlNSWqAQE5m7Y2NzzmUplWH1xoqgo7uQGrbT9JxlngqhE+8zkbqhWWVaoYNK8GQTl3Q1hD8DXAgGCqIbGPqiQ3Y6onXHCqKs2Fqi1J1FczqjDE4aozOAk23AX2qjh5TKo70heqPlbcRfg1Sjr4Q745H13bqkcvm0nEqkv91TjSR5Q82TV217qqUzbLFDw7dqpXBcc/KUCqPziqXTifNa+2pmQnip2qZA8vY787jnuBqmpUSUw3MAI0H1/AN4hCrj1YRdWd5Kp2Pos1+jrBqno780MzY+Kqf6rQqoKuHDgxAWmqhjhUqohGv0pLqotPizMmqo44MQFpVKqpH6qTPbyNYaqXanOqmoZENv1tYTexq083ozQfSsuqo1oTNvMHEkw3S2IFelGTObLbzTI6Nh1fbzk4EAg5IjTfqrQ4KAv3d4oCqTPZQvBDqRDdqr06HQ/wRRoHxGPwN1wBt7xKqsc01zwQQMMPtjfTd7qqzlTojRqq0jiqNRKIP6rXRjyq2ohNON9xHTIMMv9ASTHYOdmq4zU26Nuq50KKXy6q6jYyMkBHq0wLAa893jOb7NKq9E7xrzyq+EjXWuJWSDYJf2Gq/z+mRFg1LQWJN+1jmzvuNWlBqTh/gA48z0D+aac2NzHrUnF30asTa8wy2M84qxhEPDNfqxvZ0qseNVsyA0/YqyJVZqslEAlEtzrBVQmrKzQGQf+rLkjUPf6yNKszUydFs0qDNc804gczP/xARHdv4rOrPwkHKEJaSglV3a+rRlAnq0hAEKtLNXAGbTznaMerUUSYMjI4qFPrT3mrWEIPq1pfLlF2PuurXkNAOSc0KCZgQiI4O0Bfq2Y7ZTfXa36razPVq21LYTKLNck0Iz34Nb4yTNm8q3cC4jZsMz0/1FA1Wy1nq6uARCRUL1GvAawBfT31Mow1LTivSRI4hjIplwirjz5DNp05BjulNd04xjjIRYM7aKuaROE1OT4/q588OTQyhGKrpDRl0v++C6uqOXMxwAXJBxGrrzNWPAE2VEKQRNg8bTaL1AWruUVjXh+rvVVXRSVdPTNk/M6cP6vFapw3bVsvOq5fb2Gaq80vYDRlq9GjSq8C2Am2ZKvbNMU+1zKMM/4zODWFfpCr5Kbhq+c2XEPNNZk3mkVpPFWAU6vwAek5C6vzMjs7B6v2Zcar+WHV1Oyr/UAFPbW9QawCNehcAqwGPCasCTYiOGg0r6IbrA877jc7NQ00/6wUQrisFlVXOkwyMkJjPmLgB6weOGI7djUsOMRbbzkITm6sJzNmNY8z3ziuT4UzQ6wuN394K6wyNxk59qw1A8ilNaw5582sPDPiDCs7/zlqOoE8Bq42rEU9EzT6OeNm+E0dP79QozobRfqsUAJZrFL4pKxVs46sWDgGP9ZhjUBTTEc3CZTJrGEyKDk0nQ2sZlh1rGk0InpMUFI7UjwABQuscKEXrHNJxjNE0meseDTyVqg4dTjNcyAx6VJrOAlwfqyDTZ+shTWmNgA8RDgXrgmsjEYpQJJBnT3NNChLYbSLrJU4HQNXrJhVdQZDrJw7VqyeNjJIrjtWXjf09TS2Rwg7B0XsV5M6D28qrKs7tTqRP3Wsr0HGrLHuv6y0Mc6stjUBN0E2xjl8A3OsvAaKOvSSM0w3NShflUF8RDsx+hD3OVTfIDXKOg88/KzMA35TjFSlrNGS66zUOXw6n6zXPoA4dUZeNBSs3DgBa72s4AG9XwI6UTziUrsFyGRzrOk35jflzUes7jQGPh0zGESdodes9TVebopbwqz6oSms/TrrrP9KUa0CWBGtBJFtrQdBJl8uNlds4nHLrQ47Jje6rRFF/jQHPDkBwbPwrRhARa0bNtGtHTSYXEU4zzVIgmKtJEKBQEk2FzPdSZHFIa0sL9kYca0vOuetMZpgrTQCn1oORR6ZzK06C3k1tTepP8U8+mXmoXatQzgXPEpl+Gd8T9BGFlbrrUxHVRDZQGhU2Fb6rVNFljoVPvStV0uUNRtU6IOaEMqtXTsAltOtYTx9PBPU7DxEW9CtZ5GgrWoQZANzrW1yJgN+rXA82jaPNR05QFmBrXc8EUbc16utfDXtQsJgezwRadI6/zpbNDqR5q2HOtNPKDwNNWCulVXcrHGhGDoZrZFLUjqwhlM6dEYFrZh3rwEbARNHLkIjRJw2IxA1NeA2tweckvMST0VuqHqtqTv4OdRgcjYadTCtsF3+PvattEVPkQmtuA8GNnRmCTucOZ9ae63ARzw9+kfUW5oGmgFdRN0/JkDmNqlRejcsrcyKnlkKAWAmYGv7rdM1j63VMjqt12ByR9RjImf0rd1dwTmgNDZnFV4RreMBG0QUOImt51AyODqNUK3sZm85HZLzEk+t8TkOPACt9IvYNgMGpOxDOBVykunurf08sE5yrgETkkIJa/WuBWG4Snxb2QGvNac1l4YMrg0ykDYaAb0/+0RuQOaXFK4WNcoyh64ZQkFCkzx6Ua2uHz1OQpw3DK4jQoaNUzLNUoyOTFW2Q6kzZUMCBuGuLjYAQeg+QzIbMht6haxDrjdB8a45Ols1SmXWrj0GsgEurkA2jziPN9GSW9BMQ6tfqK5JMFKuTDoiKEI0AX69FNY3r4/ZTOxZvD6sBImuWDmPaGZSBUmIQE0zm0VFrmHnsq5kNcauZjiQYgCuagEajU+ubjLWNxF1Uq5zPEczYTPDPZlVklTfQ+v0ea59OjY35tJJroI4dUB+QPauhlyjrom5Iph8ro0yPa6PAS112zbzR+o9+jx9EXuulwEmT8gwERaQrpwK3zZlNWk7vEBYB782lTPIC2yupjQNOTg1FjHfQOCurTkrOoaJPq6xPPZQL6vTrrVNjq64PY49mDeVvly+S9f92AnYAtf+2ALX/tgCTf7RCK7SP0IOVq7VPI809q7YZLdhpTcKVumu3jphVdxUADi/iPKu5UzsVYA5tK7qgsKu7WdD7+au8UTaA7Ix8GiQbA2u+AFVVuA9g0OPzgYFhEpco0qvAtgJ2ALX/tgC1/7YAtf+2ALX/k41rxV0vK8XOXNT6TKQAtOW4K8efzSvIUPgryM4kDL9N8403K8oRSlK7jXlRIE8M2sLYWc+xEK8WkmvNDHwVIIU/lbiNuo6ITn/Na8GQa8+j7dnqa9COU46/2ixNMhDv9iFR6RA9j/Wyk6vTjTJr1GjSq9U1/7YAtf+Tc+vXDH1X360Z69hO9dNdT+COdivZ5/Jaf2vazhmPzE5wTSMNa0PL0OIOBlHCgcyTzXnU695Qmyve1PmRGrql92Jr4E8Qq+DVXEFiT56X/KviauOO8qecq+ONWNl1jfRr5ICJExHBhUBfQfhXH+vmlZ+VOg8U1foM46voDNBQ/BYOj35NbxChg5DdIevqkDXPutYPTzvOLldSzjbNzRDC9Our7ZMd4KWr7o0FU8Zr71LUDuOEXg1o6/CRPE4J6/FNzQ5CDQ7QvI8OwJ1r8xEAa/OObs2eYphNfY0lzaWNkJLC0KuOXyv2VFSOBdSpjd1PkRNNa/gRegyWAcRO49lXFE+OOsFC6/pNRcQ2T/mM50z3a/vasev8vmLr/WosK/49/5R70N9byuv/kkNOno37FKVOuVrBjHfOuUQRzeQEBxSZj3NSpCwDkBcTMY3+D8qZt+wFD38NA8yLXmSSXE47DQPYd2wHgR+PZMFvkClOII3bTqwX/+wKDphRCovl5OusC7fckZLNQewMjUzPaI1LQI1sDc2OGE7iE1GrnGaUI0+W7A/QFwQBbQ7sETI100uVu5GZLBKM0M9aTskS/Jqe0UK0iiwU21qVISwVjI2CXFSjDQuWqCwXTXeXeVVZ7BiRAYyh7BlT66wZ9aPsGpjTzwUQQ51STw5ODJQ/xJPSLFDzAXeSlysMrB5Me5a9osUNC46gzX6bNVR7zL/VP2whkZiOUpUxbCKa1CwjTc6mWqZuLCSURqwlYXmQPU5HlTY1EkFQU6KM2WwngatRIBqAzoYPUdGmDXOOZ9ifjaDsKneubCsOI9HwkMTsLA5HkMCgpOwtRTWsLc4aF8CQ1g0kT0ON481uAG365KwwktchFdHc7DHEEe6EH8msMwzsDL8Dy/SALDSMtCC27DWRGw+xwFHSi0/57DcNyBAOLDfNehPCDUbsONAV02GQGikwUfOsOk+oTifA0k15T9Cm16w8TVbsPPPwToYSXFz4rD5A3WSZLD9aaeF87EBBLJeoTL9MvwGNzQ2VpJC+LEKQvBC/bHxsQ++U9gGvlOxFQLrPOSxGEPgRuU12kerM+3d0LEfVmljWzX6sSM8dDqDlE1fbzj0R84Yq7EsPIKxLk6KQdRjv7gWPgqWSzIbUAs0wVF2R06xOjUjUnE3fEs5R2pTZD2OsULLz9f92AnYAk3+sUm6ro8wsU1CrLFPXCyxUlUKE01gAz7WvaaxWQlbV/hF1DKZRBSxX0jIOd+xY1ZmsWU30oxRsWk00EZlsW0zPjS53FKxcjYkBn5gtLF3UDKxeTYjQ682XnbwB2ng+kyEOP10A7GETHfxXDXZd7o0yT2EsYziErGPkHpJzkJxkaexlQG3Qq6xmEbIsZpqOLGdNRCxnzXeNpKCwYPSsaU/gYPzM66npbGrseSxrgmIsbBWEY/ZSBQ+YTMRR6k5hTZ5MnSxulFHRG44azuZRU82RjVwR2E30kPCNVQ+3zwQsci2mbHLP95lXLHOB9lTZLHRMpe3tLHVARpHP3/tsdo/0VRuQImx3jiSTBfi/bHjN3Ox5TL4N7FHq09x+c1LlkFEPxa5bkRXQhYCy/jSsfQ2N7H2UmGx+TyAQeI9nEiMR4JvO1UjsgI1PzYXYv+yB11YN7fVEbIMNpM8UFTHFspvBjzuLk5gA0BlYH9JnYk+PvMCS7Ib+B+yHl7bsiCtRLIjSENT20OosidYArIp8AqyLDppsi9e+LIyPPxizV8DSk2AqDUzuK4GzDn+N8WwYLI/YsBA/D3nMq81o0bXRERN6UPBTK8x7b9qsk03nlKHASc8ABgRbBuyVQEa+ZQHv+FAYYn0JErLP7/jVrJgWMayY+hAhHuyZzruPESyakaPsmw28zI6OoGycIEmsnNeEk80gqVLdUeVcOayez6eP7k4zDSw3LQ4l0AjO6RQMwdRBzVXKIxisooFivjnso40GLKROawHdbKUNhw7oYZJspntBDk6SDqynrp3sqHF+bKkN/OOHrKomr01/bKrYflL8TH7WkiEezd1srI3dbK02Aa+U6DhsrmQFUSkjXNgPT4sO6oQ0U0ZvaGyxGarN4BUaDT/PBVDDEFMNv1WYTuhW3tnHrLSNysKhQIoQRRsibLZM1w6t7LcA3XYnDQ/suDsvsZaxljGVhAIATNVtjCTVUFVcTDheb4CMDgyPJuy8DuMSRdBubL0N1A510cfC+hB5FstOJ80NuDxsv8KhWJR0SazBDkuswZSjD0uETyzCzb5Qws2tzLUM0sBvjW4ZvhWcVMtD/C1VwUKNQ96TDdUOhM7fkd1M/mzITbKN6UHKUZMOiJWk4v3syo5djxnNMIx6kTtNQ1DQw1zDy+zNDnGQZ09hjw2L9lHxYW/szxPOUEOMvBx27g5s0M12mTjNmRrJi/YUgOzSjOvVjBGOzS5XqY84rVzs1NU6ESBNLU1AE1DNs4/1DcURwy3crNfPN1QY0nxS/RW7ouds2dH27NqRxGzbHpcs29FhzcmQ5hJSkdhQZuc8DzdQZU4Azp/WDBb0IMps3+vebOC6JyzhT1FOxDt7bOK7oSzjUdhMdw3xw5WNbgQDFTFQoFQjpKas5kHUk/DDkUzOLOeBn4zSnc1R8JBBjmKQcoy/bOnQWdRqzaVc04y5kVRRVE2fza2NnVtYbOzbLE17kGis7eZ/LO6piQ227O9P95ABfPDs8I17mAiMJM6V1wpWUg0DDv1Nb1qkj6wQXxIXLPRNYI9qGZvAd9z3D7/OIcz2TSYCN449jYAPjw2ATgtPkEQ47PjZJU4jgIHM5M62Eb/ORFlxbPtPhA08jmt0btcRUiDs/U0NLP3ODKz+TvQuLo3u0gnWAoIXj6ROAhZqzImt/W0BjqtPDNYnbQLSEC0Ddc+tBBD50vLTqpe00mMQ4+vGLQZSPWGRDSUtB03YecftCFE2M4ltCU1sTa3tChzTkEzRatC9DJTc7q0MDJtM+xhoUwMMfg5unJNtBG0OjcUiINIEjnstD/bQLRCOhm0RGv4tEcGN7RJN4O0WbRNU5IDXDV8v/A0sAEDORK0VTIOPvU0KLRZVvUFv7RcQZdfVA5X++m2b7RkRzK0Zq9gtGk6NGQJtG1MdzlXfaO0cjrkOZwBBDmvVL+0eS5KBcgx9biCtH/izoBRtIM+YhD3OTY5JgNKNs86krSLxtu0jgTuexYyJTyDNVgCWUsnS1K0D7SZRV5UVHp9tJ41zmxRtKI/tVrNtKao9baAtKr3RrStOAk0H3lkMkeUIDzdtLQ6S0KhtLc2E7S5R0w3HTvdPYNAnTwYaIWiV0x2mbq0xTphtMdXM083/AhP3kVePEFCcz7j99S00kCxd95MZ7TXVSFoWjYitNth7TM8Boi03z8EtOFF/Q9gMzptJ5eltOhzcLTrMc80ybTv5XK08j2crM49Tmhac9w3LbT5EUG0/EYp0wgQuVv6tQIyM1kWtQYPBbUJM98yMVoPtQ003LUPWPp2IrUTNec4IbUWWqRKFrUakjNK1USjMgjCnrUhP2Q9gDthW6VgpDmTo2u1KgSbtSx5kkWJOXY1EETCtTJNALU1BynvmrU5AcG1O0Q4NOW6VbVAhqm1Q5YxtUY3EzZEgzK1S7UDtU5IC7VQP/tIjbVTFNa1VTZRsxhHslFZYqpIC/6HtV5HbHestWJdWD1Kapy1Z0EGZNO1ajn+P0k5bXi0kgm1cblnWae1dTYVdxABKENYtXoyAjUHM+3mtbWAN7pIQHeVtYW1Tk22EMNEbzOhYhg0kFxzNThkJzrTV5M8czj1tZRydkCsMclAGTUVtZoWyoz9tZ48yTT1RsY2bjl6P/cx4zPRtadbV7WqQ0o74IAita9PZHcUtbPvNbW2BNoyrDLw9Qu1vDuadau1wGELUgNEBERPBYo1ijp2tcgyQDMIO9zDfVkAtc8G60tSQsK10zpfSHczujIfOjc8bUJgY5u13IlK6Ne14EEOoVy15LqbtedDrDyPWnw4XWYbte7uQrXxX29Chzpbtai191JGtfnorbX8W4g1z09tdeFIQ7YChLC2BUcIM2ZGbjW9ZOMzjj6tZ+o29FgUSdqAMbYT/Xy2FgYHOS0//DkdkeC2HQbrOAMzHQanPEgF1bTFtiZBgLJ8Sxs7R0YZti2d5bYwcJE22jWYQD62NjMDtjjYApjDtjw+U0PM2162QTrXPhpXojUQgsEyNz3BxQxA17ZMtk4H4dgztlI48jgGeEi2VzZOZT22W0/Ztl1NlrZgq9O2YtgF1/1NlbZoXzq2a1j5NlsyrjiCtnA3+DXWN0xk5081CUgGFTUwJmA8gEhKPLcN/7Z/Vn7wjbaDNyw8Qjz7MetAvTjgY6E5nraMMmw1tUDrtpAwAj1GtpMB6mruTTlmTQP1scq2mzcgSoMBgDs2ONurK7ajN45qmThkVEk2/TxSQFZhzLasP8c/9UEWWxcznjMYNtuiBUKhkZUGmgIotrlCG0JMZ5s1SG2eRxcWyrbCBFs/nrbFNXiLOrbJuz884j6V0Ce2zzHqATQ6IrbTM0G21RF7Od41jjcnaFqecN1FMxlIog/jNVg1WEX9tuMyOpubYoleE7bpp/i27AhoQvy/ybbxiby29D6hpXO2+AcptvoFyFhqXBw0DzcqEKc8NlRhN6djSzKQtwYFv20JtwoFo7cNRES3DzzotxJFCtlstxZGM4kMFso9qmnAAk45HU83XdJRDLchPn5p0g5DPsdHwzXDary3KjoRpbg1w0ZnR7C3MQERNgpBaEzGR1xmsUX+iIu3O0BuMgdAcT2wRbJcEkC9Rwy3RDxtNybTrDdzt0kyEjc5t0yNLrdPzK+3UjhkNyQ7Ol6Vt1jJ37bBAjQ1SG2et158g7dhOVW3Y6RHt2ZBRbdpOKs19lstOUex+7dwS8S3czACYuq3dlY/Ab0/LTvMNtS1Jbd+dUFVLVmcQGdLOD09QIyR+jM+t4hIeavsemw52UdcPkQ8ALeQO59LlbhtSShqkxc5t5gzk0eYOti3nFbcRWK3oAUnPU871EBINT4wEUtKOOy4quGGt6xFHl0rP2S3sDdpD7xHzk6nP/k6vPiNt7lArbe8O1K3vlr5O+kST7fCWBg6FEiut8Y6wVIZBkE4eIi7t81MgzS6a6G30bedt9Q7UTh5PJNA7QLTWpu32z14O/VWcUbqt+Ax1lTiX/K35e4ct+ha9lksENGLLbfuNMVHTrfxN1Qz33bUt/b397f5M8cXLoXnt/4yNjVIPsy4AkaSZvi4BVQxRtMx7VZPRB32GULOuA6avLgRTR24E3XhPShu5GUfuBkBBbicVGW4HjI8NVw7ZTXSM0u4JDfSOsUCqbgoDCo2xnYsR0Xpm7gvQE+4MUlKuDNK5TawVhE4O7g4NW8wEQbMuDw3gQEDQVJAKTSYfrYyEUNAUupBPz7y/NO4SnXsNeW4a7hPOIpBnEZnEJFChzhmTHdRP7hZEOVHTkgqNmE08ltZQyzxi0SZb7i4ZT7blXhU7bhqQZ24bDfqsWe4cDJkPQZVKLh1YYU0QjO0ZES4ewFxNQQyQw8jTOyMPbiDPY9h7riHMz48bT4yuIxjaLiONSzUWbiSO6hgHAKCe4q4mEGcSD+4nDpbL2A3akgeNYJYpVwSVnEx5gkHdn24qTQ3Oh0x52GiafW4sDbaWy9F9DeCN9FW6GruuLiV17i7PYu4vddauMBd/j+xNg1HBlzDuMdEJjrXNJpY+22quM6i6VSkWlAy91q34HA38mvFN2c4+7jZOmG42wLKNJO43jKXNn+44UukMv08TrjlN+U7p2TTX8EzuUPrRgS47lE+THe48T2CuPMyGVg6xlnGU05euPlLiDqbmZG4/jmYNdi5AUSrp+G5BalZuQhDj48kuQwHdWnBuRAPfrkTNSNVyTwHPblWqLkZMfA0ZTrE2Jw0P7Lg7L7GWsZYxlaYXLkmVbZAuXDMmca5LBo9kq25MDr9O5G5Mzr/OF004z8jT4U0JDRCuTs4vDofRv01uBA4uUFBzzqFdAy5Rk1qCCdVeNJVOhFY+kUYuVA10D9tOlG4ODtK+cW5WFPmuVo04ASmuV1EJjh1NYZCwrliR1hWq3BzuWcu7rlpEAm5a1PmP+5CqwJ1uXA1LjNgUkYyA0YJPvg2Qk8ouXkyLl0URJjGyT7fIhg8vEUlNvHVVLmFQZyHebmJPcpDKrmMPd+5jjIbuZA2u7mSNcO5lN69Qf/WbbmZR581aQGyAjVNauqBuaFEJrmjSZ25pQGoaIK5qT8xQGV0hTWToTU+CzXnuYdD7TW5U2QPIznRR0o5qEXURwxD4DQMT1k/YjeLucB387nCTrkFkrnFbjY/ZEO5NiBNNZ4Auc04JDTUX7kQvlqb0xa51UVuOca52F61udtEwjcfud5WL0glASY5YEBZOv2C3F0HNRZ3Sk+urKG57EfDSEpBxLnw+dppqT71Srw8/7n2RKurdrn6EA+5/DIdZ5Q+8ZT0NAg8BboDVRh0hVRONSJaRCEKX5K6C0JOug1adj/iuhA0lEIquhNBlIXXMmu6F1wOBopLcgYVSBI7zmLNFQy6IAMPQkG6I0yQspBNGU1QPwS6KTMdx2I3Rz4ZP9882VQEP0K6MkRPNmFBIw/vPeIyPF6mujpFNETmuj0ycro/awq6Qka/QGU6dDsOAnW6SD/3PNm6SzhBMz1MR7pPn+y6Uje7Tus2uTjin7I1aU1kUbiyg7pdBj4/kg+2zfe6YzACPYlNZLpnblk1gFpuecAzQzqwM8U5OvNkunJHDEouPAfHRrp4zs+6ezT6d4G6fkGVuoA18Vt7uoNMODlON2I/0TdLBRwBdge/UIA3kASJXClUALqRWbi6lDl6upbiWbqZPyZfoTcOPLVHTkuYOlRGKLqiBzK6pPbHuqdBgLqpBgC6q1Csuq5xHT28urHMjLq0RVY6pBNNurgBGglxursHEbq9bf66wEnVZt9mE7rFBZKbn1gCQWoEWzrTbWhAnTWZO+m60EJZNzxZi7rVNAS61zoRSZFUYTbhEIdAw7reSu49hrrhRKMHxbrkZvi65gE0NzS66UcMQHSgTjvQM9Re07rwQsRRrzaMYLe69qkYuvlt8ESrPOw8KD6TMtczXDWjPze7BDcMfj+7CAEIMmBrl0x1NXe7DjWPEe27ETeCFJxQYzzJvJ27GDn/uxrqNLsdUDc4xFriAUw4k0ELNTAHqTJo/Hc91DjSuyuog7suMtg97UbjVs27MwX7OrE2/0uxuzhCXX3zuzzHA7s/TNREIQ/SOL85M1eYu0dDskTCQfY4/UwrOHiwBLtQFsq7UjzIRQpQQQN5NlVG0VPZOEi7WzHKq8y7X0H/X6sQZLtjSGi7ZYcwu2hK7jcvTJBM1rttNiK7b0sKAii7cmMJMJ0+C8qmu3gHAbt6shdiNgN0NDpDqDZGiTy7g00VaG43PkNWXwM5hFKMPRM6FUXJR6QBcklVWjlK57uTeNW7lkLuu5k9ozz6AUlHPHnTu6A2NDKLX1W7pDM6rCFuwQmIPdY5qDaRPcoyBkUcRck1yjSROTu7s7V6u7Y6mTetBLIQZGh0N2Y+KEHC3vO7wQIl4hW7xbQPmjW7ybeOu8xe0zKLPDk3KEk6u9NRlAY3O4+aTFMXNn+72odKqvu73g7ANhY13AE0PrC75GKqO840tj/7u+l7KrvrNRx10EYZu/BVAEpchxK79U9RB8S7+JuSu/szEDeLbHU2pFPMvAE05rwE8vE6uA8vvAhacEF8OsF+z2GiQ1jxF7wRPDY6GDOxcR07yFwoVhZV2rZNPF802zZKNclLLi0iM0x/MbwkOvKndLwoBwM727wrMxM2wzm9R5e8MHjiRigw1j7zMya8NgZtY5teq7w6R3VJkTehMrA3+VfkvEI5xjLaOhV1PbxIRiq8SkiuvEwFhHhyNmEXLjKHvFJDQjyP6BcyJHc0RQC8WlS+ZtcyVkpGN3Y8FbxhNnUyN0nhNqw5zbxoNaZCbUH/vGw52zJjMhw+HDPRTmpQHLx0Mxi8dg1zMy04Bv2lvHxHsLx/PLw7p7yCYCI+f0uYB3F51DtgYYU36ElTvIwyA1r5Q2K8kGHCdK8HKbyUM1iV93j82BTYE7yaN/ZWfj5TBfW8n0F0gzBCQbCwBpQHal+rRQrLODa6o+W8rEKoWkQ4nz8EdnA0Dw+PAg01Try2NMeAkTQ8Ack8R2mUNE03sUD1OLHGT9f4xk+jabzFNc06b70ivMoxxFwplMz//3cHvNG9arzUMmpBY0WyQB69HbzbMfI5jmzpvOC3uFHvR2WPc7zmAYtbe5MCvOs4hnjuvO83c7zxMdhCqHnEvPYQCDkDvPmgWTIPO0JSfraZvQBBS+MuRO1ICzX9PBe8Qb0JV9U9wTn6r8K9D71XvRI2rtLCMjU1dDqDvRhZaL0aQBO9HDHOBskFej/mvMi9Iy7uOEi9Jk9qRWNBxlEMNZS9dr0uD5Tg970ym369NTmyN2cx4kQUAV29OxFzOQu9PlPmvUBRrwJFRAO9RU2pNxX9cTXJOk1CWU34vU4E7kwsDIRE0To2QBO9Vb0QvVi9E71b6em9XjMRbyq9YT7jvWMzm71lMC5O4DruRBm800tRAai9bTcIQagGBznj7Yk5HTQWNidkiUDrQlm9wTTKN2e9fJm4vX9h1UmcN40zMmOATzc/rb2HTRk5ozJVPfk/QjTIvY5Hp0pLRsa9kkThvZQCMPuVvZgzJ0mRvZsx372dMldPJEW+OGw4aL2jQMyKMKxAvahZSKy2PAVA7TZhva5DwjXkPQ1FCTRAOIFLRL22RWBDGQF2Mwa9u0JgX6s0AWDgB9E0Pb3DSvm9xjapZIk9JD5qSxQ+JjOhMmo1ozUdAuC90tgGvlOY0L3XSZCyX4daNxtOpzOwNVU5BwR+Zf+94zx6mK6950mPPd696pPPve004b3vSeFSob3zN2699dgF1/3YCdgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2AK+YABavmIBBb5kA1sl5y0VKmnCX8TRAg0xDA4EHee+cMM+HeQVWcJfxNEv0753vxfDSMSuGZ++fL57w1HEk76Cw1TAcsNWwHUmk8B3wd4g0sHQEVLB0hCUwdQlgCvFHcsrWcHYBBjAdSaTwHcEgsIkweAVFsHmDZLB5r7BGrXB6cIDw9rEfb7JwfAMKr7MwfPB6sINvtEsEb7Tw/y+1ieoweHB/MH/wf4nwMIAIoPCAsEbw9rEfb7JwfAMKr7MwfPCDCq8wg4sEb7Tw/zCEinbFRbCGb7vMC4EWb7dwlMbJsGuvuLAdL7kJpPAdwKLwiPEisIlFFzCFTAuKVoBJMIoJyoXJsItvvUBSL73FenD2QYdxH2+/jAuJuQrvyyXvrArlb7zMC4mQCTaCgYNfwyrw/m+48HaIxG/ExixvxXD+Cxbwz8sZcNBLoMnBCi1FurDRr8Xw0gC3MNOBOLDUBBRw04E4sNQxLK+k8HIwHLDVsB1JpPAd8HeINIiesNJwH7EDME8L6rDZcB+JyoXJsCICEPDnsNsCb/Aj8NwACDDl8CUw3UI98N3Dg3AnMN7wJ/DfsCiMEUJcEFOw4MDwcOFwKovqQIlE5LDigbPB1TAsWoFw48AIMC1Lo3AtwnTP8XAusOWw3LDmMDXwMEAbcOcCEPDnsNsBNPDocNwwM3DpATBw6YwYMDTwNXDrMDAxBEXLSurwN3DswqkwOHDtgUQw7gGQcO6CSvA6gbxwQXDwcIzEoDEfcEfDZwnzMPIwSPDyhuCwPkWfMD7wP3D0Ab8w+e/AcDpw73BBC9ww+rD2QYdxH3BHw2cw98XVr8FKNonwyuiwRAGGsPmAdTD08Dqw+rBBTG1AfHD2QYdxH3BHw2cJ8zDyMEjw8obgsD5AabCQ8P7xDAn78P/vnTDxMExuCkMAcE0xDHBYRyxBekGvQ8jMBPENr5wwz4n8Cy8xDsRC8Q9FvzEP8F9CQ/Bc8RAxEnERsRAxEksbMRDxEzBesROH6ExC8GDC+4K2S/8v0sCB8GKxFgIJjNjBKbEXBNMAD0vnxElJmwBAMRiCgYEdTNjC3sxIRS4L58Ci8GdxGouHsRsvtfBo8RvDmTEchZoxHTBqgW9xHfEk76Cw1TAciOIwl/E0VXXFTUD7AIHwiDAdzFIvzfEiAKlwiTCShjmxJENksSRwlMbJsS0vyYGMcShMYwxbjFjMO8xcyvLLLEOab59xKIxbjGXMO8xc77xvzcxeBMTwiTCSr56KW8QUcTZwlMbJsS0vyYGMcShxL8xjsR/MO/EvMGxxLcxlcTAMXAw7yqdAU/ExDGdwoK/YQjGMaPEy8GYwpUxqsTQDmoxrwKfxNUxtMTYGL8xuQA0MbuVS8TgMcMxxW9eMqcywTHPxOcx0sTqMdUx1zHZVuHE8DLYxPIBEDHlxPUx6zHtMe/E+jgxxPwxxMT+Mfsx/cUCi17FBTIHMgkyCzINMg8yETITxQ7S09CSMhvy8DIfjLRGIzIlxRcyKg+TxRoyLzOOxR1pwMUfawbFITI9Mj8yQTJDyekySMUpMk0yT8YcMlPdpTJXMlnFMjJdhmLFNjKRMmQyJcU6vNVJ5sU+sjnFRMVExUTFRMVExUTFRMVEP2ozkTKKMowBnMVOMpIylBCRNDbFU8XKMqRBS8XOMqHF0TN9xeLFXDOCxV8zhcViM4kykMVlMr7F3jHKxWoyxsVtMk3FbzLMxXIy0TLTMtUy18V3Mtwy3kCgTO0y4/GVxX8y60ZHxYIzvsWFMvbFiDL6OgjFizMACVUzAsWPMwfFkjMMxZUzEjMUN1XFmTMaMxwzHjc6xZ4zIzMlxaJ48DMsMy7Fp1LPxalNXMWrMzozPDM+M0B6LcWybZ/FtTNNM09uYzNSM1Q8p8W8M1o77sW/M2AzYjNkV2DGO8XHNC3FyjN1M3kzecTlxVnFW8XUM4LFXzOFMkkziDK5xdsxzTOMM45DSjOQM5LF4TKpVk3F5ND3M5tfxcXoM6DF6zOlxe4zqDOqxfIzr4lhxfYztsX5M7vFgjO+M8AGbcYAM8Uzx3v9M8vGBgdRxggzCsYKT0zGDDPZM9sPI8YQM+Ez4zPlM+fGFTPrM+0z78YaM/Mz9cYeM/o4XcYhNcbGIzQDxiY0CTQLxik0EMYsM6jGLjQYxjE0HMY0NCHGNzyPxjk0KcXGxj3FyDQuNDDGQs0yNDYQkcZGNDq8wjRGxkzX+MZP1/jGT9f4xk/X+MZP1/jGT9f4xk/X+MZPNFHGXGrhxl9+LMZiNJY0mDSajsM0n8ZpNKM0pTSnxm40qnPKNK4+gsZ0NLbGdjS6xng0vcZ6NMDGfDTFxn6Mx8aANM/GgzTTxoY012L9NNs03Q/0xow04zNUxo8/0MaRlTXwH8aWNPU091eBNPoBL8acNP41ADUCxqE1BsakNQrGpzUPNRE1EzUVNRfHHjUaxrA1H8azNSTGtgE8NSk2Qsa6OoXGvDU0NTY1OJIPNTzGwkNENUPGxlg9xsieJ8bLiryDHtwaxs81XcbRNWLG1DVmNWg1asbZNW41cEWAxt1Y1cbgNXukfUBHxuU1hTWHxuk1jDWONZDG7jWWNZg1mjWcNZ7G9TWhxvg1pjWoxvw2K8b+NbHHADW1Nbc1uTW7vHo1wDXCxwk1xscLPYDHDUW1xxA11ccTNdg12jXcNd5VcccZNeQ15scdNevHIDXwNfLHJDX3xyc1+jX8Nf7HKzYDxy1cSccwNg7HMzYSNhTHNwUDxzk2HUPJxzw2IzYlNic2KTWsx0M2MMdGNjXHSTY6NjzHTTZAx082RcdRPKfHUz7Ex1U2UkkNt/E2VzZZx1w2XcdfNmLHYTZnx2RPgjZvx2g2czZ1MpPHbJLLNnzHcEekx3I2hHDMx3U2iQF4x3gwFcd6NpNes8d+NprHgS+ax4M2oTajNqXHiMjbNqs2rTavNrE2swXJx5A2uMeTNr1PbceWRhPHmYTjx5w2zjbQx6A21cejMrLHpQSJx6c248epNubHqzbqNuw27sewNvI29MezNvfHtVRDNv0J7Me5NwI1tMe8NwfHv4zTx8I3E16ux8Y3GsfJOX322sfNNyg3KsfQNy/H0zcyNzTH1j0dx9iJxsfb//43RTWxx9/RADdNx+M1VcflN1TH5zdYx+o3XE81x+3ktsfwN2XH8zdpN2vH92RHThTH+jd4x/03e8gAN4A3gjeEEAjIBTYVs/nICDePN5FL8cgMN5UBsMgPAQQ3nFlCN583oYkHN6VGi8gXN6zIGjeyyB03tje4yCE3vDe+NVbIJTfCyChPazfJVjDILEBoyC430cgwVifIMkwZPa4248g2N+HIOTfnN+n85Mg+N/HIQTf1NEV52kauyEY3/chJOADITFVjyE44CchQOA3IU5DHOBPIV1n5yFk4GzL/yFw4IMhfOCVIEzgpOCvIZdq8ODLIaDg2ODg+lchsOD04P8hwl7E4ROXaQ2rIdThLyHg4Tsh7dsmPr8h/BkE4WThbS2PIhDhgyIeRPzQIyIqNgjhrOG3Ij5KU45nIkzh4O/3Iljh9Ph04gMibTenInTOwyJ88DsihOJE4kzquyKU4l8inRM7IqjigyK04pP7bq1TIsjityLU4sUuYyLg4tTM5yLsCnMi9PT7Iv1hxOMRrEDjIyMQ4zDjOyMg40zj6yMs42DTNyM443cjROOLI0zjmM5vI1jjrOO3I2jjwyN0+CDj1OPdT5jW9yOM4/sjmOQLI6YeXpjfI7TkPyPA5E1puyPPg+sj1OwjI9zkdyPk5Icj8OSU5J8j/QWnJAju3yQTQs8kHMkrJCTLhyQs5QjBTOUXJEPatOUtAVskURSXJFjlVPD/JGTlaOVw5XjlgOWI5ZAGcOWcJXzlqOWw5bjlwySg5dLzNOXg4+8ktAtTJLzmBOm7JMjmGyTU5ijmMyTk5kTmTyT05lzmZOZs5nTmfyUM5owdSyUY5p8lJO4/JSzmvyU3srTm1yVHuOzm6Obw5vslXOcEPvMlaOcXJXTnKOczJYTnPNtHJZDnUR8zTVDnZyWmNU0enOeHJbkYoyXDdvDnqUMXJdDnvyXc58jZeOfU598l9c5s5/MmBOgE6A1YwyYY9TsmIOgvJijoQOhI6FDoWyZCsTTi+yZOzJjcRyZZDQMmYOinJm3wcNAg6L8mfOjM6NTo3cFM6O8mnOj/JqjpCya06RsmwOks6TT81ybQ6UTcCybdzrsm6OlrJvUnqyb86Ywv2ycI6aMnFOmzJyESryco6czp1yc46eTp7ydI6fjqAOoLJ1zqHNYE6isncOo49ucnfOpJCFsniOHg6l8nmOps8ccnpOp9CccnsswA6pjqoXlbJ8TqsyfQ6sDqyOrTJ+Tq5yfw6vcn/OsDKAjrEOsY6yDXOygc6zTSiygo60soNOteBg8oRQdTKEzlTyhU65DrmOuhKn8oaOu0678oeOvI69EMzyiI6+Dr6MdrKJjr/yig7AzSSyis7BzsJOwszAMownJDKMjVZyjQ7Fso3a53KOdmh3dDKPAjuOyQOVspAOynKQzssykY0yspIOzPKSzs2OzjKT8i2Oz3KUztBylY7RTtHylkHKcpbPfPKXTtRO1PKYTtWymM7W8pmO187YTtjymtW3MptL2DKbwNzynEP4spzO3M7dTt3QnM6W8p5O30Bhcp8O4HKfzuEQKrKgkHkyoQ7jWnHVZM7lDuWEerKizubOTU7nsqQOgLKkjl/ypQ7q8qXO68/D8qad4rKnDu3OZ3Kn4NAO747wDvCQLM7xjORO8k7y8qqO9DKrDY3yq472D3gO9rKslSByrSddjvjyrg75sq7R5fKvTvvNUDKwHzsO/VVSMrEOa/Kxjv9O/88ATIUystJJjwIP5I8C8rRPA/K1DwUytY+nMrY7yNAucrbjRJIkMrePCc8KUWWyuIzzsrkPDHK5wIvyukBLsrrVWg8PcrvtM08Q8rzPEj4KDxMTbfK+EBlyvo8Bcr8jY7K/jxcywE8Xz2hywQ8ZMsHmwE8ajxsPG7LDTbiyw88d8sSPHw8fkZLyxY8hMsZknw8imI/yx42IssgNXDLIjyXNAfLJTycyyg8oMsrPKM2ossuPKcxw8sxAX7LMzyuECM8scs4PLV4+Ty5yz1VbTy/y0E8wvbGPMbLRjzKy0lJ+ctLOPrLTTzUy1A82MtTNCjLVUjcy1cCL8tZPOjLXDX6y1488MthPPM1hT+9y2U8+Tz7PP1HVctqPQI9BKrOc9yGij0Ky3JbND5qy3Y9Est5PRbLfD0ay389HT/xy4JbysuE6SQ9JsuIOQTLij0vy409MsuQPTXLkz05UZvLlj0+O2XLmUUky5s9Rz4fy55EwsugPU49UMukPVTLpz1Xy6o9W8utPV/LsD1jy7MyNcu1PWnLtz1sSuPLuj1wOh1Jkcu+PXXLwWr/PXrLxT1+RSbLyAily8ox2MvM9PU9ycvPPY/L0ZaGy9Q9mD2aNnDL2JY1glzL3D2mMcLL3z2qQiPL4j2uy+U9sku3y+ht5z24PbrL7T2+y/BYlj3Dy/Q9xsv3Pco9zD3Oy/w90T4Ey/891j3YzANGS8wFPeB/Pj3kVXXMCjNXzAxB+cwOPe/MET3zEe3MFD34PfoyHcwYAX7MGj4CzB2Gtj4HzCE+Cz4NzCVU0z4SzClhDswrPhg+GjlqzC8+H5j0RfTMMz4nPinMNz4szDkzGsw7ODHMPQq/zD8+OsxCOpLMRD5AzEc+RcxKPkjMTYpRPk/MUT5TWCs+VsxWPlnMWUSkMIc+X8xenoE+ZUKhzGI+aT5rzGZLf8xoPnHMaz51zG66cT56S5XMcj5/zHQ+g8x3OdfMeXeK0bJF14lCPpA+ksyBUddFxz6azIZMaMlrPqDMij6lzI0+qWh+OpHMkT6wOvLMlP8oPrfMmD66zJsxxsydPsED2j7EMxzMokxBzKQ+zEs9zKg+00pGzKs+2MyuPts+3T3kzLI+4sy1PuYzJD7pzY8+7cy8MgbMvmqXPveOEj77zMQ+/szHPwI/BDS0zMw/CMzOPwvM0UMCzNM/EszWse024P6uPxrM3D8ezN8/IsziPyZbCz8pPyv8Xz8vzOtWTT8zzO4/N8zxPzpt0sz0QgbM9j9CSR/M+T9GzPw/STaYzP8/Tc0CP1HNBT9UzQgEms0KP1vNDT9eARQ/YDIUzRJFDT9nNsnNFz9rNx3NGj9wzR0y8j9zL38/dTP5zSE/eTLyP3vNJT9/OivNKPe5zStCMs0tAX3NLzCTzTE/k800P5fNNz+azTo/ntqcP6LNPz+mP6jNQ14SzUU/sM1IP7TNS7J9zU4/vVTHzVE/wkk9zVQ/x81WUl3NWD/OzVtCxT/Ur0s5Vj/ZPwTNYj/dP9/NZQN+P+PNaT/oQiJ6eD/tzW8/8s1yP/XNdD/5zXYz4M14NcDNekAEQAbNfuHgQAvNgjzDzYRAEs2HQBbTVD5DQBrNjkAdzZFSukAkzZU8/82XBnTNmUAtP4nNnEAxzZ9ANM2iQDg4UM2lQDzNqBBkzapAQm7qNt/NrkBIzbBATM2zQmDNtUBUO6nNuEBaQqjNu0BgPsTNvkBkzcFAac3EQGzNx0BwzcpAdEKhzc1Aec3QzdhAfvh5zdRAg0CFM53N2ECJNiLN20XJzd1AkUCTzeFAls3kPFJAm83oQJ/N60Cjze5AqM3xt7pArs31QLHN90uVzflAdkJdQLpAvM3+QMBskmG4QMXOBK79U52uzc4JQNPODEDWOcfOD0DbzhJA3kgHzhVA4s4YQOZrzM4bQOrOHjzlziBA8c4jQPRA9kO/zicDTs4pPz/OK0EBzi7NFTl6zjFBCU9azjVBEM44Mw/OOkEYzj1BG85AN9jOQkEizkVBJjIlzkhBKs5LQS3OTUEwzlBBM3SyQTbOVUE6zlhBPc5bNUXOXUFDQUXOYjzlzmQO0kFPzmgyhzmOQVaMpkFZzm5BXVQ3znFBYc50QWXOd0FoOSzOekFszn1Bb85/QXJNLs6CQXcvf8lpzoY0o86IQYHOi0GFNsbOjkGJzpEyvM6TQY9BkfHSzplBl0GZWnZSss6fQaDOolVDQaXOpkGoQapBrM6rQa9Bsc6vQbTOskG3zrVBu0VezrhBv2umOX/OvItKD/XOv0HKP5hBzc7EQdHOxy0izsk5WEHazsz2rUHfztBB4kHkOCXO1EHoztZB7Dc6BEjO2kHxOoHO3UH1zuBB+s7jPILO5UIBzuhCBc7rQglDQ87uQg08Ds7xQhJEbE8/zvUGdM73QhtCHWmUzvs+lc79V0dCJ88BQiswLkIuzwZCMUIzjT9CNjq8zwxCO88POVfPEUJBzxNCRM8WBLrPGEJKzxs6Ic8dQlFNZM8gQlXPI0JYQlpRz88nOGLPKTfvzytCZc8uSK7PMEJrzzNYPc81PbzPN0J2zzpCekJ8zz5Cf2Vsz0FChM9ETm1CikjiOkTPSUKQR87PTG6Kz05ClwEPz1GBB89UQp/PV5syz1pCqc9dQq3PX0KxNavPYjqaz2RCuDiLz2czJM9pSbnPbImKQUw2nc9wQsrPc0LNz3ZC0M95QtPPfELXPOlrhc+BQt4zPM+EQuLPh0LmNJxSA8+LN0mTUkLuN+JC8c+SS4nPlEL4TzBC+0L9OZ3PmkMBQwPPnkMGz6FDCs+kvO5DEEb9X5LPqUMWPOLPrEMbhEPgWUMgz7JDI8+1NbjPt3Y7NRzPukMvz705Ts+/QzbPwkM7z8VDP8/IQ0TPy0NHz85UhM/QQ041gs/UQ1LP10NVz9rQJkNbz95DXkO8z+FDYkoSz+ReWkNoz+i2+ENuz+yyOUNzz/BDds/zVdNDfM/3Q4DP+kODz/1Dhjih0AA4F9ACQ420FtAGQ5JDlED2Q5dDmdANQ5zQEDyT0BJ8Z0Ol0BZDqEOq0BpnfNAcQ7DQH0O0OeNDt9Akn7LQJkO+0ClDwzJO0CxDx9AvQ8vQMTtJMz5D0jmjQ9U0Dj4Q0DlD21tEVUjQPZqYQ+PQQUAZ0END6kPs0EdD8T/m0EpD9dBNQ/hIhklP0FJD/9BVNiXSbUQGNpvQWkQK0F1EDtBgRBFBAkQUOhnQZUQY0Ghe09BqMv3QbAEQ0G46m9BwOgbQcpu90HVEMXFB0HlENTWx0HwF1dB+iHJEP0RB0INERdCGREjQiURL0IxmjFWc0I9EUtCSRFXQlbPTRFvQmURe0JxEYdCfBd7QoURnARNEadCmRm/QqERx7hxLWdCsbyrQrkR60LGtq4JXRII/4j5Y0LhAaNC6RIrQvUSNRm7QwESS0MNEldDGRJhEmkK40MpUFkSh0M5EpdDRRKjQ1ESs0NdEr9DaRLLo9fnkPX7Q397URLvQ40S+QGXQ5pktRMU7WkTH0OtEykTM0O9Ez9DyRNPQ9UTW0PhKy9D6RN0QK9D9cW9E5NEBOM/RA0Tq0QZE7kTw0QpE9NENRPcBcWSMRPvRE0T+RQCOaEUDWclFB0Y7RQrRHEUO0R9FEdEiRRXRJUUY0SgMqUUc0SuF7EUh0S9FJUUnaGbRM0Us0TZFL3ZqRTIEQUU00TxFN0U5RTvRQT8/0UM1UtFFNwrRRzqw0UlFSjN20UxFTkVQ0VBFVNFTF6LRVXY7RV3RWTVNprjRXEVm0V8EftFhRW3RZEVx0WdFddFqRXjRbUV70XBFftFzO6TRdTZB0XdFhzbb0Xo4c9F8RY8RBz0s0YAy3QSV0YN3StGFRZwy4dGIRaE2eNGLRaXRjj4U0ZBFrdGTRbDRlkW00ZlFuNGcRbs10tGfQLrRoUXC0aRFxdGnzIU9pDwF0aw+ldGudGbRsUXWPo1F2QgnMunRt0Xe0bpF4dG9ReTRwAcRReg3QdHDRe3RxkXwOy/RyUX20cwzYtHORfxF/kYA0dNGA9HWRgfR2QHq0dtGDdHeRhBU9dHhRhTR5EAE0eZGGjOh0elGHtHsRiLR70Yl0fJGKkYs0fZBVdH4U2nR+tYcRjgy1tH+M7LSAEY/0gNGQ9IGRkZGSNIKRktGTdIORlDSEUZTRlVGV0ZZPtFGXDZ4Rl/SG0ZiA8TSHkZmRmjSImnFRmzSJkZw0ilGc9IsTLfSLkZ50jFGfC+D0jRGgDaY0jdGhNI6Rogwn9I9EerSP0aQhb/SQ0aV0kZGmDmt0klGnNJMRp/ST0ai0lJGpYLcuUtGqdJYOwjSWk0u0lxGsdJfRrTSYjpE0mRGudJnRrw2Q2nA0ms2htJtRsXScOvPRsvSdEbO0ndG0UbTAiXSe0bX0n5G2tKBRt5cAEbh0oZG5tKJRunSjEbt0o9G8NKSRvMBhNKWRvdG+dKaRvzSnUt90p9HA9KiXkRHCBAGRwo3ydKnRw/SqmqT0qxHFdKv38ZHGjmc0rNHH0Yr0rZHI9K5Z33Su0cp0r4y6tLAUnLSwkcyQZ3SxYuyRzjSyUc8NFHSzIVI0s5HQ9LRNubS00dJ0tZFstLYR1GUvEdU0t1HWDS50uA10NLiR2DS5Udk0uhHZ9LrR2pW2zSj0u9HcNLyR3RHdtL2R3o5M9L5R35BsNL8MevS/q8DvgzTAUeQ0wQBr9MGR5dHmTPw0wtHntMOMf/TEBC50xJHqbHoOIvTFkev0xlHsj6Q0xxHttMfAVXTIUe80yT4udMnYOJHxzM20ys7qdMtR83TMEfRBXrTM1K70zVH2NM4R9s6FYOV9QpH4Tm40z9H5dNCR+jTRTjL00dH7kBI00uSfUfzOVXTT0f31ehbL9NTyWhBetNXTJAPBtNaSARIBtNfSArTYkgOWwc1pEgRSBPTaEgXN9jTa0gb025IHmDiSCHTc2By03VIKtQ/SCzTekgv031IMtOASDXTg0Tt04UQCNOHNwnTiUhCSETTjUhH05BISq0bSE1AgDaYSFDTl6gcSFXTm0hY055IW0FW06FIX0VDRy7TpUhkTDc4kNOpRajTq0hs065Ibwlb07FIc9O0SHbTt0h7UQ3Tukh/ZzFIgkkfQCPTwEiH08NIijqa08ZIj9PJSJPTzEiWnRJImUib09JIn0ih09dIpdPaSKnT3Eis099Ir9PiS/HT5Ei10+eTgki70+tIv9PuSMLT8UjF0/Sa+tP3SMzT+kjP0/1YPdP/SNbUAkja1AX7iUjfQ/3UCUjj1AxI5lYW1A9I6jm4OoPUE0jw1BY5/jQ01BlxEUj51B1I/DSs1CBJANQjSQM8DtQmSQfUKUqd1CtJDQEo1C5JEUkT1DJJFkkY1DYNO9Q4SR5JINQ8SSPUPzwG1EFJKjUs1ERCnNRGSTFJcdRJSTXUTDmiAUvUT0k9NW7UUp+y1FRJRNRXSUfUWjzP1FxJTdRfSVHUYoYVhdDUZUla1GhJXdRrSWAy/UHa1G9JZdRySWhJatR2SW3UeUlw1Hxj9kl21IBJejk01INJftSGSYFJg9SKaBrUjEmK1I8zI9SRSZE859SUqYvXrEmYQARJm0mdBprUnFLwSaM3DHi01KFJqThI1KRLmNSmSbHUqUm0Pa/UrUBI1K9Ju9SySb/UtUnCQF/UuEnG1LpJydS9Sc3UwEnROQfUw0nW1MbrDEAp1MlJ39TMVDvUzknl1NE4t9TTNgPU1Tc/1NeRAknz1NtJ99TeSfs12dThSf/U5EoC1OdKBVRUMzfU60oKM0BKDdTwShDU81Ak1PU3rdT3NafU+Uoc1PwGitT+Sh7VAEol1QNKKNUGSis0BkouOrjVCkoyfGJKNdUPSjg2uRDLSjzVFfVQSkHVGUpE1RxKR9UfP9HVIUpP1SRKUtUnSlXVKkpZ1S1KXNUvSl9KYdUzSmRA7dU2SmjVOUpr1TxKbtU/NN3VQUp01UQ3JNVGSnrVSWgMSn85/9VNSoM+N9VQSoc5IlVj1VRKjNVXSo/VWkqSNgNWq9VeSpfVYUqb1WRMK9VmSqJiGNVpSqZ/JUqpY6HVbkquAUtpP9VySrPVdUq2qslKuluPOW/Ve0rA1X1Kw9WASsbVgz/5OhnVhlUK1YhKzzdb1YtK1NWOStiR3UrbO6XVk0rg1ZZK5Erm1ZpK6tWdSu3VoErx99ZK9FWCSvfVp0r61apK/T/w1a1LAtWwSwXVs0sIR2lLCze91bhLD0QmPUbVvF6oSxbVwIJkSxvVw0sf1cZLItXJVmHVy5YtSypYGtXPSy9T5mYp6Y1LNdXWsT7V2Ubq1ds5HUtA1d5LRGg41eE1BNXjS0xUTuGwtdHV6UtVUzTtQEta1e8QK9XxSnzV80tlR9FLaDc51fnbQVPD1fxLcUtzVXXWAEt41gNLe9YGAcDWCEuCOMbWC0uGD7bWDkuL4OFLjtYTS5HWFkuUS5ZmB4ZAS5vWHVK71h9LoTOoEk/WI0un1iZLqkus1ipLr9YtS7PWMNEoS7nWNEu81jdLvz/k1jrspkvE1j431NZAS8rWQ0vO1kYx/9ZINIfWSjUT1kwzuNZORZjWUEvf1lNL4tZWS+XWWcb1S+nWXUvs1mBL79ZjS/PWZkv3NJdMg9ZqS/zWbUv/1nBMAtZzM/3WdUwJ1nhURtZ6TBA00NZ9TBQBKNaAQnHWgkwb1oU5ctaHTCE0/z4m1otMJtaOTCnWkT6j1pNMMEBC1pZMNNaZTDdMOdadfNhMPjiaeGw8o9ajTEXWpkxJ1qlMTDXsS4jWrUxR1rBafNayTFjWtUxcZchMXzRHTGEHxT3g1r3Mhkxo1sBMa9bDM/zWxUxx1shMdNbLTdbWzUx71tBMfkkN1tNMgtbWTIbW2VSoTIvW3UyO1uBMktbjTJVI99bmTJpl0NbpTJ5MoD9OEYvW7kyl1vFMqdb0TKwx4db3YkTW+UyzNphMtTIk1v5MutcBjM9Mv9cFTMM7atcITMjXC0zLOVdMztcQTNLXE0zWO2HXFgfR1xhM3dcbTODcfUzj1yBRGUznRWfXJD/UO7LXJ0zvTPHXKzeD1y1M99cwTPrXM0z91zZNANc5TQTXO00HB0zXPk0L10FND9dETRJDQE0U10hNGNdLTRzXTk0gjFPXUU0k11T5XU0pOWPXWU0t11xNMddfTTTXYk0412VNPD0r12hNQNdrTUPXbk1Gq+NyA01L13RNTmLcTVLXeU1V13xNWTcl+Y5Ap9eBTWDXhDTl14ZNZw/i14nfpE1t141NcNeQTXPXk013AlXXllXa15hNftebBd5NgteeTYVNh9eiXilNjNel1/2vVteoTZvXq02e166u3U2j17JNpte1TanXt02s17pNr9e9TbI3YTM518F4w9fDTbs2hNfON27XyE4L1+nXzNfXTkLX0DIU19JN0ITy19XX2U36TclN+u/RTd3X4Nf21+HeaU2S1+xN9NfnR4vX6ZOKTi/X7E30rDpN99fxTfo0Ztf0TgzX9tfh1/iCok5D1/vYAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tLouSTX+MZP1/jGT9f4xk/X+E5NTmDYGT692BtOZwq/Ts/YH3hT2CFOcU6ZTnQ4nNgmTnjYKdq4Tn1y4E6A2EDZKU6G2iJOoU+o2DZOj9g5TpJWEdJhTpbYP06ZUCrYQjhd2ERO89hHTqZOqNhMOv/YTk6u2FFPYNhTTrbYZ9hYTrxRYdhbTsDYXjK42GBOxU9mTx1Oyk7M2GdOz05rjjxO0+5dTtYymdhuTtoGXFAT2PLYdDaU2IbYmNh5TurYfE7u2H9O8tiCTpVO99iGTvpP7U7+2ItPAYlPTwTYkNhi2JNPC9iW2HcN6tiZTxLYnE8VMrjYj08Z2GJPHTyj2KRPMdjQ2KhPKDjk2KtPLdiuTzHY0NiyvYUxP9i1T2ebpdi6QF3YvE9G8807tdjAOL/Ywk9PT1Ey3djGVJ/YyE9XOKdPWtjNT17Y0E9hXWLY0wRb2NXqRtjXT2rY2U9u2NxAINjeDKnY4E942OPY/4qy2OdDVtjpY4dPhU+dT4nY7wWc2PFPj9kCT5LY9tkGT5gBRzX82PtPnU+JPBVPfGZW2QFPpdkEO8PY90+rNNA1QNkKNeTZDEHk2Q5Pt7GJT7rZE0ef2RVPwNkYT8TZGy+W2R1Py0/NENGUStkjBe1P09kmT9bYME/Z9J1P3EFMT9/ZMGHfT+PZM0+QT+nZN0762TlP7wRckrzZPU/0UYrZQE/WTnSzlk/72UbZIU8PNT5HwtlLUATZTjQ02VBQC2ZWTt9QDtlVUBFQE08WRDvZWlAY2V1QG1Ad2WFQINlk2LFQJAaa2WfYl9kjUCzZbPQxUDHZcHAffnxQOdl1QcLZdzy12XlQQVt42X1QRtmAifdQStmEUE3Zr0wM2YhImtmKzjEBnNmNNDFQWpkuUF3ZklBgRSZQVUM02a/ZmVq32ZsFN9mdUG/ZoFBy2aNRPtmlRC04YjoO2a/ZmVB/2a1Qg1DQRq/Hh1CI2bRQiwcB2bdQkNm6UJPZvVCW2cBQmUPR2cNQndnGTtbZyFCk2ctQp9nnleFQqwJNCNzZ0lCwUL9QwdnqULbZ2lC5MdbZ3ZoLUL9QwdniUMTZ5dnNleFQzAUD2exQ0NnvToDZ8lDXUFDZ9gGi2fg06tn6OMrZ/FDj2f8BPNoBUOraBDTI2gZQcG5jUPNVV9oLUPfaDlD62hFQ/draUQHaFlEERCEtItoaNBJRC9oeYhjaIDNd2iJRFVFU2iVRGtpnUR0jY1Es2ixRg5I52i/aTFFs2k5RpVFJ2jbaRVF02mnaSVFo2j5RQtoy2lxRpVFg2mbaYNpH2lbaa9pLUULaMtpcUaVRYNpm2mDaR9pW2mvaS1FC2jLaXFGlUWDaZtpg2kehMVF52oVRfdpU2mnaSVFo2j7ablGl2nBRbFFFUY04G9p0OY7adlGV5nZRmFGtnGfafVGe2oBRoWIIUaTahUuU2odRqtqKUa5RsEBSUbLaj1G1D2LakjhdBKvalYvVUb/amVHCRbfanFHGRGzan0aI2qFRzdqkVzPapjSL2qhR1tqrUdnarsokUd7aslOS2rRR5DZE2rdR6Nq6UevavVHuUfDawVHz2sRPLNrGxylR+xAH2soRB9rMUgLazzc72tFSCdrUUgza11IP2tpSEkGcAQja3gKc2uBSGjYmB8JSHtrmSD3a6HJU2utSKfih2u9SLjiK2vI3Z9r0UjTa91I32vo8Qdr86IxZvNr/UkLbAlJF2wVSSVJL2wlSTlJQ2w1SUzPCUlbbElJZ2xVSXNsYUmDbG1Jj2x5SZrMjUmlzp9sjUm7bJlJx2yhSddsrUnjbLlJ72zE7kdszUoHbNlKEOzrbOT/U2ztVP6rrUo8xyttAUpPbQ7+zUpjbR1Kc20pSn9tNUqLbUBYX21JSqdtVRrnbV1KvgQlSsttcUrXbX1K522I8SNtkUr/bZzKy22lSxdtsUsjbbzWT23FSztt0UtLbd2GHOK/behDd23xGXmxb239S3tuCUuHbhVLk24hBl9uKdjdS6jJz245S7tuRUvEKWzpX25VS99uYUvrbm1L9255TAFMC26JTBdulUwjbqFML26tT9dutUxHbsFMU27NTF/lWUxrbuFMd27tTINu+BvbbwFMm28NTKjt928b+ulMw28qPptvMUzfbz1M629JTPdvVU0Db2FND29tTRtveU0lDFkJ/2+JTTtvlU1Hb6FNU2+tTVzSaQkFTWtvwU13b81Ng2/bialNmNaY1Vtv7U2zb/lNvM0MCYFNzWhZTdgcR7BRTegFLU3xm+NwLO1Y8QdwOU4Smj1OH3BNTikVY3BZTj9wZNVhTk9Z6U5bcH1OZ3CJTnTLV3CVToU2RU6NZjWtNazzcLJjL3C5TrnQz3DE1uDdxU7PUDFO2MclTuFZbU7vcO1O+3D5TwTQvU8TcQ1PHQIDcRrVBU8zuWFPPN6/cTOkDU9TcUFPYU9rcVFPeU+DcWFPkVifcW1Pp3F1YnlPu3GEyWVPzU/VDDNxmU/kzpNxpOWbca1QARf/cblSq3HBUBz7P3HNUCzhV3HYCLtx4R7RWEUOx3HxUFgN1VMfcgFQbS1KRoVQfitZUIjbiVCXcilQo3I1UK5CwVC7ckuzgVDTcluo2VDncmjYN3JxUP0Ap3J9UQ9yiVEZGH9ylQSTcp1ROgcJUUdysVFU3Q9yvOWbcsVRc3LSVslRhwY/cuFRl3LtUaFGr3L5UbNzBAa/cw3Ri3MUHKdzHVHjcylR7NU1RlNzOW/JUg1SF3NNUiNzWVItUjdzaVJDc3VST3OBUlmuqVJk3Wy3g3OZUntzpVKI7R9zsVKfc78b3VKzc81T13PVDqdz3Rbfc+VS4P2IyaNz9VL6PrFTBNc7dAlaHVMc9YN0GhNBUzTVcR8PdC1TSON7dDjya3RBL9N0SVNw5VPRfZ0bdF1Tj3RpU5t0dWVxU65OZVO7dI1Tx3SZU9N0pOQxU+jCfPtvdLlT/VQHdMgns3TRVB903VQvdOk/I3Tw2AN0+VRTdQVUX3URVG91HVR7dSlUhPiXdTVUl3VBVKN1TVSvdVj503Vg59N1aAXbdXFU33V8P1t1hEtzdY1VB3WZVRN1pVUfdbFVLNlpVTt1xWy7dc1VU3XZVVwaa3XlZLN17qudVYKGBVWM2sN2BVWfdhFRV3YZVbd2JVXBVct2NVXU1Wd2QVXndk1V83ZZVf1WB3Zu1h1WGnL5ViUOoCZLdolWO3aVVkd2oVZRSld2rVZjdrlWb3bFVn920+WZVo20XVabdulWp3b1VrN3AlphVsd3EVbTdx4Yu3cpVvDr5Q/tVwN3QVcNsgt3TVcfd1lXK3dlVzd3cNSRV0t3gVdXd41XY3eZfhNT5Vd/d6z213e1V8lXn009V6n/gVe3d9XR4VfJ+SlX1VfdjIt38Vfvd/zmt3gFWAQyf3gRWBd4HVgjeCjJY3gxWD94PVhNWFd4TVhneFlYcOG4zRN4aViLeHVYl3iBWKV8C3iM2VN4lVjDeJ2x13ilWNt4sVjneL1Y83jJWP1ZB3jZWRF7/VkdWSd48VkzeP3sgVlI6H95DVlY3bjKO3kdWW3kWVl7eTFZiVmTeUXik3lO8m1Zs3ldWb95a2/FWdIFSVnfeYEhv3mJWfFZ+Ph/eZlaCEDhWbd5qOTPebFaKo/xWjVbL3nI1UlaT3nVWlt54VplNK1acM13eflah3oF4pN6DVqfehlarTqfeiVav3oxWsvbH3pBWtt6TVrmLhd6XVr7emlbBP3NWxN6fVsc8djJR3qNWzFbO3qdW0d6qVtTerVbX3rA51N6yPYDetIBbVuI1cFbk3rlW51bp3r1W7N7AVu/ew1c3VvTex1b43spW+1+V3s1W/97QVwLe01cFQc/e1zjP3tkxyAG93txXD97fMvfe4VcV3uRXGN7nVxve6lceWy7e7Vci3vDjpVcn3vRXK9733DdXMNYVVzM2Xt79VzffAFc63wNXPd8GV0BF/t8JV0TfDFdH3w84+98RV02LGFdQAb7fFldUPHjfGVdZ3xzhDlde3yBXYS/YUozfJFdm3ydXad8qV21On98tV3HfMFd03zNXdz4K3zYST984V3/fOzUD3z1Xhd9AV4jfQ1eL30ZXjt9JV5HfTEHaV5XfT1eY31IzTd9UV57fV1eh31pXpd9dV6jfYDZB32JXrd9lV7DcbFez32pXtt9tV7nfcF+S33JXvt91V8HAfd94V8Xfe1fI335XzDMQ34E2y9+DV9M72FfWW4tX2QtsV9zfjFff349X4l3zV+VapN+UPMjfllfs35lX8N+cQHZX9N+fV/c0r9+iV/vfpVf+SsDfqFgCNNzfq1gG365YCVgL37Lkmd+0WBLft1gVQDjfuv5Mph5YHd+/WCAPk08338M1k9/FWCjfyFgr38tYLt/OWnzf0Fg039NYN9/WWDvf2Td839tYQd/eWEQ8AN/hRDvf4+o9WE3f51hQWg/f6lhU3+1YVzeAO8nf8VhcN1Tf9DZe3/ZYYt/5WGXf/DSlWGnf/1hta35YcDjC4ATrsFh2NzsyOuAJWHvgDFh+yfFYgeARWITgFN7GWIngGFiM4BtYj+AeBJrgIFiWPkQ1VOAkWJvgJ1ieOGw8eOArWKPgLjQoWKc4EAYV4DJYrOA1WK/gOFiyYdXgOzlV4D1YuDsD4EBhs1i9EXN4pFjA4EZYw+BJP+7gS1jJ4E5YzP66WM/gU1jSN9M1vOBXo2tY2TNTNOfgXDVs4F4yT+BgWOTgY1joNXd5kuBnWO11r1jw4GxY8+BvWPbgcj2Y4HQySuB2W2/geFkC6ZBZBeB8WQitzlkL4IFZDuCEWRHghznR4IlZF+CMWRoKW+CPNAvgkVkhX8JZJAUKS1pZKOCZ6zVZLFDOWS93klky4KI9u1k34KY1RuCoWT3gq1lA4K423FlE4LFZR+C0WUv+YFlOOnMzWOC6Q3fgvEfD4L5ZWODBWVvgxFle4Mc/VeDJWWPgzFlm4M9ZajYk4NNuluDVWXHg2Fl1Sa7g21l5SUBLWODfPSDg4VmB4ORZhDpI4OdZiODqWYvg7VmO4PBZkaZlWZS5JmIGWZzg+ATq4PpfvFmg4P5TaeEAPJDhAlmp4QT+h1muVn3hCFmy295ZteENWbg4p+EQWbzhElm/Xb9ZwjWK4RhZxlEANmXhHFnL4R9ZzuEiMznhJFnUQLnhJ1nY4SpZ2zXkBszhLlng4TFZ4zMD4TRZ5+E3Wes/kDW/4TtEbOE9WfNoseFAWfez5Vn64UU0O1n+4UhaAeFLWgThTk834VBmTOFSWpVaDOFWWhA6dLSCTNbhW1oX4V5aGuFhWh1Cqzw/WiA7ReFmWBHhaFonQFRApuFsWizhb1ovqeNaMuF0NXzhdlo6DkTheVJG4Xs3yeF9WkQzOOGAOeDhglpL4YVCvIdmWlDhiVpTUgXhjEVj4Y5aWeGRWlzhlHcTWmDhmFpjN7vhm1pn4Z5aauGhWm3hpFQ34aY2UeGoPSzhqlp6WDE+k+GufKfhsFqD4bNahlqI4bc3EuG5Wo1WFOG8WpF0pFqU4cFal+HEWprhx1qe4cpaoUou4c2OU1qn4dFaquHUWq3h11qw4dpGvzr/4d1atlq44eFau1S84eRav+HnWsLhXVrF4exayDm74fBazOHzWs84xOH2O4/h+FrW/JFa2eH9Q3nh/1rf4gJa4pmKWuXiB1ro4gpa6+INWu7iEFrx4hM+fuIVOmfiF1Bp4hla/UPuNmviHUcG4h9bBeIinJ1bCuImWw00I1sQ4itbE+IuWxYCSzmY4jJbG+I1WrviN1shijFbJOI8OTPiPlsqAh1bLVsvONjiRFsz4kdbNuJKWzlkbVs84k9bP0fH4lJQvOJUW0XiV1tI4lpbS+JdW07iYFtR4mPVuVtW4mdbWTX64mpbXeJtW2DicFtk4nNbZzDWW2pd5eJ5W25bcOJ9W3PigFt2yRlbeeKFOx3ih1t/4opbglmNW4Xij1uIOpvikluM4pVKvOKXOdLimTRR4ptbl0jc4p450uKgXWLioluh4qVbpUUE4qhbqeKrW6x8gFuvC3kykuKxW7TitFu44rdbvDXPQnfiu1vB4r5I7eLAW8fiw56EW8w54DHB4siH31vT4sxb1uLPW9k44OLSW93i1XA+XhHi2Fvk4ttb50OP4t5b6zuq4uF3RlvxVIHi5Vv14uhb+OLrW/thjeLu1aHi8VwD4vRcBuL3XAni+lwM4v1cD+MAtwFcFOMEAQTjBlwa4wlVDeMLXCHjDlwk4xFcJ+MUMtTjFlwu57rjGj/I4xxcNjk24x9cOuMiXD1ABOMlXEHjKFxE4ytcSOMuXEvjMVxO4zRcUT1PS7HjOFxWcDZcWeM9XFzjQFxf40NcYjiPMgJcZTTz40lcaeNMXGzjTlxvS7LjUVx0XyHjVFx441dcewdp41pcf+NdXILjYHIdXIfjZFyKNJw2ZuNoXI/ja1ySahZclTQJ43BIkONyXJxWceN1Rwb2Llyi43pcpeN9QZzjf26i44FhruODl2k3gAe/44dctOOKMo/jjOXa4443xeOQXL4y/zj745SiBVa745dcxuOaXMlCk+OeXM02fjXQ46Jc0+OlXNbjqINEXNszw+OsXN81KeOvXOPjslIlXOfjtlzq47lc7eO8RTg9PeO/XPPjwlz2QbvjxVz631Rc/ePKOG7jzF0CbOLjz10GRnzj0l0K49VdDePYXRDj210T495li11h4+FdGlJzXR3j5l0g4+lZQuPrXSbj7j+L4/B08l0t4/RpjOP2QUrj+F014/tVg+P9XTs30V09Z4PkAV1B5ARdROQHXUfkCl1K5A1dTuQQXVHkE11U5BZdV+QZXVvkHF1fUGNdYkVy5CFdZkNY5CRdauQnXW08ETtl5CtdckpO5C5ddzxBO3ZdeuQzXX02wuQ2XYHkOV2E5DwCWeQ+OufkQF2MB+U0tuRENsjkRl2UM9XkSl2Y5E1dm+RQXZ7kU12h5FZdpENA5FldqORcXau5Fl2u5GE95+RjXbU27WKJ5Gddu+RqNVzkbF3Bip7kb13F5HJdyOR1XcvkeF3O5HszPeR9OTPkf13X5IJ6Zl3c5IZd3+SJundd5F3mOQPkj13B5JFd7eSUXfA1MuSXXfQ/FeSbXfgx4eSeBt/koF3/5KMy3eSlXgTkqF4H5KteCuSuPvTksF4QXhIz6eS0Xhbkt14Z5LpeHOS9Xh9t8F4hGukF4OTCXibkxUwQMrLkyF4s5MteL+TOXjI8+uTRYLFNQTLl5NVeO2ga5NiS9F5A5NxeQ+TfXkZH6uTiStjk5F5N5OdeUOTqXlM1duTuRHHk8F5a0lg7kUk55PVD5+T3AUpeZOT6Xmfk/V5q5QCU2F5v5QTTDV50Om3lCF54RE9CA+UMXn7lD16B5RJehDMd5RVeiDjC5RgyBuUaXo/lHTQF5R9elTOxd3zlI16aToGahF6eSLHlKTtH5StepeUuXqkEm+UxXq5n6uU1XrM6pj8W5Tl7ZHXz5T1evuVAS5jlQl7D5UVexuVIXsnlS17MNMLlTtseOEHlUTQ/XtXlVF7Y5Vde2zjG5Vpe3zgpXuHlXjsA5WBTMF7p5WRe7D5hOFXlaDkOUT7lazee5W1e9+VwSRLlcjmq5XRe/+V3XwJfBOV7Y29fCeV/PLblgV8PXxHlhRCH5YdfF+WKOIZfG+WNXx7lkJjxXyPllF8m5ZdfKeWaNUjlnDOi5Z5fMuWhXzXlo1845aZfO+WpXz4JiOWsTVDlrjPd5bBfSF9RX0vltV9O5bhfUeW7lf1fVgFMMb/lwF9bOBflwzTp5cVfYuXIX2UyieXMX2kPSF9s5dFfb0ZH5dQzmOXWX3Yx+uXZX3rl3F99X3/l4EEO5eJV3OXkX4cDXtfwX4tTtDdx5etfkOXu5drl8Eiu5fJfmuX1X509i07J5fk8F+X726Jfp4T5X6rmAV+uOPY0/uYFX7NQN+YIX7fmC1+6Z0JfveYQX8BfwuYUX8Vegl/IsKJfy16rXO5fz+YeX9JGXuYhX9fmJF/a5icQNeYpX+BgP1/j5i435eYwX+jmM1/r5jZf7uY5X/HmPF/05j9f9+ZCXXTmRF/95kdQ+eZJYANUguZMYAekQ2AK5lFgDeZUPqzmVmATRjvmWWAXUalgGuZeYB3mYQoC5mOdc2Al5mdgKFFZZpLma2AtPT5HYeZvYDNA9uZzYDfmdmA65nmNZmA/5n1gQmAyOjbmgWBHvTMx6+aFOS7mh2BP5opgUuaNYFWC02BYVpPmkmBc5pVK0uaXx/5gZIxo5ptgaOaeYGvmoWBu5qRgceanYHXmqmB4M2DmrjuM5rBgf2CB5rRghOa3YIfmum8iYItCHOa/YI/mwmCS5sVglUtj5shgmYW/5stgnebOYKE68zQV5tJgpzrT5tVgq+bYYK6y3emmkIZgtObf7mJguebjYLzm5mDA5uk4vObrN2Dm7WDJAUqdBGDNM/w3Kub0YNI3qub4YNYBceb7YNo1zeb+YN8yATZs5wJg5OcFYOfnCLA0YOtMQecNYPDnEGDz5xNgYecVYPnnGGD8QvDnG2EABtxhAucfYQUzPEgoYQnnJTz75yfgNWERYRPnLGEW5y9D2OcxYRw5Bec0YSDnN2EjNNthJuc8XT3nPmEs+qxhL+dDYTJhNOdHYTfnSmE6501hPudQYUHnU2FEOV3nVmFI51lhS+dcYU7nX2FR52I10udkYVfnZzdg52kDV+drYWHnbmFkBsphZ0/G53Nha+d2YW7neWFxbornfGF15382lTi354Jhe+eFYX7niGGB54thhOeOYYhhilaTMgrnlGGQ55dhk0EOS1/nm2GY555hmzp5OQvnomGg56VhpOeoYajnq2GsiwZD4Oew6PzntEE557ZhuOe5X0NhvOe9Yb/nwGHCAnXnwzMQ58VhyefIYcznymHPYdHnzmHUYdZLiTLLYdrn1WHd59ga6QLl59th5OfeYedoZWHq5+Nh7Q8G5+a2ODdxYfNOXufrYfhh+ufvND5h/gIuQBPn82ID5/bg9uf4OFRHU2IM5/xiD+f/YhIvtTx+YhYy0OgFYhsy3OgIYh82pWIi6A1iJegQYijoE2Ir6BZiLjMPAXjoGmIzXtMz3ugeYjnoIWI86CRiP0Zn6CdGb+gpj0tiRzTn6C1iS+gwYk7oM2JR6DZiVOg5YlfoPGJa6D9iXehCD+ToRDeN6EZiZwJY6Epia1Xn6E1ib+hQYnLoU2J16FZieOhZYnvoXGseYoDoYGKD6GJihuhlYoroaEHX6Gpijz55YpLob2KVPHHoemKZRTjodmKdVqvoemKhNjYQ1Oh+DlXogGKpYqvohFctYrBGCZ+y6IlWoOiLYreHq2K66JBiveiTYsA15TRHYJxixT9JMyHommLLsjSA1zlg6J9i0uiiYtUtIuilYtli2+ipYt5Hq+isYuLor2Ll6LJi6Oi1Vgpi7ei5QAzou2Lz6L5i9ujBYvnoxDau6MZi/ujJYwE19ejNYwXo0GMJMxPo02MN6NZjEKY5YxPo22MWNv8tu2Ma6OFjHejkYyHo52Ml45RjKOjsDero7q5WYy9HOjd16PNB+ej1Yzfo+GM6Ya7o++ey6P1jQekAY0TpA2NHNXQyb+kHVNtjTukLY1I4CekOSrxjV3QmY1pjXOkVY183CTJK6RljZGNm6R1+B2NrRsbpIUEYY3DpJUfF6SdjdukqY3lJEuktBc1jfkc5Y4HpM2OE6TZjhztWO9fpOmOMBts49ek+Y5HpQQF26UMNc368do5jmelJY50zV+lNY6E8SOlQY6VDAU2p6VRjqqiLY60xzulZOdHpW2O0U/pjt+lgY7pmLWO96WVjwFkYY8NYWWPGMzjpbWPK6XBjzelzY9DpdkCE6Xhj1el7Y9gQh6utY9zpgWPf6YRj4umHM03piWPo6Yxj6+mPM/o2bumSY/HplZ7rY/ZF1emZY/rpnEdVRuPpn7w3ZAHpo2QE6aZkB35KZArpq1hL6a04O+mvZBNjTzz76bNkGOm2ZBs85DYj6boyGem8ZCLpv2QlBQNkJ+nDS2jpxWQt6chjvmQyQdNKXOnNZDeah2Q6R+rp0mQ+6dQ3xGRC6dh5OenbZEnp3mRM6eJkT6um6eZkU2Rh6ek0VmRY78BkW03sZF5kYFqvZGM5reD6U8Pp9WRpQeQ5kun5OWzp+2RxM5NHaen/Uy3qAWR56gRkfOoHZH8+C+oKQVNkhAgnH6nqD2itPGHqEmSN6hVkkOoYZJTqG2SY6h5km+ohZJ7qJGSh6idkpOoqBts0zeotUurqL2SujfdksUUF6jRkteo3ZLhD/TX1ZLvqPAJZNoPqP2TB3qBkxEGo6kRkyOpHTbXqSWTOOaPqTGTS6k8+eupRZNnqVGTd6ldk4NxSZOOCaGTm6l5k6sd7ZO1BOepjZPHqZmT0OhFhoupqZPljPWmvZP02LOpwPkvqckKo6nRlBz8D6ndlCwGvPPtlDup8ZRHqfwav6oE1neqDZRjqhmUb6ollHuqMSi45n+qPZSTqkmUn6pVlKuqYZS0xxeqbZTEBCeqeSKPqoGU46qNlO9XYZT4+J+qoZULqq2VF6q5lSOqxZUtAsTlH6rVlUDSrZVOeDWVW6rxlWeq/j/xlXurDZWHqxmVkNJRSpurKZWk5i+rNSRrqz2Vw6tJlc+rVZXbq2GV56ttlfKntZX/q4GWC6uM5y+rlZYjq6GWLY3JljurtNcTq72WU6vJll0uk6vYFx+r4ZZ7q+2WhS7fq/mWlDZDrAmWp6wVlrOsIZa8yM9NQZbPrDmW2N3LrETdu6xNlvOsWQqHrGIHeZcPrHELB6x5hpesgZc0R7esjCGbrJWXUQN7rKWXZXJLrLBLuMw7rLzyA6zFl4zMw6zVl5+s4ZerrO2Xt6z5l8OtBZfPrRGX260dl+etKZfzrTWX/61BmAjH6RMLrVGYH61fo9mYMO1nrW0rj611mE+tgTFdmFzoOREpmGz2cZh3raGYg9gdmI+ttZiZjT2Tj63FmK0Bv63Q5iut2ZjLreUoS63tmOOt+uMxmPeuCMgjrhGZD64dmRuuKZknrjWZMhjVmT+uSZlI05euVZlbrmGZZ65tmXOueZl/roWZo5ezmk2Zn66dmanWCZm1e2Or0ZnLrsK2SZnZQwDLj67Vme+u4Zn7ru2aBOhWmt2aF68FmiOvEZovrx2aP68pmkjrV681mluvQZpnr02adQGhNLuvXphBmpOvbZqc2hOvfZqs3yeviNAfr5Dih6+ZmtTbtZrfr62a6BLJmvOvvZr9IYOvyZsTr9WbH6/hmyuv7Zs3r/mbQ7AFm0+wEZtbsB2baZtw6H+wMZuHsD0i8NAjsEmbnZrHsFmbrNk7sGTeY7Btm8uweVJ1m9+wiZvvsJWb+YcLsKGcDh7xnBuwtZwnsMGcN7DNnEOw2ZxPsOTwb7DtnGUHDOtPsP2ceAb3sQmciPLfsRUbB7EdnKOxKZyvsTWcu7FBnMexTZzTsVmc37FlnOuxcn4JnPzqoeDBnQ0Bf7GM9kexlZ0rsaGdNQJg1texsZ1Lsb2dVXGwGQ2dZOt/sdWdd7HhnYAavZ2LsfWdleU9naOyCZ2zshWdvNEZ3MVSlZ3TsjEGpZ3g/8Gd6NCfskWd/7JRnguyXZ4bsmltZ7Jxni/mMZ47soYcwZ5M231j57KZnmOypZ5zsrGef7K9nouyyZ6XstWeo7Lg1ruy6EJHsvHskZ7JNzme17MLjjE3+7MVnu25vNEzsyU4u7Mtnw6De4QJSPuzQZ8ns02fMEDhnzuzYZ9Hs22fU7N5n12fZxTxn3OzkZ9/s52fi7Opn5VLYZ+g0R+zvZ+w+LkCY7PNn8TUR7PZn9ez5Z/js/Gf77P9n/u0CaAHtBWgE7QgEle0KaArtDWgNgQHtEGgR7RNoFO0WP+LtGGgaP+rtG2gf7R5oIu0hAnntI0YxMfntJkoM7ShoLu0raDHtLmg0PvMXLu0yOCztNGg8M2vtN2hATUNoQ+08aEY4ZASa7UBoS4oONvftRGhRd3xUTu1IaFZJj+1LaFpMhO1OaF4+N+1RaGLtVJmOZJXtV2hq7VpobWxgaHDtX2hz7WJod+1laHrtaGh97WtogTgG7W9ohu1yaIntdWiM7Xhoj2iR7Xw9oe1+VglDse2BaJrthGid7YdooDpV7Ys+C+2NaKbtkGip7ZNorO2WaK/tmXLa7ZtotUYQ7Z5oue2haLx4I2i/7aZowu2paMXtrGjI7a9oy3zb7bNoz/6FaNLtuDVg7bpbDmjZ7b5o3O3BaN/txGjiR5Xtx2jmNjLtykKn7cwU/u3OSeft0GjxQwHt1Gj17ddD2O3ZaPvt3Gj+tlFpATQj7eFpBe3kaQgyXO3naQw6RC+W7etpEe3uBL/t8FVj7fJB9+30aRvt9xEHaR/t+mki7f2ha2km7gFpKe4EoitpLu4IaTFck2k07g1pN+4QaTruEwcB7hVUwe4XaUPuGmlG7h0yCu4fb/hpTjx9SZFpUUH/5A5pVe4oNsHuKmlb27hpXu4vaWFmU2lk7jRxxGlp7jhpbO47aW8y9UT/7j8CTu5BaXcGzO5EaXs8E+5HaX9/dO5KaYPuTWmGREDuUT/4NNvuVDLI7lZpkDuhaZLuW0Ku7l1pmO5gaZvuY2meSk5poO5naaM3gclRaacJkmmpCr/ubmmt7nFYke5zabPudgNe7nhpue57abwyxO5/a6PugWnD7oRpxu6HacnuimnMgjxpz+6PadIJB+6SadZhzGE7adnul2nc7ppp3+6dN6hp4+6gaebuo2np7qZp7O6pfi444e6tafM4kgd/7rFp+AWcZNPutVFH7rdqAO66agNm+O69agfuwGoK7sNqDe7GahDuyT5a7stqFu7Oahnu0Woc7tRqH+7XaiLu2mol7t1qKO7gaivu42ouNbMFne7najNCdznJ7utqOO7uk6hqPEnpaj+cn+70akPu92pGmwpqSe79akzvAGpPRW5rEmpT7wZiRO8Ialk5HUyD7wxqXnFB7w9qYu8SamXvFWpo7xhqawit7xtqb3f7anJcazZBNaXvI2p4MfnvJjdO7ygRc+8qaoJUN+8taoZkPpyf7zFIBzea7zRqju83apHvOmqV7z1Dj+8/apxqnu9DNV3vRWqkOGTvSDi870pqrEGY701P0O9ParPvUmq271VquTk0PWDvWWq+W5RqwWc8NybvXziB72FqyO9kass5KMXJas86D+9qatPvbWrW73BEuO9yA3nvdGrf73dq4jI973o34u98aulAj+9/QhzvgWrxlYVq9DzmPBHvh2r574o32O+Mav9KvO+PawPvkmsHOctNwu+WNkPvmGsP75trEjObaxSpP2sX76Iyzmsb76VrHlWAMuTvqWsj76xrJu+vOHQ5/msqXGxm32st77U3Pu+3azLvums1773Xq++/azrvwmtHMjvvxZOBNHhrQjRt78prRlOq783jh+/PNXZrTVOo79NQHO/VUv1rVhAP79lrWj02NwprXe/ea2Dv4Wtj7+Q0P2tn7+drau/qnwhrb+/ubWjv8Gt17/NreDyD7/drfANOPlvv+2uB7/5rhImba4e8T2uK8AVrjfAIa5BW6PAMVVfwDmuXXpBrmvATa53z0Gug8BhUYfAaOnrwHGup8B9rrPAia6/wJWuyN9fwKWu28CxrufAvthlrvvAza8HwNmvEYRBrx/A7UBLwPUtj8D9yLvBBa9NBLfBEd582OvBHa9pcHPBKM4fwTDqx8E40lDHL8FFr5fBUa+jwVzgj8Flr7vBcC8TwXkfU8GABdvBia/nwZUEW8Gdr//BqbALwbWwF8HBsCDU8bArwdT6A8HdsD/B6bBLwfWwV8IBsGPCDbBtHOfCGQEK9Emwh8ItsJPCObCfwkWwq8JRsLRLu8JdVgzy18JpsNEtkNa7wnmw58KFsPPCkbD9UvvCnbEPwqmxGARHwrWxK8LBsTfCzlWhsUvC3bFXwumxYM5HwvkTf8MBsX3/0bGLwxmxlOZ7wyWxpS7LwzWxt8NA08vDSbHPw1ZU3bHjw2e9fbH3w3WyAVTnw4GyFO6FYavDkbIrw5wSb8OlskfDsbJQByfDvbJjw8mybzn1snvD3bKHw+myk8P1spzfc8QBsq0ju8QRsr/EHCGBstPELbLdWAGy6bwdsvfESbMA1pjgh8RZsxfEZbMg1NvEcQLIyFPEfbNBNZ/EibNSwgfElbNjxKGzc8Sts3/EubONT9D8b8TJs6DYi8TU9SvE3bO7xOmzx8T1s9NN9bPfxQkOyRf3xRQlx8UdtAPFKbQPxTW0G8VBtCfFTbQwzWvFWbRDxWW0T8VxtFgJ56jRtGklx8WJtHjSa8WVtIvFobSVisPFsbSrxbzQEbS7xcm0x8XVtNPF4bTfxe2068X5VGPGATp3xgm1DRzZT6fGGbUhgf2GN8YptTfGNM8bxj21S8ZJtVTt7bVfxl21a8ZptXUUUNUjxnm1j8aFCuPGjNrvxpQY/8advO/GpbXIzKTHf8a1td5G+8bBte/GzPBPxtW2B8bhthQLLCGjxvJCtbYvxwG2OA3Xxw22S8cZtlfHJbZjxzG2ckI4zSPHQbaLgNPHUPjeqNm2o8dmGDPHbba3x3m2wslpts/Hjbbbx5m25NaXx6W298ez1Cm3CWUFtxfHzbcjx9m3L8fltzjrn8f02BvH/bdXyAm3Y9ajyBm3d8glt4DwF8gxt5PIPbefyEjRR8hRt7fIXbfDyGW3zNj3yHG33OvnyIG378iNt/vImbgHyKW4EXhHyLG4I8i9AAfIxbg/yND1l8jZuFQE48jpuGUv1MJNuHAIvNkDyQG4h8kNuJPJGbidhO20KbivyTG4u8k9uMeTIbjQ2wm438lZW7vJYbj3yW25AfO5VPvJgbkXyY25I8mZuS1COQKZwNm5Q8m5uU8rxblbyc+rXblvyd25e8npuYfJ9bmVvGEVgQMhrOJaabm3yhW5w3CtuaW51U6hloG558o5ufPKRbn8zpPKUboPyl26G8ppuifKdbo3yoFUw8qJPGm6UfKdulwYA8qhum/Krbp7yrm6h8rFupfK0bqjyt1bbbq3yu26w8r5us/LBbrbyxG658sduvPLKbr/yzTll8s88z/LR099uyfLVPtPy127P8tpu0vLdP07y3593btnBj27c8uVu3zUy8ug0FPLqbucz4FBj8u5u7PLxbu9BS/L0bvPy91ZEbvjy+06K8v1JxvL/bwHzAm8F8wVvCYOPbwzzCm8P8w0C5fMPbxTzEm8X8xVRz/MXbx1ohfMadYHzHW8l8yBvKPMjbyzzJsdYbzHzKm808y1vNxUMXaRvOzoG8zNvPz3B8zZvQ/M5WD3zO0Kn8z1vS3p4P+QDyPNCb1HzRW9UOWVvVvNJb1nzTG9c809vX1H7OW3zU29k81ZvZ/cMb2rzW29t815vcPNhb3PzZG92jh7zaG9682tvfUtEN3Xzb2+C83JvhfN1Ak7zd2+L83pvjvN9b5FVP2+U84Nvl/OGb5rziRDU84tvoPOOb6NY9G+m85NvqfOWb6zzmUOS85tvsfOeb7TzoW+4S53zpEeWb70Bt/Oob8Hzq2/E865vx/Oxb8o1z/O0b85PNUou87hv0/O7b9bzvm/Z88Fv3PPEO+3zxjScP47zyW/lMxNSVfPNTS7zz2/s89JRm/PUb/IHA2/089hv9zodb/nz3EFL894Q3TJP8+HIOHAE8+VwB/PocArz63ANPoVwD/PvbrFwFEjTcBfz9XAa8/hwHVJp8/tuLnAjPHnz/0jU9AFwKvQEcC30B3AwNXj0CpD7cDY2qfQPcib0EXA89BQBafQWcEH0GXBE9BxwR/QfcEr7bHBN9CUDu3BQ9ChwUzUc9CtAQvQtcFpJnPQwcF70M0kX9DVwY/Q4WD30OnBp9D020fQ/cG/0QnByYdNwdfRHNQf0SUGw9Etwfj+/Ndj0T3CD9FJwhvRVN370V3CM9Fo5XXCQ9F1wlPRgcJf0Y3CaQ4hwnPRncJ87//RrcKP0blUacKj0cnCrN6n0dgaU9HhwsvR7cLX0fnC49IFwuzpi9IRwv/SHcML0ijKH9Iz7OXDJ9JBwzPSScM/0lXDS9Jhw1Us3cNj0nXDb9KBw3vSjcOH0pjZV9Khw5/SrcOo1WfSuNcn0sHDx9LNw9PS2MJ05J/S5cPqi3nD99L5LOPTAcQL0w3EFOJz0xnEJ9MlxDPTMcQ/0z3ESSZz00jc/PE/01XEZ9NhxHPTbcSAzJ/TecST04XEn9OR4jPTmbIdxLj+J9OpxMvTtcTX08HE4PZVJ8fT0cT3093FARlQ9mkncMin0/XFHV79xSvUCOSf1BHFQVUj1B3FU9QpxV/UNPkz1D3FdcV9xYEPJ9RQ1Z/UWzapxaVaBcWz1HHFv9R8y2/UhcXX1JHF49Scy9fUpcX71LPJ69S5xhEEc9TFHpPUzcYr1NnGNiu1xkDJONJ31PHGV9T9UVXGZ9UJxnPVFcZ/1SHGi9UtxpfVOcajdUnGr9VRxrvVXNZb1WXG09VxxtzM59V9xuz/8/QxxvzzC9WVxw/Voccb1a3HJ9W5xzH+2cc/1c3HSO2z1d3HW9y9ZpVO0N8lx3PV+cd/1gXHi9YRx5UP+cegJR3Hq1X1x7TjA9Y5x8fWRrT5x9vWVcflH6vWYcf31m3IAPS71nnIE9aFyB/Wkcgp1LHINbdpyEPWrchP1rnIW9bFyGfW0cfRyHTuI9bhyIfW7ciT1vjjA9cByKvXDPdr1xXIv9chyMvXLcjU5PvXOcjn10XI8CK311HJA9dc8TvXZN3X12z7Sckj13jNM9eByTvXjclFK1fXmUib16HJY9etyW/XufA1yX4UHcmL19HJlOVv19zpu9flya/X8NGz1/jRu9gBycjfm9gNyd/YGeCc71vYJcn32DHKA9g9yg0EW9hJBB/YUcor2F3KN9hpykDls9h5ylfYhcpj2JE+u9iZynjKybUByovYs7ohypzYy4Sdyq0XN9jNyr/Y2pXNyswanpSxytzobNYv2PnK8ne32QXLA9kRyw/ZHSsv2ST7R9ktyy0Uk9k5yz/ZRctIz4/ZUctb2V05i9lly3U6nowZy4WiU9l8CjnLm9mJy6fZlN+Ux2/ZoQUz2anLy9m1y9fZwcvhHCvZzUbd27nL+9nhzAUcINfP2fHMGShJzCPaAcwv2g+vLcxD2h2SJ9olzFvaMcxn2jzKopYJzHvaUMj8/NfaXcyX2mmGi9pxzKodFcy04kTjHczBiyPakczReezc09qhzOeO1czz2rXM/Eer2sDWY9rIHEfa0c0j2t3NL9rpzTja6c1D2vnNTAmn2wXNX9sRzWvbHc132yqdvc2FGFvbPc2U3YXNn9tRzakq49tdzbvbac3H23XN09uBzd/bjc3trBhF79udzgA+G9upzhDL/9u1ziDNY9vBzjGJfc4729HORUuRzlPb5c5f2/HOa9v9znfcCc6D3BXSv9wdGkvcJPh/3C3Or9w5zrvcRc7H3FHO09xfiLjma9xpzu/cdMkL3H3PBO/IxzfcjRsb3JXPI9yg0Lvcqc833LXPQ9zBz0/czPclz1/c2c9o/c3Pd9ztz4Pc+c+NCcz5990Jz6PdFc+s0oTT+90kx1fdLc/NTkvdONRz3UDbC91Jz/DWnc/46vPdXM287IFSM91t0Bm8q914CJPdgVIz3YjIUVCSDMPdldBP3aHQW2bl0GfdtdBz3cHQfM5H3c3Qj93Z0JkjX02N0Kjp5WPv3fX4ldDH3gWw9dDb3hXQ594h0PWT4dEBFN/eOdEQ5u/eRdEj3lHRL95c8w/eZdFD3nEg5dFX3oHRYOYf3pHRc96d0X1Gb96qe+PesdGb3r3Rp97J0bPe1dG8zSkUJ97l0dHgTdHf3vnR6O933wXR+P8r3xHSC98d0hWWm98o1pffMOzf3znEmdJD30ge/99R0lvfXO5T32VKDdJ733XSh9+B0pDZoyYF0qHc+dKv36HSu9+s7dDbL9+50tffxerd0uff1Q/p0vff4dMBIo/f7dMT3/nTHOYt14XTK+ANAHfgF/b100PgJdNM+ffgMNkH4DnTa+BF03TfnPO74FXTi+BgwAvgadOj4HXTr+CB07vgjPAb4JXT0nJH4KXT4+Cw5qvgudP5B6PgxMs74M3UEWNZ1B08f+DgFv/g6QwH4PHUR+D8++PhBOJf4Q3UZ+EZ1HPhJPZX4S3Ui+E51JUA6dSg3zvhUdSz4V3Uv+Fp1MvhddTX4YETK+GIzYPhkdTz4Z3U/Yzf4awFKdUX7aHVI+HB7KvhydU407jjR+HY+Q/h4QIAOVvh7VKT4fXVc+IB1X/iDdWI97obz+Id1Z/iK+KZ1a/iOOCf4kHVxVuBDhXV1+JZ1eD3wPTb4mnV9+J1KuvifdYP17DipN0v4pC7udYn4p0MCPTb4qnWPN6cQ0fiudZT4sXWX+LR1mjP9buT4uHWfQTlHTPi8daQ/yVZm+MB1qfjDdaz4xjMk+Mh1sfjLdbT4znW3+NF1uvjUdb06YfjXdcFce3XEOPz43XXIBEhtsnXM+ON1z/jmddP46XXXNEJ12WHyddwHDIuQdeD48nXkTn349vtHdeo5rPj6de48A3XxR8OC9fkAaYz5AnX4+QV1+/kIZv48EPkLdgH5DnYE+RF2B/kUdgr5F3YN+Rp2EPkddhM38/kgO1/5InYZVfF2HPkndh/5KnYi+S12Jfkwdij5M3Yr+TZ2L/k5djL5PDfO+T52OPlBdjv5RHY+Mrz5R3ZCL9M1UflLdkf5TnZK+VEyBflTdlD5VnZT+Vl2Vvlcdln5X3Zc+WI6MvlkN4v5ZnZl+Wl2aPlsdmsyDPlvdm9Awz4Q+XN2dD/8dnb5eHZ5pF12fBMLM8L5fnaB+YF2hPmEOZL5hjl8+Yh2jPmLdo/5jnaSMwn5kXaW+ZR2mfmXdpz5mnafQTP5nnajMwT5oWxGdqk6IHarR8D5qHav+at2svmudrX5sTJ0+bN2u/m2dr5EJE04dsL5vAwq+b5KtHbIPM92yjmqOQv5xXbP+ch20p3tdtTcXXbX+c522jic+dF23vnUduH513bk+dp25wd/+d126/ngdu5UhDtR+eR28/nnAtT56Xb5NCf57Xb9+fAzZZ4zdwL59UkN+fd3CPn6dwsTwPn+dw/6AXcTzKx3FvoGdxn6CXcc+gx3H/oPS+N3Izc3B393JvoVdyn6GAEPdy36G3cw+h53NPohdzgBcXc6+iZ3PamYd0AESPord0REnfoud0gzEHdKUAb6M3dO+jZ3Ufo4Rsj6OndW+j13WfpAd1xCXTHW+kQy7vpGNdJO8PpJSdz6S3dp+k53bPpRQtz6VHdyBLL6V1G4+lk7Ifpbd3xzePpeNi76YHeEAutHRfpkuqVjofpnd45UWPprd5I3mfpud5Y8V/pxd5p+HleTCt/6dk5t+nh3pPp7d6dJnEEO+n8ysfqBjn49TvqEd7M6z3e18O93uEnOd7v6jVPm+o93wTk6PAH6kwGg+pUCyzgP+ph3y/qbd876nnfR+qF31PqkPEYzmPqnd9ozw/qqNhP6rHfhMzA7svqwd+b6szIU+rV36/q4R6kxq/q7d/H6vlDld/UNczxQd/j6w3f7+sW0d3gArT76yngE+s14B/rQeAr603gN+tbYxHgSRjhFu/rbeBf63mqp+uB4HfrjeCD65lm8+uh4JvrreCn67ngs+vGjCHgw+vUF+/r3NNn6+Xg5+vw+vfr+eD4ycvsCeEIQK/sFeEb7CHhJbqd4TEqa+w0ORfsPeFIykPsSeFb7FXhZ+xh6/nheOCcyG/sdeGNB/1BjeGb7Inhp+yV4bLSXeG+ywe93Qln7LHh2+y8BD/sxeHz7NEPnqW14gfs5eIT7PEfF+z54i/tBcDZJIniRM0f7RniVeKQ0kvtKeJr7TQY++094n0QG+1J4o/tVeKf7WHiq+1t4rftePfj7YHizeLVBRjyj+2UMC/tneLz7ani/+201zftveMb7cnjK+3VLift347B40kBS+3x41p1KeNn7gVQAM+N43fuFeOD7iHjjMkp45fuNeOj7kHjrN+M/V3ju+5V48fuYePT7m0DjMl/7nnj6+6E00fujOFR5AfumN9T7qHkHTsv7qz3g+62EvnkP+7FFBfuzR6d5Fj/ZYTj7uHkc78VFBT+b+715Ivu/DKn7wXko+8R11nksMgL7yHkw+8t5M0CYka9AAfvQeTn703k8+9Z5P/vZeUIHafvceUZacPvgeUoHfz1T++R5T/vnNfT76TsSMqj77HlY++95W/vyeV779XlhN/D7+TaheWb7/Hlp+/95bD5D/AJ5cD0t/AV5dDWS/Ahw+3l5x4h5fPwOPlN5gEJxiNT8EnmF/BVE7fwXeYs25/wbeY8G2/weMev8IHmWMiV5mEaaeZv8J3me/Cp5ofwteaRJ+fwweaj8M3mrknN5rvw4ebF3b/w7ebX8Pnm4U+N5u3Q8Oj38RHnB/Ed5xPxKecf8TXnK/FB5zfxTedH8VnnU/Fh514LB/Fs3+fxded38YG6WMq/8Y1Ip/GV55gdMeej8aXnrO6f8bVZj/G958jguP678c3n3/Ha7KHn8/Hp5//x9egL8gHoF/IN6CfyGeg1DB0rL/IpB6fyMehQy7vyPehj8kmVp/JR6H/yXeiL8mnolOhP8nXop/KB6LFNw/KM5/vylEk96NPyoejdV2l2hejv8rno+iwf8sVAK/LN6RTKLQBP8t3pK/LqevTOR/L16UfzAr+B6Vlvweln8xnpceTT8ynpgO/P8znpk/NE7UfzTemr81jkf/NicX3pyWof83Hp2/N96eUfe/OJ6ffzleoD86HqDOkv863qINmr87nqM/PF6jzSY/PR6k/z3epb8+i+Xd/Z6m/z/ep79ArNGeqP9BnqmP/hL0v0Keqv9DXqu/RA2Ef0SOVf9FHq2/Rd6uf0amSR6vv0eRJz9IHrE/SN6xzGr/SZ6y2bX/So+7zxl/S160v0wetX9M3rYdLJ62/04Nnn9Ojaw/Tx64/0/yQJ65zOReun9RfT5/Uh68P1LMdf9TXr2/VB6+f1TNZI6RP1WpOF7AP1ajFP9XBCn/V57CP1hdiz9Y3sNWKX9Z3sR/Wp7FGSrARL9bnsZUj79cXsd/XR7IEMBeyL9eXsl/Xx7KP1/VZz9gUA2/YNHaXsx/YZ7NP2JezebPns6/Y5Def2QgXV7QP2Ue0M4gUfO/Zh7SD4c/ZsNc3tNPSw15/2fe1L9ontVQoj9pd8Oe1r9qXtdAaxgv/2te2I1uEfA/bFoM3tpQTP9tjbW/bh7b/27e3L9vgJY/cB7eP3DAqR7fTyFRPH9yHuCaOF7hT+Ye4j9z3uL/dI3IP3Ue5E6bQGr/dhC+P3ae5k3VnubR8M1k/3gaHN7oTjie6P95num/el7qX1s/ex7rf3ve7D98jj1/fR7tv33e7n9+jx2/fx7v/3/NO3+AVV4/gN7xzbyPjz+B3vM/gp7z/4Ne9I3YP4QELn+EnvZ/hV73f4YP27d0P4be+NGOzene+b+IHvp/iN77IAZe+9QY/4oe/NPcUx3/ix7+P4ve/v+MjhG/jj+NeMQ/jf+NLuvfAk4Rv49fA01aTv//kF8Ev5EfBVhX2Sr/kg5WnZkfBz+TVQ7/k9yzXwj/lOQkXwo/lc0JP5ZijZ8L/5dTuv+X3w0/mJ8N0Ks/mU92nw8/mg2af5qfEL+bXxFNobGZ3xJ/nMvYHxN/nZ8UDaZOCp8U/57fFb+fnxZ/oF8XP6EfF/+h3xiN2ZABf6LfGc1sDiG/o98bEAF/pN8cP6WfHP+mXx2PqZ8eP6dVhT2i3x9/qLOrP6lfIT+qHyH/qtXz/6tfIw2QEOi/rF8kf60fJT+t3yX/rp8mv69fJ3+wEEU/sJ8o50KfKZ8qLELfKv+ynyuS3/+zXyy5w98tXLS/tJ8uv7VfL0/5P7ZQeL+23zEOJL+3nzI/uF8y/7kQeQ9XP7nfNH+6nzU/u02jP7vfNp83EZn/vR84P73fOP++nzm/v186Thz/wB87f8DfPA59YuKfPT/CXz3/wx8+v8POeP/EU8h/xN9Av8Wder/GH0I/xt9C0ZvM8f/H4/01q99Ev8kfRX/J30Y/yp9Gz+9/y43gP8wQSQ2ev8zfSX/Nn0o/zk7jP87fS7/PjT+fTH/QTQG/0N9NjTh/0Z9OrXrfT3/TH1A/099Q/9SfUb/VTmU/1c0H/9ZfU86djU//119VD/m/2B9WP9jQiNA/v9mfV6Zhn1h/2s6Mf9tfWf/cH1qe6r/dHynQPX/dzd8/3l9df98fXj/f07W/4E4Mf+DfYD/hn2D/4lHlP+LfYn/jn2M/5F9jwSa/5R9k/+XRx99l/+afZoSDX2ccyD/oH2g/6NwvVj7/6Z9p/+pNuP/q32t/647Ej8bBZ3/sX20/7QNkP+2fbpN1v+5fb7/vH3B/799xP/CTzT/xH3JSXMDc//Ifc7/y33RPpUzh//PfdYz8H3YMgD/1D4s/9Z93jYT/9l94jfURSb/3ZElfen/4X3sO6n/5F/UYTv/533zP+cGWf/rffgBcnWfm159/f/yfgD/9X4D//henX4HP9D//H4M//9+DzLNR2lAuQY//Jl+Fj+BMuE8ZY1zatl+HfhifiBEV0P9vXB+JTiXfic5C1d8Ohg9NjSRTPDuqzpuRIE6djJLfjM6TX41U2k/1EVDNAYHxUOYPRhrA34/lPqRxX5DQf86vHI1SrwyOe7WFhdHNvVZfk59wn5RNbF+Uz0dtIR+VzU04L4BvwdpflyR4H5fPMQzTvLr8x9+ZUiS8oV+aT9CA3R+bDKgQ+sBt+cCEMpANH507np+d0M0B+V+ejsmMeEzIUphfoBJrjND+4d+hVhPXbpBODc1OPoEq2qZs4h+jz7f/DJ+kzfzNvDI+X6YTLV+mld/fp06xAvq/h1+oklxfqRCujM2MzB+qAbcQk+UNn6uUqQ9vDihfrI8Rn60V6I14DrFNZIyQWdDO8Q0h36+N2ZaqH7CN+Q/P0wPNZg0GTTIfskFvTlsib5+zjc/QEk/pvElftTm8X7XxOptp37bFhc02TPkVqhaZn7imQA6u0dMfuZGknkMW0h+63aifu44VUepNiF+8lLPfvSRsn73PLY1RX91NYA0oH7+OBnKf38CMgI2Su5bfwc5knTBOiU5R38MNA016BPABzIDT0DWfxPj1H8WOhIybEVZO0V/G1AnR8MPjn8fMxv0Z38jNO5Eb4wHfyg0olq3X1V/LF8CPwg9CQffNlxGrhOSONJHWH/4fzg1Pi+DNuDHon8+MfxJ8TXof0IHnEVZ1i5/Rz/7TqqF539MOzp/TjVbRlY+7wF9XAh/VTftRQXcKX9aU6WG8/U1MkC60X9hRosxxDpLf2UzS39nE5I2RTKtf2ul+X9uOdt4w18uBynryn91iMRBaA5XNIxW6H97QEQ2YVbcQ30yAgWdQgk5Y3+EPHZYIDnoOhV/iTt0AWGGUH+Ob7UDRWEONrqRQEKnNcM0iFrxNK8U1X+b/+h/njWuOgA4vhLuO0fTi0RPZZV/qAVDNypSXRcKW6F/rz8Wf7EFlDt2Urc2oTIGQ5M11PqHZzxXMzQINuOzyX/AMtiLb3/ENSU1QX7Df8lD9Ft712AyZDJPN8Y6mgdONJFd0jW3OAmI3X/Yne07o4xTQKp/3TJRR3FSJuNHf+Mx8jNnBcl/5zrFcBahw3/sM0AzBortf/HfDH/0QfFDtjNjMq0z3X/6WCTjIn/+tYOAATTQNeNdRYAGQuxTkj/URNA/ToAMSMU8Tgb0gBA1QDxBd7yAFUT5QFc0jjQHV20Q9zguMdc25zcOZvyAIlAyBYmmJoAnZp+AKjPRQzNAIzeCPEyAMFNj4rKANDg7kjM+noA4oLtAiTYdPbxLxjX+TIaAQUBPNRtbL13UM+k7Ol1YWqSzrUUKTAoQhzkdNc0ReTW4R76tAYBVQsFosQwLVdGAW5eqNMU7XzVuOkk4JzxtXxB5woBmtQ2AabKRgGxmCZ3tTTVd1EUKgHI31j5NN+9tglA1XhLJPIB7BJVB45FegIA2hDa896qAhQaaPBBBl6wYgIs4n0QU0E013TPagJJQJD36Vh+All3+gJlVH4CcPSyAnvvUgKE2JjNaP9833BF4C8SAqE9tUb3TFjmwPOIx4n3tgLE/ZErdXvk2oUmCYhiAuNdgbdqAvDPVW4g6SDX0Q+iAw1PVRBQGyTCdhJaAyjmdNVM//EKcSNxFClIDWnBChjeuPBc91TSjPqafd5ziUkY99YDdO3+A4DPJgOJ3UUClQJiA5l+ggOk8Fp46N61ViIDvAkZA5jhdbdK2TT+QAWl62YD5QLE3CVtpO5ZF/YD/NO6BAUbJgQRCbFW5Q4OBCVDnU5uz74EOAuKBEHfagROowoEWQFGBGTxrT4U0BoEdSttBwjlHgSGswUUMegZJrkTYRI9DykxbQcTIjoEtOQMyoH1VgTKBeoE1NJk53TTdNv8/v0SpgT0zSoxTOk0Fk4bGgUQ/9+PbgUhnRoFKT946SBDEgU8z+Dx6Byk8kAnsgVV4qoFYMriBWjgtgVxUvpRNgWA1rz8EQKyBZFbNVguXhoFpTx2BbEGiOob4eTJLXRQ3IwGwXqsBA1FSQGg+nIF6PumG84YMpzw1jYGApFuBg9ycgYYxwYGIhLGBiz2jPWUBNEwyB5xcEjxvA3Q1YT7HOS0Bf1A3NeIy+ETvCYg5xmmUNotvBlVjP61MkDMD/K6BpxhxPP85jctgga1UL1mrrVlbJoGzO5o8/zI2OOYzDT7TWUgzukHG/KmBvz/FP6ZpPYHEBb6XhzhigchVLUnhOamBzTTgLk4zKhJPMg032DImMwg5CQ/1gdk0CgE5NcABwIHeN3ODEIHieU8Dc85Xgec4GzcJlFOB7Dw7NWwG0jndO7kz6TqWQHw1yFvsgfg9PmujNPU634Elgf+WwESYTemCBDqOOFJEHUPMeM2CC0UFO2E/LVohghFIyGsFghU0j2v1gYOCGvyRV+1Dsjk2O29H1DMhPLMHggdpW4SCJz2T1PlWSUEXOhiCLTHWNMYzyDzsAus2WETuhJWCN0GENpk2okUFOFA09TIHOBf3rIJCi3uCRQlbOA5wuYJKWXJDODRHq76CUGJfglLd5YJVMyfQtPiAglo5EvbBgl42hkVgRHZat1WDuLoJiE9ZWwdGCQ/1NeiCa0b/SY9dK3ChgnFJFzgJE5I1/YJ2Pe0+UQ/kPKM+76jcr8KCf7MngoJXPIKFkjOChxHqc6c426jNgo1t8Oe5OXR8NTKoTEE94DZiVdo0/0BcD+NAXDhUb8iCnjJeN72CoU4PQSY0WoKmQak0ykHKPIJWemdpO3NK0zO3NNmCsTSQOV9XM03WPeE6sTzlgrk1gbBLgr04NUP6RYeCwkfePlE6oYf6gsg6gRUpRbCCzW3wgs8Ev4LRPIw1NksuUs80wjKc5UqC2j2igt1ChhA4AncxxgJpn+WC5VU+QRJd0jYJEws4kjols5+C72YJTArwgTO4Zvg7qQEHgvcKW4L5X8BBuzO0McWShoMAPYtId1XDgwUDV0xaOvgXojWlVElENTPMOL4MqjfjjLyDEzOTgxUyJJRqgxkBqzcJOBjoLTVWskdFXjstgaiDJEABM3ZfwTbfQiVDDTYTTApJSoMuEOaDMTaYNsMCTj4x+SWDOFbNhUg2bGjGO8SDPzh/q4qDQ0pNZ3qDRwQhg0pXaloPg01qA0Y1iE02BlI+O6MG32oD4oSDWExeTutiHYNdPBcx22MiQAhYGEecO2LOW4NnNJxbykhANDpRDDgtNv1pqWDcSzg90TWANNwhCjDWUMBcVIN6bPRvCIN+l5mDgUrkOZw0jTY2QKBkPjhegKODi30Eg45vCzh7FGIyh4OTF7ODlh+pS0Qy64ObBpZhwli2SAdE/zHXODVCrtUXg6ZKq4OoQJinXYOsgGg3EDS2YDaDsjYIN7tDyY5/g7g12mqTTdY6oZKPUCQ6jDWrg8Ea6VAzONE8dUFMMO47kTSxekqDzDuUP/tjPTsvTAyekIPUTKWD11E7T0iD2zMYNvRfl21h9y6D4jIB792D5gG/RAGD6T1pOhM2OTLmOtY3AjK3NMVCLYP0PQ6D9qAyXUsyClAy2xWD/QEpMf9D7TybPhuEBDJGQMAx7jYVOsQQp0JdM1pQ/4QOSTl3EIQRQPZ6eIQVOSyEGDjgLRgyHD05Gj2EHgEyRpKEITX9B0k1VYQlko42TksUTDhZ6IFOhC1V5TgGUf45it30N6eENDpUhDZcskRWT9k52IQ8Y/C2RIRAQc2EQ3uRhEZBFxCn6QcB6Q/0Uhn4joRPQARcRTT/QUyEVEuJS78zJj9JP94+NzgQRDU1o4gMhGAP5DHwAkVR64RmM3ZN6jJSRP9U91ImlNKEb03qhHI3Z+Du6eChJkDMhHpFJVZpNbtPPscfhIG5GYSEOkwG6zkEN8iEikCm8yg3CptfhJBUMTyPOQUuBYSWQcYzYzzJVgGEnDcoZjo1Rjw6Q9g17wlVPDZq7jgMMcVfLjMmc36ErEl3ZD4yszqDETk82c+aB5w8SHd7AWnXYIS5Pq2Euz9OhL04+zn/hMBmb5RohMTXs3johMhBOzLYPrU0IJ17hM9y8ITSN4JSmQNWA7wx+DZgRG/9ooTcMw8EpjI3O+422DIENspJj0D+Tq6E6DhGhOoBebFlhO4HnYTwTdHn3oT14cVwVoT5Ao6E+0naPeFZn4UAPAWFAnw1hQWKloKlhQk0mEO/Z4M6eTc+Mc1MPDb3n0iFFFftNvc2zgFylHtNF4UcNywBhUq8MrGFIXrPhSQ9U0H2RVqD1oUq/Q6FLXaphTBPbUPMPNlA/Do0SdxF1DwBYe1GOGBlhT01cDJmizaFQjwgMjU1HDU8RYeFSVUzhUs9vHHmhU9ni4VSb+qFVT8VhVc9LDcMhVo/gfElhV43j4VgMwgxvjQUMw4RizSRTx9B2j3wV1gHKTMNYJ4+H1COVUg+x4odN+UYcTdBURk5CDwSOq5hzDHEOZ5g3Dhm5fOFgTfiO5E9yjxBPgxERBEHSyQ22zOT/BuFjkudUQABWT18SY8/FTpfTNY2z0aFhZk2OTmOOXYRe0RASRIIaIWhdxDTLYWlNis2q0EXc/YCMz+Oqi00LkVAprM7+YWyNbuBTYW2Oo22wTSmRJx65oW9PvOFwGJvO8Mz+DfpYaE5IjSdOWABCGM9R9RCHoXP1QA4VFU5NdRAqoXWAZw4cD7qREOF2zYVSuQBJpYgOA6F4V3UL5o1rqPyhedBOV09OeQ5EjhaQIWCwZDJhfGiNYX0RJk2WD2YPP9t8DlmPYAQuTwYAmlDlj4hBcMBLjsAR04/vzhnQHberYYKkNGGDTQWOccvm8/dhhNKYHWXhhcR6gN1Ab81XTsYROGGHlz6hiEGQTabPCA+SzzZ9z6GKUJgSzlEOAdHVbgOwEQEX6ECVWg4OdE1CzlShjcPVzUjPmoBE4Y8SzJPZDazhkAzVkGcQzGGRUVYhkg9SjewBeDXh4ZONr9U0IZSO9xEcWVNhldKS5yfhlo5j4ZcVkA+3zJtPpV5ZGQpvU6GZTXKNvmC3D+tNstV50cfBcNDDTvOX+tCpFo9YN2GdTbFOvo1dDzdhno3FDyNBwhfIThrRISeHIaDQI84wjoIhocBvkpwMdc96IaNp4mGkEtjQVO5g4aVM246f/uAQFLjvYacXbmGnjwHhqBDnYaiin2GpTsIUiI/c5+MO0cC4oasB8WDmk7WM1Y45QJLQ8oFClbNB2c6OUMZD4+AkTyzaJAzKDihQBON+4bCN62mzIbGTAs91ESrhspBJne1Weg25IbQTuBIIYbUOsc8jUncNvsxqzwGaHSG3Hinht802obhNB45YDhrCXFHnDSJN5kHZy0iTNYz9zrlOxtFWkRqNgt1ZDqObsE1pjWTTBey5j2cR8A3M0feimEyNjpMMr9s9FXa/UqHBjbOPMKHCTKchwtBQYcOTak3oblIhxNc8IcWWJE2XjuRas82mYhKRP87kYcfXOaHIuOwRZ58B4cnA3MyQIdiQUZoHAMPPBZI0z5NO0dMOPP2QfY4Uoc3ileHOmD4hz1MOBDdNt+HQUBJmv2HRQ+GVouHSTONNxRU3zL3NcE0sji/SNdAE2ewh1U1XIdXNFYMKUblh1u90svQX42HYG7uh2I2yJ/jh2Y3uw+IM907WkYuOR9CWTsdP/w82TdLTYZhEDiTN1AzIIlph3k0nId7NMs9UzuZO8pBSk/MOM3Gt4eFTnuHiFxsQod5boeNyhEGr3ikh5E2t4eTO5aHlUEXOQl7Knkmh5sGfkKBBZ1ZvDNK9H859v28NRSK4kvyNgLGKYeqRDU+yUGER0oyNzhIrJGHs2auMihFzW0naiuHuqVEh73oEIfASQM4sete+zGHxkJgh8hV7UG+h8w9gzIEN343jWeMWmM1JT1CMtDKKYfYN5UzbkGVNtRWzYR3h+AzOjsmh+OSn4fmAbdy0vhIh+uFXYfuQAHvE4fyQbhDNEMHNsYy3Jsuh/o/0DaDOQ5CMof/OFc35zorM6lbtU1QiAZ794gJR04zNlmNiA5D/DMca6GIEjHDQAE20zctQB2IGTVgB3FBmEGkiB86+juVT7xJ+RhxNc44p3YsTvGIKTHFVe8BIktEZteIMDmFQeQ0NhDlMwZK1Yg3P+SIOeL4Vfc2uufHiD9S6jegWt6IRDjbRHEzZKiHiEp2LDfFiE41k0tSNeA6tUVebeBWcYhWVow684a/iFtICQJ1QcZNtohgRSk0wUdMRkDb1EIyRoU+3YhqVWOFkYhuXyGIcDPpNzlSZjhkCK00Doh3cibtt4h79JiIfnMQiIFDAQYGQXRtaJ3oP64+6JldVpKgiIiNX/mIkFY/duCIlESTiJc5SvMaiJuIp1fbNk+GFYihNU465zXUoiqIp0pNSwpd1GcgiK05XoivRHNDFkmpN/mItDnLB4UHw4i4MuMz4GHQPw8FZIi/BTc77jpRUcZHJbGYiMg7ygJ5OC5vKjf4PfiIzzNHPQ5jvjsFNpWr/YjYOf4E6jjGAiQ9PQE5iN87Bw8/Oeh5z4jlYkRGKTVFARBRDY+kiO1cczkGPjMvxjSyNuo2yYJCB787UgUDiPk2L0NiT7iI/j3LRjtTjIkCPTz5OXR1iQcIZgFakb+3GEncN+KJDzNBO9xCHTRTnjeJFsnfRic2RAFxOow+fmshO0KamYkhD9Y3gYHuiSZoNIkp5OmJLF09SuOzPYkxMmwykbubiTZImkEdNxBesDYJiTxDv4k/sRuJQls3iUVT9TgtR5RGj4lKXwOMY4lOaAeJUUDDiVM3AolVUgN9vUavPcteEjoUVuBB/I8/DkPRy4liOSk4rO6+iWdRAPSYiWtWj0P8MkOJbzwQVdyJcgEiBr01FjI/RSQ9fgOyA9pRQDYnQvCJfj1FQRxsyomDPclKmUI2NY9MMomKOPZFaVEZXpGJkDSdiZJE3TJsW26JlsnfBDl+vTTqAutLsWDtu+SJoMlwiaM6GDNKEOZT9A5XctriSYmsYhiJrjg6SNw2bDVjibMzZEDRUUmJuLll7FGJvDWuYmGJwDrrATw7aonEPE43Pj+xcnY3ujcrSCoznonNSc444QW/ik+J00kDYYdmionYARI1+joCM6I7uTjmZlOJ4UTuT7xGxgZ0OfpKEjv+MwhN6bcEie3cTYnwVDmJ85MkifZP2TQWq+CJ+5bGMpBDankRRQk6djzdU0CKBZEHigg684v5igxQoIoPRJ6KEToUOrs3VjMJRdFCuEEzNrA4qUX0bD6KHjObTNY7vDfrVYM0/zjVOtRO1lgkoMCKK0FLP1U8Sjg7ijFCNDunSco6YTp2C+g+10qDNn9Nam4Pij5CkIjUZNpq7gWcP6BLS//zikgFvzifN5gS7nlkRLc8c0EUNjJoUIpUQpD4h4pYnoCKWztldZ9S9IpgimJK1UmMMdU0uF0UbRiKajeiOh9lizcPM7s68nJMinOC3DYMTamKdzvnPeE1HFaqin00TDofs/OKgnESNrZJkD09ENRK1QGiM/dDnYs9io5Bi4qRO8E0oYqUlV43dUIEMvEx14qaOIZEBj+Sip80MYqhdIUDfoqkM0OWPoqoZcg9qD+tRgk+HYquB78z+ZUsirQ6NzTvR8KVSj21msOKvLTzir81UAe/NkBv+YrFOmo0rFX3NzxRQJrDyJQ2UVm5itDsO4rTOpFPajcdSXdEFYraNoaK3DYrDy6K4Arf6gOK5KGJRFY2horoYnKK60DjUjWK70syNkU0sE0nV3eK9jDhPno5sE5oivwDTw5XNrsBSTheUVI4cFhFiwaLCFPQiws/JG0//Qsy/jKppx6LE4sVQf88t1VwNlg9nEO7ASmppYsf92eLIl7QQFpBYjYliyh+QTV3DCs4NTfkNCSLMEpcgIiLNDMTOUlCWYbPOeQTwAcyizw/lj+/OHsFFmLqMlVeETQEi0U0+g+OT0xNKotLZBBLJDU1NlxaiEtBPvKLU4tZi1YzCItUi1oVKTsHPrsyAmdFi2Hyn4tkNkRHDDXui2hHpAJkr8o6HzVnQTNTujKgPtxHcS3EZyvp3Yt3O0p/F4t7Mk6LfQkQTz8yHz70MypIekEUi4U/dUF2i4lZBTg1YhhskMsLi5ACW4swi5RFQDP0Nng5bTQjOZ42xjSmNwlJaT8mNM5HE4ujPA0HKQG+PTlBfDwgAuCLqxhxASKLrjNLNrKSjYuzOKk4EDh7OOJBS0QhXXQ7Vk95i744RovAQV054EkojqqLxjXBAUsORDVhNmgyQUOdqWRF1UMqNIrAUovUSByL10JgR5cNc0xHQscBBHQFTZg+rD6mi+JBFz4oVN6L50aFPQ6L6oGNi+3CbYvwSU+Pkov0OV8BhUqdNrIzODcTT1tIQzn9PiSL/zRHjAEx355vMws2sg9X7FCMCTYnMqw7GzKgphqMEDX9NbhEKkjuUDU0NHOnPLqLFF10PvP0zwjeO0pAXDJDSkYzUkb/QEI0FDb9NTxO8Q9XUa2MLEtRRf5abnsqNpSMMj6ANglIKkSyQoqndYw6QyrwuY/MjEBWfIxDAb+MRTqSjEj8p4xLBtI8tYxOQdNCpT/7O0KMVDHoPG9KtzNLm0KMWzlUPPZUBDYEjGA2bmTaL39HxYxlOmpObYxpBR2Fq/sHjG7zjYxxNZJd3Ix1QliMd0nCjHq28Ix9PqxCP4yBS203rzwuNRtDu4yHOCoHqU1JQoFB6TMRNA2MjzXxjJEHKUBCVWeMlkX4OhEOQzvBR2F/cYyePfAxyjxzOks0KJFHjKYzsET5jKlEBDXOPShtYTWlSdiMsDgQa8wy5jIhA6xQ6z+CA0lAjJKiyB6MvWbSScKMwQlIQIA2uzXi1m6MyDLrATgGsozMNkBAVDdnMjM53DYyT3857Fhnd4pT5niAjNo4WQpbNU7JjYzgkieM4zyOjOVM0VDVjOk2wS+6RGaM7jfUNpQK3jIXA1Zj8D/iN2lSjwdpQSZsdecLjP1jDI0ARv9HlWp7by62V40HBY+NCgEcO6E+zTACQO09i0nnPCI4Bz7ROhVNgI0YQVE2bDoT0xmNHkU0S7Q24jU8SNONJFP1XxA/H0bSUGk8ujYCa5dzeVbNTqo8tUt9S7I+yY00ShKNNj7jOyTYGI07P3U/MUwM0jiNQU2GPS3mk41GQJA44ktjSnBFAlbuOPpBPzTUENEFHVT1OFKNVU8QjVhDDEGYSVVITY1eL7oyDD7JToE/umfYT9meeY1oiQKpzY1sC+iiQ41wUKI92o10XwKNdn1xOKpAao17Mmo5Wjx0VhI/0LgujYNj4Y2G+H+NiTXARzJ3ijK8WLGNkDqFcnYFvWBLjZasso2ZSpk5QkFTjZ5YxVsvVJ9dmo2kDeo5L2z0R8M5e42qNr9baTm7MjEQRzihVhY8O28WjbVHakYqN39POT5tOMgPhjWDM4Br9UcfewGNw0X9P25SXQ9Xjcg4wD/xhzFoWjYfNlQ0MTujOAY2z43TOZj5wo3XBb+N2UVZN9xvP43eTWdIUzMpQ7aPSY3lMgg0CUjtOItyNWaXje2sTwJVNpF8Lo3zMfJkbAcRSbCN+YbAjfxCYDL3VsiOAUUeq/+OBWXWZTE9XEFiCltzTjwBWkuODzm6PaFvcI4UOAxJGY4YQNo5ZjP9U8GOHkGEWSw3dT/mkYaOJS0iD/QzCD+rQaI1zoYMA0sBq44vamqOMkBfjjQ79TNkOVRroTpHTqc0TzG9OkRAVl1YjkBBgDTXjkSqpY5HVYmOSmJfQeg1a1BCPEzrxI5SOeg6ji/TSNRMW45YORJtWDmEMkmEEzhiRRT4ZI5iOhU1cJRsNspPAzpEb+ZApkC5YDJKEjWRT640mUnVNzc0rE6NTQ46ITS6MhdOn2FgjnxUMVBqjoCEg46DO7+OhXwXjoh4Uzw7jguOjTI1QrQ27TIAQ0JOqpoujpZBOVYwbgwyTUKBNWtXv46fAig4rjbGjqM3qY6lhBcQDwc+NbpEJouwjq05dj7Hf+eOsgETSENVV3evRpgzQDgpNWc/ym6WPqwIaDSmjsA/8VyLjsQzzToSS79Q2Y7KQoxDK47O6VE1Dzd8RMBLHFCAjtUJSNoLjtkCLjNjPpFahgb4jt9PWznHOAgz4EQdMtk4OqsoOGSs4Y7rAQJCvjOdVMUzKY7xMegyXziBjvU1sFdtOIkG4Vo0jvuP2Tb/N05k2u0ZD/QymTzPAS46hVG8jwe7wT9kgY6PDIAxjw8ydHKpjxOcn6yhSPdNko8ZNb5ffjzDAUiPHjl6jyBLaHynpOKPJTbnOhNYMGNoTFVoWsZwOFQ/8EBuec4CWDo0M6M2iQ7A6LCPODI5NUpDnTphjz1hJo9ANMg+po9DSqttlY9HlCCPSkBST4ZlTI9PC2yBjY9TRi5SGTSSNkViGI9ZEAUzmEI2+Agvulhqu4CPYnstTIQ9L49nkUSPakqdNNky+kW+CGY4F49xTfmPdB+pSljoiTkFQ5M5no97PC4MKnwBj4BIaPCfgpuPhTuRfKfyJo+KaXRhf02Xj44BSjx8Qh0z5j4Kf8KPlgEKNiZADFWAR2pICzYlj59Su4+hPttByg9hNRePp/wbkrxASY+Bj607rDhVN9hR0TSaNC86FY+1M945Ljl/ZYtFOHTtj701rhE5SAVSj4/CSp2PxHbVNStG5I/IUA6Py0Ynj82QMY/QEA9GRzzZM57f5NtDj9iP2pK8gueP3jcdPic6yjakaD+P5bOBMhQx7jUyRmJcbMT6j+7h+TH8BZM3Ij/J8OaP9jJTj/iNc110EQdA9TIQAieP/8ankAIynEzNQdqQBpNfkAlLXzvQN8a6xplFNNRjmztZSF2QFD1lP542S0ccRE87P1oPNKM2yjHjNqk6bT+3ETlcYpAlVec74DbFQQk2kUn5NMcwkyIYOEYx4wcBRGo6mj5qOAuUe5A3lp4GoZA7O4w3NFLqaFGQQYwZkEQHnMdAkEgzzrhukEw0spBOOfZHajV2QUQ7bzUO6BBKg5BwM7mIQlldkFxGQIRrkGAykTKyOHVHNmHtP38zJzm4MzlHClwAkG1Y5TV5Bn41DDP+TYk7kGelkHdrOLGQN3FCLQW9NpI9SqcgOxIGr5CD3GtEJDpJY5tDkmTT0yOQjI8XbZ4P/HKCkJIPL5CUP45aHpCYNSVPLlbuOctJvJCeYbU3cQgl8OuQpEBxQgOQp0PLQPBObVqNM9k6InVBMkVxHpCyRmdA5lwyRmI5mkd0PYE7vDZrAYA++ZC+QVOQwU3CAiU1WJDFc0WQyDICW3tPyFJxQvQBHJDPP9CQ0jXeNVOQ1Ue+NpIz4JDZQjI8FTU9jZ0y6YXVOEgy3EVUkOTluJDnSFNX6D1pS5g4OmzHoIiQ8DUUUYo4CUUaAXhQo0+qNSO8QG8C9Azec5D+OAxM50H3M/E4dG3TkQU3PucfkQk+tTaWZmVConkLkRBHET74MehQ5ztvM6E5njM7/+yRGwS6ONJVGGujXkiRIk8akSVT9T7cMcXmtpErR8dwzDk1YqqRMIqe8sRDQ2SKkTZPUD/rkTkBsAWSkTxV1pE/cLWRQj3+cI5P2DmqNlEzQzwX/TGRTLrIkU8z5GXNWWhS6j0gM405bHHEkVl3uj5qE01Gv2udBR28I5FiOaNp0kzNbdNInNvekWpOnTTdPfWNrJFwPh01zo8vkXVs/EeXSGORemjiN8k1YTc0kX85qpGCOfY8FTaQPBg6szlySXfippGMTNRAHoOOkZE4LtYCkZUyR0+86hORmuxSkZ0v0zkzRO2sU5GjODBHw5GmQTg2szgjTutbopGsS/U6SmwykbF2DJG0O0WRtmLGQu5HBlPpOXo2ljWIBJyRwN5yNvduj5HFP56d7QLrNwg4xJ71kc1CdwLlNM1E2Jk2kdQBD5HWveiR2UuTDlY6E1lvkd801Fu5PpHTyJHlNZX8p5HpT79DE1X3W2k85TgtO2KR8TpIgdibD5H222GR+ZH7506R/kPpPUaSATZ5VGEGnhD1NjuSB0NlO8EBSJILobYCLkLCOZOSEXFmkhQz5lZhSZU2bTfoOSdKwDSrWrv5u5IgNOwzoYeCR59AFZInOJe165IrEws2ZTU4OJDrOETxNZOSND3Rkjc8dTyzN8cCKJI8V9th0FJxkkA44c0HM2cyaJyfNVM9sDjkQllJCTZRTQE+f1TWUvYzHJJRQm1lXHDjayIU1s0NRjU8G0JsO8w7jDI5RU9AbzU6S0E2IGObgy+2NpJnPLqwYFIiRo+4mUt/SFMy4AJFVMmSczeIknV0PG8tknk6t92Ykn021TqJeMNBDzkRMd87v5KFib6SiJimkou9WpKOPCQ7AGoDPeQ7ljhyP9lEIJKYNmsz3+Zwkp05d01WSPc15ZKiM5hN95KmR+EQHJKpVKiSrH9akq9uBDZuB9FACDTDsiFzvJK4ak+Su5K9NihTADUyksE5dDHEC7pN25LHTNY52MdtksxUjGCkOAdSAzTtkvKS1GTVktZJ2DvPMlKP2THqdQ5DmAFukuA1cG42OluS5ELaPnM93hNNQS2KyJLsk0JPIZNEOvk4F1GQSMmTSgNJOnQz+m2Ckvo49jxvAj46IjNEMew3rdNxkwRbiEMTSG9b2ZMJVsc7B1S4kw5CT5MRCUgBHTegBn42+0GRTJBB/D34dseTHUGANTQybkOdqbKTJBNNbv2TKFqbk0mTLF/FPuozKDnYkzEyP0gHOdcC0pPxWvCTOZNYkzxbBzI/kz895JNck0MHDDr5k0aUOpNJkvVA5zI/k1KTT2A/k02TUwJ1q9KTV5M7k1pRGpNdOvkyPzgHOwe8oZNjPk2TZZ18k2hGWD6OWoYQZAUcNEw3gWdw00CTczdEN2I+u/vEBteTel+bBOqTfkyDuyZ11chWddA0WpOFq6U0QJOIYshHhpObk45iC5ORMvBLluXlBgAtGH18k5kzjToPk5xe9ZOfbPQ2IDSjSAU9gevGk6dIX5OqeaWTrdBaMzk7yDbKC/dROVr2O784zZO3PiYS05O7MsQy5zPdUnKTwAGvUdqTxBINagPpu5PJnDY36myCliPcE5Pik9GUs5PUPd6T1md8OS56wZPbSZUtxEM0pzrcE5Pi3qSUszm7UP8BG0CJN+hT9F8hP6M0xJPuW2GT8Mkbk/NhiZL0bx01M5P4lHs0yR+pXL+T/kb4roCUAjVbPp456mz8N3yduZQKbMYCjktmlA/dOpQSk0eUFT0TlCqUGUN3QpyUHIGGDKkP04TalCI8FJQkWe6UOQFHQEQ/dZQYlCxLX5QuPBSUJJQxOg5EO5LplDaUS5Q5lQSUT5Q+lFiUQZRbN2eUWExhPMSUQ0/QlDiTR5TrlD2UUZRYPLCET5RDlFY3Z5RYlEGUWzMpSppE8TmSSoOUYUVeO5JEKDJgcpJ3qjV6R6SUaknklG0+lW7wlHEzO5HgT1SUdgY+NlhHHLzqNO479TsJmVKUgYViMhI1VFpEa/VPzJSJS0E9PjcPlI1xtJSQXBwR6j3wkfo1zkRxPBVA/Dv7ObgzJ00blJ43zpSgVH+Uoz1OT4NpBlm8N/I+BEtKQ5Z4TZSuOguU2GRflLI8gpTVS8OUt9K5lLrtiZS9Pf5YhjcpaDiU25TEuuSUxwKOlQOUy0k9lLpRRTZVlOSU0lPvPIKU1UHkSY87vzP9lNqUw5TdXqtqmWbfOGwzZ5TQlOVJj5TnN3GVA5TrmQGU7nFjlPFOgJUBlPaVBPTflO2U+2IIlP49lGE7OkyVApT3ST2VBkeVBymVCTUzRRo0opUNVlc8s5UQ2L2VnpUUgXiWWpXwMcGVpJUclgc4DDHbbZnaOpUkO85hH0rqlSmVHJUslytly5WOlTOVfpU29XSVOQaUOI5bYa9ElT+VcLYmlXI8ujvvlbA7UkuIlWuVTIgMlU9tsJVSWBiVVEDDlXyVWJcrlZ6VFIF4llqVqJVi1TIFnDI+la6VRpVpS4iVazbSlT6Vb5VBtiaVcn0E86uVdj7JO85hH5V6QMOVfJVYlyuVnpUUlYOVl1bglZmITTSZlZxjvzK4lY6VM5V+lyuVnpUUlYOVl1bglZmITTSZlZxjv5WBlaCWWpXwMcGVpJUclgc4DJVhlao73AWcMj6VrpVGlWmVsjNWlbSIL5XDCGiVxZW7MzKVvWo6lcA3PIgvlcMIaJXFlUSVyAO8NOqVzJ4Ilc82yQIlWPmV0zhkS7RRuJPHljSV2paDlZKV7JNEll+Wb5XnllSV6jE/lleV7pWhlfCWXJaGll6WbpYIlnCWZJYMlkyWZ5YYlmqWM5Y7eZOWB5X2lnCWZJYMlkxfVJYQlGiWE09alk2WepYAlnyWipYwQESWjZYiOPyWg5WSlleWiEn5ln2Wi0BElo2WNZZIlSyXK2XLljsPYZaDlj+WUj6wllSV6jE/leyTRJZfmBCWc5aDlj+WUj6wllSV6jE/lleV7pWhlfCWXJaGll6WbpYIlnCWZJYMlkyWZ5ZYlhmXPpY7lkiWB5X2lnCWZJYMlkxfVJZ0NXqWE09alk2WepYrlnyWipYwQESWjZYiOPyWg5WSlleWiEn5ln2Wi0BElo1tYZaPlSw6/5aSaYxm1wEilpY08KBqOUmWmk2JlpwzsDV3TbUQHpail2WX85ZrlwmXKkkaOtXsqJcPlrFd1DYhO3SXFQUclx2XiZdLNZGW+Zd5Nuc0P0X+lv2WxZcAPN5JUzTIl0GWq5bNne1PJJcul6E3q5bVluuW2JbultudrpblOVWYH5biluRRO5bmlsCW6ZbWluyW2ZbvP9mXTJb5l3mYID/ZlviWvpd5Nuc0P0X+lv2WxZcAm72XOZcElzyXB5c/lqmXC5asl0SWr5cQl0iXEzKHlxUFHJcdl7uXGpcVlxyWuJe7ODeXIENWlyKF1U6fZjqU8jXlT9SXKpbNne1PJJcul6E3q5cyT2SXWpc2P32WoZc6lwWYL5cJlypJGpdElq+XEJdIlxOXS5bylr6XiJfPl1KW+ZeIlroBcd9Gl2uXWw9hl10yuJdfNKaXYZcHvTE+65dlio6XMJdpYLFPZJdalzaXbpcDTs+XLpdnl3QCJJd2UBxPSJgfO0A7oTLbUGkyLgFIOXs6WzTzTamXy5fjl4iXz5fLl+OXiJa6l5A5KfNol5Q8GGdp2fCYMJeul2GXBzQ0mC2XZpcwOQs13pgol6YyrZgsmBKXqpfzlmuX8ZgySRqYNDWLl7MGNzXil4SXzJe6lxmYAJe/XYyXwjIUuoM1ylDFl8c6bkhAmCGXuJfNl4mX0JgBl9OYBJfWN7qjmZfal/qX3Ze/OtmX4JeKl7gyYJd5l+VmCU/YQlgFyIFqmDCXrjQxl/OWa5fxNDGX85gVl/aITZf4mBmX3Ze/mAI/Tpf/l/uXv5gCP06X1JgFOyeYCBHtl5cMU1jFTyQIJ5dylkuYETncl6qX85gVl/aITTSdl/m07QfEOm9Jj1AcT0iYH5fKmCKXzZglPYuXpJgpOkwyrZgsmBKXqpfzlmuX8ZgySRqYNDWLmDYGN5g4PuPYFNgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE9gQ2BPYENgT2BDYE5hnmJgyTjf8bOI+rzcRNkg0uZigL5qYojMQBZQz4JimPlhL1DguNktZLkUa4jWYrwXINMmYszE/mLU7wJi4MoeYulZINieYvTir96diCzMTCCXYCdgC1/7YAtf+2ALX/tgC1/5ONZje9jOY4TgxmOMzrWgNYuplcJjpXt+Y7EPKPlKVVZjxS3IHdT4hybGY90zBbfDIqZj8Bvw+HVP/mQE0ZZkEPJqZBjVvTHfYFNgTmFCZDeL9mRA5H07WmRNWCzflNkUGWZkYb7VRRzSImRwyRZkeP4KE6p/JcBY41U5iNCI87zgLX5ID9UjTURE1d5ktEeo+rTYXmTFENzfoEYuR0pk3Myo2QWGJVqg50jI7B2pSz5lAT4M8OW4QZNpDYjZAVAD31ZlKYY15VUFVPHtE+XmlmVJbfkYJsxqZV+oZmVoHEkwLmV2B9JlgNadMrzlHM+QDfplmqv+ZaZlrynaZbj0dYQKZckHDPYGZdUHPNiWZeZl7Mm9apIMhN9dG5A5WmYI8P5mEBZSZhktyAZ0P5D/RWwyZjWhmU1uZkTKXOK7w8joLoKCZmF8hMFwBonsqVtk1gc44maE98FASRjM9/AGu/4uZqVsPC7pImmLICQdHq07ePG83JDdEQ/BjA5m3SqeZul8VnVWZv1khNxAzVjYuRLnazpnHaXY0rxAJP+o5RZnOBfU2F1EMMxYv2Z16mdZEFDx1CXCy8pncAtJBnZnfOhQ5R3TTVb6Z5TZmwrFQ53MOPaJvHJntedRbDz3dPOcCjkLpmfWHeZn4NAaZ+jACMwNBL5n/Q/A/QhNNN7dQvJoFR6E/fZoIARQ0JDctOqgzaDqfNn9C8DljmhI6SD6wmhU+HD6cmhg5P+51OR+bzriAmh87fY3FmiM95Dg+Mb39LzJNOZ5FDF+VVhE3uznaN9c6Mjkd9seaNLX9mjdA0TnGM+JWoDo5O0VAE7wPmkEy60avRuM2a2KDlIg+NAwLSzOaTDYyUmVDzE93mlI7MEELRMBVY1QDmllVM0VRM9E9mVbNN86xMZpindmaZUD+QQuaaTcOUeGabThk/AiacTjhh/qadQIkNQ9olDiNWx03Q21hO1ZboksKUgMxs2z8YYkH2Ta2MlEx2ElTaDiaijaGmoxE70q8PiWTmTYNau4zqzQPMrxT5jhrOPs260maeHI9ipqeM8NZLEKjNNFCp0Rsxq6ap06KQqEyXZqrOGg2ujSeNVWasEOVmrM6H5q1VN8xwzisNtQ/izOwmrw60zZ1MwszPprBMC41JJrFBZQ+eprIPtE4V1AISB47vzsK4ug2mzbEWo1Cem5BjgKa1zdQSLY9I5rcTemp5prgMvA0TDQomuRNdUtcddCfFJrqCCdTnAgn9yya8D+1bsma9O0umvc8+zVSSMlJ6Zr9Yhg5OjUtM0Ov4ZsEOhs7jEQEawY3bFH+PedURkbqRgk2Cjg1mxEzZDklmxQEueKpmxg06/OFW9D9BpsePwg+1wEDS6s+d0UETmJLqzPINW2bKkXyMxE8yQScGBFQNZn2mzNJPWiUOjYGr5s4PO61RaV1mz4BEjsAgD6bQ/hcm0Y15EHjWvlXEJtMBBs/5nm+OAxoZptSQsSXTlTfBnGbWDl7R+E8Rk1nS5abXjabQ8FEO0JsBLoFRTv1mtqbaFaPAnc45WNlOUFBCnVPARVhh0wKT21EC1JmOjFKnQIlj5UzzDi5OhWbfb00m4BlbJuCNDGbhDvEQJg7yDZRb4dBLTeaATlFXjlmm49QEjH8BftiNjYaOZQxwkCdY2UH2T5qm5sCRgavNC4/yAdqPiVq1ZukTz9JqUqrQ7ObqjPbUmY2AzVOQsQ+r0auVhEKhRD3PTYK3zaTP7pBSDpKQcJacDnYO+AGPz+VBb81fWNbO86bxTaoP6tQ52dKm8tFmDoxNmxGXjM9NZab0gE8m9Q7NjmsP6ZYhjVTm9o+1jI/m90/HALlaWmb4jMGbeDdXBAjOVeb6Ddum+rYCZvtNB7Zf5vxNfqb84gvAuJKgy3gNJ+b+mUPm/23DJwAGBFEC16wW5cQZDrF0jucCTNgNCI3G1einA6nXZwRQ5ik4ZwVk0ecGDRlMq05xj2OnB6989f9vk2cJDWROSycJ+rwPNp325wsOFI0J5wvGumcMTPUqU2cNQV6Bj2TQj/7LcRABHe4nD4CMzz7a5acQ1asnEY70EQBnEkXCjncP/U0pUpfPGVGOA5FMsgDV5xUxOcQh06KVymcWjhVTopT+ZxfSk4zCEttMxmWoJxmUZs4a0fDNNA+fWNoL9lm30mMMuo+4zVWPgRK9Jx1NZg4wzidMt2npZx8WEg0pmEUnIE/BM1xnIU8tTHWnIg0nTcAPfWcjMg7nI+ckTc5XqaclNoGnJdt35yaOrg/VzvKQKWcoETCMjoyxJykOXh1B5yosg+cqz80Mrg9JPgrnLEFN0GZaBxfIpy3Q1hHPJBJnLyIfZy/GukDxLhtnMRSSUX/St0EiTSdVfGczEUkNkQ5jzJCMz+c0k0daYGc1k9bOrZR+wWdQQ8E7ZzdWhmc4JD6nONI+ZzmXz6c6TWLPxWpZJzugwOc8QRBnPM8wkufnPdvYA8GlDWc/HImnP5xOJ0BSVMxP50ETFWodZ0IMfCCY50M6tCdDzI8Q500jDvtQLY9BjzJMd6LkJ0aQc4wAp0drZadIEGrx4idJDbGVGjo450pOolcKEglQQeoMJ0wO5U63zSIS1CdNTH/86mdOXiwRr8Haj60o2SdQIZERMhroz6hM00tJ0zsbc+dSjjROxs35jYjnU8y4zzmOxKdUzQ5ZOOdVi3gs/mdWkMdOokzJlcrN2FJzkBYh82dZAazXtvIZJ3BnWpO/Z1sMgadbgJNPAkx2EWYA6xBHgdpNTSfEGfCnXqZ1jbiO500+jbUNLLkrZ2EOpIHKReiBJveSJ2LOHNTg0x3Nxwt4DlbiT4SYgjeNn85akClSIoxvzUlQQlhz2iUQoE+WA2Qlcsyj0BfPos6V0uIMsNLUKWr5z6drDP6+akGdDbKNsYzk1dYldGdtkUpNUwzRLLanbylUZ2/MykCzDr5PpFCWT2kouM1qjwsPx8/NTWWP/A2ocaYWo1SSp3Repmd1EK0N+ICNEhKUj420UQUBcmd3XsqXtM8eTpHARSd46p1neY4Uk6xOc+d6jVeSQOd7hCnEAyKc53zobud9lwSZCcyYDHuO+6d/HsWnf80BDybWHOeBG1iRDhT3z+O1GKeC9ocng5sOZ4RAVwy67fCnhY6epZRCfwMn0naBDk1cAETVu4CNp4hY0tgInOUniY1To4cOvM7JtWoni1DYoKLnjE9sE8ZVlM4MnzbSAc9HZ45njtBhBAPNC7t8gLrTwhIEp5Dr5meRkiMOMyeSQ+ORO8z6rYmSO47akFLVXg8dVH7RHM6SHnXNpb9ap5aPJBGFjw7PnQ5jryonmI5M2bvnmaD6xA1Rjg+0RArPbldwTirCNw9vGB/N7g5T0rAkuCedzLjQ50P7557PP3+rZ5/cBY03TbzbZmehEBlnoZI0w/16/iei0xGno0933bGnpE24DVMNLU2m0kxAVpDDTtzWtg5QTq3ZX2enzj1NRwzmDZkAVpRt1IiOfaeqAYGNWeeq80Hnq462E1inrIE2j252JqetzlKPks5fzWqOj1Ou56/hAQ2sJG/XBxJ+UerM0xAw57ISZqeyoI0ns0EmjKyVYGe0jg3ntS7zp7XRHGe2TicXXQ68w/0nt43FIulnuJRuJ7kOkdHwZ7nPWk66+mWhzVDEz7rO7VNdZ7xOxKe81zEnvYx6wFJ7NSe+zy3PACe/k8fNgMG9DXgeyo16TJAnwY9eE9tOHUBOUVenwxoO58Pys6fEjeLnxQ65y/GPq6FOz/5p6WfHHI0nx9DQjlyTOw4Zz9OnyXI/58oOkw8ugSbOVIxyzr9NLBnFTVBATIx5onxnzbk3585taCfPFsHnz44/FgRftSfQ4bHn0ZQQT5TOwGf4HHbRv86IkBIY/AwETHYn1MHEZ9WPfg1hEVHn1tEwJ9dQZ1MRwaLOqdC1wFBn2Q5YDbtV207z59pU9k5JU7xQzQIJzxzc36fck2pM6GV7jhUN2xfl0FoRioJR0iWn35Gr1Nfn4JHYU2pn4U9pEmMNaUyakKBn4sHEjceMz5HH5+QNdJnfJ+TDKm35J+XMgyf9Z+bZMTJP5+fPItaNDrZQqGfpHKSVTAzODI3rXGfq5k+n6440p+wXtufsw5DPCwx8DetNWFndDiXQgk8WTs2PzWfvzvtrSCfwzkun8U4qU9Dr2hahkzzA7y0Lp/PT3U4f/sdn9Q51zM3dPJfbzehNQ0BQTaMMq44GDxOTJ83ojUXSdg2V0GpNv39CjjylNanWp/sNn9eEjXKOktdBovZn/QPttyEn/gCqZ/6NUFT6XnOO1Fat0MdUiI52TW0S/Q73U59oAg876AKNTc4izJMpdfVlDuMVTBaYzb3M7kYEQXVOOVeEkRuQ9E/DT25Os9Su2l3NDpdXEvGoCNO9T/ZNXcPL0N3oCk+GjotNsagLUxhQeM2xTz/NTZObdYFoDYI6yMiheygOzt9ZtKgPjl/XJ43jjs6Sdp6BkrRTHc+d6BIs3ugSzQuoE2gTzYjO/JRRzVRoFQ1RkHGM8a6j6BaPORS6kJgOhWgXzgLM3QzO92joGU5QjYNoGgxP64UQR5FQDMP++GgcGar9mugdMYjoHczbjuVWvGgfHSvA0tRvToIQsJcnqCEMsSCBjaYgzGgil1iU8M9KzeOOJKgkERANcCgk2QnoJWR+pRfoJk1EDWdoJw/GwYGMkugoFKEeSygpEH/QMBKDBLuoKkvYDMq4PrI9TRqoK5JH7SMBp5ERFwn3WVT6zoMOOEw4TW1bZ6h96C9SNugwAdHoMJ/jTaYNgZC7FstVn0z4+z7oMyA7qDPcjVLnKDTN6sHPKDXNGxofku0YguraS+X2AW+Q6DjPcpMcaDnNpBqkw8/AkWg7IR2oO84cJ9VNsKRgqD1ORJQN2ivMr8yrjH5oPzMJVTToQAxtVHPOU6hBFqkP4Iz6Tdm7jtbbKEMQ/1Lt6EPPcE0DKESTLdAU0L4rHGhGEv0Nss2LD4fNt83VaEf86+hIteroSQ1vTNJoSeKYTHVWi6hLFwSU+Z+/UYCoTI6DzHjsQihN0fObFtG2wYAOI4HqaE+ECs5KUc8QcpLTzZeN+s7Wj1+QA6xUKFLEDU24z0+tbNLsToUoVIzhz8kVh9QEkFRAk2hWVGQSMmhXDjHoV5T7KFhUcI+FASmoWU6UDl4AS07KqFrM6FNdl+sTDz67TkdkvOhdASyNLZCWaF4SPc0wb2noX16hRGLN5yhgjLVMbXpNaGHOthNiVQ3OgiLGaGOXlWhkYlOoZQ3uMpDoZgzmz5iNIg3Ej1goZ6KC6GhTNQybzxHVh835aGnXCgBNVEANSVBfz71Q2o753UrobJVuTXSM0pCiGVsRKRDDD70PmIHlFydob+inaHCPedEBNIBocdBVj/Qoco44kQ7oc035TpfodBk8zcdOGxCqwFKodaZmDxGWBgCWzQfPkGiRaHfXdRTzDZdoeSuX11YAstCCT6s1Fih7L5toe9LFAIHRihKSzTdoR2h91vQMmoy76H7x/ih/kMTPM+px6IDvRyiBlRJQ2VtiqILMkI4jToOT1k3pQavTVwG+DQBQ9HdSKIYXeWiGuIRoh1HPK6GoiE5JTzPMjFQxQEdNCRbtqIqaE1DrKItm2qiML9fojNhMzZDZOP8PaI5ZNMP74yroj4+rX98TYZjZQvEqMk6elEZR6syDqJJkvOiy6JNE5I+pjcqNKw5CTtaTxuiVj71N+SiWTM2n9VAVjmfSuNB+T7RNXUCDeioomXyCqJoj9eia0WzL587e0pONUCicTivRDSidRDDNO1DwkHTTmo5vY/ZNSM5kwUWdEU5CQEFQ0K2pzM/lemiiAEtuoWijAUDPE6ijwcpopHL1aKUNYg4QUPYRinVWb0fopyhwaKfQJ1afFZ9r2yipW7koqef4K2bqbeirTrioq9PIWHMuf9DOU9torWs9KK4RJw2eDfyNnRGKTfpNAc13JR7OGhs/DpIAUqixjVNVKQ1/nd80OyizToDM81ApFYLQBl3tT7bM8ZLWDZPO6kwAkenD45hiUW336+i4A+UQwxHwT6mQqOymDQfNyui6cXwoux14Ty8Mos2T5VoZcoHxKL0eQs4LUFaODA1OTPsneSL7JLzov871ECnRVk6A0TxNIlafDQfUGlFqEkJb+WjDVtuMtU72zl8veCjFJTSx/jYCk3+oxo2CE/GsaajH1JaoyLjfFPDoyWPlaMoRMpXWFdFoy01DLtQozECRaMzOHU1qopkozg1WTxOozs1M+YCPcFHTE/MPiw1ykwsNAtiRGHtvfRAvaNJq9M4c0FG2Am+QqNSN3WytE4Vo1bjlE4To1m+U9gGvlNOGKNi16th97kk1/jGT9f4NEmjazuUo21Hl1G3AUijcbPJo3QzjTvuUKCjeQcro3xEWDnoo39BWkGVYYdfb0kiQq5PKDctfDZeVlMTo4xGjjNxNvBPIUb9RKujkznePYKdfKOYXkZvIpwcQUw7JK8D2AWjW6OjN4KjpUS3NNpFmDrEPdVQJziHMz4IrT8/YsAzMqOySBhD4DVrUPBWCwwro7kQ9YOzBLo+2zNa56KjwTW2MO45uzX2Na1VcWZco8pl0ERAOhNTnP5Xd0pAT6PSCGgBTD2GQag+d6Tvo9pYdaPdOKc0tEZ8Mm6j4jeYS1w6dAI1Eu6j6AHFW8o3jWCeOUej7kmQO8+RsqPzcoej9lvHo/k+kMLxo/0/LaP/O6E4iQEcPfwx/z8IPyqfR6QJAQi5YEJMQQk5gVeT4eyM4qQTRKQ5LaQWmoykGUMHMmwDdEOoODRMQTQGBd5TJzbAOd2kJToYY0ukKDTXOSxD3VFSeEOkLwwptiSkM0aOpDUzSzTXTTSG1KQ7ikF0baQ/OFA/0THwpEM2JKRFPR1IU3jUMoyCmaRMNvFGCaRPOEikUTVbQywzaDlgQz053TX9ASkHETx4YaVtz6RfS23awaRjNSk2HTr0jdWkaZzFpGw1MDiPNtc9PaRxNw6kc2TVNfsPk3a1pHktGEN9BwF3mqR/Y6qkgla7PYAyAfuFeISkiVu1cnGkjUS4pI80wQSbSztuilYJRJ00BgreQISkmVSBc05CuFAvXrA4nEMBD5RfrUVipKU7AWNPQZykqWyNpKyDxZUipLA/xTU9pLNLtODxpLdPbWJ5pLtT4Vv7TXZAjDVLReub9KTEQyUyXTPiDTsx/QSbQ8Iz+NbwENk4PjeqBwgDvEH/Py1nQ0QkOZo9LDjiNThKuluIpN1EgEGbP6Gk4jTdRFgH0VcDpOhAsTOYMwDIB1noOhhNZzPsVJ84dTtlPEI7Qj8pV8mvr6T6bHVuDDZLpP5ATUl3O2JHAKUEqPelB0lzUDKlCr2mpQ2PHqUQ7cE+9aAHjSJE4WY6Ms8GFaUZOpo5f4WNpR4y5jLEPX43Q6UjU/ylJZubRfgzC0CxS1JCkzPCdrg8+sdpOBg7UoawNB46YjbiVFQVDDZRQnM25jiKPjEG3rIypUDgqRC5pUNacDZ/pUZMp6VIOXQBwTM3Sk33/qVPaLKlUjKQXhSlVjJqQS393aVbOJdG6KVfDKo5UjwzNpDkq6VmQvJhzEeOQ8o5SaVsSNwDT2cKPahAuzY4QUpKYEEepXZJkKV4RHhEiqV8M2hGZ1aoNgSlgV92QnpGi7EApYc3lVqbO1o9gqWMXqs0HqWPOYozMgKOpZNERDbxrb6lmHynnF41KU1JNVY3sTawBR2gJj+EAj4zHDzIPgwz96Wophem8aWt29+lsIphdLw5nUsKNjE89jQeGb2luj4ok+Clvj5+Srg1hjaLAeqlxDlTUTs1YTtHMckyNTIDNcNLy1vZQYA6hUB+pdJEBDTCR2ygDkiaPaMDOXpMNy0x8jnsPaNQN6XhMuM8FFDwSHenQqXoVglWC20nOv8yl1svpe8Fnf8JpfNz8qX2MzpIyUWmNbCuGwJOMxCl/lRhNb06yKMUTWo4imbfPCc5az+xPcKmC03F34umDzZRNVUw4TUwUKNExTW9phdVeKYZbeAwkqYdPEhfwDY7ODumIkrAluMZjV43OPqmKDH/NO1VdaYsD7aMSaYwAo4x4QffQF9eq287VhWmOAFZUasBeDeOOWumPpZMpkFGYjPMQFwOVqZGQRR8NouZpktJxjtKNgcydEccgSs+sDvdYAemVja7SRcxszNZPwSmXDeFpl/J39gJTiSmZUhCVhGmaDUyO9+mbDkDN7pCLUhDOX/9vDQnXu6mdkPgMfs4dEKISIxAq6Z9Vh8P0j4c+0844dfEOKs5ZzHOSts5gXVcpotV96aNUEE7YROSUMZDy69CCQcdY6aXMg4xvUKoNE1lyEBSuSLYFk4DpqJb+zdcqjimpzybSFOmqqFKPM85Sja2MnExvwreQhymtDxrN45ExUVjPwQ32qa7NyhshjNmnJ9epjWRpsI+NabENU41Ug/jOS9fklbqpszc2abPOm46jIA9PKeN8abWNO4BTKbZRNA7/6bcOOCm3k9MRMU7ljlSRWnZ9awCpudGQDkoBxLUmqbtONIKWz/RQDhkJ2RypvXh2Kb4BZRB0gnsQiM1tTjHNSg6e6cCAwU+sKcFNYA9hkKif0inCz3INRWnDlGQYFenEgJNNkCnFWGbpxgHgjVSkjynHWADRz807kJgpyJCKk65PORO4ELbOkenKTrFX29Naj/rpy45nDwGNO6nMlNjARSiZac3SplObac7iG6nPkPUMmCnQT9osg+nRdMdP2inST2Zyg8E66dNDy88EQEHp1FkPjL0PCQvl1CiPiRWu6I7p1s42DYzSEA6JadgAV04sTyDPM86sadmNfozJji/NZVGEEHjRLcxzVT3OVWncVeMp3TKf6d3M90Hv6d6Ow44DKd9Tz5Z9KeBQKw3YDPmA1Y5ZTPNOh8z2kt9Ok3/DFtNp483IDpfp5I3JTwGp5VWCVv7t3anmku3Nc9z3DQ6e9p5zkho3eMyMUuIPYI0BeTMQHY84jMPp6sx1jehMpoHv0X4Pn8zJ6ezSeintt71p7lB8eSAtgWnvmqSQwHJDKfDOf5lbE59p8dmbzoZPGuny3/MMgpw+qhdp9E041xzNCBndafXSGg+NdVBp9wCjjWkmUGn4TNdOxtoCqfmQndB5EI4Q9Q8GzTielan7ztHet2n80KhOHsz2o2dp/k/3y+WOrBpp243qAABeDbKOVWoBAG/nZkzzUClNZI7qjWOMzf5GagPQ5M3aUlpBEE3rVsdPqwyRTUlNO08fUtKPn1Nv0AOctJbp6giXNCoJDOmqCc8Fz/1e5GoLDGcVEk5kqgwVvCoM0v1CF46jTZEOI8z0QEcBAMz6jSsTWqoP4jEVKRD62TTPckUYgfgNfNqkkWqfP+oTMvuNbpLUUM5X29N6ahTTB1C7TsSTvFHJYPpqFthUKheRexuxEigQJg8kDCTARV2owHfECJBog9j9wTHW6huoOiocTLiqHQ6A0g3OFoQDDQoqHpY+0sbN9aofkOcAUg3VFu5ORHnoqiG1guoiToiRosCeVvKNjgCd1YLNifdo6iUMi2olqliqJkG206KYV86tjXsRtM8DTSRMgU2RKikd0yopzgy646oqzNSYCIDc0dOOiQ1zfbHcMw3oK73WIYHAai43emouzTwOiI/zAbhVbZapKjCNVE6kvnaqMdLxlo9O0oLeUEjMhBrk6jQQRdi2gIvqNRuCTu3XEVIozlVNTuo3FgCMAIyVznLBzOq06jkQVKo5jYzMdc/+TSvU2MQ0U7WVIEGBkyDNRK5oaj0afWo9zldSuM8CV1LP+uo/TgyNz49TmWPqQM9BuQQqQdD0qkKhkc6aqJh5zGpEECMNpZST/asqRZA5jc/Q5upGz8VNNA9o18QrhxWwzWlqSM93mFxOWcHaT9CN++pKkZdqS1LFDG9ND9RwgW/fHGpNTrBM/c+JTaQt3ipPDQgVygHTkD1ARyAGKlEVL5S/KlIMnQ8JEfDqUw8QW4MMimmEZkHqVNUhEkNNxs3sTQ2Mws/vzYbNr+i0alfNwipYbuFqWRizQEVNuta4jWwN0M6Gfs2YBdCGalxQX+eK9TPbHU2+zgnQVKW8Kl6RLhiNkGdNkRFCj0phkSU3DL+Q7+eCadCqYjVL0xGAb81PDVUY2ipjzuqNI9skAJ1qZQ5mEYzR8E336maOtY7jqmd4MCpoE/ZqaI2Qku0QIxMC1ID6BRmFamrV9s0CUj1Pd8za0zUNKs1Pam0QH5LUkZWqbh4Vam7Z6ypvjAuH+8GdzmyNxlAWlKPV9tG5A+UOVqpyjcOM9k4ijbrB5wB6j/USaBP3nISqdZmXFm8M66b16ncOcE0uThzFpCp4T/3/Pip5UEUmoOp6TskNv05V6ntdoGp8DL8YJ4yPUaOqfU52jckrFpLCjTdqfs8HT7EPkwyJTUlqgEBOZu2Njc85lKZVh9caKoKO7kBq20/ScZZ4KoRPvM5G6oVllWqGDSvBkE5d0NYQ/A1wIBgqiGxj6okN2OqJ1xwqirNhaotSdRXM6owxOGqMzgJNtwF9qo4eUyqO9IXqj5W3EX4NUo6+EO+OR9d26pHL5tJxKpL/dU40keUPNk1dte6qlM2yxQ8O3aqVwXHPylAqj84ql04nzWvtqZkJ4qdqmQPL2O/O457gapqVElMNzACNB9fwDeIQq49WEXVneSqdj6LNfo6wap6O/NDM2Piqn+q0KqCrhw4MQFpqoY4VKqIRr9KS6qLT4szJqqOODEBaVSqqR+qkz28jWGql2pzqpqGRDb9bWE3satPN6M0H0rLqqNaEzbzBxJMN0tiBXpRkzmy280yOjYdX285OBAIOSI036q0OCgL93eKAqkz2ULwQ6kQ3aq9Oh0P8EUaB8Rj8DdcAbe8SqrHNNc8EEDDD7Y303e6qs5U6I0aqtI4qjUSiD+q10Y8qtqITTjfcR0yDDL/QEkx2DnZquM1NujbqudCil8uquo2MjJAR6tMCwGvPd4zm+zSqvRO8a88qvhI11riVkg2CX9hqv8/pkRYNS0FiTftY5s77jVpQak4f4AOPM9A/mmnNjcx61Jxd9GrE2vMMtjPOKsYRDwzX6sb2dKrHjVbMgNP2KsiVWarJRAJRLc6wVUJqys0BkH/qy5I1D3+sjSrM1MnRbNKgzXPNOIHMz/8QER3b+Kzqz8JByhCWkoJVd2vq0ZQJ6tIQBCrSzVwBm0852jHq1FEmDIyOKhT6095q1hCD6taXy5Rdj7rq15DQDknNCgmYEIiODtAX6tmO2U312t+q2sz1attS2EyizXJNCM9+DW+MkzZvKt3AuI2bDM9P9RQNVstZ6urgEQkVC9RrwGsAX099TKMNS04r0kSOIYyKZcIq48+QzadOQY7pTXdOMY4yEWDO2irmkThNTk+P6ufPDk0MoRiq6Q0ZdL/vgurqjlzMcAFyQcRq68zVjwBNlRCkETYPG02i9QFq7lFY14fq71VV0UlXT0zZPzOnD+rxWqcN21bLzquX29hmqvNL2A0ZavRo0qvAtgJtmSr2zTFPtcyjDP+Mzg1hX6Qq+Sm4avnNlxDzTWZN5pFaTxVgFOr8AHpOQur8zI7Ower9mXGq/lh1dTsq/1ABT21vUGsAjXoXAKsBjwmrAk2IjhoNK+iG6wPO+43OzUNNP+sFEK4rBZVVzpMMjJCYz5i4AesHjhiO3Y1LDjEW285CE5urCczZjWPM984rk+FM0OsLjd/eCusMjcZOfasNQPIpTWsOefNrDwz4gwrO/85ajqBPAauNqxFPRM0+jnjZvhNHT+/UKM6G0X6rFACWaxS+KSsVbOOrFg4Bj/WYY1AU0xHNwmUyaxhMig5NJ0NrGZYdaxpNCJ6TFBSO1I8AAULrHChF6xzScYzRNJnrHg08laoOHU4zXMgMelSazgJcH6sg02frIU1pjYAPEQ4F64JrIxGKUCSQZ09zTQoS2G0i6yVOB0DV6yYVXUGQ6ycO1asnjYySK47Vl439PU0tkcIOwdF7FeTOg9vKqyrO7U6kT91rK9Bxqyx7r+stDHOrLY1ATdBNsY5fANzrLwGijr0kjNMNzUoX5VBfEQ7MfoQ9zlU3yA1yjoPPPyszAN+U4xUpazRkuus1Dl8Op+s1z6AOHVGXjQUrNw4AWu9rOABvV8COlE84lK7Bchkc6zpN+Y35c1HrO40Bj4dMxhEnaHXrPU1Xm6KW8Ks+qEprP0666z/SlGtAlgRrQSRba0HQSZfLjZXbOJxy60OOyY3uq0RRf40Bzw5AcGz8K0YQEWtGzbRrR00mFxFOM81SIJirSRCgUBJNhcz3UmRxSGtLC/ZGHGtLzrnrTGaYK00Ap9aDkUemcytOgt5NbU3qT/FPPpl5qF2rUM4FzxKZfhnfE/QRhZW661MR1UQ2UBoVNhW+q1TRZY6FT70rVdLlDUbVOiDmhDKrV07AJbTrWE8fTwT1Ow8RFvQrWeRoK1qEGQDc61tciYDfq1wPNo2jzUdOUBZga13PBFG3NerrXw17ULCYHs8EWnSOv86WzQ6keathzrTTyg8DTVgrpVV3KxxoRg6Ga2RS1I6sIZTOnRGBa2Yd68BGwETRy5CI0ScNiMQNTXgNrcHnJLzEk9Fbqh6rak7+DnUYHI2GnUwrbBd/j72rbRFT5EJrbgPBjZ0Zgk7nDmfWnutwEc8PfpH1FuaBpoBXUTdPyZA5japUXo3LK3Mip5ZCgFgJmBr+63TNY+t1TI6rddgckfUYyJn9K3dXcE5oDQ2ZxVeEa3jARtEFDiJredQMjg6jVCt7GZvOR2S8xJPrfE5DjwArfSL2DYDBqTsQzgVcpLp7q39PLBOcq4BE5JCCWv1rgVhuEp8W9kBrzWnNZeGDK4NMpA2GgG9P/tEbkDmlxSuFjXKMoeuGUJBQpM8elGtrh89TkKcNwyuI0KGjVMyzVKMjkxVtkOpM2VDAgbhri42AEHoPkMyGzIbeoWsQ643QfGuOTpbNUpl1q49BrIBLq5ANo84jzfRklvQTEOrX6iuSTBSrkw6IihCNAF+vRTWN6+P2UzsWbw+rASJrlg5j2hmUgVJiEBNM5tFRa5h57KuZDXGrmY4kGIArmoBGo1Prm4y1jcRdVKuczxHM2Ezwz2ZVZJU30Pr9HmufTo2N+bSSa6COHVAfkD2roZco66JuSKYfK6NMj2ujwEtdds280fqPfo8fRF7rpcBJk/IMBEWkK6cCt82ZTVpO7xAWAe/NpUzyAtsrqY0DTk4NRYx30Dgrq05KzqGiT6usTz2UC+r0661TY6uuD2OPZg3lb5cvkvX/dgJ2ALX/tgC1/7YAk3+0Qiu0j9CDlau1TyPNPau2GS3YaU3Clbprt46YVXcVAA4v4jyruVM7FWAObSu6oLCru1nQ+/mrvFE2gOyMfBokGwNrvgBVVbgPYNDj84GBYRKXKNKrwLYCdgC1/7YAtf+2ALX/tgC1/5ONa8VdLyvFzlzU+kykALTluCvHn80ryFD4K8jOJAy/TfONNyvKEUpSu415USBPDNrC2FnPsRCvFpJrzQx8FSCFP5W4jbqOiE5/zWvBkGvPo+3Z6mvQjlOOv9osTTIQ7/YhUekQPY/1spOr040ya9Ro0qvVNf+2ALX/k3Pr1wx9V9+tGevYTvXTXU/gjnYr2efyWn9r2s4Zj8xOcE0jDWtDy9DiDgZRwoHMk8151OveUJsr3tT5kRq6pfdia+BPEKvg1VxBYk+el/yr4mrjjvKnnKvjjVjZdY30a+SAiRMRwYVAX0H4Vx/r5pWflToPFNX6DOOr6AzQUPwWDo9+TW8QoYOQ3SHr6pA1z7rWD087zi5XUs42zc0QwvTrq+2THeClq+6NBVPGa+9S1A7jhF4NaOvwkTxOCevxTc0OQg0O0LyPDsCda/MRAGvzjm7NnmKYTX2NJc2ljZCSwtCrjl8r9lRUjgXUqY3dT5ETTWv4EXoMlgHETuPZVxRPjjrBQuv6TUXENk/5jOdM92v72rHr/L5i6/1qLCv+Pf+Ue9DfW8rr/5JDTp6N+xSlTrlawYx3zrlEEc3kBAcUmY9zUqQsA5AXEzGN/g/KmbfsBQ9/DQPMi15kklxOOw0D2HdsB4Efj2TBb5ApTiCN206sF//sCg6YUQqL5eTrrAu33JGSzUHsDI1Mz2iNS0CNbA3NjhhO4hNRq5xmlCNPluwP0BcEAW0O7BEyNdNLlbuRmSwSjNDPWk7JEvyantFCtIosFNtalSEsFYyNglxUow0LlqgsF013l3lVWewYkQGMoewZU+usGfWj7BqY088FEEOdUk8OTgyUP8ST0ixQ8wF3kpcrDKweTHuWvaLFDQuOoM1+mzVUe8y/1T9sIZGYjlKVMWwimtQsI03OplqmbiwklEasJWF5kD1OR5U2NRJBUFOijNlsJ4GrUSAagM6GD1HRpg1zjmfYn42g7Cp3rmwrDiPR8JDE7CwOR5DAoKTsLUU1rC3OGhfAkNYNJE9DjePNbgBt+uSsMJLXIRXR3OwxxBHuhB/JrDMM7Ay/A8v0gCw0jLQgtuw1kRsPscBR0otP+ew3DcgQDiw3zXoTwg1G7DjQFdNhkBopMFHzrDpPqE4nwNJNeU/QptesPE1W7Dzz8E6GElxc+Kw+QN1kmSw/WmnhfOxAQSyXqEy/TL8Bjc0NlaSQvixCkLwQv2x8bEPvlPYBr5TsRUC6zzksRhD4EblNdpHqzPt3dCxH1ZpY1s1+rEjPHQ6g5RNX2849EfOGKuxLDyCsS5OikHUY7+4Fj4KlksyG1ALNMFRdkdOsTo1I1JxN3xLOUdqU2Q9jrFCy8/X/dgJ2AJN/rFJuq6PMLFNQqyxT1wssVJVChNNYAM+1r2msVkJW1f4RdQymUQUsV9IyDnfsWNWZrFlN9KMUbFpNNBGZbFtMz40udxSsXI2JAZ+YLSxd1AysXk2I0OvNl528Adp4PpMhDj9dAOxhEx38Vw12Xe6NMk9hLGM4hKxj5B6Sc5CcZGnsZUBt0KusZhGyLGaajixnTUQsZ813jaSgsGD0rGlP4GD8zOup6Wxq7Hksa4JiLGwVhGP2UgUPmEzEUepOYU2eTJ0sbpRR0RuOGs7mUVPNkY1cEdhN9JDwjVUPt88ELHItpmxyz/eZVyxzgfZU2Sx0TKXt7Sx1QEaRz9/7bHaP9FUbkCJsd44kkwX4v2x4zdzseUy+DexR6tPcfnNS5ZBRD8WuW5EV0IWAsv40rH0Njex9lJhsfk8gEHiPZxIjEeCbztVI7ICNT82F2L/sgddWDe31RGyDDaTPFBUxxbKbwY87i5OYANAZWB/SZ2JPj7zAkuyG/gfsh5e27IgrUSyI0hDU9tDqLInWAKyKfAKsiw6abIvXviyMjz8Ys1fA0pNgKg1M7iuBsw5/jfFsGCyP2LAQPw95zKvNaNG10RETelDwUyvMe2/arJNN55ShwEnPAAYEWwbslUBGvmUB7/hQGGJ9CRKyz+/41ayYFjGsmPoQIR7smc67jxEsmpGj7JsNvMyOjqBsnCBJrJzXhJPNIKlS3VHlXDmsns+nj+5OMw0sNy0OJdAIzukUDMHUQc1VyiMYrKKBYr457KONBiykTmsB3WylDYcO6GGSbKZ7QQ5Okg6sp66d7KhxfmypDfzjh6yqJq9Nf2yq2H5S/Ex+1pIhHs3dbKyN3WytNgGvlOg4bK5kBVEpI1zYD0+LDuqENFNGb2hssRmqzeAVGg0/zwVQwxBTDb9VmE7oVt7Zx6y0jcrCoUCKEEUbImy2TNcOrey3AN12Jw0P7Lg7L7GWsZYxlYQCAEzVbYwk1VBVXEw4Xm+AjA4MjybsvA7jEkXQbmy9DdQOddHHwvoQeRbLTifNDbg8bL/CoViUdEmswQ5LrMGUow9LhE8sws2+UMLNrcy1DNLAb41uGb4VnFTLQ/wtVcFCjUPekw3VDoTO35HdTP5syE2yjelBylGTDoiVpOL97MqOXY8ZzTCMepE7TUNQ0MNcw8vszQ5xkGdPYY8Ni/ZR8WFv7M8TzlBDjLwcdu4ObNDNdpk4zZkayYv2FIDs0ozr1YwRjs0uV6mPOK1c7NTVOhEgTS1NQBNQzbOP9Q3FEcMt3KzXzzdUGNJ8Uv0Vu6LnbNnR9uzakcRs2x6XLNvRYc3JkOYSUpHYUGbnPA83UGVOAM6f1gwW9CDKbN/r3mzguics4U9RTsQ7e2ziu6Es41HYTHcN8cOVjW4EAxUxUKBUI6SmrOZB1JPww5FMzizngZ+M0p3NUfCQQY5ikHKMv2zp0FnUas2lXNOMuZFUUVRNn82tjZ1bWGzs2yxNe5BorO3mfyzuqYkNtuzvT/eQAXzw7PCNe5gIjCTOldcKVlINAw79TW9apI+sEF8SFyz0TWCPahmbwHfc9w+/ziHM9k0mAjeOPY2AD48NgE4LT5BEOOz42SVOI4CBzOTOthG/zkRZcWz7T4QNPI5rdG7XEVIg7P1NDSz9zgys/k70Li6N7tIJ1gKCF4+kTgIWasyJrf1tAY6rTwzWJ20C0hAtA3XPrQQQ+dLy06qXtNJjEOPrxi0GUj1hkQ0lLQdN2HnH7QhRNjOJbQlNbE2t7Qoc05BM0WrQvQyU3O6tDAybTPsYaFMDDH4ObpyTbQRtDo3FIiDSBI57LQ/20C0QjoZtERr+LRHBje0STeDtFm0TVOSA1w1fL/wNLABAzkStFUyDj71NCi0WVb1Bb+0XEGXX1QOV/vptm+0ZEcytGavYLRpOjRkCbRtTHc5V32jtHI65DmcAQQ5r1S/tHkuSgXIMfW4grR/4s6AUbSDPmIQ9zk2OSYDSjbPOpK0i8bbtI4E7nsWMiU8gzVYAllLJ0tStA+0mUVeVFR6fbSeNc5sUbSiP7VazbSmqPW2gLSq90a0rTgJNB95ZDJHlCA83bS0OktCobS3NhO0uUdMNx073T2DQJ08GGiFoldMdpm6tMU6YbTHVzNPN/wIT95FXjxBQnM+4/fUtNJAsXfeTGe011UhaFo2IrTbYe0zPAaItN8/BLThRf0PYDM6bSeXpbToc3C06zHPNMm07+VytPI9nKzOPU5oWnPcNy20+RFBtPxGKdMIELlb+rUCMjNZFrUGDwW1CTPfMjFaD7UNNNy1D1j6diK1EzXnOCG1FlqkSha1GpIzStVEozIIwp61IT9kPYA7YVulYKQ5k6NrtSoEm7UseZJFiTl2NRBEwrUyTQC1NQcp75q1OQHBtTtEODTlulW1QIaptUOWMbVGNxM2RIMytUu1A7VOSAu1UD/7SI21UxTWtVU2UbMYR7JRWWKqSAv+h7VeR2x3rLViXVg9SmqctWdBBmTTtWo5/j9JOW14tJIJtXG5Z1mntXU2FXcQAShDWLV6MgI1BzPt5rW1gDe6SEB3lbWFtU5NthDDRG8zoWIYNJBcczU4ZCc601eTPHM49bWUcnZArDHJQBk1FbWaFsqM/bWePMk09UbGNm45ej/3MeMz0bWnW1e1qkNKO+CAIrWvT2R3FLWz7zW1tgTaMqwy8PULtbw7mnWrtcBhC1IDRARETwWKNYo6drXIMkAzCDvcw31ZALXPButLUkLCtdM6X0h3M7oyHzo3PG1CYGObtdyJSujXteBBDqFcteS6m7XnQ6w8j1p8OF1mG7Xu7kK18V9vQoc6W7WotfdSRrX56K21/FuINc9PbXXhSEO2AoSwtgVHCDNmRm41vWTjM44+rWfqNvRYFEnagDG2E/18thYGBzktP/w5HZHgth0G6zgDMx0GpzxIBdW0xbYmQYCyfEsbO0dGGbYtneW2MHCRNto1mEA+tjYzA7Y42AKYw7Y8PlNDzNtetkE61z4aV6I1EILBMjc9wcUMQNe2TLZOB+HYM7ZSOPI4BnhItlc2TmU9tltP2bZdTZa2YKvTtmLYBdf9TZW2aF86tmtY+TZbMq44grZwN/g11jdMZOdPNQlIBhU1MCZgPIBISjy3Df+2f1Z+8I22gzcsPEI8+zHrQL044GOhOZ62jDJsNbVA67aQMAI9RraTAepq7k05Zk0D9bHKtps3IEqDAYA7Njjbqyu2ozeOapk4ZFRJNv08UkBWYcy2rD/HP/VBFlsXM54zGDbbogVCoZGVBpoCKLa5QhtCTGebNUhtnkcXFsq2wgRbP562xTV4izq2ybs/POI+ldAnts8x6gE0OiK20zNBttURezneNY43J2hannDdRTMZSKIP4zVYNVhF/bbjMjqbm2KJXhO26af4tuwIaEL8v8m28Ym8tvQ+oaVztvgHKbb6BchYalwcNA83KhCnPDZUYTenY0sykLcGBb9tCbcKBaO3DUREtw886LcSRQrZbLcWRjOJDBbKPappwAJOOR1PN13SUQy3IT5+adIOQz7HR8M1w2q8tyo6EaW4NcNGZ0ewtzEBETYKQWhMxkdcZrFF/oiLtztAbjIHQHE9sEWyXBJAvUcMt0Q8bTcm06w3c7dJMhI3ObdMjS63T8yvt1I4ZDckOzpelbdYyd+2wQI0NUhtnrdefIO3YTlVt2OkR7dmQUW3aTirNfZbLTlHsfu3cEvEt3MwAmLqt3ZWPwG9Py07zDbUtSW3fnVBVS1ZnEBnSzg9PUCMkfozPreISHmr7HpsOdlHXD5EPAC3kDufS5W4bUkoapMXObeYM5NHmDrYt5xW3EVit6AFJz1PO9RASDU+MBFLSjjsuKrhhresRR5dKz9kt7A3aQ+8R85Opz/5Orz4jbe5QK23vDtSt75a+TvpEk+3wlgYOhRIrrfGOsFSGQZBOHiIu7fNTIM0umuht9G3nbfUO1E4eTyTQO0C01qbt9s9eDv1VnFG6rfgMdZU4l/yt+XuHLfoWvZZLBDRiy237jTFR0638TdUM9921Lf29/e3+TPHFy6F57f+MjY1SD7MuAJGkmb4uAVUMUbTMe1WT0Qd9hlCzrgOmry4EU0duBN14T0obuRlH7gZAQW4nFRluB4yPDVcO2U10jNLuCQ30jrFAqm4KAwqNsZ2LEdF6Zu4L0BPuDFJSrgzSuU2sFYRODu4ODVvMBEGzLg8N4EBA0FSQCk0mH62MhFDQFLqQT8+8vzTuEp17DXluGu4TziKQZxGZxCRQoc4Zkx3UT+4WRDlR05IKjZhNPJbWUMs8YtEmW+4uGU+25V4VO24akGduGw36rFnuHAyZD0GVSi4dWGFNEIztGREuHsBcTUEMkMPI0zsjD24gz2PYe64hzM+PG0+MriMY2i4jjUs1Fm4kjuoYBwCgnuKuJhBnEg/uJw6Wy9gN2pIHjWCWKVcElZxMeYJB3Z9uKk0NzodMedhomn1uLA22lsvRfQ3gjfRVuhq7ri4lde4uz2LuL3XWrjAXf4/sTYNRwZcw7jHRCY61zSaWPttqrjOoulUpFpQMvdat+BwN/JrxTdnOPu42TphuNsCyjSTuN4ylzZ/uOFLpDL9PE645TflO6dk01/BM7lD60YEuO5RPkx3uPE9grjzMhlYOsZZxlNOXrj5S4g6m5mRuP45mDXYuQFEq6fhuQWpWbkIQ4+PJLkMB3VpwbkQD365EzUjVck8Bz25Vqi5GTHwNGU6xNicND+y4Oy+xlrGWMZWmFy5JlW2QLlwzJnGuSwaPZKtuTA6/TuRuTM6/zhdNOM/I0+FNCQ0Qrk7OLw6H0b9NbgQOLlBQc86hXQMuUZNaggnVXjSVToRWPpFGLlQNdA/bTpRuDg7SvnFuVhT5rlaNOAEprldRCY4dTWGQsK5YkdYVqtwc7lnLu65aRAJuWtT5j/uQqsCdblwNS4zYFJGMgNGCT74NkJPKLl5Mi5dFESYxsk+3yIYPLxFJTbx1VS5hUGch3m5iT3KQyq5jD3fuY4yG7mQNru5kjXDuZTevUH/1m25mUefNWkBsgI1TWrqgbmhRCa5o0mduaUBqGiCuak/MUBldIU1k6E1Pgs157mHQ+01uVNkDyM50UdKOahF1EcMQ+A0DE9ZP2I3i7nAd/O5wk65BZK5xW42P2RDuTYgTTWeALnNOCQ01F+5EL5am9MWudVFbjnGudhetbnbRMI3H7neVi9IJQEmOWBAWTr9gtxdBzUWd0pPrqyhuexHw0hKQcS58Pnaaak+9Uq8PP+59kSrq3a5+hAPufwyHWeUPvGU9DQIPAW6A1UYdIVUTjUiWkQhCl+SugtCTroNWnY/4roQNJRCKroTQZSF1zJruhdcDgaKS3IGFUgSO85izRUMuiADD0JBuiNMkLKQTRlNUD8EuikzHcdiN0c+GT/fPNlUBD9CujJETzZhQSMP7z3iMjxepro6RTRE5ro9MnK6P2sKukJGv0BlOnQ7DgJ1ukg/9zzZuks4QTM9TEe6T5/sulI3u07rNrk44p+yNWlNZFG4soO6XQY+P5IPts33umMwAj2JTWS6Z25ZNYBabnnAM0M6sDPFOTrzZLpyRwxKLjwHx0a6eM7Puns0+neBun5BlbqANfFbe7qDTDg5TjdiP9E3SwUcAXYHv1CAN5AEiVwpVAC6kVm4upQ5erqW4lm6mT8mX6E3Djy1R05LmDpURii6ogcyuqT2x7qnQYC6qQYAuqtQrLqucR09vLqxzIy6tEVWOqQTTbq4ARoJcbq7BxG6vW3+usBJ1WbfZhO6xQWSm59YAkFqBFs6021oQJ01mTvputBCWTc8WYu61TQEutc6EUmRVGE24RCHQMO63kruPYa64USjB8W65Gb4uuYBNDc0uulHDEB0oE470DPUXtO68ELEUa82jGC3uvapGLr5bfBEqzzsPCg+kzLXM1w1oz83uwQ3DH4/uwgBCDJga5dMdTV3uw41jxHtuxE3ghScUGM8ybyduxg5/7sa6jS7HVA3OMRa4gFMOJNBCzUwB6kyaPx3PdQ40rsrqIO7LjLYPe1G41bNuzMF+zqxNv9Lsbs4Ql1987s8xwO7P0zURCEP0ji/OTNXmLtHQ7JEwkH2OP1MKzh4sAS7UBbKu1I8yEUKUEEDeTZVRtFT2ThIu1sxyqvMu19B/1+rEGS7Y0hou2WHMLtoSu43L0yQTNa7bTYiu29LCgIou3JjCTCdPgvKprt4BwG7erIXYjYDdDQ6Q6g2Rok8u4NNFWhuNz5DVl8DOYRSjD0TOhVFyUekAXJJVVo5Sue7k3jVu5ZC7ruZPaM8+gFJRzx507ugNjQyi19Vu6QzOqwhbsEJiD3WOag2kT3KMgZFHEXJNco0kTk7u7O1eru2Opk3rQSyEGRodDdmPihBwt7zu8ECJeIVu8W0D5o1u8m3jrvMXtMyizw5NyhJOrvTUZQGNzuPmkxTFzZ/u9qHSqr7u94OwDYWNdwBND6wu+RiqjvONLY/+7vpeyq76zUcddBGGbvwVQBKXIcSu/VPUQfEu/ibkrv7MxA3i2x1NqRTzLwBNOa8BPLxOrgPL7wIWnBBfDrBfs9hokNY8Re8ETw2OhgzsXEdO8hcKFYWVdq2TTxfNNs2SjXJSy4tIjNMfzG8JDryp3S8KAcDO9u8KzMTNsM5vUeXvDB44kYoMNY+8zMmvDYGbWObXqu8Okd1SZE3oTKwN/lX5LxCOcYy2joVdT28SEYqvEpIrrxMBYR4cjZhFy4yh7xSQ0I8j+gXMiR3NEUAvFpUvmbXMlZKRjd2PBW8YTZ1MjdJ4TasOc28aDWmQm1B/7xsOdsyYzIcPhwz0U5qUBy8dDMYvHYNczMtOAb9pbx8R7C8fzy8O6e8gmAiPn9LmAdxedQ7YGGFN+hJU7yMMgNa+UNivJBhwnSvBym8lDNYlfd4/NgU2BO8mjf2Vn4+UwX1vJ9BdIMwQkGwsAaUB2pfq0UKyzg2uqPlvKxCqFpEOJ8/BHZwNA8PjwINNU68tjTHgJE0PAHJPEdplDRNN7FA9Tixxk/X+MZPo2m8xTXNOm+9IrzKMcRcKZTM//93B7zRvWq81DJqQWNFskAevR282zHyOY5s6bzgt7hR70dlj3O85gGLW3uTArzrOIZ47rzvN3O88THYQqh5xLz2EAg5A7z5oFkyDztCUn62mb0AQUvjLkTtSAs1/TwXvEG9CVfVPcE5+q/CvQ+9V70SNq7SwjI1NXQ6g70YWWi9GkATvRwxzgbJBXo/5rzIvSMu7jhIvSZPakVjQcZRDDWUvXa9Lg+U4Pe9Mpt+vTU5sjdnMeJEFAFdvTsRczkLvT5T5r1AUa8CRUQDvUVNqTcV/XE1yTpNQllN+L1OBO5MLAyERNE6NkATvVW9EL1YvRO9W+npvV4zEW8qvWE+471jM5u9ZTAuTuA67kQZvNNLUQGovW03CEGoBgc54+2JOR00FjYnZIlA60JZvcE0yjdnvXyZuL1/YdVJnDeNMzJjgE83P629h00ZOaMyVT35P0I0yL2OR6dKS0bGvZJE4b2UAjD7lb2YMydJkb2bMd+9nTJXTyRFvjhsOGi9o0DMijCsQL2oWUistjwFQO02Yb2uQ8I15D0NRQk0QDiBS0S9tkVgQxkBdjMGvbtCYF+rNAFg4AfRND29w0r5vcY2qWSJPSQ+aksUPiYzoTJqNaM1HQLgvdLYBr5TmNC910mQsl+HWjcbTqczsDVVOQcEfmX/veM8epiuvedJjz3eveqTz73tNOG970nhUqG98zduvfXYBdf92AnYAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgC1/7YAtf+2ALX/tgCvmAAWr5iAQW+ZANbJectFSppwl/E0QINMQwOBB3nvnDDPh3kFVnCX8TRL9O+d78Xw0jErhmfvny+e8NRxJO+gsNUwHLDVsB1JpPAd8HeINLB0BFSwdIQlMHUJYArxR3LK1nB2AQYwHUmk8B3BILCJMHgFRbB5g2Swea+wRq1wenCA8PaxH2+ycHwDCq+zMHzwerCDb7RLBG+08P8vtYnqMHhwfzB/8H+J8DCACKDwgLBG8PaxH2+ycHwDCq+zMHzwgwqvMIOLBG+08P8whIp2xUWwhm+7zAuBFm+3cJTGybBrr7iwHS+5CaTwHcCi8IjxIrCJRRcwhUwLilaASTCKCcqFybCLb71AUi+9xXpw9kGHcR9vv4wLibkK78sl76wK5W+8zAuJkAk2goGDX8Mq8P5vuPB2iMRvxMYsb8Vw/gsW8M/LGXDQS6DJwQotRbqw0a/F8NIAtzDTgTiw1AQUcNOBOLDUMSyvpPByMByw1bAdSaTwHfB3iDSInrDScB+xAzBPC+qw2XAficqFybAiAhDw57DbAm/wI/DcAAgw5fAlMN1CPfDdw4NwJzDe8Cfw37AojBFCXBBTsODA8HDhcCqL6kCJROSw4oGzwdUwLFqBcOPACDAtS6NwLcJ0z/FwLrDlsNyw5jA18DBAG3DnAhDw57DbATTw6HDcMDNw6QEwcOmMGDA08DVw6zAwMQRFy0rq8Ddw7MKpMDhw7YFEMO4BkHDugkrwOoG8cEFw8HCMxKAxH3BHw2cJ8zDyMEjw8obgsD5FnzA+8D9w9AG/MPnvwHA6cO9wQQvcMPqw9kGHcR9wR8NnMPfF1a/BSjaJ8MrosEQBhrD5gHUw9PA6sPqwQUxtQHxw9kGHcR9wR8NnCfMw8jBI8PKG4LA+QGmwkPD+8QwJ+/D/750w8TBMbgpDAHBNL7WASTBNsQIDKvBOR7uw2DBPMQPwT/EE8FCLzDBRRgoxBohHy61HaspcipcLdknaBRQxCMBIsFSL0nBVAPBxBECvcQrD4oiSSyZKDAsncQxwWEcsQXpBr0PIzATxDa+cMM+J/AsvMQ7EQvEPRb8xD/BfQkPwXPEQMRJxEbEQMRJLGzEQ8RMwXrAWg/CCDY1kg8cXRQwki4FAeHDThFsACMDrsIqAQ1ifgFHBUAAOjexASIAKAK7Et4PugENYn4BRwVAADo3sQEiACgCu75nDxUBCgFYATtBF0TQ8JvA4hH8v3++/7+Bvy7ClTGqxNAE477/v4G/LgKXBH4Xgz8cPGE3aTG2AVo+1wA2ADpdXDupFQwzGhDbv4TCn7+IwqI5qL+/wqW/j7+Rwqm/lL/uwqy/mcBNwrAtGL+eAl6/oMLRwyDC07/QADTC0cMgwtO/0L+vACLABMLCv7UvycLFwvzCxwAiwKzCyQJewxrCzcAdwDbCtsLSwDq/W8LVwsvDC8Mcv9rARcMPwyvDEb/kwxTC4gLMwxfALsMjv/A7hsMmwEK/9sLubAq//MLy81zAAMBLwvjCwy/JwsXC/MLHACLArMLJwwED/MMDwBPDBsAWwwnCy8MLwxy/2sBFww/DK8MRv+TDFMLiAszDF8AuwDDCy8MLwxzANsJ7wtPDIsLnv/A7hsMmwEK/9sBFww/DK8MRA07ASwA8wE3DMRb6Auw34hF1DRcY7sM4K8DD4CRywJwIbAWJl3/Cnr+Gv4jCojmov7/Cpb+Pv5HCqb+Uv+7CrL+ZwE3CsC0Yv54CXr+gwtHDIMLTv9AANMLRwyDC07/Qv68AIjA/E0y/jcJ7wtO/0L+vACIAIBbZv43Ce8LTv9C/rwAiwATCwr+1L8nCxcL8wscAIsCswskCXsMaws3AHcA2wrbC0sA6v1vC1cLLwwvDHL/awEXDD8MrwxG/5MMUwuICzMMXwC7DI7/wO4bDJsBCv/bC7mwKv/zC8vNcwADAS8L4wsMvycLFwvzCxwAiwKzCycMBA/zDA8ATwwbAFsMJwsvDC8Mcv9rARcMPwyvDEb/kwxTC4gLMwxfALsAwwsvDC8McwDbCe8LTwyLC57/wO4bDJsBCv/bARcMPwyvDEQNOwEsAPMBNwzEdcMJ7wtO/0L9TENfCe8LTv9ADnwH7");
return await buildMangroveComponents(doc, "undrr", ["horizontal-book-card"]);}