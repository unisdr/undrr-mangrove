from pathlib import Path
import subprocess,json,hashlib,gzip
from urllib.parse import quote

OUT=Path(__file__).parent
ROOT=Path('/Users/khawkins/Documents/git/drupal-base/.ddev/related-repos/undrr-mangrove')
SOURCE=ROOT/'examples/figma-plugin/holistic/assets/semantic-inline'
SESSION='mangrove-generated-ink-d6cea725ad81'
OUT.mkdir(parents=True,exist_ok=True)
def call(*args,stdin=None):
    r=subprocess.run(['agent-browser','--session',SESSION,*args],input=stdin,text=True,capture_output=True)
    with (OUT/'browser.log').open('a') as f:f.write(json.dumps({'args':args,'exit':r.returncode,'stderr':r.stderr})+'\n')
    r.check_returncode()
    return r.stdout
def evaluate(code):return json.loads(call('eval','--stdin',stdin=code))
capture=(SOURCE/'capture.js').read_text()
capture=capture.replace('(async()=>{','(async()=>{const sourceFrame=globalThis.document.querySelector("#storybook-preview-iframe"),document=sourceFrame.contentDocument,sourceWindow=sourceFrame.contentWindow,getComputedStyle=sourceWindow.getComputedStyle.bind(sourceWindow),location=sourceWindow.location,innerWidth=sourceWindow.innerWidth,innerHeight=sourceWindow.innerHeight,performance=sourceWindow.performance;',1)
themes={'undrr':'Global UNDRR Theme','delta':'DELTA Resilience Theme','irp':'IRP Theme','mcr':'MCR2030 Theme','preventionweb':'PreventionWeb Theme'}
cases={}
try:
    call('frame','main')
    call('set','viewport','1600','1500')
    for mode,theme in themes.items():
        for locale,lang in [('english','en'),('arabic','ar'),('japanese','ja')]:
            for kind in ['quotation','list-ordered','list-unordered']:
                url='http://localhost:6121/?path=/story/components-typography--typography-'+kind+'&globals='+quote('theme:'+theme+';locale:'+locale)
                call('open',url)
                call('wait','--fn','Boolean(document.querySelector("#storybook-preview-iframe")?.contentDocument?.querySelector("#storybook-root")?.children.length)')
                for width in [390,1164]:
                    evaluate('(()=>{const f=document.querySelector("#storybook-preview-iframe");for(const k of ["width","min-width","max-width"])f.style.setProperty(k,"'+str(width)+'px","important");return true})()')
                    case=evaluate(capture)
                    assert case['viewport']['width']==width
                    assert case['rootLanguage']['lang']==lang
                    key=f'{mode}-{locale}-{kind}-{width}'
                    case['sourceContext']={'kind':kind,'locale':locale,'viewport':width,'sourceManagerURL':url,'method':'Actual Storybook globals and preview iframe width allocation; source content DOM unchanged. Complete actual accessibility snapshot records generated quote/marker text separately from authored DOM characters.'}
                    (OUT/(key+'-dom.json')).write_text(json.dumps(case,ensure_ascii=False,separators=(',',':'))+'\n')
                    call('frame','#storybook-preview-iframe')
                    snapshot=json.loads(call('snapshot','--json'))
                    assert snapshot.get('success') is True
                    (OUT/(key+'-ax.json')).write_text(json.dumps(snapshot,ensure_ascii=False,separators=(',',':'))+'\n')
                    call('frame','main')
                    cases[key]=case
                    print(key,case['tree'][0]['rect']['height'],flush=True)
    packed=json.dumps({'sourceOnly':True,'cases':cases},ensure_ascii=False,separators=(',',':')).encode()
    with (OUT/'source-footprints.json.gz').open('wb') as f:
        with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=9) as z:z.write(packed)
finally:
    manifest={'sourceOnly':True,'casesCompleted':len(cases),'session':SESSION,'captureSourceSHA256':hashlib.sha256((SOURCE/'capture.js').read_bytes()).hexdigest(),'files':[]}
    for p in sorted(OUT.glob('*')):
        if p.is_file() and p.name!='capture-manifest.json':manifest['files'].append({'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    (OUT/'capture-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    call('close')
