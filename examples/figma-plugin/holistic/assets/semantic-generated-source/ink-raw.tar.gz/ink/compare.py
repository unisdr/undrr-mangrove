from pathlib import Path
import json,gzip,re,hashlib

b=Path(__file__).parent
oldPath=Path('/Users/khawkins/Documents/git/drupal-base/.ddev/related-repos/undrr-mangrove/examples/figma-plugin/holistic/assets/semantic-inline/source-footprints.json.gz')
a=json.loads(gzip.decompress(oldPath.read_bytes()))
def expand(v):
    if isinstance(v,list):return [expand(x) for x in v]
    if isinstance(v,dict):
        if list(v)==['$sourceStyle']:return a['styles'][v['$sourceStyle']]
        return {k:expand(x) for k,x in v.items()}
    return v
old=expand(a['data'])['cases']
records=[]
for f in sorted(b.glob('*-dom.json')):
    key=f.name[:-9]; c=json.loads(f.read_text()); original=old[key]
    for field in ['html','tree','text','viewport','rootLanguage']:
        assert c[field]==original[field],(key,field)
    axPath=b/(key+'-ax.json');ax=json.loads(axPath.read_text());assert ax['success']
    snapshot=ax['data']['snapshot']
    tokens=[(m.group(1),json.loads(m.group(2))) for m in re.finditer(r'^\s*- (StaticText|ListMarker) ("(?:\\.|[^"\\])*")\s*$',snapshot,re.M)]
    if c['sourceContext']['kind']=='quotation':
        authored=[n for n in c['tree'] if n['tag']=='Q'];assert len(authored)==1
        assert len(tokens)==3 and all(k=='StaticText' for k,v in tokens)
        assert tokens[1][1]==authored[0]['text']
        generated={'beforeAX':tokens[0][1],'afterAX':tokens[2][1],
                   'authoredCharacters':authored[0]['text'],
                   'sourceBeforeContent':authored[0]['pseudoBefore']['content'],
                   'sourceAfterContent':authored[0]['pseudoAfter']['content']}
        assert generated['sourceBeforeContent']=='open-quote' and generated['sourceAfterContent']=='close-quote'
    else:
        markers=[v for k,v in tokens if k=='ListMarker'];assert len(markers)==3
        items=[n for n in c['tree'] if n['tag']=='LI'];assert len(items)==3
        generated={'markersAX':markers,'authoredItems':[n['text'] for n in items],
                   'sourceListStyleType':[n['style']['list-style-type'] for n in items],
                   'sourceListStylePosition':[n['style']['list-style-position'] for n in items]}
        assert generated['sourceListStylePosition']==['outside']*3
    records.append({'key':key,'language':c['rootLanguage'],'viewport':c['viewport'],
                    'sourceTreeTextHTMLExact':True,'generated':generated,
                    'domSHA256':hashlib.sha256(f.read_bytes()).hexdigest(),
                    'axSHA256':hashlib.sha256(axPath.read_bytes()).hexdigest()})
assert len(records)==90
result={'sourceOnly':True,'native':False,'cases':90,'all90SourceTreeTextHTMLViewportLanguageExact':True,
        'originalArchiveSHA256':hashlib.sha256(oldPath.read_bytes()).hexdigest(),
        'records':records,'scope':'Actual browser accessibility generated quote and marker characters, separate from unchanged authored DOM copy and complete recorded source flow. AX order is recorded verbatim, not asserted visual order or native glyph/marker metrics. Pseudo ink bounds, native synthesis/font/raster/edit reflow remain open.'}
(b/'generated-ink-source-proof.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'cases':90,'allSourceFieldsExact':True,'generatedQuoteCases':30,'generatedListCases':60,'nativeAccepted':False}))
