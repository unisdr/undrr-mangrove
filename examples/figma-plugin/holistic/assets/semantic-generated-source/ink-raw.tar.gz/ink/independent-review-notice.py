from pathlib import Path
import json,gzip,hashlib,re,itertools
b=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((b/'final-provenance.json').read_text())
assert len(f['files'])==188 and len({x['path'] for x in f['files']})==188
for x in f['files']:
 p=b/x['path'];assert p.stat().st_size==x['bytes'] and sha(p)==x['sha256'],x['path']
assert 'final-provenance.json' not in {x['path'] for x in f['files']}
expected={'-'.join(map(str,t)) for t in itertools.product(['undrr','delta','irp','mcr','preventionweb'],['english','arabic','japanese'],['quotation','list-ordered','list-unordered'],[390,1164])}
assert {p.name[:-9] for p in b.glob('*-dom.json')}==expected
assert {p.name[:-8] for p in b.glob('*-ax.json')}==expected
root=Path('/Users/khawkins/Documents/git/drupal-base/.ddev/related-repos/undrr-mangrove/examples/figma-plugin/holistic/assets/semantic-inline')
a=json.loads(gzip.decompress((root/'source-footprints.json.gz').read_bytes()))
def expand(v):
 if isinstance(v,list):return list(map(expand,v))
 if isinstance(v,dict):
  if set(v)=={'$sourceStyle'}:return expand(a['styles'][v['$sourceStyle']])
  return {k:expand(x) for k,x in v.items()}
 return v
old=expand(a['data'])['cases']
packed=json.loads(gzip.decompress((b/'source-footprints.json.gz').read_bytes()))
assert set(packed['cases'])==expected
proof=json.loads((b/'generated-ink-source-proof.json').read_text());records={r['key']:r for r in proof['records']};assert set(records)==expected and len(proof['records'])==90
for key in sorted(expected):
 dom=json.loads((b/(key+'-dom.json')).read_text());assert packed['cases'][key]==dom
 for field in ['html','tree','text','viewport','rootLanguage']:assert old[key][field]==dom[field],(key,field)
 ax=json.loads((b/(key+'-ax.json')).read_text());assert ax['success'] is True
 tokens=[(m.group(1),json.loads(m.group(2))) for m in re.finditer(r'^\s*- (StaticText|ListMarker) ("(?:\\.|[^"\\])*")\s*$',ax['data']['snapshot'],re.M)]
 r=records[key];g=r['generated']
 assert r['domSHA256']==sha(b/(key+'-dom.json')) and r['axSHA256']==sha(b/(key+'-ax.json'))
 assert r['language']==dom['rootLanguage'] and r['viewport']==dom['viewport']
 if '-quotation-' in key:
  q=[n for n in dom['tree'] if n['tag']=='Q'];assert len(q)==1 and len(tokens)==3 and all(t[0]=='StaticText' for t in tokens)
  assert [g['beforeAX'],g['authoredCharacters'],g['afterAX']]==[t[1] for t in tokens]
  assert g['authoredCharacters']==q[0]['text'] and g['sourceBeforeContent']==q[0]['pseudoBefore']['content']=='open-quote' and g['sourceAfterContent']==q[0]['pseudoAfter']['content']=='close-quote'
 else:
  items=[n for n in dom['tree'] if n['tag']=='LI'];assert len(items)==3
  assert g['markersAX']==[v for k,v in tokens if k=='ListMarker'] and len(g['markersAX'])==3
  assert g['authoredItems']==[n['text'] for n in items]
  assert g['sourceListStyleType']==[n['style']['list-style-type'] for n in items]
  assert g['sourceListStylePosition']==[n['style']['list-style-position'] for n in items]==['outside']*3
m=json.loads((b/'capture-manifest.json').read_text());oldpins={x['name']:x for x in m['files']}
assert (b/'capture-manifest.json').read_bytes()==(b/'capture-manifest-pre-close-preserved.json').read_bytes()
assert sha(b/'run-used-for-capture.py')==oldpins['run.py']['sha256']
assert oldpins['browser.log']['sha256']!=sha(b/'browser.log')
assert m['captureSourceSHA256']==sha(root/'capture.js')
used=(b/'run-used-for-capture.py').read_text();future=(b/'run.py').read_text()
assert future.rstrip()==used.replace('finally:\n    manifest=',"finally:\n    call('close')\n    manifest=").rsplit("    call('close')",1)[0].rstrip()
assert proof['sourceOnly'] is True and proof['native'] is False
result={'accepted':True,'scope':'Exact recorded DOM/html/tree/CSS/text rectangles/viewport/language and verbatim actual AX generated ink order only. No visual glyph position/native marker/font/raster, recipe completion or publication acceptance.','rawCases':90,'quoteCases':30,'listCases':60,'finalPinsVerified':188,'originalArchiveSHA256':sha(root/'source-footprints.json.gz'),'finalProvenanceSHA256':sha(b/'final-provenance.json'),'preservedHistoricalBrowserLogMismatch':True,'futureDriverOnlyCloseOrderingChanged':True,'losslessRawGzipEquality':True,'sourceCaptureUnchanged':True}
(b/'independent-review-notice-verdict.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
