(async()=>{
const f=document.querySelector('#storybook-preview-iframe'),d=f.contentDocument,w=f.contentWindow;
await d.fonts.ready;
const root=d.querySelector('#storybook-root'),css=(n,p)=>{const s=w.getComputedStyle(n,p);return Object.fromEntries([...s].map(k=>[k,s.getPropertyValue(k)]));},rects=n=>[...n.getClientRects()].map(r=>r.toJSON());
const range=d.createRange(),owners=[...root.querySelectorAll('q,li')];
const records=[];
for(const owner of owners){
 const style=css(owner),pseudo=css(owner,owner.tagName==='Q'?'::before':'::marker');
 range.selectNodeContents(owner);const authoredWhole=rects(range),segments=[];
 const walk=d.createTreeWalker(owner,w.NodeFilter.SHOW_TEXT);let n,offset=0;
 while(n=walk.nextNode()){
  const characters=[];let i=0;
  for(const ch of n.data){range.setStart(n,i);range.setEnd(n,i+ch.length);characters.push({start:offset+i,end:offset+i+ch.length,characters:ch,rects:rects(range)});i+=ch.length;}
  range.selectNodeContents(n);segments.push({start:offset,end:offset+n.length,characters:n.data,parentTag:n.parentElement.tagName,style:css(n.parentElement),rects:rects(range),characterRects:characters});offset+=n.length;
 }
 const tokens=globalThis.__diagnosticAXTokens;
 const generated=owner.tagName==='Q'?[tokens.beforeAX,tokens.afterAX]:[tokens.markersAX[records.length]];
 const measurements=[];
 for(let ti=0;ti<generated.length;ti++){
  const ps=css(owner,owner.tagName==='Q'?(ti?'::after':'::before'):'::marker');
  const probe=d.createElement('span');probe.textContent=generated[ti];probe.setAttribute('data-mangrove-detached-measurement','true');
  for(const k of ['font-family','font-size','font-weight','font-style','font-stretch','font-variant','font-feature-settings','font-variation-settings','letter-spacing','word-spacing','line-height','text-transform','direction','writing-mode'])probe.style.setProperty(k,ps[k]||style[k]);
  probe.style.cssText+=';position:absolute;left:-10000px;top:0;display:inline-block;white-space:pre;visibility:hidden;padding:0;margin:0;border:0;';
  d.body.appendChild(probe);const probeRect=probe.getBoundingClientRect().toJSON();
  const canvas=d.createElement('canvas'),ctx=canvas.getContext('2d');ctx.font=[ps['font-style'],ps['font-weight'],ps['font-size'],ps['font-family']].join(' ');ctx.direction=ps.direction;
  if('letterSpacing' in ctx)ctx.letterSpacing=ps['letter-spacing'];if('wordSpacing' in ctx)ctx.wordSpacing=ps['word-spacing'];
  const m=ctx.measureText(generated[ti]);const metrics=Object.fromEntries(['width','actualBoundingBoxLeft','actualBoundingBoxRight','actualBoundingBoxAscent','actualBoundingBoxDescent','fontBoundingBoxAscent','fontBoundingBoxDescent','emHeightAscent','emHeightDescent'].filter(k=>typeof m[k]==='number').map(k=>[k,m[k]]));
  measurements.push({token:generated[ti],pseudoStyle:ps,detachedProbeLineBox:probeRect,canvasFont:ctx.font,canvasDirection:ctx.direction,canvasMetrics:metrics,scope:'Detached token capacity/ink metrics only, not original generated pseudo placement or font-byte equivalence.'});probe.remove();
 }
 records.push({tag:owner.tagName,characters:owner.textContent,ownerClientRects:rects(owner),ownerBoundingRect:owner.getBoundingClientRect().toJSON(),authoredRangeClientRects:authoredWhole,style,pseudoBefore:css(owner,'::before'),pseudoAfter:css(owner,'::after'),pseudoMarker:css(owner,'::marker'),segments,generatedTokenMeasurements:measurements});
}
return {sourceOnly:true,native:false,records,apiLimits:['Pseudo-elements and ::marker have no DOM Node for Range or Element.getClientRects in this documented DOM path.','Q owning client rect union and authored Range rects do not determine generated glyph ink bounds or visual bidi placement.','Detached line boxes and Canvas TextMetrics are separate capacity observations, not original pseudo/marker coordinates.'],fonts:[...d.fonts].filter(x=>x.status==='loaded').map(x=>({family:x.family,weight:x.weight,style:x.style})),viewport:{width:w.innerWidth,height:w.innerHeight},rootLanguage:{lang:d.documentElement.lang,dir:d.documentElement.dir}};
})()
