from pathlib import Path
import subprocess,json,hashlib,gzip
from urllib.parse import quote

OUT=Path(__file__).parent
ROOT=Path('/Users/khawkins/Documents/git/drupal-base/.ddev/related-repos/undrr-mangrove')
SOURCE=ROOT/'examples/figma-plugin/holistic/assets/semantic-inline'
SESSION='mangrove-generated-geometry-28559e52c1d4'
OUT.mkdir(parents=True,exist_ok=True)
def call(*args,stdin=None):
    r=subprocess.run(['agent-browser','--session',SESSION,*args],input=stdin,text=True,capture_output=True)
    with (OUT/'browser.log').open('a') as f:f.write(json.dumps({'args':args,'exit':r.returncode,'stderr':r.stderr})+'\n')
    r.check_returncode()
    return r.stdout
def evaluate(code):return json.loads(call('eval','--stdin',stdin=code))
capture=(SOURCE/'capture.js').read_text()
capture=capture.replace('(async()=>{','(async()=>{const sourceFrame=globalThis.document.querySelector("#storybook-preview-iframe"),document=sourceFrame.contentDocument,sourceWindow=sourceFrame.contentWindow,getComputedStyle=sourceWindow.getComputedStyle.bind(sourceWindow),location=sourceWindow.location,innerWidth=sourceWindow.innerWidth,innerHeight=sourceWindow.innerHeight,performance=sourceWindow.performance;',1)
themes={'undrr':'Global UNDRR Theme','delta':'DELTA Resilience Theme','irp':'IRP Theme','mcr':'MCR2030 Theme','preventionweb':'PreventionWeb Theme'}
cases={}
try:
    call('frame','main')
    call('set','viewport','1600','1500')
    for mode,theme in themes.items():
        for locale,lang in [('english','en'),('arabic','ar'),('japanese','ja')]:
            for kind in ['quotation','list-ordered','list-unordered']:
                url='http://localhost:6121/?path=/story/components-typography--typography-'+kind+'&globals='+quote('theme:'+theme+';locale:'+locale)
                call('open',url)
                call('wait','--fn','Boolean(document.querySelector("#storybook-preview-iframe")?.contentDocument?.querySelector("#storybook-root")?.children.length)')
                for width in [390,1164]:
                    evaluate('(()=>{const f=document.querySelector("#storybook-preview-iframe");for(const k of ["width","min-width","max-width"])f.style.setProperty(k,"'+str(width)+'px","important");return true})()')
                    before=evaluate(capture)
                    assert before['viewport']['width']==width and before['rootLanguage']['lang']==lang
                    key=f'{mode}-{locale}-{kind}-{width}'
                    token=json.loads((Path('/tmp/mangrove-semantic-generated-ink-20261006')/'generated-ink-source-proof.json').read_text())
                    generated=next(r['generated'] for r in token['records'] if r['key']==key)
                    evaluate('globalThis.__diagnosticAXTokens='+json.dumps(generated,ensure_ascii=False))
                    geometry=evaluate((OUT/'geometry.js').read_text())
                    after=evaluate(capture)
                    for field in ['html','tree','text','viewport','rootLanguage']:
                        assert before[field]==after[field],(key,field,'source changed')
                    original=json.loads((Path('/tmp/mangrove-semantic-generated-ink-20261006')/(key+'-dom.json')).read_text())
                    for field in ['html','tree','text','viewport','rootLanguage']:
                        assert before[field]==original[field],(key,field,'source drift')
                    case={'key':key,'before':before,'geometry':geometry,'after':after,'allRecordedSourceFieldsExact':True}
                    (OUT/(key+'-diagnostic.json')).write_text(json.dumps(case,ensure_ascii=False,separators=(',',':'))+'\n')
                    cases[key]=case
                    print(key,len(geometry['records']),flush=True)
finally:
    call('close')
    manifest={'sourceOnly':True,'native':False,'casesCompleted':len(cases),'session':SESSION,'captureSourceSHA256':hashlib.sha256((SOURCE/'capture.js').read_bytes()).hexdigest(),'files':[]}
    for p in sorted(OUT.glob('*')):
        if p.is_file() and p.name not in ['capture-manifest.json','run.log']:manifest['files'].append({'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    (OUT/'capture-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
