from pathlib import Path
import json,collections,hashlib
b=Path(__file__).parent;records=[]
for p in sorted(b.glob('*-diagnostic.json')):
 c=json.loads(p.read_text());owners=[]
 for o in c['geometry']['records']:
  authored=collections.Counter(json.dumps(r,sort_keys=True) for r in o['authoredRangeClientRects'])
  owner=collections.Counter(json.dumps(r,sort_keys=True) for r in o['ownerClientRects'])
  residual=[json.loads(r) for r,n in (owner-authored).items() for _ in range(n)]
  characters=[r for s in o['segments'] for x in s['characterRects'] for r in x['rects']]
  owners.append({'tag':o['tag'],'characters':o['characters'],'ownerClientRects':o['ownerClientRects'],'authoredRangeClientRects':o['authoredRangeClientRects'],'ownerRectsNotEqualAuthoredRangeRects':residual,'firstAuthoredCharacterRects':next((x['rects'] for s in o['segments'] for x in s['characterRects'] if x['rects']),[]),'lastAuthoredCharacterRects':next((x['rects'] for s in reversed(o['segments']) for x in reversed(s['characterRects']) if x['rects']),[]),'sourceFont':{k:o['style'][k] for k in ['font-family','font-size','font-weight','font-style','line-height','direction','writing-mode']},'tokenCapacities':[{k:m[k] for k in ['token','detachedProbeLineBox','canvasFont','canvasDirection','canvasMetrics']} for m in o['generatedTokenMeasurements']]})
 records.append({'key':c['key'],'rawSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'recordedSourceBeforeAfterAndAcceptedBaselineExact':c['allRecordedSourceFieldsExact'],'owners':owners})
assert len(records)==90
result={'sourceOnly':True,'native':False,'cases':90,'allRecordedSourceFieldsExact':True,'records':records,'scope':'Actual owner fragments and authored UTF16 Range flow. Extra Q fragments are observed owner boxes, not directly addressed pseudo nodes or glyph ink. Marker DOM geometry unavailable; detached token line-box and Canvas ink capacities do not establish original marker placement. Canvas fallback/synthesis/native face/glyph/raster/bidi/edit-reflow remain open.'}
(b/'geometry-source-proof.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'cases':90,'QExtraFragmentCounts':dict(collections.Counter(len(o['ownerRectsNotEqualAuthoredRangeRects']) for r in records for o in r['owners'] if o['tag']=='Q')),'native':False}))
